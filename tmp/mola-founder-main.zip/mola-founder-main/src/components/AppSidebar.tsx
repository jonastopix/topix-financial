import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useCompanyStatus } from '@/hooks/useCompanyStatus';
import { NavLink } from '@/components/NavLink';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  BarChart3,
  Home,
  Bot,
  TrendingUp,
  Clock,
  ListTodo,
  ShoppingCart,
  Briefcase,
  FileCheck,
  TrendingDown,
  FileText,
  Settings,
  Users,
  HelpCircle,
  BookOpen,
  LifeBuoy,
  LogOut,
  UserCircle,
  Building2,
  DollarSign,
  FolderOpen,
  UserPlus,
  Handshake,
  ClipboardCheck,
  Newspaper,
  Car,
} from 'lucide-react';
import molaLogo from '@/assets/mola-logo.png';
import { cn } from '@/lib/utils';
import { KeyboardShortcutsHint } from '@/components/KeyboardShortcutsHint';
import { useIsMobile } from '@/hooks/use-mobile';

export function AppSidebar() {
  const { user, signOut } = useAuth();
  const { isAdmin, activeRole } = useRole();
  const location = useLocation();
  const navigate = useNavigate();
  const { open } = useSidebar();
  const isMobile = useIsMobile();

  // Fetch founder's company_id for status check
  const { data: founderProfile } = useQuery({
    queryKey: ['founder-profile-sidebar', user?.id],
    queryFn: async () => {
      if (!user || isAdmin) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !isAdmin && !!user,
  });

  // Get company status for founder
  const { data: companyStatus } = useCompanyStatus(founderProfile?.company_id);

  return (
    <Sidebar collapsible="icon" className={cn("transition-all duration-300", open ? "w-64" : "w-14")}>
      <SidebarHeader className="border-b border-border/50 p-4">
        <div className="flex items-center justify-between gap-2">
          <img 
            src={`${molaLogo}?v=1`}
            alt="MOLA" 
            className={cn("h-8 w-auto object-contain transition-opacity", !open && "opacity-0 w-0")}
          />
          <SidebarTrigger />
        </div>
      </SidebarHeader>

      <SidebarContent className="px-2">
        {/* Analytics & Insights - Admin Only */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Analytics & Insights</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/" end activeClassName="bg-primary text-primary-foreground">
                      <Home className="h-4 w-4" />
                      {open && <span>Dashboard</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/insights" activeClassName="bg-primary text-primary-foreground">
                      <Bot className="h-4 w-4" />
                      {open && <span>Insights</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/financial-dashboard" activeClassName="bg-primary text-primary-foreground">
                      <TrendingUp className="h-4 w-4" />
                      {open && <span>Finansiel Dashboard</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/time-analysis" activeClassName="bg-primary text-primary-foreground">
                      <Clock className="h-4 w-4" />
                      {open && <span>Tidsanalyse</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Founder Dashboard - Founder Only */}
        {!isAdmin && activeRole === 'founder' && (
          <SidebarGroup>
            <SidebarGroupLabel>Dashboard</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/" end activeClassName="bg-primary text-primary-foreground">
                      <Home className="h-4 w-4" />
                      {open && <span>Dashboard</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                {companyStatus?.isInDueDiligence && (
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild>
                      <NavLink to="/my-due-diligence" activeClassName="bg-primary text-primary-foreground">
                        <FileCheck className="h-4 w-4" />
                        {open && <span>Due Diligence</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )}
              <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/financial-dashboard" activeClassName="bg-primary text-primary-foreground">
                      <TrendingUp className="h-4 w-4" />
                      {open && <span>Finansiel Dashboard</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                {founderProfile?.company_id && (
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild>
                      <NavLink to={`/company/${founderProfile.company_id}?tab=governance`} activeClassName="bg-primary text-primary-foreground">
                        <ClipboardCheck className="h-4 w-4" />
                        {open && <span>Governance</span>}
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Fund Partner Dashboard - Fund Partner Only */}
        {activeRole === 'fund_partner' && (
          <SidebarGroup>
            <SidebarGroupLabel>Portfolio</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/fund-partner-dashboard" activeClassName="bg-primary text-primary-foreground">
                      <Briefcase className="h-4 w-4" />
                      {open && <span>Portfolio Dashboard</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Portfolio Management - Admin Only */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Portfolio Management</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/portfolio/overview" activeClassName="bg-primary text-primary-foreground">
                      <Briefcase className="h-4 w-4" />
                      {open && <span>Overview</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/portfolio/valuations" activeClassName="bg-primary text-primary-foreground">
                      <TrendingUp className="h-4 w-4" />
                      {open && <span>Valuations</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/portfolio/companies" activeClassName="bg-primary text-primary-foreground">
                      <Building2 className="h-4 w-4" />
                      {open && <span>Companies</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/portfolio/due-diligence" activeClassName="bg-primary text-primary-foreground">
                      <FileCheck className="h-4 w-4" />
                      {open && <span>Due Diligence</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/exits-history" activeClassName="bg-primary text-primary-foreground">
                      <TrendingDown className="h-4 w-4" />
                      {open && <span>Exits Historik</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/group-overview" activeClassName="bg-primary text-primary-foreground">
                      <FolderOpen className="h-4 w-4" />
                      {open && <span>Koncernoverblik</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/portfolio/pr" activeClassName="bg-primary text-primary-foreground">
                      <Newspaper className="h-4 w-4" />
                      {open && <span>PR Overblik</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Opgaver & Workflow */}
        <SidebarGroup>
          <SidebarGroupLabel>Opgaver & Workflow</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/tasks" activeClassName="bg-primary text-primary-foreground">
                    <ListTodo className="h-4 w-4" />
                    {open && <span>Opgaver</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
              {!isAdmin || activeRole === 'founder' ? (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/monthly-report" activeClassName="bg-primary text-primary-foreground">
                      <FileText className="h-4 w-4" />
                      {open && <span>Monthly Report</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ) : null}
              {['owner', 'mola_admin', 'fund_partner'].includes(activeRole) && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/admin/mileage" activeClassName="bg-primary text-primary-foreground">
                      <Car className="h-4 w-4" />
                      {open && <span>Kørselsregnskab</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Community & Netværk */}
        {!isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Community</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/meet-the-founders" activeClassName="bg-primary text-primary-foreground">
                      <Users className="h-4 w-4" />
                      {open && <span>Meet the Founders</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

            {/* E-commerce Tools - All roles */}
            {(
          <SidebarGroup>
            <SidebarGroupLabel>E-commerce Tools</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/ecommerce-tools" activeClassName="bg-primary text-primary-foreground">
                      <ShoppingCart className="h-4 w-4" />
                      {open && <span>ROAS Beregner</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Deals & Indkøb - DEAKTIVERET MIDLERTIDIGT */}
        {false && (
          <SidebarGroup>
            <SidebarGroupLabel>Deals & Indkøb</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/procurement" activeClassName="bg-primary text-primary-foreground">
                      <ShoppingCart className="h-4 w-4" />
                      {open && <span>Indkøb</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Kunder & Relationer - Placeholder for future */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Kunder & Relationer</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton disabled className="opacity-50 cursor-not-allowed">
                    <Building2 className="h-4 w-4" />
                    {open && (
                      <>
                        <span>Advisory Board</span>
                        <Badge variant="secondary" className="ml-auto text-xs">Snart</Badge>
                      </>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton disabled className="opacity-50 cursor-not-allowed">
                    <UserPlus className="h-4 w-4" />
                    {open && (
                      <>
                        <span>Bestyrelsesposter</span>
                        <Badge variant="secondary" className="ml-auto text-xs">Snart</Badge>
                      </>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Fakturering & Økonomi */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Fakturering & Økonomi</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/customers" activeClassName="bg-primary text-primary-foreground">
                      <Users className="h-4 w-4" />
                      {open && <span>Kunder</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/invoices" activeClassName="bg-primary text-primary-foreground">
                      <FileText className="h-4 w-4" />
                      {open && <span>Fakturaer</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/income-reports" activeClassName="bg-primary text-primary-foreground">
                      <DollarSign className="h-4 w-4" />
                      {open && <span>Indkomst Rapporter</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Dokumenter & Filer - Placeholder for future */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Dokumenter & Filer</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton disabled className="opacity-50 cursor-not-allowed">
                    <FolderOpen className="h-4 w-4" />
                    {open && (
                      <>
                        <span>Alle Dokumenter</span>
                        <Badge variant="secondary" className="ml-auto text-xs">Snart</Badge>
                      </>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Administration - Admin Only */}
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Administration</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/admin-settings" activeClassName="bg-primary text-primary-foreground">
                      <Settings className="h-4 w-4" />
                      {open && <span>Admin Indstillinger</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/user-management" activeClassName="bg-primary text-primary-foreground">
                      <Users className="h-4 w-4" />
                      {open && <span>Brugeradministration</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/fund-management" activeClassName="bg-primary text-primary-foreground">
                      <TrendingUp className="h-4 w-4" />
                      {open && <span>Fund Management</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/admin/tool-analytics" activeClassName="bg-primary text-primary-foreground">
                      <BarChart3 className="h-4 w-4" />
                      {open && <span>Tool Analytics</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {/* Hjælp & Support */}
        <SidebarGroup>
          <SidebarGroupLabel>Hjælp & Support</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/network" activeClassName="bg-primary text-primary-foreground">
                    <Handshake className="h-4 w-4" />
                    {open && <span>Netværk</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
              {/* Resource Hub - midlertidigt skjult indtil admin-funktion er klar
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/resources" activeClassName="bg-primary text-primary-foreground">
                    <BookOpen className="h-4 w-4" />
                    {open && <span>Resources</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
              */}
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/support" activeClassName="bg-primary text-primary-foreground">
                    <LifeBuoy className="h-4 w-4" />
                    {open && <span>Support</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-border/50 p-3 space-y-3">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <button
                onClick={() => navigate('/profile')}
                className="w-full flex items-center gap-3"
              >
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-primary/10 text-primary text-xs">
                    {user?.email?.substring(0, 2).toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                {open && (
                  <div className="flex-1 min-w-0 text-left">
                    <p className="text-sm font-medium truncate">
                      {user?.user_metadata?.full_name || 'User'}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {user?.email}
                    </p>
                  </div>
                )}
              </button>
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <button onClick={signOut} className="w-full">
                <LogOut className="h-4 w-4" />
                {open && <span>Log ud</span>}
              </button>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
