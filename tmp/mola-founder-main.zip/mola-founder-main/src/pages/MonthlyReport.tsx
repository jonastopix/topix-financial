import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Layout from '@/components/Layout';
import SmartMonthlyReportForm from '@/components/SmartMonthlyReportForm';
import MonthlyReportCharts from '@/components/MonthlyReportCharts';
import MonthlyReportImportDialog from '@/components/MonthlyReportImportDialog';
import { CompanyPerformanceSummary } from '@/components/CompanyPerformanceSummary';
import { BudgetOverviewCard } from '@/components/BudgetOverviewCard';
import { useCompanyData, useMonthlyReports } from '@/hooks/useCompanyData';
import { Button } from '@/components/ui/button';
import { Upload } from 'lucide-react';

const MonthlyReport = () => {
  const [searchParams] = useSearchParams();
  const companyIdFromUrl = searchParams.get('company');
  
  const { data: company } = useCompanyData();
  const effectiveCompanyId = company?.id || companyIdFromUrl || undefined;
  const { data: reports, refetch } = useMonthlyReports(effectiveCompanyId);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number | null>(null);

  const handleSubmit = () => {
    refetch();
  };

  const handleImportComplete = () => {
    refetch();
  };

  const handleMonthClick = (month: number) => {
    setSelectedMonth(month);
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2">Monthly Reporting</h1>
            <p className="text-muted-foreground">Rapportér dine månedlige tal</p>
          </div>
          <Button onClick={() => setImportDialogOpen(true)}>
            <Upload className="h-4 w-4 mr-2" />
            Importér fra Excel/CSV
          </Button>
        </div>

        {reports && reports.length > 0 && (
          <BudgetOverviewCard 
            reports={reports} 
            currentYear={new Date().getFullYear()}
            onReportClick={handleMonthClick}
          />
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SmartMonthlyReportForm 
            companyId={effectiveCompanyId} 
            onSubmit={handleSubmit}
            initialMonth={selectedMonth}
          />
          <MonthlyReportCharts reports={reports || []} />
        </div>

        {reports && reports.length > 0 && (
          <CompanyPerformanceSummary reports={reports} />
        )}
      </div>

      <MonthlyReportImportDialog
        open={importDialogOpen}
        onOpenChange={setImportDialogOpen}
        companyId={effectiveCompanyId}
        onImportComplete={handleImportComplete}
      />
    </Layout>
  );
};

export default MonthlyReport;
