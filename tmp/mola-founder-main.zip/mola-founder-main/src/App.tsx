import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { RoleProvider } from "@/contexts/RoleContext";
import { KeyboardShortcutProvider } from "@/contexts/KeyboardShortcutContext";
import { OnboardingModal } from "@/components/OnboardingModal";
import ErrorBoundary from "@/components/ErrorBoundary";
import Dashboard from "./pages/Dashboard";
import Company from "./pages/Company";
import PortfolioCompanies from '@/pages/PortfolioCompanies';
import PortfolioValuations from '@/pages/PortfolioValuations';
import DueDiligencePipeline from '@/pages/DueDiligencePipeline';
import DueDiligenceCase from '@/pages/DueDiligenceCase';
import FounderDueDiligence from '@/pages/FounderDueDiligence';
import Auth from "./pages/Auth";
import AcceptInvitation from "./pages/AcceptInvitation";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import MonthlyReport from "./pages/MonthlyReport";
import Insights from "./pages/Insights";
import Shipping from "./pages/Shipping";
import Procurement from "./pages/Procurement";
import ProcurementBenchmarks from "./pages/ProcurementBenchmarks";
import ProcurementAdmin from "./pages/ProcurementAdmin";
import FinancialDashboard from "./pages/FinancialDashboard";
import Resources from "./pages/Resources";
import Support from "./pages/Support";
import Contact from "./pages/Contact";
import Version from "./pages/Version";
import DataProtection from "./pages/DataProtection";
import TermsOfUse from "./pages/TermsOfUse";
import AdminSettings from "./pages/AdminSettings";
import UserManagement from "./pages/UserManagement";
import SupportContactsSettings from "./pages/SupportContactsSettings";
import FooterSettings from "./pages/FooterSettings";
import EmailTemplateManagement from "./pages/EmailTemplateManagement";
import FundManagement from "./pages/FundManagement";
import FundPartnerDashboard from "./pages/FundPartnerDashboard";
import Tasks from "./pages/Tasks";
import ExitsHistory from "./pages/ExitsHistory";
import Portfolio from "./pages/Portfolio";
import TimeAnalysis from "./pages/TimeAnalysis";
import Profile from "./pages/Profile";
import Customers from "./pages/Customers";
import Invoices from "./pages/Invoices";
import IncomeReports from "./pages/IncomeReports";
import InvestorDashboard from "./pages/InvestorDashboard";
import InvestorCompanyView from "./pages/InvestorCompanyView";
import MeetTheFounders from "./pages/MeetTheFounders";
import TokenizedMonthlyReport from "./pages/TokenizedMonthlyReport";
import Network from "./pages/Network";
import TrustedPartnersAdmin from "./pages/TrustedPartnersAdmin";
import GovernanceTemplatesAdmin from "./pages/GovernanceTemplatesAdmin";
import GroupOverview from "./pages/GroupOverview";
import PROverview from "./pages/PROverview";
import EcommerceTools from "./pages/EcommerceTools";
import ToolAnalytics from "./pages/ToolAnalytics";
import MileageAdmin from "./pages/MileageAdmin";
import MileageHistory from "./pages/MileageHistory";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          <div className="text-foreground text-sm">Indlæser...</div>
        </div>
      </div>
    );
  }

  return user ? <>{children}</> : <Navigate to="/auth" replace />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <RoleProvider>
            <KeyboardShortcutProvider>
              <OnboardingModal />
              <ErrorBoundary>
                <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/accept-invitation" element={<AcceptInvitation />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/report/:token" element={<TokenizedMonthlyReport />} />
              <Route
                path="/"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
            <Route
              path="/monthly-report"
              element={
                <ProtectedRoute>
                  <MonthlyReport />
                </ProtectedRoute>
              }
            />
            <Route
              path="/insights"
              element={
                <ProtectedRoute>
                  <Insights />
                </ProtectedRoute>
              }
            />
            <Route
              path="/shipping"
              element={
                <ProtectedRoute>
                  <Shipping />
                </ProtectedRoute>
              }
            />
            <Route
              path="/procurement"
              element={
                <ProtectedRoute>
                  <Procurement />
                </ProtectedRoute>
              }
            />
            <Route
              path="/procurement/benchmarks"
              element={
                <ProtectedRoute>
                  <ProcurementBenchmarks />
                </ProtectedRoute>
              }
            />
            <Route
              path="/procurement/admin"
              element={
                <ProtectedRoute>
                  <ProcurementAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/financial-dashboard"
              element={
                <ProtectedRoute>
                  <FinancialDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/company/:companyId"
              element={
                <ProtectedRoute>
                  <Company />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/due-diligence"
              element={
                <ProtectedRoute>
                  <DueDiligencePipeline />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/due-diligence/:caseId"
              element={
                <ProtectedRoute>
                  <DueDiligenceCase />
                </ProtectedRoute>
              }
            />
            <Route
              path="/my-due-diligence/:caseId?"
              element={
                <ProtectedRoute>
                  <FounderDueDiligence />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/valuations"
              element={
                <ProtectedRoute>
                  <PortfolioValuations />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/companies"
              element={
                <ProtectedRoute>
                  <PortfolioCompanies />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/overview"
              element={
                <ProtectedRoute>
                  <Portfolio />
                </ProtectedRoute>
              }
            />
            <Route
              path="/group-overview"
              element={
                <ProtectedRoute>
                  <GroupOverview />
                </ProtectedRoute>
              }
            />
            <Route
              path="/portfolio/pr"
              element={
                <ProtectedRoute>
                  <PROverview />
                </ProtectedRoute>
              }
            />
            <Route
              path="/resources"
              element={
                <ProtectedRoute>
                  <Resources />
                </ProtectedRoute>
              }
            />
            <Route
              path="/support"
              element={
                <ProtectedRoute>
                  <Support />
                </ProtectedRoute>
              }
            />
            <Route
              path="/contact"
              element={
                <ProtectedRoute>
                  <Contact />
                </ProtectedRoute>
              }
            />
            <Route
              path="/version"
              element={
                <ProtectedRoute>
                  <Version />
                </ProtectedRoute>
              }
            />
            <Route
              path="/databeskyttelse"
              element={
                <ProtectedRoute>
                  <DataProtection />
                </ProtectedRoute>
              }
            />
            <Route
              path="/brugsvilkar"
              element={
                <ProtectedRoute>
                  <TermsOfUse />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin-settings"
              element={
                <ProtectedRoute>
                  <AdminSettings />
                </ProtectedRoute>
              }
            />
            <Route
              path="/user-management"
              element={
                <ProtectedRoute>
                  <UserManagement />
                </ProtectedRoute>
              }
            />
            <Route
              path="/support-contacts-settings"
              element={
                <ProtectedRoute>
                  <SupportContactsSettings />
                </ProtectedRoute>
              }
            />
            <Route
              path="/footer-settings"
              element={
                <ProtectedRoute>
                  <FooterSettings />
                </ProtectedRoute>
              }
            />
            <Route
              path="/email-templates"
              element={
                <ProtectedRoute>
                  <EmailTemplateManagement />
                </ProtectedRoute>
              }
            />
            <Route
              path="/fund-management"
              element={
                <ProtectedRoute>
                  <FundManagement />
                </ProtectedRoute>
              }
            />
            <Route
              path="/fund-partner-dashboard"
              element={
                <ProtectedRoute>
                  <FundPartnerDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/tasks"
              element={
                <ProtectedRoute>
                  <Tasks />
                </ProtectedRoute>
              }
            />
            <Route
              path="/time-analysis"
              element={
                <ProtectedRoute>
                  <TimeAnalysis />
                </ProtectedRoute>
              }
            />
            <Route
              path="/exits-history"
              element={
                <ProtectedRoute>
                  <ExitsHistory />
                </ProtectedRoute>
              }
            />
            <Route
              path="/customers"
              element={
                <ProtectedRoute>
                  <Customers />
                </ProtectedRoute>
              }
            />
            <Route
              path="/invoices"
              element={
                <ProtectedRoute>
                  <Invoices />
                </ProtectedRoute>
              }
            />
            <Route
              path="/income-reports"
              element={
                <ProtectedRoute>
                  <IncomeReports />
                </ProtectedRoute>
              }
            />
            <Route
              path="/investor-dashboard"
              element={
                <ProtectedRoute>
                  <InvestorDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/investor/company/:id"
              element={
                <ProtectedRoute>
                  <InvestorCompanyView />
                </ProtectedRoute>
              }
            />
            <Route
              path="/profile"
              element={
                <ProtectedRoute>
                  <Profile />
                </ProtectedRoute>
              }
            />
            <Route
              path="/meet-the-founders"
              element={
                <ProtectedRoute>
                  <MeetTheFounders />
                </ProtectedRoute>
              }
            />
            <Route
              path="/network"
              element={
                <ProtectedRoute>
                  <Network />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/trusted-partners"
              element={
                <ProtectedRoute>
                  <TrustedPartnersAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/governance-templates"
              element={
                <ProtectedRoute>
                  <GovernanceTemplatesAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/ecommerce-tools"
              element={
                <ProtectedRoute>
                  <EcommerceTools />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/tool-analytics"
              element={
                <ProtectedRoute>
                  <ToolAnalytics />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/mileage"
              element={
                <ProtectedRoute>
                  <MileageAdmin />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/mileage/history"
              element={
                <ProtectedRoute>
                  <MileageHistory />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<NotFound />} />
                </Routes>
              </ErrorBoundary>
            </KeyboardShortcutProvider>
          </RoleProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
