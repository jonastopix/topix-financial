-- Add budget and marketing columns to monthly_reports
ALTER TABLE monthly_reports
ADD COLUMN IF NOT EXISTS marketing_cost_dkk numeric,
ADD COLUMN IF NOT EXISTS budget_revenue_dkk numeric,
ADD COLUMN IF NOT EXISTS budget_ebitda_dkk numeric,
ADD COLUMN IF NOT EXISTS orders integer;

-- Seed demo data for 9 months (Jan-Sep 2025) for a demo company
-- Get a demo company ID (using the first active company)
DO $$
DECLARE
  demo_company_id uuid;
BEGIN
  SELECT id INTO demo_company_id FROM companies WHERE is_active = true LIMIT 1;
  
  IF demo_company_id IS NOT NULL THEN
    -- Insert 9 months of data with realistic numbers and budgets
    INSERT INTO monthly_reports (
      company_id, period_year, period_month,
      revenue_dkk, ebitda_dkk, cash_dkk, new_customers, orders,
      marketing_cost_dkk, budget_revenue_dkk, budget_ebitda_dkk,
      note
    ) VALUES
    -- January 2025
    (demo_company_id, 2025, 1, 850000, 127500, 1200000, 45, 320, 85000, 800000, 120000, 'Demo YTD data'),
    -- February 2025
    (demo_company_id, 2025, 2, 920000, 138000, 1280000, 52, 365, 92000, 880000, 132000, 'Demo YTD data'),
    -- March 2025
    (demo_company_id, 2025, 3, 1050000, 157500, 1420000, 63, 412, 105000, 1000000, 150000, 'Demo YTD data'),
    -- April 2025
    (demo_company_id, 2025, 4, 980000, 147000, 1510000, 58, 385, 98000, 950000, 142500, 'Demo YTD data'),
    -- May 2025
    (demo_company_id, 2025, 5, 1120000, 168000, 1640000, 67, 445, 112000, 1080000, 162000, 'Demo YTD data'),
    -- June 2025
    (demo_company_id, 2025, 6, 1200000, 180000, 1780000, 72, 478, 120000, 1150000, 172500, 'Demo YTD data'),
    -- July 2025
    (demo_company_id, 2025, 7, 890000, 133500, 1850000, 48, 348, 89000, 900000, 135000, 'Demo YTD data'),
    -- August 2025
    (demo_company_id, 2025, 8, 1050000, 157500, 1970000, 61, 415, 105000, 1000000, 150000, 'Demo YTD data'),
    -- September 2025
    (demo_company_id, 2025, 9, 1140000, 171000, 2100000, 69, 452, 114000, 1100000, 165000, 'Demo YTD data')
    ON CONFLICT DO NOTHING;
  END IF;
END $$;