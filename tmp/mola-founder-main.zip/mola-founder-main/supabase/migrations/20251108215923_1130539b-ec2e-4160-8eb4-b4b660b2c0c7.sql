-- Create fund_ownership table to track who owns shares in each fund
CREATE TABLE public.fund_ownership (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  fund_id UUID NOT NULL REFERENCES public.funds(id) ON DELETE CASCADE,
  owner_name TEXT NOT NULL,
  owner_type TEXT NOT NULL CHECK (owner_type IN ('person', 'company', 'fund')),
  ownership_pct NUMERIC NOT NULL CHECK (ownership_pct > 0 AND ownership_pct <= 100),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create personal_fund_stakes to track user's personal ownership in entities
CREATE TABLE public.personal_fund_stakes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  entity_name TEXT NOT NULL,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('company', 'fund')),
  ownership_pct NUMERIC NOT NULL CHECK (ownership_pct > 0 AND ownership_pct <= 100),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, entity_name, entity_type)
);

-- Enable RLS
ALTER TABLE public.fund_ownership ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.personal_fund_stakes ENABLE ROW LEVEL SECURITY;

-- RLS Policies for fund_ownership
CREATE POLICY "MOLA admins can manage fund ownership"
ON public.fund_ownership FOR ALL
USING (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "MOLA admins can view fund ownership"
ON public.fund_ownership FOR SELECT
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- RLS Policies for personal_fund_stakes
CREATE POLICY "Users can view own stakes"
ON public.personal_fund_stakes FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "MOLA admins can manage all stakes"
ON public.personal_fund_stakes FOR ALL
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- Add fund_partner role to app_role enum if not exists
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_enum 
    WHERE enumlabel = 'fund_partner' 
    AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'app_role')
  ) THEN
    ALTER TYPE public.app_role ADD VALUE 'fund_partner';
  END IF;
END $$;

-- Add fund_id to profiles for fund partners
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS fund_id UUID REFERENCES public.funds(id);

-- Create function to get user's fund
CREATE OR REPLACE FUNCTION public.get_user_fund_id(_user_id uuid)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT fund_id FROM public.profiles WHERE id = _user_id
$$;