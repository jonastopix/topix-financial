-- Add columns to profiles for user management
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS last_sign_in_at timestamptz;

-- Create activity log table for audit trail (only if not exists)
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT FROM pg_tables WHERE schemaname = 'public' AND tablename = 'user_activity_log') THEN
    CREATE TABLE public.user_activity_log (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
      admin_user_id uuid REFERENCES auth.users(id),
      action text NOT NULL,
      details jsonb,
      created_at timestamptz DEFAULT now()
    );
    
    ALTER TABLE public.user_activity_log ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Drop existing policies if they exist and recreate
DROP POLICY IF EXISTS "Admins can view activity logs" ON user_activity_log;
DROP POLICY IF EXISTS "Admins can insert activity logs" ON user_activity_log;
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can manage user roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can insert user roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can update user roles" ON user_roles;
DROP POLICY IF EXISTS "Admins can delete user roles" ON user_roles;

-- Activity log policies
CREATE POLICY "Admins can view activity logs"
ON user_activity_log FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "Admins can insert activity logs"
ON user_activity_log FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

-- Profiles policies
CREATE POLICY "Admins can view all profiles"
ON profiles FOR SELECT
TO authenticated
USING (
  auth.uid() = id OR 
  public.has_role(auth.uid(), 'mola_admin')
);

CREATE POLICY "Admins can update all profiles"
ON profiles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'))
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

-- User roles policies
CREATE POLICY "Admins can insert user roles"
ON user_roles FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "Admins can update user roles"
ON user_roles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'))
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "Admins can delete user roles"
ON user_roles FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'));