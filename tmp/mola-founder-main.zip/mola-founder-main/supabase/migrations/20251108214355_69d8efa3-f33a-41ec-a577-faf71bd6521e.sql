-- Add budget_marketing_cost_dkk field to monthly_reports table
ALTER TABLE public.monthly_reports 
ADD COLUMN budget_marketing_cost_dkk numeric;