-- Create company_prices table
CREATE TABLE IF NOT EXISTS public.company_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  subcategory TEXT NOT NULL,
  value_numeric NUMERIC NOT NULL CHECK (value_numeric > 0),
  unit TEXT NOT NULL,
  sample_volume_monthly NUMERIC,
  updated_at TIMESTAMPTZ DEFAULT now(),
  archived BOOLEAN DEFAULT false
);

-- Create partner_deals table
CREATE TABLE IF NOT EXISTS public.partner_deals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  vendor TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  mola_price NUMERIC NOT NULL CHECK (mola_price >= 0),
  list_price NUMERIC NOT NULL CHECK (list_price >= 0),
  unit TEXT NOT NULL,
  terms TEXT NOT NULL,
  contact_email TEXT NOT NULL,
  activation_url TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  archived BOOLEAN DEFAULT false
);

-- Create procurement_adoptions table
CREATE TABLE IF NOT EXISTS public.procurement_adoptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  partner_deal_id UUID NOT NULL REFERENCES public.partner_deals(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('pending', 'active', 'cancelled', 'completed')),
  notes TEXT,
  activated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  archived BOOLEAN DEFAULT false
);

-- Create procurement_audit_log table
CREATE TABLE IF NOT EXISTS public.procurement_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  entity TEXT NOT NULL,
  entity_id UUID NOT NULL,
  action TEXT NOT NULL,
  diff JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.company_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partner_deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.procurement_adoptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.procurement_audit_log ENABLE ROW LEVEL SECURITY;

-- RLS Policies for company_prices
CREATE POLICY "Founders can view own company prices"
  ON public.company_prices
  FOR SELECT
  USING (company_id IN (
    SELECT company_id FROM public.profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Founders can insert own company prices"
  ON public.company_prices
  FOR INSERT
  WITH CHECK (company_id IN (
    SELECT company_id FROM public.profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Founders can update own company prices"
  ON public.company_prices
  FOR UPDATE
  USING (company_id IN (
    SELECT company_id FROM public.profiles WHERE id = auth.uid()
  ));

CREATE POLICY "MOLA admins can manage all company prices"
  ON public.company_prices
  FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for partner_deals
CREATE POLICY "Authenticated users can view active partner deals"
  ON public.partner_deals
  FOR SELECT
  USING (is_active = true AND archived = false);

CREATE POLICY "MOLA admins can manage partner deals"
  ON public.partner_deals
  FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for procurement_adoptions
CREATE POLICY "Founders can view own company adoptions"
  ON public.procurement_adoptions
  FOR SELECT
  USING (company_id IN (
    SELECT company_id FROM public.profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Founders can insert own company adoptions"
  ON public.procurement_adoptions
  FOR INSERT
  WITH CHECK (company_id IN (
    SELECT company_id FROM public.profiles WHERE id = auth.uid()
  ));

CREATE POLICY "MOLA admins can manage all adoptions"
  ON public.procurement_adoptions
  FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for procurement_audit_log
CREATE POLICY "MOLA admins can view audit log"
  ON public.procurement_audit_log
  FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can insert audit log"
  ON public.procurement_audit_log
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'mola_admin'));

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_company_prices_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_company_prices_updated_at_trigger
  BEFORE UPDATE ON public.company_prices
  FOR EACH ROW
  EXECUTE FUNCTION update_company_prices_updated_at();

-- Seed data: 5 partner deals
INSERT INTO public.partner_deals (category, vendor, plan_name, mola_price, list_price, unit, terms, contact_email, activation_url, is_active) VALUES
  ('shipping', 'GLS', 'MOLA Partner Pakke', 42, 49, 'kr/pakke', 'Faste priser, ingen minimumsvolumen. 30 dages opsigelse.', 'mola@gls.dk', 'https://gls.dk/mola-signup', true),
  ('shipping', 'PostNord', 'MOLA Express', 38, 45, 'kr/pakke', 'Volumebaseret rabat starter ved 500 pakker/md. 90 dages binding.', 'partnere@postnord.dk', 'https://postnord.dk/mola', true),
  ('payment', 'Quickpay', 'MOLA Growth', 0.85, 1.2, '% af transaction', 'Ingen opstartsgebyr. Månedlig abonnement 199 kr. Ingen binding.', 'sales@quickpay.net', 'https://quickpay.net/mola-deal', true),
  ('payment', 'Stripe', 'MOLA Standard', 1.1, 1.4, '% af transaction', 'Pay-as-you-go. Ingen skjulte gebyrer. Cancel når som helst.', 'mola@stripe.com', null, true),
  ('saas', 'Workfeed', 'MOLA Team', 89, 129, 'kr/bruger/md', '3 måneders gratis. Derefter fast pris per aktiv bruger. Årlig betaling 10% ekstra rabat.', 'hello@workfeed.dk', 'https://workfeed.dk/mola', true);

-- Seed data: 10 company prices for 3 demo companies
-- Get demo company IDs (assuming Vinhuset, Bland Selv Frø, Filternew exist)
DO $$
DECLARE
  company1_id UUID;
  company2_id UUID;
  company3_id UUID;
BEGIN
  SELECT id INTO company1_id FROM public.companies WHERE name = 'Vinhuset' LIMIT 1;
  SELECT id INTO company2_id FROM public.companies WHERE name = 'Bland Selv Frø' LIMIT 1;
  SELECT id INTO company3_id FROM public.companies WHERE name = 'Filternew' LIMIT 1;
  
  IF company1_id IS NOT NULL THEN
    INSERT INTO public.company_prices (company_id, category, subcategory, value_numeric, unit, sample_volume_monthly) VALUES
      (company1_id, 'shipping', 'home_delivery', 49, 'kr/pakke', 450),
      (company1_id, 'shipping', 'pickup_point', 39, 'kr/pakke', 120),
      (company1_id, 'payment', 'card_fee', 1.15, '% af transaction', 2500);
  END IF;
  
  IF company2_id IS NOT NULL THEN
    INSERT INTO public.company_prices (company_id, category, subcategory, value_numeric, unit, sample_volume_monthly) VALUES
      (company2_id, 'shipping', 'home_delivery', 45, 'kr/pakke', 890),
      (company2_id, 'payment', 'card_fee', 1.3, '% af transaction', 3200),
      (company2_id, 'saas', 'workfeed', 129, 'kr/bruger/md', 8);
  END IF;
  
  IF company3_id IS NOT NULL THEN
    INSERT INTO public.company_prices (company_id, category, subcategory, value_numeric, unit, sample_volume_monthly) VALUES
      (company3_id, 'shipping', 'home_delivery', 52, 'kr/pakke', 320),
      (company3_id, 'shipping', 'pickup_point', 42, 'kr/pakke', 80),
      (company3_id, 'payment', 'mobilepay', 0.95, '% af transaction', 1800),
      (company3_id, 'energy', 'electricity', 2.45, 'kr/kWh', 1500);
  END IF;
END $$;

-- Seed data: 3 procurement adoptions
DO $$
DECLARE
  company1_id UUID;
  deal1_id UUID;
  deal2_id UUID;
BEGIN
  SELECT id INTO company1_id FROM public.companies WHERE name = 'Vinhuset' LIMIT 1;
  SELECT id INTO deal1_id FROM public.partner_deals WHERE vendor = 'GLS' LIMIT 1;
  SELECT id INTO deal2_id FROM public.partner_deals WHERE vendor = 'Quickpay' LIMIT 1;
  
  IF company1_id IS NOT NULL AND deal1_id IS NOT NULL THEN
    INSERT INTO public.procurement_adoptions (company_id, partner_deal_id, status, notes, activated_at) VALUES
      (company1_id, deal1_id, 'active', 'Skiftet fra PostNord - sparer ca. 3.500 kr/md', now() - interval '45 days');
  END IF;
  
  IF company1_id IS NOT NULL AND deal2_id IS NOT NULL THEN
    INSERT INTO public.procurement_adoptions (company_id, partner_deal_id, status, notes) VALUES
      (company1_id, deal2_id, 'pending', 'Afventer kontrakt signering');
  END IF;
END $$;