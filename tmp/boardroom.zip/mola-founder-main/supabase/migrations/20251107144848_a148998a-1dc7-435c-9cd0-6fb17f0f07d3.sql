-- Create announcements table for dynamic messages
CREATE TABLE public.announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL CHECK (type IN ('manual', 'auto')),
  priority TEXT NOT NULL CHECK (priority IN ('success', 'warning', 'error', 'info')),
  message TEXT NOT NULL,
  link_url TEXT,
  is_active BOOLEAN DEFAULT true,
  company_id UUID REFERENCES public.companies(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  expires_at TIMESTAMPTZ,
  metadata JSONB
);

-- Create indexes for performance
CREATE INDEX idx_announcements_active ON public.announcements(is_active, expires_at);
CREATE INDEX idx_announcements_priority ON public.announcements(priority);
CREATE INDEX idx_announcements_company ON public.announcements(company_id);

-- Enable RLS
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

-- Only MOLA admins can view announcements
CREATE POLICY "MOLA admins can view announcements"
  ON public.announcements
  FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- Only MOLA admins can create announcements
CREATE POLICY "MOLA admins can insert announcements"
  ON public.announcements
  FOR INSERT
  WITH CHECK (has_role(auth.uid(), 'mola_admin'::app_role));

-- Only MOLA admins can update announcements
CREATE POLICY "MOLA admins can update announcements"
  ON public.announcements
  FOR UPDATE
  USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- Only MOLA admins can delete announcements
CREATE POLICY "MOLA admins can delete announcements"
  ON public.announcements
  FOR DELETE
  USING (has_role(auth.uid(), 'mola_admin'::app_role));