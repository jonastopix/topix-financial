-- Add columns to profiles for user management
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS is_active boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS last_sign_in_at timestamptz;

-- Create activity log table for audit trail
CREATE TABLE IF NOT EXISTS user_activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  admin_user_id uuid REFERENCES auth.users(id),
  action text NOT NULL,
  details jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on activity log
ALTER TABLE user_activity_log ENABLE ROW LEVEL SECURITY;

-- Policy: Only admins can view activity logs
CREATE POLICY "Admins can view activity logs"
ON user_activity_log FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'));

-- Policy: Only admins can insert activity logs
CREATE POLICY "Admins can insert activity logs"
ON user_activity_log FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

-- Update profiles RLS: Admins can view all profiles
DROP POLICY IF EXISTS "Admins can view all profiles" ON profiles;
CREATE POLICY "Admins can view all profiles"
ON profiles FOR SELECT
TO authenticated
USING (
  auth.uid() = id OR 
  public.has_role(auth.uid(), 'mola_admin')
);

-- Admins can update all profiles
CREATE POLICY "Admins can update all profiles"
ON profiles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'))
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

-- Update user_roles RLS: Admins can manage all roles
DROP POLICY IF EXISTS "Admins can manage user roles" ON user_roles;
CREATE POLICY "Admins can insert user roles"
ON user_roles FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "Admins can update user roles"
ON user_roles FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'))
WITH CHECK (public.has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "Admins can delete user roles"
ON user_roles FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'mola_admin'));