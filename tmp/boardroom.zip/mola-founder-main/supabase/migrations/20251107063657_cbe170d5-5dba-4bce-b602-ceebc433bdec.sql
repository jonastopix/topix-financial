-- Add industry column to companies table
ALTER TABLE public.companies ADD COLUMN industry TEXT DEFAULT 'other';

-- Update existing companies with industry
UPDATE public.companies SET industry = 'ecommerce' WHERE id IN (
  '11111111-1111-1111-1111-111111111111',
  '22222222-2222-2222-2222-222222222222',
  '33333333-3333-3333-3333-333333333333'
);