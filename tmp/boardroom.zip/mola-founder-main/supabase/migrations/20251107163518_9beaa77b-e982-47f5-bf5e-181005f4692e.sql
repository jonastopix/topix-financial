-- Enable RLS on all due diligence tables to fix security warnings
ALTER TABLE due_diligence_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE dd_checklist_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE dd_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE dd_checklist_templates ENABLE ROW LEVEL SECURITY;