-- Allow founders to view their own company's due diligence case
CREATE POLICY "Founders can view own company DD case"
ON due_diligence_cases FOR SELECT
TO authenticated
USING (
  company_id IN (
    SELECT company_id FROM profiles WHERE id = auth.uid()
  )
);

-- Allow founders to view checklist progress for their company's case
CREATE POLICY "Founders can view own DD progress"
ON dd_checklist_progress FOR SELECT
TO authenticated
USING (
  case_id IN (
    SELECT id FROM due_diligence_cases 
    WHERE company_id IN (
      SELECT company_id FROM profiles WHERE id = auth.uid()
    )
  )
);

-- Allow founders to view documents for their company's case
CREATE POLICY "Founders can view own DD documents"
ON dd_documents FOR SELECT
TO authenticated
USING (
  case_id IN (
    SELECT id FROM due_diligence_cases 
    WHERE company_id IN (
      SELECT company_id FROM profiles WHERE id = auth.uid()
    )
  )
);

-- Allow all authenticated users to view checklist templates
CREATE POLICY "Authenticated users can view checklist templates"
ON dd_checklist_templates FOR SELECT
TO authenticated
USING (true);