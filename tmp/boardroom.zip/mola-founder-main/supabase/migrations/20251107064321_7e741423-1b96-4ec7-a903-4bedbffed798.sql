-- Create cleanup function for demo data
CREATE OR REPLACE FUNCTION public.cleanup_demo_data()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete demo monthly reports
  DELETE FROM monthly_reports WHERE note ILIKE '%Demo-data%';
  
  -- Delete demo NPS responses
  DELETE FROM nps_responses WHERE comment ILIKE '%Demo feedback%';
  
  -- Delete demo shipping prices
  DELETE FROM shipping_prices WHERE home_delivery_dkk IN (45, 49, 55);
  
  -- Delete demo badges
  DELETE FROM badges WHERE company_id IN (
    SELECT id FROM companies 
    WHERE name IN ('Vinhuset', 'Bland Selv Frø', 'Filternew')
  );
  
  -- Delete demo companies
  DELETE FROM companies 
  WHERE name IN ('Vinhuset', 'Bland Selv Frø', 'Filternew') 
    AND is_active = true 
    AND invested_amount_dkk < 3000000;
    
  RAISE NOTICE 'Demo data cleaned successfully';
END;
$$;