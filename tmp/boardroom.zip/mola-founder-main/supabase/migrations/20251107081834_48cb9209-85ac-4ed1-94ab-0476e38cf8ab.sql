-- Create company_valuation_settings table
CREATE TABLE company_valuation_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid REFERENCES companies(id) ON DELETE CASCADE NOT NULL UNIQUE,
  revenue_multiple numeric NOT NULL CHECK (revenue_multiple >= 0.1 AND revenue_multiple <= 100),
  ebitda_multiple numeric NOT NULL CHECK (ebitda_multiple >= 0.1 AND ebitda_multiple <= 100),
  active_markets integer NOT NULL CHECK (active_markets >= 1 AND active_markets <= 200),
  valuation_weight_revenue_pct numeric NOT NULL DEFAULT 50 CHECK (valuation_weight_revenue_pct >= 0 AND valuation_weight_revenue_pct <= 100),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add comments
COMMENT ON TABLE company_valuation_settings IS 'Market-based valuation settings (admin-only access)';
COMMENT ON COLUMN company_valuation_settings.revenue_multiple IS 'Revenue multiple for market-based valuation';
COMMENT ON COLUMN company_valuation_settings.ebitda_multiple IS 'EBITDA multiple for market-based valuation';
COMMENT ON COLUMN company_valuation_settings.active_markets IS 'Number of markets company operates in';
COMMENT ON COLUMN company_valuation_settings.valuation_weight_revenue_pct IS 'Weight of revenue in valuation calculation (0-100), EBITDA weight is 100 minus this';

-- Enable RLS
ALTER TABLE company_valuation_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Only admins can access valuation settings
CREATE POLICY "Only admins can view valuation settings"
ON company_valuation_settings
FOR SELECT
USING (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "Only admins can insert valuation settings"
ON company_valuation_settings
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "Only admins can update valuation settings"
ON company_valuation_settings
FOR UPDATE
USING (has_role(auth.uid(), 'mola_admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "Only admins can delete valuation settings"
ON company_valuation_settings
FOR DELETE
USING (has_role(auth.uid(), 'mola_admin'::app_role));