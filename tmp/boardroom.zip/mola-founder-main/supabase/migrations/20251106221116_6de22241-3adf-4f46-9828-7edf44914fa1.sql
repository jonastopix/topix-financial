-- Create enum for user roles
CREATE TYPE public.app_role AS ENUM ('founder', 'mola_admin');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, role)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  company_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Trigger to create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, company_name)
  VALUES (
    new.id,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'company_name'
  );
  
  -- Assign founder role by default
  INSERT INTO public.user_roles (user_id, role)
  VALUES (new.id, 'founder');
  
  RETURN new;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- Create categories table
CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_da TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_da TEXT,
  sort_order INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create documents table
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.categories(id) ON DELETE CASCADE NOT NULL,
  name_da TEXT NOT NULL,
  name_en TEXT NOT NULL,
  description_da TEXT,
  sort_order INTEGER NOT NULL,
  required BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create uploads table
CREATE TABLE public.uploads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  document_id UUID REFERENCES public.documents(id) ON DELETE CASCADE NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  mime_type TEXT NOT NULL,
  uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, document_id)
);

ALTER TABLE public.uploads ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

-- RLS Policies for uploads
CREATE POLICY "Users can view own uploads"
  ON public.uploads FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own uploads"
  ON public.uploads FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own uploads"
  ON public.uploads FOR DELETE
  USING (auth.uid() = user_id);

CREATE POLICY "MOLA admins can view all uploads"
  ON public.uploads FOR SELECT
  USING (public.has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for user_roles
CREATE POLICY "Users can view own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "MOLA admins can view all roles"
  ON public.user_roles FOR SELECT
  USING (public.has_role(auth.uid(), 'mola_admin'));

-- Public read access to categories and documents
CREATE POLICY "Anyone can view categories"
  ON public.categories FOR SELECT
  USING (true);

CREATE POLICY "Anyone can view documents"
  ON public.documents FOR SELECT
  USING (true);

-- Insert initial categories
INSERT INTO public.categories (name_da, name_en, description_da, sort_order) VALUES
  ('Legal & Ownership', 'Legal & Ownership', 'Juridiske dokumenter og ejerforhold', 1),
  ('Financial & Tax', 'Financial & Tax', 'Finansielle dokumenter og skatteinformation', 2),
  ('Commercial & IP', 'Commercial & IP', 'Kommercielle kontrakter og intellektuel ejendom', 3),
  ('People & Operations', 'People & Operations', 'Medarbejdere og drift', 4),
  ('Compliance & Sustainability', 'Compliance & Sustainability', 'Compliance og bæredygtighed', 5);

-- Insert documents for Legal & Ownership
INSERT INTO public.documents (category_id, name_da, name_en, sort_order) 
SELECT id, 'Ejeraftale', 'Shareholder Agreement', 1 FROM public.categories WHERE name_en = 'Legal & Ownership';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Vedtægter / stiftelsesdokument', 'Articles of Association', 2 FROM public.categories WHERE name_en = 'Legal & Ownership';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Ejerbog / kapitaloverblik', 'Cap Table', 3 FROM public.categories WHERE name_en = 'Legal & Ownership';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Aftaler med nærtstående eller tredjemand', 'Related Party Agreements', 4 FROM public.categories WHERE name_en = 'Legal & Ownership';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Eventuelle retssager eller fuldmagter', 'Legal Proceedings & Powers of Attorney', 5 FROM public.categories WHERE name_en = 'Legal & Ownership';

-- Insert documents for Financial & Tax
INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Seneste årsrapport', 'Latest Annual Report', 1 FROM public.categories WHERE name_en = 'Financial & Tax';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'P&L / budget (xlsx/pdf)', 'P&L / Budget', 2 FROM public.categories WHERE name_en = 'Financial & Tax';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Kontoudtog (6 mdr)', 'Bank Statements (6 months)', 3 FROM public.categories WHERE name_en = 'Financial & Tax';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Gælds- og kreditoversigt', 'Debt & Credit Overview', 4 FROM public.categories WHERE name_en = 'Financial & Tax';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'SKAT / moms-kvitteringer', 'Tax & VAT Receipts', 5 FROM public.categories WHERE name_en = 'Financial & Tax';

-- Insert documents for Commercial & IP
INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, '3 største kundekontrakter', 'Top 3 Customer Contracts', 1 FROM public.categories WHERE name_en = 'Commercial & IP';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, '3 vigtigste leverandørkontrakter', 'Top 3 Supplier Contracts', 2 FROM public.categories WHERE name_en = 'Commercial & IP';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'IP-liste (varemærker, domæner, patenter)', 'IP List (Trademarks, Domains, Patents)', 3 FROM public.categories WHERE name_en = 'Commercial & IP';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Pitch- eller virksomhedspræsentation', 'Pitch Deck', 4 FROM public.categories WHERE name_en = 'Commercial & IP';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Marketing- eller salgsplan', 'Marketing / Sales Plan', 5 FROM public.categories WHERE name_en = 'Commercial & IP';

-- Insert documents for People & Operations
INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Organisationsdiagram', 'Organization Chart', 1 FROM public.categories WHERE name_en = 'People & Operations';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Ansættelsesaftaler for ledelse/nøglepersoner', 'Employment Contracts (Key Personnel)', 2 FROM public.categories WHERE name_en = 'People & Operations';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Standard ansættelseskontrakt (skabelon)', 'Standard Employment Contract Template', 3 FROM public.categories WHERE name_en = 'People & Operations';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Forsikringspolicer', 'Insurance Policies', 4 FROM public.categories WHERE name_en = 'People & Operations';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'It-systemer og sikkerhedsbeskrivelse', 'IT Systems & Security Description', 5 FROM public.categories WHERE name_en = 'People & Operations';

-- Insert documents for Compliance & Sustainability
INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'GDPR-politik og databehandleraftaler', 'GDPR Policy & DPA', 1 FROM public.categories WHERE name_en = 'Compliance & Sustainability';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Miljø- og bæredygtighedsinitiativer', 'Environmental & Sustainability Initiatives', 2 FROM public.categories WHERE name_en = 'Compliance & Sustainability';

INSERT INTO public.documents (category_id, name_da, name_en, sort_order)
SELECT id, 'Evt. myndighedssager eller påbud', 'Government Cases or Orders', 3 FROM public.categories WHERE name_en = 'Compliance & Sustainability';