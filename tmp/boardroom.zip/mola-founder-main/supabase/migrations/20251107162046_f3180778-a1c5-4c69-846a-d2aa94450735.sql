-- Create enum for DD status
CREATE TYPE public.dd_status AS ENUM (
  'not_started',
  'in_progress', 
  'pending_review',
  'approved',
  'rejected'
);

-- Create enum for DD document types
CREATE TYPE public.dd_document_type AS ENUM (
  'financial',
  'legal',
  'commercial',
  'technical',
  'other'
);

-- Create due diligence cases table
CREATE TABLE public.due_diligence_cases (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  status dd_status NOT NULL DEFAULT 'not_started',
  assigned_to UUID REFERENCES auth.users(id),
  started_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(company_id)
);

-- Create due diligence checklist items template
CREATE TABLE public.dd_checklist_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,
  item_name TEXT NOT NULL,
  description TEXT,
  required BOOLEAN DEFAULT true,
  sort_order INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create due diligence progress tracking
CREATE TABLE public.dd_checklist_progress (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  case_id UUID NOT NULL REFERENCES public.due_diligence_cases(id) ON DELETE CASCADE,
  template_id UUID NOT NULL REFERENCES public.dd_checklist_templates(id) ON DELETE CASCADE,
  completed BOOLEAN DEFAULT false,
  completed_by UUID REFERENCES auth.users(id),
  completed_at TIMESTAMP WITH TIME ZONE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(case_id, template_id)
);

-- Create due diligence documents table
CREATE TABLE public.dd_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  case_id UUID NOT NULL REFERENCES public.due_diligence_cases(id) ON DELETE CASCADE,
  document_type dd_document_type NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  mime_type TEXT NOT NULL,
  uploaded_by UUID NOT NULL REFERENCES auth.users(id),
  uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  notes TEXT
);

-- Enable RLS
ALTER TABLE public.due_diligence_cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dd_checklist_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dd_checklist_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dd_documents ENABLE ROW LEVEL SECURITY;

-- RLS Policies for due_diligence_cases
CREATE POLICY "MOLA admins can view all DD cases"
  ON public.due_diligence_cases FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage DD cases"
  ON public.due_diligence_cases FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for dd_checklist_templates
CREATE POLICY "MOLA admins can view checklist templates"
  ON public.dd_checklist_templates FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage checklist templates"
  ON public.dd_checklist_templates FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for dd_checklist_progress
CREATE POLICY "MOLA admins can view DD progress"
  ON public.dd_checklist_progress FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage DD progress"
  ON public.dd_checklist_progress FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for dd_documents
CREATE POLICY "MOLA admins can view DD documents"
  ON public.dd_documents FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage DD documents"
  ON public.dd_documents FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- Insert default checklist template items
INSERT INTO public.dd_checklist_templates (category, item_name, description, required, sort_order) VALUES
  ('Finansiel', 'Årsrapporter (3 år)', 'Seneste 3 års årsrapporter inkl. balance og resultatopgørelse', true, 1),
  ('Finansiel', 'Budget og forecast', 'Detaljeret budget for indeværende år og forecast for næste 2 år', true, 2),
  ('Finansiel', 'Cash flow analyse', 'Historisk og fremskrevet cash flow', true, 3),
  ('Finansiel', 'Kundekontrakter', 'Oversigt over væsentlige kundekontrakter og omsætning', true, 4),
  ('Finansiel', 'Gæld og forpligtelser', 'Oversigt over al gæld, leasing og andre forpligtelser', true, 5),
  
  ('Juridisk', 'Vedtægter', 'Gældende vedtægter for selskabet', true, 6),
  ('Juridisk', 'Aktionæraftaler', 'Alle aktionæraftaler og optionsaftaler', true, 7),
  ('Juridisk', 'Ejerforhold', 'Fuldstændig kapitaltabel med alle aktionærer', true, 8),
  ('Juridisk', 'Væsentlige kontrakter', 'Leverandørkontrakter, partnerskaber, IP-aftaler', true, 9),
  ('Juridisk', 'Retssager', 'Oversigt over verserende eller potentielle retssager', false, 10),
  
  ('Kommerciel', 'Markedsanalyse', 'Analyse af marked, konkurrenter og markedsposition', true, 11),
  ('Kommerciel', 'Kundebase', 'Analyse af kundebase, churn rate, customer lifetime value', true, 12),
  ('Kommerciel', 'Salgskanaler', 'Oversigt over salgskanaler og go-to-market strategi', true, 13),
  ('Kommerciel', 'Marketing materiale', 'Pitch deck, marketing plan, brand guidelines', false, 14),
  
  ('Teknisk', 'Tech stack', 'Oversigt over teknologier, platforme og infrastruktur', true, 15),
  ('Teknisk', 'IP rettigheder', 'Patents, trademarks, domæner og andre IP-rettigheder', true, 16),
  ('Teknisk', 'Data sikkerhed', 'GDPR compliance, datasikkerhed og privacy policies', true, 17),
  ('Teknisk', 'Tech roadmap', 'Produktudviklingsplan og teknisk roadmap', false, 18),
  
  ('Team', 'Ledelsesgruppe', 'CV og baggrund for CEO og ledelsesgruppe', true, 19),
  ('Team', 'Organisationsdiagram', 'Komplet organisationsdiagram med roller', true, 20),
  ('Team', 'Nøglepersoner', 'Ansættelseskontrakter for nøglepersoner', true, 21),
  ('Team', 'Medarbejderoptions', 'Oversigt over medarbejderoptioner og vesting', false, 22);

-- Create indexes for better performance
CREATE INDEX idx_dd_cases_company ON public.due_diligence_cases(company_id);
CREATE INDEX idx_dd_cases_status ON public.due_diligence_cases(status);
CREATE INDEX idx_dd_progress_case ON public.dd_checklist_progress(case_id);
CREATE INDEX idx_dd_documents_case ON public.dd_documents(case_id);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_dd_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for updated_at
CREATE TRIGGER update_dd_cases_updated_at
  BEFORE UPDATE ON public.due_diligence_cases
  FOR EACH ROW
  EXECUTE FUNCTION public.update_dd_updated_at();