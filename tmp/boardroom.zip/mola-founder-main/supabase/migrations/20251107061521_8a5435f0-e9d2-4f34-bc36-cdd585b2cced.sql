-- Create companies table
CREATE TABLE public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  cvr TEXT,
  logo_url TEXT,
  equity_share_pct NUMERIC,
  invested_amount_dkk NUMERIC,
  invested_at DATE,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create monthly_reports table
CREATE TABLE public.monthly_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  period_month INTEGER NOT NULL CHECK (period_month >= 1 AND period_month <= 12),
  period_year INTEGER NOT NULL,
  revenue_dkk NUMERIC NOT NULL,
  ebitda_dkk NUMERIC NOT NULL,
  cash_dkk NUMERIC NOT NULL,
  new_customers INTEGER NOT NULL DEFAULT 0,
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(company_id, period_month, period_year)
);

-- Create nps_responses table
CREATE TABLE public.nps_responses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  score INTEGER NOT NULL CHECK (score >= 0 AND score <= 10),
  comment TEXT,
  period_quarter INTEGER NOT NULL CHECK (period_quarter >= 1 AND period_quarter <= 4),
  period_year INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create shipping_prices table
CREATE TABLE public.shipping_prices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  country_code TEXT DEFAULT 'DK',
  home_delivery_dkk NUMERIC NOT NULL,
  pickup_point_dkk NUMERIC NOT NULL,
  effective_from DATE DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create badges table
CREATE TABLE public.badges (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  label TEXT NOT NULL,
  earned_at DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Add company_id to profiles table
ALTER TABLE public.profiles ADD COLUMN company_id UUID REFERENCES public.companies(id);

-- Enable RLS on all tables
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.monthly_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nps_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shipping_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;

-- RLS Policies for companies
CREATE POLICY "Founders can view own company"
  ON public.companies FOR SELECT
  USING (
    id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "MOLA admins can view all companies"
  ON public.companies FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for monthly_reports
CREATE POLICY "Founders can view own company reports"
  ON public.monthly_reports FOR SELECT
  USING (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Founders can insert own company reports"
  ON public.monthly_reports FOR INSERT
  WITH CHECK (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "MOLA admins can view all reports"
  ON public.monthly_reports FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage all reports"
  ON public.monthly_reports FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for nps_responses
CREATE POLICY "Founders can view own company NPS"
  ON public.nps_responses FOR SELECT
  USING (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Founders can insert own company NPS"
  ON public.nps_responses FOR INSERT
  WITH CHECK (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "MOLA admins can view all NPS responses"
  ON public.nps_responses FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for shipping_prices
CREATE POLICY "Founders can view own company shipping"
  ON public.shipping_prices FOR SELECT
  USING (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "Founders can insert own company shipping"
  ON public.shipping_prices FOR INSERT
  WITH CHECK (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "MOLA admins can view all shipping prices"
  ON public.shipping_prices FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

-- RLS Policies for badges
CREATE POLICY "Founders can view own company badges"
  ON public.badges FOR SELECT
  USING (
    company_id IN (
      SELECT company_id FROM public.profiles WHERE id = auth.uid()
    )
  );

CREATE POLICY "MOLA admins can view all badges"
  ON public.badges FOR SELECT
  USING (has_role(auth.uid(), 'mola_admin'));

CREATE POLICY "MOLA admins can manage all badges"
  ON public.badges FOR ALL
  USING (has_role(auth.uid(), 'mola_admin'));