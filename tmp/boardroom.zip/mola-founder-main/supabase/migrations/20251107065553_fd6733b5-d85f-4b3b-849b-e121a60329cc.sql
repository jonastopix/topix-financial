-- Create funds table
CREATE TABLE public.funds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE, -- e.g., 'MOLA', 'MLH', 'VIK'
  inception_date DATE,
  target_size_dkk NUMERIC,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create dividends table
CREATE TABLE public.dividends (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  fund_id UUID NOT NULL REFERENCES public.funds(id) ON DELETE RESTRICT,
  amount_dkk NUMERIC NOT NULL CHECK (amount_dkk > 0),
  declared_date DATE NOT NULL,
  paid_date DATE NOT NULL CHECK (paid_date >= declared_date),
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create exits table
CREATE TABLE public.exits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  fund_id UUID NOT NULL REFERENCES public.funds(id) ON DELETE RESTRICT,
  closing_date DATE NOT NULL,
  gross_sale_amount_dkk NUMERIC NOT NULL CHECK (gross_sale_amount_dkk > 0),
  mola_ownership_pct_at_exit NUMERIC NOT NULL CHECK (mola_ownership_pct_at_exit >= 0 AND mola_ownership_pct_at_exit <= 100),
  transaction_costs_dkk NUMERIC DEFAULT 0 CHECK (transaction_costs_dkk >= 0),
  earnout_possible BOOLEAN DEFAULT false,
  earnout_amount_potential_dkk NUMERIC,
  retained_shares_pct NUMERIC DEFAULT 0 CHECK (retained_shares_pct >= 0 AND retained_shares_pct <= 100),
  note TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create valuations table
CREATE TABLE public.valuations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  as_of_date DATE NOT NULL,
  post_money_valuation_dkk NUMERIC NOT NULL CHECK (post_money_valuation_dkk > 0),
  source TEXT NOT NULL, -- 'bestyrelsesbeslutning', 'runde', 'model'
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Add fund_id to companies table to track which fund invested
ALTER TABLE public.companies 
ADD COLUMN fund_id UUID REFERENCES public.funds(id);

-- Enable RLS on all new tables
ALTER TABLE public.funds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dividends ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.valuations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for funds
CREATE POLICY "Anyone authenticated can view funds"
ON public.funds FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "MOLA admins can manage funds"
ON public.funds FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- RLS Policies for dividends
CREATE POLICY "MOLA admins can view all dividends"
ON public.dividends FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "MOLA admins can manage dividends"
ON public.dividends FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- RLS Policies for exits
CREATE POLICY "MOLA admins can view all exits"
ON public.exits FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "Founders can see if their company exited"
ON public.exits FOR SELECT
TO authenticated
USING (
  company_id IN (
    SELECT company_id FROM profiles WHERE id = auth.uid()
  )
);

CREATE POLICY "MOLA admins can manage exits"
ON public.exits FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- RLS Policies for valuations
CREATE POLICY "MOLA admins can view all valuations"
ON public.valuations FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

CREATE POLICY "MOLA admins can manage valuations"
ON public.valuations FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'mola_admin'::app_role));

-- Create indexes for better performance
CREATE INDEX idx_dividends_company_id ON public.dividends(company_id);
CREATE INDEX idx_dividends_fund_id ON public.dividends(fund_id);
CREATE INDEX idx_exits_company_id ON public.exits(company_id);
CREATE INDEX idx_exits_fund_id ON public.exits(fund_id);
CREATE INDEX idx_valuations_company_id ON public.valuations(company_id);
CREATE INDEX idx_companies_fund_id ON public.companies(fund_id);