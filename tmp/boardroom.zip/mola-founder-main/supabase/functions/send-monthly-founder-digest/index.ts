import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Helper function to get month name in Danish
const getMonthName = (month: number): string => {
  const months = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];
  return months[month - 1];
};

// Helper function to replace template variables (supports {{#if}} conditionals)
const replaceTemplateVariables = (template: string, variables: Record<string, string>): string => {
  let result = template;
  
  // Handle conditional blocks first
  Object.entries(variables).forEach(([key, value]) => {
    if (!value || value === '') {
      // Remove conditional block if variable is empty
      const conditionalRegex = new RegExp(`{{#if ${key}}}[\\s\\S]*?{{/if}}`, 'g');
      result = result.replace(conditionalRegex, '');
    } else {
      // Keep content and remove conditional tags
      const conditionalRegex = new RegExp(`{{#if ${key}}}([\\s\\S]*?){{/if}}`, 'g');
      result = result.replace(conditionalRegex, '$1');
    }
  });
  
  // Replace all variables
  Object.entries(variables).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
  });
  
  return result;
};

// Helper function to format number with thousands separator
const formatNumber = (num: number): string => {
  return new Intl.NumberFormat('da-DK').format(Math.round(num));
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🚀 Starting monthly founder digest function...');

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Calculate last month and current date info
    const now = new Date();
    let lastMonth = now.getMonth(); // 0-indexed
    let lastYear = now.getFullYear();
    
    if (lastMonth === 0) {
      lastMonth = 12;
      lastYear = lastYear - 1;
    }

    const lastMonthName = getMonthName(lastMonth);
    const nextMonth = getMonthName(now.getMonth() + 1);
    const deadlineDate = `20. ${nextMonth}`;

    console.log(`📅 Processing data for: ${lastMonthName} ${lastYear}`);

    // Fetch email template
    const { data: template, error: templateError } = await supabaseAdmin
      .from('email_templates')
      .select('*')
      .eq('template_key', 'monthly_founder_digest')
      .eq('is_active', true)
      .single();

    if (templateError || !template) {
      console.error('❌ Error fetching email template:', templateError);
      return new Response(
        JSON.stringify({ error: 'Email template not found' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch all active companies
    const { data: companies, error: companiesError } = await supabaseAdmin
      .from('companies')
      .select('id, name')
      .eq('status', 'active')
      .eq('is_active', true);

    if (companiesError) {
      console.error('❌ Error fetching companies:', companiesError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch companies' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📊 Found ${companies?.length || 0} active companies`);

    let emailsSent = 0;

    // Process each company
    for (const company of companies || []) {
      console.log(`📤 Processing company: ${company.name}`);

      // Fetch latest monthly report for last month
      const { data: monthlyReport, error: reportError } = await supabaseAdmin
        .from('monthly_reports')
        .select('revenue, ebitda, period_month, period_year')
        .eq('company_id', company.id)
        .eq('period_month', lastMonth)
        .eq('period_year', lastYear)
        .maybeSingle();

      if (reportError) {
        console.error(`❌ Error fetching report for ${company.name}:`, reportError);
        continue;
      }

      if (!monthlyReport) {
        console.log(`⚠️ No report found for ${company.name} for ${lastMonthName} ${lastYear}`);
        continue;
      }

      // Fetch previous month for comparison
      let prevMonth = lastMonth - 1;
      let prevYear = lastYear;
      if (prevMonth === 0) {
        prevMonth = 12;
        prevYear = prevYear - 1;
      }

      const { data: prevMonthReport } = await supabaseAdmin
        .from('monthly_reports')
        .select('revenue')
        .eq('company_id', company.id)
        .eq('period_month', prevMonth)
        .eq('period_year', prevYear)
        .maybeSingle();

      // Calculate revenue change
      let revenueChange = 0;
      let revenueChangeColor = '#10b981'; // green
      
      if (prevMonthReport && prevMonthReport.revenue) {
        const change = ((monthlyReport.revenue - prevMonthReport.revenue) / prevMonthReport.revenue) * 100;
        revenueChange = Math.round(change);
        revenueChangeColor = change >= 0 ? '#10b981' : '#ef4444'; // green or red
      }

      // Fetch portfolio rankings
      const { data: rankings, error: rankingsError } = await supabaseAdmin
        .from('portfolio_rankings')
        .select('*')
        .eq('company_id', company.id)
        .order('ranking_date', { ascending: false })
        .limit(1);

      let portfolioRank = '';
      let portfolioTotal = '';
      let portfolioPercentile = '';

      if (rankings && rankings.length > 0) {
        // Get YTD Revenue ranking
        const ytdRanking = rankings.find(r => r.metric_type === 'ytd_revenue');
        if (ytdRanking) {
          portfolioRank = ytdRanking.rank.toString();
          portfolioTotal = ytdRanking.total_companies.toString();
          portfolioPercentile = Math.round(ytdRanking.percentile).toString();
        }
      }

      // Fetch latest milestone
      const { data: milestones } = await supabaseAdmin
        .from('founder_milestones')
        .select('milestone_type, milestone_value')
        .eq('company_id', company.id)
        .gte('achieved_at', `${lastYear}-${String(lastMonth).padStart(2, '0')}-01`)
        .lt('achieved_at', `${lastYear}-${String(lastMonth + 1).padStart(2, '0')}-01`)
        .order('achieved_at', { ascending: false })
        .limit(1);

      let milestoneText = '';
      if (milestones && milestones.length > 0) {
        const milestone = milestones[0];
        if (milestone.milestone_type === 'best_month_revenue') {
          milestoneText = 'Bedste måned nogensinde! 🚀';
        } else if (milestone.milestone_type === 'fastest_growth') {
          milestoneText = 'Hurtigste vækst nogensinde! 📈';
        } else if (milestone.milestone_type === 'first_profitable') {
          milestoneText = 'Første profitable måned! 💰';
        }
      }

      // Fetch founder users
      const { data: founderRoles } = await supabaseAdmin
        .from('user_roles')
        .select('user_id')
        .eq('role', 'founder');

      if (!founderRoles || founderRoles.length === 0) {
        console.log(`⚠️ No founder roles found`);
        continue;
      }

      const founderUserIds = founderRoles.map(r => r.user_id);

      const { data: founders } = await supabaseAdmin
        .from('profiles')
        .select('id, email, full_name')
        .eq('company_id', company.id)
        .eq('is_active', true)
        .in('id', founderUserIds);

      if (!founders || founders.length === 0) {
        console.log(`⚠️ No active founders found for ${company.name}`);
        continue;
      }

      const recipientEmails = founders
        .map(f => f.email)
        .filter(email => email !== null) as string[];

      if (recipientEmails.length === 0) {
        console.log(`⚠️ No valid emails for ${company.name}`);
        continue;
      }

      // Build template variables
      const variables = {
        founder_name: founders[0].full_name || 'Founder',
        company_name: company.name,
        month_name: lastMonthName,
        year: lastYear.toString(),
        revenue: formatNumber(monthlyReport.revenue),
        revenue_change: revenueChange >= 0 ? `+${revenueChange}` : revenueChange.toString(),
        revenue_change_color: revenueChangeColor,
        ebitda: formatNumber(monthlyReport.ebitda || 0),
        portfolio_rank: portfolioRank,
        portfolio_total: portfolioTotal,
        portfolio_percentile: portfolioPercentile,
        milestone_text: milestoneText,
        dashboard_link: 'https://founder.molainvest.dk/dashboard',
        report_link: 'https://founder.molainvest.dk/monthly-report',
        report_deadline: deadlineDate,
        next_month: nextMonth
      };

      const subject = replaceTemplateVariables(template.subject, variables);
      const htmlBody = replaceTemplateVariables(template.html_body, variables);

      // Send emails
      for (const email of recipientEmails) {
        try {
          const emailResponse = await resend.emails.send({
            from: `${template.from_name} <${template.from_email}>`,
            to: [email],
            subject,
            html: htmlBody,
          });

          console.log(`✅ Email sent to ${email}:`, emailResponse);
          emailsSent++;
        } catch (emailError) {
          console.error(`❌ Error sending email to ${email}:`, emailError);
        }
      }
    }

    console.log(`🎉 Total emails sent: ${emailsSent}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        emailsSent,
        targetMonth: lastMonthName,
        targetYear: lastYear 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('❌ Error in send-monthly-founder-digest:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
