import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Rate limit configuration
const MAX_ATTEMPTS = 5; // Maximum failed attempts
const WINDOW_MINUTES = 15; // Time window in minutes
const LOCKOUT_MINUTES = 30; // Lockout duration after max attempts

interface LoginRequest {
  email: string;
  password: string;
}

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, password }: LoginRequest = await req.json();

    if (!email || !password) {
      return new Response(
        JSON.stringify({ error: "Email og password er påkrævet" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Create service role client to bypass RLS
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get client IP from headers
    const clientIp = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || 
                     req.headers.get("x-real-ip") || 
                     "unknown";
    const userAgent = req.headers.get("user-agent") || "unknown";

    // Normalize email for consistent tracking
    const normalizedEmail = email.toLowerCase().trim();

    // Check rate limits for both email and IP
    const { data: emailAttempts } = await supabase
      .rpc("count_recent_login_attempts", { 
        p_identifier: normalizedEmail, 
        p_window_minutes: WINDOW_MINUTES 
      });

    const { data: ipAttempts } = await supabase
      .rpc("count_recent_login_attempts", { 
        p_identifier: clientIp, 
        p_window_minutes: WINDOW_MINUTES 
      });

    console.log(`Login attempt for ${normalizedEmail} from ${clientIp}. Email attempts: ${emailAttempts}, IP attempts: ${ipAttempts}`);

    // Check if rate limited
    if (emailAttempts >= MAX_ATTEMPTS || ipAttempts >= MAX_ATTEMPTS) {
      const identifier = emailAttempts >= MAX_ATTEMPTS ? normalizedEmail : clientIp;
      
      // Log the blocked attempt
      await supabase.from("login_attempts").insert({
        identifier,
        identifier_type: emailAttempts >= MAX_ATTEMPTS ? "email" : "ip",
        success: false,
        user_agent: userAgent,
        ip_address: clientIp,
      });

      console.log(`Rate limit exceeded for ${identifier}`);

      return new Response(
        JSON.stringify({ 
          error: `For mange mislykkede loginforsøg. Prøv igen om ${LOCKOUT_MINUTES} minutter.`,
          rateLimited: true,
          retryAfterMinutes: LOCKOUT_MINUTES
        }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Attempt login with anon key client (normal auth flow)
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseAuth = createClient(supabaseUrl, supabaseAnonKey);

    const { data: authData, error: authError } = await supabaseAuth.auth.signInWithPassword({
      email: normalizedEmail,
      password,
    });

    // Log the attempt
    await supabase.from("login_attempts").insert({
      identifier: normalizedEmail,
      identifier_type: "email",
      success: !authError,
      user_agent: userAgent,
      ip_address: clientIp,
    });

    // Also log IP-based attempt for tracking
    if (authError) {
      await supabase.from("login_attempts").insert({
        identifier: clientIp,
        identifier_type: "ip",
        success: false,
        user_agent: userAgent,
        ip_address: clientIp,
      });
    }

    if (authError) {
      console.log(`Failed login for ${normalizedEmail}: ${authError.message}`);
      
      const remainingAttempts = MAX_ATTEMPTS - (emailAttempts + 1);
      
      return new Response(
        JSON.stringify({ 
          error: authError.message,
          remainingAttempts: Math.max(0, remainingAttempts)
        }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Successful login for ${normalizedEmail}`);

    return new Response(
      JSON.stringify({ 
        session: authData.session,
        user: authData.user 
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("Error in rate-limited-login:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Der opstod en fejl" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
