import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PasswordResetRequest {
  email: string;
  reset_url: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, reset_url }: PasswordResetRequest = await req.json();

    console.log("Sending password reset email to:", email);

    // Create Supabase client with service role to bypass RLS
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch password reset template
    const { data: template, error: templateError } = await supabase
      .from("email_templates")
      .select("*")
      .eq("template_key", "password_reset")
      .eq("is_active", true)
      .single();

    if (templateError || !template) {
      console.error("Template fetch error:", templateError);
      throw new Error("Password reset email template not found");
    }

    // Replace variables in subject and HTML body
    const currentYear = new Date().getFullYear().toString();
    
    const subject = template.subject
      .replace(/\{\{email\}\}/g, email)
      .replace(/\{\{year\}\}/g, currentYear);

    const htmlBody = template.html_body
      .replace(/\{\{email\}\}/g, email)
      .replace(/\{\{reset_url\}\}/g, reset_url)
      .replace(/\{\{year\}\}/g, currentYear);

    // Send email via Resend
    const emailResponse = await resend.emails.send({
      from: `${template.from_name} <${template.from_email}>`,
      to: [email],
      subject: subject,
      html: htmlBody,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true,
        message: "Password reset email sent successfully" 
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("Error in send-password-reset-email function:", error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

serve(handler);
