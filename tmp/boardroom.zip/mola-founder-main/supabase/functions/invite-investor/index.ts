import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    // Check if user is admin or founder for the company
    const { capTableEntryId, email, companyId } = await req.json();

    console.log('Inviting investor:', { email, companyId, capTableEntryId });

    // Check if email already has a user
    const { data: existingUsers } = await supabase
      .from('profiles')
      .select('id')
      .ilike('id', `%${email}%`);

    let userId: string | null = null;

    // Check via auth.users table using admin API
    const { data: authUsers } = await supabase.auth.admin.listUsers();
    const existingAuthUser = authUsers?.users?.find(u => u.email === email);

    if (existingAuthUser) {
      userId = existingAuthUser.id;
      console.log('Found existing user:', userId);
    } else {
      // Invite new user
      const { data: inviteData, error: inviteError } = await supabase.auth.admin.inviteUserByEmail(email, {
        data: { 
          role: 'investor',
          company_id: companyId 
        }
      });

      if (inviteError) {
        console.error('Invite error:', inviteError);
        throw inviteError;
      }

      userId = inviteData?.user?.id || null;
      console.log('Created new user invitation:', userId);
    }

    if (!userId) {
      throw new Error('Failed to get or create user');
    }

    // Add investor role
    const { error: roleError } = await supabase
      .from('user_roles')
      .upsert({ 
        user_id: userId, 
        role: 'investor' 
      }, { 
        onConflict: 'user_id,role',
        ignoreDuplicates: true 
      });

    if (roleError) {
      console.error('Role assignment error:', roleError);
      throw roleError;
    }

    // Update cap table entry with user_id
    const { error: updateError } = await supabase
      .from('company_cap_table')
      .update({
        user_id: userId,
        invited_at: new Date().toISOString(),
        invitation_status: 'pending'
      })
      .eq('id', capTableEntryId);

    if (updateError) {
      console.error('Cap table update error:', updateError);
      throw updateError;
    }

    // Log activity
    await supabase.from('company_activity_log').insert({
      company_id: companyId,
      user_id: user.id,
      activity_type: 'investor_invited',
      description: `Inviterede investor ${email}`,
      metadata: { email, cap_table_entry_id: capTableEntryId }
    });

    console.log('Investor invitation completed successfully');

    return new Response(
      JSON.stringify({ success: true, userId }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in invite-investor function:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 400, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
