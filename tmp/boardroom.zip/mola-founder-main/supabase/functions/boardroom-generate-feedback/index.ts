import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.49.1'

type Payload = { report_id?: string }

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  })
}

function env(name: string): string {
  const v = Deno.env.get(name)
  if (!v) throw new Error(`Missing env var: ${name}`)
  return v
}

function safeNum(v: any): number | null {
  if (v === null || v === undefined) return null
  const n = Number(v)
  return Number.isFinite(n) ? n : null
}

function formatDKK(n: number | null): string {
  if (n === null) return 'ikke oplyst'
  return new Intl.NumberFormat('da-DK', { maximumFractionDigits: 0 }).format(n)
}

function pct(n: number | null): string {
  if (n === null || !Number.isFinite(n)) return 'ikke oplyst'
  return new Intl.NumberFormat('da-DK', { style: 'percent', maximumFractionDigits: 1 }).format(n)
}

Deno.serve(async (req) => {
  try {
    if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)

    const { report_id } = (await req.json()) as Payload
    if (!report_id) return json({ error: 'report_id is required' }, 400)

    const supabaseUrl = env('SUPABASE_URL')
    const serviceKey = env('SUPABASE_SERVICE_ROLE_KEY')
    const openaiKey = env('OPENAI_API_KEY')

    const sb = createClient(supabaseUrl, serviceKey)

    const { data: report, error: rErr } = await sb
      .from('monthly_reports')
      .select('id, company_id, period_month, period_year, revenue_dkk, gross_profit_dkk, payroll_dkk, other_opex_dkk, result_before_tax_dkk, note, status, companies(name)')
      .eq('id', report_id)
      .single()

    if (rErr) return json({ error: rErr.message }, 400)

    const revenue = safeNum(report.revenue_dkk)
    const grossProfit = safeNum(report.gross_profit_dkk)
    const payroll = safeNum(report.payroll_dkk)
    const otherOpex = safeNum(report.other_opex_dkk)
    const resultBeforeTax = safeNum(report.result_before_tax_dkk)

    const dg = revenue && grossProfit !== null ? grossProfit / revenue : null
    const payrollPct = revenue && payroll !== null ? payroll / revenue : null
    const opexPct = revenue && otherOpex !== null ? otherOpex / revenue : null
    const resPct = revenue && resultBeforeTax !== null ? resultBeforeTax / revenue : null

    const companyName = report.companies?.name ?? 'Virksomhed'
    const month = String(report.period_month).padStart(2, '0')
    const ym = `${report.period_year}-${month}`

    const prompt = `Du er Morten/Jonas fra The Boardroom. Skriv på dansk, kort, konkret, professionelt.

Du får en månedsrapport (en virksomhed pr. måned). Du skal levere:
- summary: 3-6 korte sætninger (ingen hype)
- key_observations: 3 punkter (string)
- recommendations: 3-4 konkrete næste skridt (string)
- slack_line: 1 linje i format: "${companyName} – ${ym}: ...".

Regler:
- Gæt aldrig på tal. Hvis noget mangler, skriv "ikke oplyst".
- Fokus på 1-3 vigtigste pointer.
- Anbefalinger skal være eksekverbare.

Data:
Virksomhed: ${companyName}
Måned: ${ym}
Omsætning: ${formatDKK(revenue)}
DB/bruttoavance: ${formatDKK(grossProfit)}
Dækningsgrad (beregnet): ${pct(dg)}
Løn: ${formatDKK(payroll)}
Løn% (beregnet): ${pct(payrollPct)}
Øvrige kapacitetsomk.: ${formatDKK(otherOpex)}
Kapacitet% (beregnet): ${pct(opexPct)}
Resultat før skat: ${formatDKK(resultBeforeTax)}
Resultat% (beregnet): ${pct(resPct)}
Noter fra medlem: ${report.note ?? 'ingen'}

Svar KUN som gyldig JSON med keys: summary, key_observations, recommendations, slack_line.`

    const oaiResp = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${openaiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5',
        input: prompt,
        text: { format: { type: 'json_object' } },
      }),
    })

    if (!oaiResp.ok) {
      const detail = await oaiResp.text()
      return json({ error: `OpenAI error: ${oaiResp.status}`, detail }, 500)
    }

    const oaiJson = await oaiResp.json()
    const raw = oaiJson?.output_text
    if (!raw) return json({ error: 'No output_text from OpenAI' }, 500)

    let parsed: any
    try {
      parsed = JSON.parse(raw)
    } catch {
      return json({ error: 'Model did not return valid JSON', raw }, 500)
    }

    const summary = String(parsed.summary ?? '').trim()
    const key_observations = Array.isArray(parsed.key_observations)
      ? parsed.key_observations.map((x: any) => String(x))
      : []
    const recommendations = Array.isArray(parsed.recommendations)
      ? parsed.recommendations.map((x: any) => String(x))
      : []
    const slack_line = String(parsed.slack_line ?? '').trim()

    if (!summary || key_observations.length === 0 || recommendations.length === 0 || !slack_line) {
      return json({ error: 'Incomplete AI payload', parsed }, 500)
    }

    const { data: existing } = await sb
      .from('ai_feedback')
      .select('id')
      .eq('report_id', report_id)
      .maybeSingle()

    if (existing?.id) {
      const { error } = await sb
        .from('ai_feedback')
        .update({ summary, key_observations, recommendations, slack_line })
        .eq('id', existing.id)
      if (error) return json({ error: error.message }, 500)
    } else {
      const { error } = await sb
        .from('ai_feedback')
        .insert({ report_id, summary, key_observations, recommendations, slack_line })
      if (error) return json({ error: error.message }, 500)
    }

    return json({ ok: true })
  } catch (e) {
    return json({ error: (e as Error).message }, 500)
  }
})
