import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.80.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { companyId } = await req.json();
    
    if (!companyId) {
      return new Response(
        JSON.stringify({ error: 'Company ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get company data
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: company, error: companyError } = await supabase
      .from('companies')
      .select('name, industry, status, description, business_model, target_market, growth_stage')
      .eq('id', companyId)
      .single();

    if (companyError || !company) {
      console.error('Error fetching company:', companyError);
      return new Response(
        JSON.stringify({ error: 'Company not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get latest monthly reports for context
    const { data: reports } = await supabase
      .from('monthly_reports')
      .select('revenue, ebitda, month')
      .eq('company_id', companyId)
      .order('month', { ascending: false })
      .limit(12);

    // Calculate some basic metrics for context
    let revenueContext = '';
    let ebitdaContext = '';
    if (reports && reports.length > 0) {
      const totalRevenue = reports.reduce((sum, r) => sum + (r.revenue || 0), 0);
      const totalEbitda = reports.reduce((sum, r) => sum + (r.ebitda || 0), 0);
      const avgRevenue = totalRevenue / reports.length;
      const avgEbitda = totalEbitda / reports.length;
      
      revenueContext = `Average monthly revenue: ${Math.round(avgRevenue).toLocaleString('da-DK')} DKK`;
      ebitdaContext = totalEbitda > 0 
        ? `Average monthly EBITDA: ${Math.round(avgEbitda).toLocaleString('da-DK')} DKK (${((avgEbitda/avgRevenue)*100).toFixed(1)}% margin)`
        : 'Company is currently operating at a loss';
    }

    // Call Lovable AI
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = `You are a valuation expert specializing in Nordic SMEs and growth companies. 
Your task is to suggest appropriate Revenue and EBITDA multiples for company valuations based on industry benchmarks.

Guidelines:
- Use current market benchmarks for Nordic/European private equity and venture capital
- Distinguish between industries (SaaS, e-commerce, marketplace, manufacturing, services, etc.)
- Consider typical valuation ranges: SaaS (3-8x revenue), E-commerce (0.5-2.5x revenue), Manufacturing (1-3x revenue)
- EBITDA multiples typically range from 6-15x depending on sector and growth
- Be conservative - private company valuations are typically lower than public markets
- For loss-making companies, focus on revenue multiples
- Always explain your reasoning clearly in Danish

Respond with a JSON object containing:
{
  "revenue_multiple": number (e.g., 2.5),
  "ebitda_multiple": number (e.g., 10.0),
  "suggested_revenue_weight": number (50-80, percentage weight for revenue vs EBITDA),
  "reasoning": "string in Danish explaining the suggested multiples"
}`;

    // Build detailed company context
    let companyContext = `Company: ${company.name}
Industry: ${company.industry || 'Unknown'}
Status: ${company.status}`;

    if (company.description) {
      companyContext += `\nDescription: ${company.description}`;
    }
    if (company.business_model) {
      companyContext += `\nBusiness Model: ${company.business_model}`;
    }
    if (company.target_market) {
      companyContext += `\nTarget Market: ${company.target_market}`;
    }
    if (company.growth_stage) {
      companyContext += `\nGrowth Stage: ${company.growth_stage}`;
    }
    if (revenueContext) {
      companyContext += `\n${revenueContext}`;
    }
    if (ebitdaContext) {
      companyContext += `\n${ebitdaContext}`;
    }

    const userPrompt = `Suggest appropriate valuation multiples for this company:

${companyContext}

Please provide realistic multiples for private equity valuation in the Nordic market.`;

    console.log('Calling Lovable AI with prompt for company:', company.name);

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('AI gateway error:', aiResponse.status, errorText);
      
      // Return fallback values
      return new Response(
        JSON.stringify({
          revenue_multiple: 2.5,
          ebitda_multiple: 8.0,
          suggested_revenue_weight: 50,
          reasoning: 'AI-forslag kunne ikke genereres. Disse er standard værdier for nordiske SMV\'er. Tilpas dem efter din vurdering af virksomheden.',
          is_fallback: true
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiData = await aiResponse.json();
    const content = aiData.choices[0].message.content;
    
    console.log('AI response:', content);
    
    const suggestion = JSON.parse(content);

    return new Response(
      JSON.stringify({
        revenue_multiple: suggestion.revenue_multiple,
        ebitda_multiple: suggestion.ebitda_multiple,
        suggested_revenue_weight: suggestion.suggested_revenue_weight || 50,
        reasoning: suggestion.reasoning,
        is_fallback: false
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in suggest-valuation-multiples:', error);
    
    // Return fallback on any error
    return new Response(
      JSON.stringify({
        revenue_multiple: 2.5,
        ebitda_multiple: 8.0,
        suggested_revenue_weight: 50,
        reasoning: 'AI-forslag kunne ikke genereres på grund af en fejl. Disse er standard værdier for nordiske SMV\'er.',
        is_fallback: true
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
