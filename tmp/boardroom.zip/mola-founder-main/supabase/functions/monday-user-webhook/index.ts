import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const REVERSE_STATUS_MAPPING: Record<string, string> = {
  'To-Do': 'todo',
  'To Do': 'todo',
  'Working on it': 'in_progress',
  'Done': 'done',
  'Stuck': 'cancelled'
};

// Helper function to fetch item details from Monday.com API
async function fetchMondayItemDetails(apiToken: string, itemId: string) {
  try {
    const response = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiToken,
      },
      body: JSON.stringify({
        query: `query {
          items(ids: [${itemId}]) {
            column_values {
              id
              text
              value
            }
          }
        }`
      }),
    });

    const data = await response.json();
    return data.data?.items?.[0] || null;
  } catch (error) {
    console.error('Error fetching Monday item details:', error);
    return null;
  }
}

// Helper function to fetch Monday.com user details (email + name) by user ID
async function fetchMondayUserDetails(apiToken: string, mondayUserId: string): Promise<{ email: string | null; name: string | null }> {
  try {
    const response = await fetch('https://api.monday.com/v2', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': apiToken,
      },
      body: JSON.stringify({
        query: `query { users(ids: [${mondayUserId}]) { id email name } }`
      }),
    });

    const data = await response.json();
    const user = data.data?.users?.[0];
    return {
      email: user?.email || null,
      name: user?.name || null
    };
  } catch (error) {
    console.error('Error fetching Monday user details:', error);
    return { email: null, name: null };
  }
}

// Helper function to parse persons from various Monday.com formats
function parsePersonsAndTeams(value: any): { mondayUserId: string | null } {
  // Handle null/undefined
  if (!value) {
    return { mondayUserId: null };
  }

  // If value is a string, try to parse it as JSON
  let parsed = value;
  if (typeof value === 'string') {
    try {
      parsed = JSON.parse(value);
    } catch {
      console.log('Could not parse value as JSON:', value);
      return { mondayUserId: null };
    }
  }

  // Format 1: { personsAndTeams: [{ id: 123, kind: 'person' }] }
  if (parsed.personsAndTeams && Array.isArray(parsed.personsAndTeams)) {
    const person = parsed.personsAndTeams.find((p: any) => p.kind === 'person' || !p.kind);
    if (person?.id) {
      return { mondayUserId: person.id.toString() };
    }
  }

  // Format 2: { changed_at: "...", id: "123" } (sometimes used for single assignments)
  if (parsed.id && !parsed.personsAndTeams) {
    return { mondayUserId: parsed.id.toString() };
  }

  // Format 3: Direct array [{ id: 123, kind: 'person' }]
  if (Array.isArray(parsed)) {
    const person = parsed.find((p: any) => p.kind === 'person' || !p.kind);
    if (person?.id) {
      return { mondayUserId: person.id.toString() };
    }
  }

  console.log('Could not extract person from value:', JSON.stringify(value));
  return { mondayUserId: null };
}

// Helper function to look up or create Monday user mapping
async function getOrCreateUserMapping(
  supabase: any,
  mondayUserId: string,
  apiToken: string
): Promise<{ platformUserId: string | null; mondayUserName: string | null }> {
  // First, check if we already have a mapping
  const { data: existingMapping } = await supabase
    .from('monday_user_map')
    .select('platform_user_id, name')
    .eq('monday_user_id', mondayUserId)
    .single();

  if (existingMapping) {
    console.log(`Found existing mapping for Monday user ${mondayUserId} -> ${existingMapping.platform_user_id}`);
    return { 
      platformUserId: existingMapping.platform_user_id,
      mondayUserName: existingMapping.name
    };
  }

  // No mapping exists - fetch Monday user details and try to match
  const mondayUser = await fetchMondayUserDetails(apiToken, mondayUserId);
  
  if (!mondayUser.email) {
    console.log(`Could not fetch email for Monday user ${mondayUserId}`);
    return { platformUserId: null, mondayUserName: mondayUser.name };
  }

  // Try to match by email using auth.admin.listUsers
  let platformUserId: string | null = null;
  try {
    const { data: authData, error } = await supabase.auth.admin.listUsers();
    
    if (error) {
      console.error('Error listing users:', error);
    } else {
      const matchedUser = authData.users?.find(
        (u: any) => u.email?.toLowerCase() === mondayUser.email!.trim().toLowerCase()
      );

      if (matchedUser) {
        platformUserId = matchedUser.id;
        console.log(`Matched user by email: "${mondayUser.email}" -> ${platformUserId}`);
      } else {
        console.log(`No platform user found for email: "${mondayUser.email}"`);
      }
    }
  } catch (error) {
    console.error('Error matching user by email:', error);
  }

  // Save mapping for future lookups (even if platformUserId is null, we cache the Monday user info)
  if (platformUserId) {
    const { error: insertError } = await supabase
      .from('monday_user_map')
      .insert({
        monday_user_id: mondayUserId,
        platform_user_id: platformUserId,
        email: mondayUser.email,
        name: mondayUser.name
      });

    if (insertError) {
      console.error('Error saving user mapping:', insertError);
    } else {
      console.log(`Saved new user mapping: Monday ${mondayUserId} -> Platform ${platformUserId}`);
    }

    // Also update profiles.full_name if it's empty
    if (mondayUser.name) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', platformUserId)
        .single();

      if (profile && (!profile.full_name || profile.full_name.trim() === '')) {
        const { error: profileError } = await supabase
          .from('profiles')
          .update({ full_name: mondayUser.name })
          .eq('id', platformUserId);

        if (profileError) {
          console.error('Error updating profile name:', profileError);
        } else {
          console.log(`Updated profile full_name for ${platformUserId}: "${mondayUser.name}"`);
        }
      }
    }
  }

  return { platformUserId, mondayUserName: mondayUser.name };
}

// Helper function to match company name to company_id
async function matchCompanyByName(supabase: any, companyText: string): Promise<string | null> {
  if (!companyText || companyText.trim() === '') return null;

  const normalizedSearch = companyText.trim().toLowerCase();

  // First try exact match (case-insensitive)
  const { data: exactMatches } = await supabase
    .from('companies')
    .select('id, name')
    .ilike('name', companyText.trim())
    .limit(1);

  if (exactMatches && exactMatches.length > 0) {
    console.log(`Exact match found: "${companyText}" -> "${exactMatches[0].name}"`);
    return exactMatches[0].id;
  }

  // Then try partial match
  const { data: partialMatches } = await supabase
    .from('companies')
    .select('id, name')
    .ilike('name', `%${companyText.trim()}%`)
    .limit(5);

  if (partialMatches && partialMatches.length > 0) {
    // Find best match - prefer shorter names that contain the search term
    const bestMatch = partialMatches.reduce((best: any, current: any) => {
      const currentLower = current.name.toLowerCase();
      const bestLower = best?.name?.toLowerCase() || '';
      
      // Exact match always wins
      if (currentLower === normalizedSearch) return current;
      if (bestLower === normalizedSearch) return best;
      
      // Prefer name that starts with the search term
      if (currentLower.startsWith(normalizedSearch) && !bestLower.startsWith(normalizedSearch)) return current;
      if (bestLower.startsWith(normalizedSearch) && !currentLower.startsWith(normalizedSearch)) return best;
      
      // Otherwise prefer shorter name
      return current.name.length < (best?.name?.length || Infinity) ? current : best;
    }, null);

    if (bestMatch) {
      console.log(`Partial match found: "${companyText}" -> "${bestMatch.name}"`);
      return bestMatch.id;
    }
  }

  console.log(`No match found for company: "${companyText}"`);
  return null;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json();
    
    // Handle Monday.com webhook challenge
    if (body.challenge) {
      return new Response(
        JSON.stringify({ challenge: body.challenge }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { event } = body;
    
    if (!event) {
      return new Response(
        JSON.stringify({ error: 'No event data' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const boardId = event.boardId?.toString();
    const itemId = event.pulseId?.toString();
    const itemName = event.pulseName;
    const columnId = event.columnId;
    const columnValue = event.value;

    if (!boardId) {
      return new Response(
        JSON.stringify({ error: 'No board ID in event' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Find user config by board_id
    const { data: config, error: configError } = await supabase
      .from('monday_user_config')
      .select('*')
      .eq('board_id', boardId)
      .eq('is_active', true)
      .single();

    if (configError || !config) {
      console.log('No active config found for board:', boardId);
      return new Response(
        JSON.stringify({ skipped: true, reason: 'No config for this board' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Find existing task by monday_item_id
    const { data: existingTask } = await supabase
      .from('tasks')
      .select('*')
      .eq('monday_item_id', itemId)
      .single();

    // Handle different event types
    if (event.type === 'create_pulse' || event.type === 'create_item') {
      // New item created in Monday
      if (existingTask) {
        return new Response(
          JSON.stringify({ skipped: true, reason: 'Task already exists' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Try to match company from Monday.com item details
      let companyId: string | null = null;
      
      if (config.company_column_id && config.monday_api_token_encrypted) {
        try {
          // Decrypt token (stored as base64)
          const apiToken = atob(config.monday_api_token_encrypted);
          const itemDetails = await fetchMondayItemDetails(apiToken, itemId);
          
          if (itemDetails) {
            const companyColumn = itemDetails.column_values?.find(
              (col: any) => col.id === config.company_column_id
            );
            const companyText = companyColumn?.text;
            
            if (companyText) {
              companyId = await matchCompanyByName(supabase, companyText);
              console.log(`Company matching for item ${itemId}: "${companyText}" -> ${companyId || 'no match'}`);
            }
          }
        } catch (error) {
          console.error('Error matching company from Monday:', error);
          // Continue without company - don't fail the entire task creation
        }
      }

      // Create new task with matched company
      const { data: newTask, error: createError } = await supabase
        .from('tasks')
        .insert({
          title: itemName || 'Ny opgave fra Monday',
          status: 'todo',
          priority: 'medium',
          company_id: companyId,
          assigned_to: config.user_id,
          created_by: config.user_id,
          monday_item_id: itemId,
          monday_board_id: boardId,
          monday_last_synced_at: new Date().toISOString(),
          sync_source: 'monday'
        })
        .select()
        .single();

      if (createError) {
        console.error('Error creating task from Monday:', createError);
        return new Response(
          JSON.stringify({ error: 'Failed to create task' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, created: true, taskId: newTask.id, companyId }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (event.type === 'update_column_value' || event.type === 'change_column_value') {
      if (!existingTask) {
        console.log('No existing task for Monday item:', itemId);
        return new Response(
          JSON.stringify({ skipped: true, reason: 'No matching task' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const updates: Record<string, any> = {
        monday_last_synced_at: new Date().toISOString(),
        sync_source: 'monday'
      };

      // Update based on which column changed
      if (columnId === config.status_column_id) {
        const labelValue = columnValue?.label?.text || columnValue?.label;
        if (labelValue && REVERSE_STATUS_MAPPING[labelValue]) {
          updates.status = REVERSE_STATUS_MAPPING[labelValue];
          if (updates.status === 'done') {
            updates.completed_at = new Date().toISOString();
          }
        }
      }

      if (columnId === config.date_column_id) {
        const dateValue = columnValue?.date;
        if (dateValue) {
          updates.due_date = dateValue;
        }
      }

      if (columnId === 'name') {
        updates.title = columnValue;
      }

      // Handle company column changes - match text to company_id
      if (columnId === config.company_column_id) {
        const companyText = columnValue?.text || columnValue;
        if (companyText && typeof companyText === 'string') {
          const companyId = await matchCompanyByName(supabase, companyText);
          if (companyId) {
            updates.company_id = companyId;
            console.log(`Updated company for task ${existingTask.id}: "${companyText}" -> ${companyId}`);
          } else {
            // Clear company if no match found
            updates.company_id = null;
            console.log(`Cleared company for task ${existingTask.id}: no match for "${companyText}"`);
          }
        }
      }

      // Handle assignee column changes - use robust parsing and cached mapping
      if (columnId === config.assignee_column_id) {
        console.log('Processing assignee change, raw value:', JSON.stringify(columnValue));
        
        const { mondayUserId } = parsePersonsAndTeams(columnValue);

        if (mondayUserId && config.monday_api_token_encrypted) {
          const apiToken = atob(config.monday_api_token_encrypted);
          const { platformUserId, mondayUserName } = await getOrCreateUserMapping(supabase, mondayUserId, apiToken);

          if (platformUserId) {
            updates.assigned_to = platformUserId;
            console.log(`Updated assignee for task ${existingTask.id}: Monday user ${mondayUserId} (${mondayUserName}) -> ${platformUserId}`);
          } else {
            console.log(`No platform user found for Monday user ${mondayUserId}`);
          }
        } else if (!mondayUserId) {
          // Person was removed in Monday.com - clear assignee
          updates.assigned_to = null;
          console.log(`Cleared assignee for task ${existingTask.id}`);
        }
      }

      const { error: updateError } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', existingTask.id);

      if (updateError) {
        console.error('Error updating task from Monday:', updateError);
        return new Response(
          JSON.stringify({ error: 'Failed to update task' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, updated: true, taskId: existingTask.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (event.type === 'delete_pulse' || event.type === 'delete_item') {
      if (!existingTask) {
        return new Response(
          JSON.stringify({ skipped: true, reason: 'No matching task' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update task to remove Monday link (don't delete the task)
      const { error: updateError } = await supabase
        .from('tasks')
        .update({
          monday_item_id: null,
          monday_board_id: null,
          monday_last_synced_at: null,
          sync_source: 'platform'
        })
        .eq('id', existingTask.id);

      if (updateError) {
        console.error('Error unlinking task from Monday:', updateError);
      }

      return new Response(
        JSON.stringify({ success: true, unlinked: true, taskId: existingTask.id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ skipped: true, reason: 'Unhandled event type', type: event.type }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Error in monday-user-webhook:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Intern serverfejl', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
