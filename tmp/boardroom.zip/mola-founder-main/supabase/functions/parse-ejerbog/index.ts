import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ParsedEntry {
  owner_name: string;
  owner_type: "person" | "company";
  ownership_pct: number;
  shares: number | null;
  owner_cvr: string | null;
}

interface ParsedEjerbog {
  total_capital: number | null;
  share_denomination: number | null;
  ejerbog_date: string | null;
  entries: ParsedEntry[];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { filePath } = await req.json();
    
    if (!filePath) {
      throw new Error("Ingen filsti angivet");
    }

    // Get Supabase client with service role for storage access
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Download PDF from storage
    const { data: fileData, error: downloadError } = await supabase.storage
      .from("ejerbog-uploads")
      .download(filePath);

    if (downloadError) {
      throw new Error(`Kunne ikke hente fil: ${downloadError.message}`);
    }

    // Convert to base64 for AI processing
    const arrayBuffer = await fileData.arrayBuffer();
    const base64 = btoa(
      new Uint8Array(arrayBuffer).reduce((data, byte) => data + String.fromCharCode(byte), "")
    );

    // Call Lovable AI to extract ejerbog data
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY er ikke konfigureret");
    }

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: `Du er en ekspert i at analysere danske ejerbøger (shareholder registers).
Din opgave er at finde OPSUMMERINGSTABELLEN (typisk sidst i dokumentet) og udtrække ejerskabsdata.

Du skal returnere struktureret JSON med følgende format:
{
  "total_capital": <samlet selskabskapital i DKK som tal>,
  "share_denomination": <stykstørrelse i DKK, typisk 1>,
  "ejerbog_date": "<dokumentets dato i format YYYY-MM-DD, f.eks. 2024-07-11>",
  "entries": [
    {
      "owner_name": "<navn på ejer>",
      "owner_type": "<'person' eller 'company'>",
      "ownership_pct": <procent af kapital som tal>,
      "shares": <nominelt beløb/antal aktier som tal>,
      "owner_cvr": "<CVR nummer hvis angivet, ellers null>"
    }
  ]
}

Regler for owner_type:
- "company" hvis navnet indeholder: ApS, A/S, Holding, IVS, K/S, P/S, I/S
- "person" for alle andre (fysiske personer)

Vigtige tips:
- Find "DATO" på forsiden og konverter til YYYY-MM-DD format (f.eks. "11. juli 2024" → "2024-07-11")
- Find tabellen der viser "Procent af kapital" eller lignende
- Nominelt beløb = antal aktier (stykstørrelse er typisk DKK 1)
- Ignorer transaktionshistorik - fokuser på OPSUMMERINGEN
- Returner KUN valid JSON, ingen markdown eller forklaringer`
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Analysér denne ejerbog og udtræk ejerskabsdata fra opsummeringstabellen:"
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:application/pdf;base64,${base64}`
                }
              }
            ]
          }
        ],
        temperature: 0.1,
        max_tokens: 4000,
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error("AI response error:", errorText);
      
      if (aiResponse.status === 429) {
        throw new Error("Rate limit nået. Prøv igen om lidt.");
      }
      if (aiResponse.status === 402) {
        throw new Error("AI kredit opbrugt. Kontakt support.");
      }
      throw new Error("AI kunne ikke analysere dokumentet");
    }

    const aiData = await aiResponse.json();
    const aiContent = aiData.choices?.[0]?.message?.content;

    if (!aiContent) {
      throw new Error("AI returnerede intet svar");
    }

    // Parse the AI response - extract JSON from potential markdown
    let parsedResult: ParsedEjerbog;
    try {
      // Try to extract JSON from markdown code block if present
      const jsonMatch = aiContent.match(/```(?:json)?\s*([\s\S]*?)\s*```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : aiContent;
      parsedResult = JSON.parse(jsonStr.trim());
    } catch (parseError) {
      console.error("Failed to parse AI response:", aiContent);
      throw new Error("Kunne ikke parse AI-svar til JSON");
    }

    // Validate the parsed result
    if (!parsedResult.entries || !Array.isArray(parsedResult.entries)) {
      throw new Error("Ugyldigt format: Ingen ejere fundet");
    }

    // Clean up and validate entries
    parsedResult.entries = parsedResult.entries.map(entry => ({
      owner_name: entry.owner_name?.trim() || "Ukendt",
      owner_type: entry.owner_type === "company" ? "company" : "person",
      ownership_pct: typeof entry.ownership_pct === "number" ? entry.ownership_pct : 0,
      shares: typeof entry.shares === "number" ? entry.shares : null,
      owner_cvr: entry.owner_cvr || null,
    }));

    // Calculate total ownership to validate
    const totalOwnership = parsedResult.entries.reduce((sum, e) => sum + e.ownership_pct, 0);
    
    console.log(`Parsed ejerbog: ${parsedResult.entries.length} ejere, total: ${totalOwnership.toFixed(2)}%`);

    return new Response(JSON.stringify(parsedResult), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("parse-ejerbog error:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Ukendt fejl ved parsing af ejerbog" 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      }
    );
  }
});
