import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Helper function to replace template variables
const replaceTemplateVariables = (template: string, variables: Record<string, string>): string => {
  let result = template;
  Object.entries(variables).forEach(([key, value]) => {
    // Handle both {{variable}} and {{#if variable}} syntax
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
    // Handle conditional blocks - simple implementation
    const ifRegex = new RegExp(`{{#if ${key}}}([\\s\\S]*?){{/if}}`, 'g');
    if (value) {
      result = result.replace(ifRegex, '$1');
    } else {
      result = result.replace(ifRegex, '');
    }
  });
  return result;
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { requestId, notificationType } = await req.json();
    
    console.log('Sending notification for request:', requestId, 'Type:', notificationType);

    const { data: dataRequest, error: requestError } = await supabaseClient
      .from('data_access_requests')
      .select('*, profiles(*)')
      .eq('id', requestId)
      .single();

    if (requestError || !dataRequest) {
      return new Response(
        JSON.stringify({ error: 'Request not found' }), 
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get user email from auth.users
    const { data: { user }, error: userError } = await supabaseClient.auth.admin.getUserById(
      dataRequest.user_id
    );

    if (userError || !user?.email) {
      console.error('Could not get user email:', userError);
      return new Response(
        JSON.stringify({ error: 'User not found' }), 
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch email template
    const { data: template, error: templateError } = await supabaseClient
      .from('email_templates')
      .select('*')
      .eq('template_key', 'data_request_notification')
      .eq('is_active', true)
      .single();

    if (templateError || !template) {
      console.error('Could not find email template:', templateError);
      return new Response(
        JSON.stringify({ error: 'Email template not found' }), 
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const userName = dataRequest.profiles?.full_name || 'Bruger';
    const requestTypeLabel = getRequestTypeLabel(dataRequest.request_type);
    
    // Prepare template variables based on notification type
    let title = '';
    let message = '';
    let actionUrl = '';
    let actionText = '';

    if (notificationType === 'request_received') {
      title = 'Din data anmodning er modtaget';
      message = 'Vi har modtaget din anmodning om data export. MOLA vil gennemgå din anmodning inden for 1-3 hverdage. Du vil modtage en email når din data er klar til download.';
    } else if (notificationType === 'data_ready') {
      title = 'Dine data er klar til download';
      message = 'Din data export er nu klar. Du kan downloade dine data ved at klikke på knappen nedenfor.';
      actionUrl = 'https://founder.molainvest.dk/support';
      actionText = 'Download data';
    } else if (notificationType === 'request_rejected') {
      title = 'Din data anmodning kunne ikke godkendes';
      message = 'Din anmodning om data export kunne desværre ikke godkendes. Kontakt venligst MOLA support hvis du har spørgsmål.';
    }

    const variables = {
      user_name: userName,
      request_type: requestTypeLabel,
      request_date: new Date(dataRequest.requested_at).toLocaleDateString('da-DK'),
      notification_type: title,
      title: title,
      message: message,
      expiry_date: dataRequest.download_expires_at ? new Date(dataRequest.download_expires_at).toLocaleDateString('da-DK') : '',
      rejection_reason: dataRequest.rejection_reason || '',
      action_url: actionUrl,
      action_text: actionText,
      year: new Date().getFullYear().toString()
    };

    const subject = replaceTemplateVariables(template.subject, variables);
    const htmlBody = replaceTemplateVariables(template.html_body, variables);

    // Send email via Resend
    const resend = new Resend(Deno.env.get('RESEND_API_KEY') as string);
    
    const { error: emailError } = await resend.emails.send({
      from: `${template.from_name} <${template.from_email}>`,
      to: [user.email],
      subject,
      html: htmlBody,
    });

    if (emailError) {
      console.error('Error sending email:', emailError);
      throw emailError;
    }

    console.log('Email sent successfully to:', user.email);

    return new Response(
      JSON.stringify({ success: true, message: 'Notification sent' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('Error sending notification:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});

function getRequestTypeLabel(type: string): string {
  const types: Record<string, string> = {
    personal_data: 'Personlige oplysninger',
    company_data: 'Virksomhedsdata',
    full_export: 'Fuld export'
  };
  return types[type] || type;
}
