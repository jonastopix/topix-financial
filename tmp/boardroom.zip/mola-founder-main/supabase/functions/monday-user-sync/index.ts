import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const STATUS_MAPPING: Record<string, string> = {
  todo: 'To-Do',
  in_progress: 'Working on it',
  done: 'Done',
  cancelled: 'Stuck',
};

const PRIORITY_MAPPING: Record<string, number> = {
  'low': 1,
  'medium': 2,
  'high': 3,
  'urgent': 4
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { taskId, userId, action } = await req.json();

    if (!taskId || !userId) {
      return new Response(
        JSON.stringify({ error: 'Task ID og User ID er påkrævet' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get user's Monday config
    const { data: config, error: configError } = await supabase
      .from('monday_user_config')
      .select('*')
      .eq('user_id', userId)
      .eq('is_active', true)
      .single();

    if (configError || !config) {
      // No active config - skip sync silently
      return new Response(
        JSON.stringify({ skipped: true, reason: 'No active Monday config' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!config.board_id || !config.monday_api_token_encrypted) {
      return new Response(
        JSON.stringify({ skipped: true, reason: 'Incomplete Monday config' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get task details with company info
    const { data: task, error: taskError } = await supabase
      .from('tasks')
      .select('*, company:companies(name)')
      .eq('id', taskId)
      .single();

    if (taskError || !task) {
      return new Response(
        JSON.stringify({ error: 'Task ikke fundet' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Skip if this change came from Monday
    if (task.sync_source === 'monday') {
      // Reset sync_source for next change
      await supabase
        .from('tasks')
        .update({ sync_source: 'platform' })
        .eq('id', taskId);

      return new Response(
        JSON.stringify({ skipped: true, reason: 'Change originated from Monday' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get creator name for assignee field
    let creatorName: string | null = null;
    if (config.assignee_column_id && task.created_by) {
      const { data: creator } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', task.created_by)
        .single();
      creatorName = creator?.full_name || null;
    }

    const decryptedToken = atob(config.monday_api_token_encrypted);

    // Build column values
    const columnValues: Record<string, any> = {};

    const normalizeStatus = (raw: unknown): keyof typeof STATUS_MAPPING | null => {
      if (raw == null) return null;
      const s = String(raw).trim().toLowerCase();
      if (['todo', 'to do', 'to-do', 'to_do', 'not started', 'ikke påbegyndt'].includes(s)) return 'todo';
      if (['in_progress', 'in progress', 'working on it', 'i gang'].includes(s)) return 'in_progress';
      if (['done', 'færdig', 'completed'].includes(s)) return 'done';
      if (['cancelled', 'canceled', 'stuck', 'annulleret'].includes(s)) return 'cancelled';
      return null;
    };

    // Status
    if (config.status_column_id && task.status) {
      const normalized = normalizeStatus(task.status);
      const label = normalized ? STATUS_MAPPING[normalized] : undefined;

      if (label) {
        columnValues[config.status_column_id] = { label };
      } else {
        console.log('Skipping status sync (unmapped status):', { taskId, rawStatus: task.status });
      }
    }

    // Deadline (date)
    if (config.date_column_id && task.due_date) {
      columnValues[config.date_column_id] = { date: task.due_date.split('T')[0] };
    }

    // Company name (text)
    if (config.company_column_id && task.company?.name) {
      columnValues[config.company_column_id] = task.company.name;
    }

    // Assignee (People column - auto-match via email)
    if (config.assignee_column_id && task.assigned_to) {
      // Get assigned user's email from profiles
      const { data: assignedUser } = await supabase
        .from('profiles')
        .select('email')
        .eq('id', task.assigned_to)
        .single();

      let mondayUserId: string | null = null;

      if (assignedUser?.email) {
        // Fetch all Monday.com users and find match by email
        const usersResponse = await fetch('https://api.monday.com/v2', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': decryptedToken,
          },
          body: JSON.stringify({
            query: `query { users(limit: 100) { id email } }`
          }),
        });

        const usersData = await usersResponse.json();
        const mondayUsers = usersData.data?.users || [];
        
        // Find Monday.com user with matching email (case-insensitive)
        const matchedUser = mondayUsers.find(
          (u: { id: string; email: string }) => 
            u.email?.toLowerCase() === assignedUser.email?.toLowerCase()
        );

        if (matchedUser) {
          mondayUserId = matchedUser.id;
          console.log('Matched Monday user by email:', { email: assignedUser.email, mondayUserId });
        } else {
          console.log('No Monday user found for email:', assignedUser.email);
        }
      }

      // Fallback to integration owner's Monday user ID
      if (!mondayUserId && config.monday_user_id) {
        mondayUserId = config.monday_user_id;
        console.log('Using fallback Monday user ID:', mondayUserId);
      }

      if (mondayUserId) {
        columnValues[config.assignee_column_id] = {
          personsAndTeams: [{
            id: parseInt(mondayUserId),
            kind: "person"
          }]
        };
      }
    }

    // Link to platform (link)
    if (config.link_column_id) {
      const taskUrl = `https://mola-founder.lovable.app/tasks?taskId=${task.id}`;
      columnValues[config.link_column_id] = {
        url: taskUrl,
        text: 'Åbn i MOLA'
      };
    }

    if (action === 'delete' && task.monday_item_id) {
      // Delete item from Monday
      const deleteResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `mutation { delete_item(item_id: ${task.monday_item_id}) { id } }`
        }),
      });

      const deleteData = await deleteResponse.json();
      
      if (deleteData.errors) {
        console.error('Error deleting from Monday:', deleteData.errors);
      }

      return new Response(
        JSON.stringify({ success: true, deleted: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (task.monday_item_id) {
      // Update existing item
      const updateResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `mutation ($itemId: ID!, $boardId: ID!, $columnValues: JSON!) {
            change_multiple_column_values(item_id: $itemId, board_id: $boardId, column_values: $columnValues) {
              id
              name
            }
          }`,
          variables: {
            itemId: task.monday_item_id,
            boardId: config.board_id,
            columnValues: JSON.stringify(columnValues)
          }
        }),
      });

      const updateData = await updateResponse.json();

      if (updateData.errors) {
        console.error('Error updating Monday item:', updateData.errors);
        return new Response(
          JSON.stringify({ error: 'Kunne ikke opdatere Monday item', details: updateData.errors }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Also update item name if title changed
      await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `mutation { change_simple_column_value(item_id: ${task.monday_item_id}, board_id: ${config.board_id}, column_id: "name", value: "${task.title.replace(/"/g, '\\"')}") { id } }`
        }),
      });

      // Update last sync time
      await supabase
        .from('tasks')
        .update({ 
          monday_last_synced_at: new Date().toISOString(),
          sync_source: 'platform'
        })
        .eq('id', taskId);

      await supabase
        .from('monday_user_config')
        .update({ last_sync_at: new Date().toISOString() })
        .eq('user_id', userId);

      return new Response(
        JSON.stringify({ success: true, updated: true, itemId: task.monday_item_id }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );

    } else {
      // Create new item
      const createResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `mutation ($boardId: ID!, $itemName: String!, $columnValues: JSON!, $groupId: String) {
            create_item(board_id: $boardId, item_name: $itemName, column_values: $columnValues, group_id: $groupId) {
              id
              name
            }
          }`,
          variables: {
            boardId: config.board_id,
            itemName: task.title,
            columnValues: JSON.stringify(columnValues),
            groupId: config.group_id || undefined
          }
        }),
      });

      const createData = await createResponse.json();

      if (createData.errors) {
        console.error('Error creating Monday item:', createData.errors);
        return new Response(
          JSON.stringify({ error: 'Kunne ikke oprette Monday item', details: createData.errors }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const newItemId = createData.data.create_item.id;

      // Update task with Monday item ID
      await supabase
        .from('tasks')
        .update({ 
          monday_item_id: newItemId,
          monday_board_id: config.board_id,
          monday_last_synced_at: new Date().toISOString(),
          sync_source: 'platform'
        })
        .eq('id', taskId);

      await supabase
        .from('monday_user_config')
        .update({ last_sync_at: new Date().toISOString() })
        .eq('user_id', userId);

      return new Response(
        JSON.stringify({ success: true, created: true, itemId: newItemId }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error: unknown) {
    console.error('Error in monday-user-sync:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Intern serverfejl', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
