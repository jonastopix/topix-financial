import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendTestEmailRequest {
  templateId: string;
  testEmail: string;
}

const replaceVariables = (html: string, variables: string[]): string => {
  let result = html;
  
  // Default test values for common variables
  const testValues: Record<string, string> = {
    inviter_name: 'Test Bruger',
    role_name: 'Administrator',
    company_name: 'Test Virksomhed ApS',
    fund_name: 'Test Fund I',
    invitation_url: 'https://example.com/invitation/test-token',
    status_class: 'received',
    status_title: 'Test Status',
    status_message: 'Dette er en test besked',
    request_type: 'Personlige Data',
    download_url: 'https://example.com/download/test-file',
    rejection_reason: 'Test afvisningsårsag',
  };
  
  variables.forEach((variable) => {
    const value = testValues[variable] || `[TEST: ${variable}]`;
    
    // Replace simple variables like {{variable}}
    result = result.replace(new RegExp(`{{${variable}}}`, 'g'), value);
    
    // Handle conditional variables like {{#variable}}...{{/variable}}
    if (value && !value.startsWith('[TEST:')) {
      result = result.replace(
        new RegExp(`{{#${variable}}}([\\s\\S]*?){{/${variable}}}`, 'g'),
        '$1'
      );
    } else {
      result = result.replace(
        new RegExp(`{{#${variable}}}[\\s\\S]*?{{/${variable}}}`, 'g'),
        ''
      );
    }
  });
  
  return result;
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const resend = new Resend(Deno.env.get('RESEND_API_KEY') as string);

    const { templateId, testEmail }: SendTestEmailRequest = await req.json();

    console.log('Fetching template:', templateId);

    // Fetch the template from the database
    const { data: template, error: templateError } = await supabase
      .from('email_templates')
      .select('*')
      .eq('id', templateId)
      .single();

    if (templateError) {
      console.error('Error fetching template:', templateError);
      throw new Error('Template not found');
    }

    console.log('Template found:', template.template_name);

    // Replace variables with test values
    const htmlBody = replaceVariables(template.html_body, template.available_variables);
    const subject = replaceVariables(template.subject, template.available_variables);

    console.log('Sending test email to:', testEmail);

    // Send the email
    const { data, error } = await resend.emails.send({
      from: `${template.from_name} <${template.from_email}>`,
      to: [testEmail],
      subject: `[TEST] ${subject}`,
      html: htmlBody,
      text: template.text_body || undefined,
    });

    if (error) {
      console.error('Error sending email:', error);
      throw error;
    }

    console.log('Test email sent successfully:', data);

    return new Response(
      JSON.stringify({ success: true, message: 'Test email sent successfully' }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in send-test-email function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
};

serve(handler);
