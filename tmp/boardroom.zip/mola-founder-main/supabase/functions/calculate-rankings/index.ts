import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CompanyMetrics {
  company_id: string;
  ytd_revenue: number;
  latest_month_revenue: number;
  growth_rate: number;
  ebitda_margin: number | null;
  customer_count: number;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting portfolio rankings calculation...');
    
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;

    // Fetch all active companies
    const { data: companies, error: companiesError } = await supabase
      .from('companies')
      .select('id')
      .eq('is_active', true);

    if (companiesError) throw companiesError;
    if (!companies || companies.length === 0) {
      console.log('No active companies found');
      return new Response(JSON.stringify({ message: 'No companies to rank' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const companyIds = companies.map(c => c.id);

    // Fetch monthly reports for all companies
    const { data: reports, error: reportsError } = await supabase
      .from('monthly_reports')
      .select('*')
      .in('company_id', companyIds);

    if (reportsError) throw reportsError;
    if (!reports || reports.length === 0) {
      console.log('No reports found');
      return new Response(JSON.stringify({ message: 'No reports to rank' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Calculate metrics for each company
    const companyMetrics: CompanyMetrics[] = companies.map(company => {
      const companyReports = reports.filter(r => r.company_id === company.id);
      
      // YTD Revenue
      const ytdRevenue = companyReports
        .filter(r => r.period_year === currentYear)
        .reduce((sum, r) => sum + (r.revenue_dkk || 0), 0);

      // Latest month revenue
      const latestReport = companyReports
        .filter(r => r.period_year === currentYear && r.period_month === currentMonth - 1)
        .sort((a, b) => b.period_month - a.period_month)[0];
      
      const latestMonthRevenue = latestReport?.revenue_dkk || 0;

      // Growth rate (MoM)
      const previousMonth = companyReports
        .filter(r => {
          if (currentMonth === 1) {
            return r.period_year === currentYear - 1 && r.period_month === 12;
          }
          return r.period_year === currentYear && r.period_month === currentMonth - 2;
        })[0];
      
      const growthRate = previousMonth && previousMonth.revenue_dkk > 0
        ? ((latestMonthRevenue - previousMonth.revenue_dkk) / previousMonth.revenue_dkk) * 100
        : 0;

      // EBITDA Margin - only calculate if we have actual data
      const ebitdaMargin = latestReport && latestReport.revenue_dkk > 0 && latestReport.ebitda_dkk !== null
        ? (latestReport.ebitda_dkk / latestReport.revenue_dkk) * 100
        : null;

      // Customer count
      const customerCount = latestReport?.new_customers || 0;

      return {
        company_id: company.id,
        ytd_revenue: ytdRevenue,
        latest_month_revenue: latestMonthRevenue,
        growth_rate: growthRate,
        ebitda_margin: ebitdaMargin,
        customer_count: customerCount,
        has_data: latestReport !== undefined, // Track if company has submitted data
      };
    });

    const totalCompanies = companyMetrics.length;
    const rankings: Array<{
      company_id: string;
      metric_type: string;
      rank: number;
      percentile: number;
      metric_value: number;
      total_companies: number;
      period_year: number;
      period_month: number;
    }> = [];

    // Calculate rankings for each metric
    const metrics = [
      { type: 'ytd_revenue', key: 'ytd_revenue' as keyof CompanyMetrics },
      { type: 'latest_month_revenue', key: 'latest_month_revenue' as keyof CompanyMetrics },
      { type: 'growth_rate', key: 'growth_rate' as keyof CompanyMetrics },
      { type: 'ebitda_margin', key: 'ebitda_margin' as keyof CompanyMetrics },
      { type: 'customer_count', key: 'customer_count' as keyof CompanyMetrics },
    ];

    for (const metric of metrics) {
      // Filter out companies without data for EBITDA margin
      const relevantCompanies = metric.type === 'ebitda_margin'
        ? companyMetrics.filter(c => c.ebitda_margin !== null)
        : companyMetrics;
      
      const sorted = [...relevantCompanies].sort((a, b) => {
        const aVal = Number(a[metric.key]);
        const bVal = Number(b[metric.key]);
        return bVal - aVal;
      });

      sorted.forEach((company, index) => {
        const rank = index + 1;
        const percentile = ((sorted.length - rank) / sorted.length) * 100;

        rankings.push({
          company_id: company.company_id,
          metric_type: metric.type,
          rank,
          percentile: Math.round(percentile),
          metric_value: Number(company[metric.key]),
          total_companies: sorted.length, // Use filtered count for EBITDA margin
          period_year: currentYear,
          period_month: currentMonth - 1,
        });
      });
    }

    // Delete old rankings for current period
    await supabase
      .from('portfolio_rankings')
      .delete()
      .eq('period_year', currentYear)
      .eq('period_month', currentMonth - 1);

    // Insert new rankings
    const { error: insertError } = await supabase
      .from('portfolio_rankings')
      .insert(rankings);

    if (insertError) throw insertError;

    console.log(`Successfully calculated and stored ${rankings.length} rankings for ${totalCompanies} companies`);

    return new Response(
      JSON.stringify({
        success: true,
        companies: totalCompanies,
        rankings: rankings.length,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error calculating rankings:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});