import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ManageInvitationRequest {
  action: 'cancel' | 'resend';
  invitationId: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get JWT from authorization header
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      console.error('No authorization header');
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client with service role key for admin operations
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Extract token from authorization header
    const token = authHeader.replace('Bearer ', '');

    // Verify user is authenticated via supabaseAdmin
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);
    if (userError || !user) {
      console.error('User verification failed:', userError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify user is admin
    const { data: roles, error: rolesError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    if (rolesError) {
      console.error('Error fetching user roles:', rolesError);
      return new Response(
        JSON.stringify({ error: 'Failed to verify admin status' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const isAdmin = roles?.some(r => r.role === 'owner' || r.role === 'mola_admin');
    if (!isAdmin) {
      console.error('User is not admin:', user.id);
      return new Response(
        JSON.stringify({ error: 'Forbidden: Admin access required' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse request body
    const { action, invitationId }: ManageInvitationRequest = await req.json();

    if (!action || !invitationId) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: action and invitationId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Managing invitation: ${invitationId}, action: ${action}`);

    if (action === 'cancel') {
      // Delete invitation completely
      const { error: deleteError } = await supabaseAdmin
        .from('user_invitations')
        .delete()
        .eq('id', invitationId);

      if (deleteError) {
        console.error('Error deleting invitation:', deleteError);
        return new Response(
          JSON.stringify({ error: 'Failed to delete invitation' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log('Invitation deleted successfully');
      return new Response(
        JSON.stringify({ success: true, message: 'Invitation deleted' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );

    } else if (action === 'resend') {
      // First, get the invitation details
      const { data: invitation, error: fetchError } = await supabaseAdmin
        .from('user_invitations')
        .select('email, invited_role, company_id, fund_id, notes')
        .eq('id', invitationId)
        .single();

      if (fetchError || !invitation) {
        console.error('Error fetching invitation:', fetchError);
        return new Response(
          JSON.stringify({ error: 'Invitation not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update expiration date and status to pending
      const { error: updateError } = await supabaseAdmin
        .from('user_invitations')
        .update({ 
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          status: 'pending'
        })
        .eq('id', invitationId);

      if (updateError) {
        console.error('Error updating invitation expiry:', updateError);
        return new Response(
          JSON.stringify({ error: 'Failed to update invitation' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Call invite-user function to resend the email
      const { data: inviteData, error: inviteError } = await supabaseAdmin.functions.invoke('invite-user', {
        body: {
          email: invitation.email,
          role: invitation.invited_role,
          companyId: invitation.company_id,
          fundId: invitation.fund_id,
          notes: invitation.notes,
        },
      });

      if (inviteError) {
        console.error('Error resending invitation email:', inviteError);
        return new Response(
          JSON.stringify({ error: 'Failed to resend invitation email' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      console.log('Invitation resent successfully');
      return new Response(
        JSON.stringify({ success: true, message: 'Invitation resent' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );

    } else {
      return new Response(
        JSON.stringify({ error: 'Invalid action. Must be "cancel" or "resend"' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

  } catch (error) {
    console.error('Unexpected error in manage-invitation:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
