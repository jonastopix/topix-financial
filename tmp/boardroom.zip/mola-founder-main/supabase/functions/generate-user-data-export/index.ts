import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Check admin permission
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user } } = await supabaseClient.auth.getUser(token);
    
    if (!user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }), 
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if admin
    const { data: isAdmin } = await supabaseClient.rpc('is_admin', { _user_id: user.id });
    if (!isAdmin) {
      return new Response(
        JSON.stringify({ error: 'Forbidden - Admin access required' }), 
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get request details
    const { requestId } = await req.json();
    
    console.log('Processing data export request:', requestId);

    const { data: dataRequest, error: requestError } = await supabaseClient
      .from('data_access_requests')
      .select('*, profiles(*)')
      .eq('id', requestId)
      .single();

    if (requestError || !dataRequest) {
      return new Response(
        JSON.stringify({ error: 'Request not found' }), 
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Generate data based on request_type
    let exportData: any = {};
    const targetUserId = dataRequest.user_id;

    console.log('Generating export for user:', targetUserId, 'Type:', dataRequest.request_type);

    if (dataRequest.request_type === 'personal_data') {
      // Only personal info
      const { data: profile } = await supabaseClient
        .from('profiles')
        .select('full_name, company_name, created_at')
        .eq('id', targetUserId)
        .single();
      
      exportData = { profile };
    } else if (dataRequest.request_type === 'company_data') {
      // Company related data created by user
      const { data: tasks } = await supabaseClient
        .from('tasks')
        .select('*')
        .eq('created_by', targetUserId);

      const { data: meetings } = await supabaseClient
        .from('company_meetings')
        .select('*')
        .eq('created_by', targetUserId);

      exportData = { tasks, meetings };
    } else if (dataRequest.request_type === 'full_export') {
      // Full export - MOLA controls what is included
      const { data: profile } = await supabaseClient
        .from('profiles')
        .select('*')
        .eq('id', targetUserId)
        .single();

      const { data: tasks } = await supabaseClient
        .from('tasks')
        .select('*')
        .eq('created_by', targetUserId);

      const { data: meetings } = await supabaseClient
        .from('company_meetings')
        .select('*')
        .eq('created_by', targetUserId);

      exportData = { profile, tasks, meetings };
    }

    // Generate JSON file
    const jsonData = JSON.stringify(exportData, null, 2);
    const fileName = `${targetUserId}/mola_data_export_${Date.now()}.json`;

    console.log('Uploading file:', fileName);

    // Upload to storage bucket
    const { data: uploadData, error: uploadError } = await supabaseClient.storage
      .from('data-exports')
      .upload(fileName, jsonData, {
        contentType: 'application/json',
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      throw uploadError;
    }

    // Update request status
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

    const { error: updateError } = await supabaseClient
      .from('data_access_requests')
      .update({
        status: 'completed',
        file_path: uploadData.path,
        file_generated_at: new Date().toISOString(),
        download_expires_at: expiresAt.toISOString(),
        processed_by: user.id,
        processed_at: new Date().toISOString()
      })
      .eq('id', requestId);

    if (updateError) {
      console.error('Update error:', updateError);
      throw updateError;
    }

    console.log('Data export completed successfully');

    return new Response(
      JSON.stringify({ success: true, filePath: uploadData.path }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('Error generating data export:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
