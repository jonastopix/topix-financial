import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MondayBoard {
  id: string;
  name: string;
  columns?: Array<{
    id: string;
    title: string;
    type: string;
  }>;
}

interface MondayColumn {
  id: string;
  title: string;
  type: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Ingen autorisation' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: 'Ugyldig bruger' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { action, apiToken, boardId, columnMapping } = await req.json();

    if (action === 'validate_and_fetch_boards') {
      // Validate API token and fetch boards - exclude subitem boards
      const boardsResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': apiToken,
        },
        body: JSON.stringify({
          query: `query { boards(limit: 50, board_kind: public) { id name board_kind } }`
        }),
      });

      const boardsData = await boardsResponse.json();

      if (boardsData.errors) {
        return new Response(
          JSON.stringify({ error: 'Ugyldig API token', details: boardsData.errors }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Filter out subitem boards (they have names starting with "Subitems of")
      const mainBoards = (boardsData.data.boards as MondayBoard[]).filter(
        (board: MondayBoard) => !board.name.toLowerCase().startsWith('subitems of')
      );

      // Fetch the current user's Monday.com info
      const meResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': apiToken,
        },
        body: JSON.stringify({
          query: `query { me { id name } }`
        }),
      });

      const meData = await meResponse.json();
      const mondayUserId = meData.data?.me?.id?.toString() || null;
      const mondayUserName = meData.data?.me?.name || null;

      // Encrypt and store the API token
      const encryptedToken = btoa(apiToken); // Simple base64 for now - can be enhanced with proper encryption

      // Upsert user config with Monday user info
      const { error: upsertError } = await supabase
        .from('monday_user_config')
        .upsert({
          user_id: user.id,
          monday_api_token_encrypted: encryptedToken,
          monday_user_id: mondayUserId,
          monday_user_name: mondayUserName,
        }, {
          onConflict: 'user_id'
        });

      if (upsertError) {
        console.error('Error upserting config:', upsertError);
        return new Response(
          JSON.stringify({ error: 'Kunne ikke gemme konfiguration' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          boards: mainBoards,
          mondayUser: mondayUserName ? { id: mondayUserId, name: mondayUserName } : null
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'select_board') {
      // Fetch board columns for mapping
      const { data: config } = await supabase
        .from('monday_user_config')
        .select('monday_api_token_encrypted')
        .eq('user_id', user.id)
        .single();

      if (!config?.monday_api_token_encrypted) {
        return new Response(
          JSON.stringify({ error: 'Ingen API token fundet' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const decryptedToken = atob(config.monday_api_token_encrypted);

      // Fetch board details with columns
      const boardResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `query { boards(ids: [${boardId}]) { id name columns { id title type } groups { id title } } }`
        }),
      });

      const boardData = await boardResponse.json();

      if (boardData.errors || !boardData.data.boards.length) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke hente board detaljer' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const board = boardData.data.boards[0];

      // Update config with board selection
      const { error: updateError } = await supabase
        .from('monday_user_config')
        .update({
          board_id: boardId,
          board_name: board.name,
        })
        .eq('user_id', user.id);

      if (updateError) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke opdatere konfiguration' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          board: {
            id: board.id,
            name: board.name,
            columns: board.columns,
            groups: board.groups,
          }
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'save_column_mapping') {
      // Save the user's column mapping preferences
      const { 
        status_column_id, 
        date_column_id, 
        company_column_id, 
        link_column_id, 
        assignee_column_id 
      } = columnMapping || {};

      // Get config to fetch board_id and token
      const { data: existingConfig } = await supabase
        .from('monday_user_config')
        .select('board_id, monday_api_token_encrypted')
        .eq('user_id', user.id)
        .single();

      if (!existingConfig?.board_id || !existingConfig?.monday_api_token_encrypted) {
        return new Response(
          JSON.stringify({ error: 'Mangler board eller token' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const { error: updateError } = await supabase
        .from('monday_user_config')
        .update({
          status_column_id,
          date_column_id,
          company_column_id,
          link_column_id,
          assignee_column_id,
          is_active: true, // Activate when column mapping is saved
        })
        .eq('user_id', user.id);

      if (updateError) {
        console.error('Error saving column mapping:', updateError);
        return new Response(
          JSON.stringify({ error: 'Kunne ikke gemme kolonne-mapping' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Create webhooks for Monday.com events
      const decryptedToken = atob(existingConfig.monday_api_token_encrypted);
      const webhookUrl = `${supabaseUrl}/functions/v1/monday-user-webhook`;
      const events = ['create_item', 'change_column_value'];
      const webhookIds: string[] = [];

      for (const event of events) {
        try {
          const response = await fetch('https://api.monday.com/v2', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': decryptedToken,
            },
            body: JSON.stringify({
              query: `mutation { create_webhook(board_id: ${existingConfig.board_id}, url: "${webhookUrl}", event: ${event}) { id } }`
            }),
          });
          
          const data = await response.json();
          console.log(`Webhook creation for ${event}:`, JSON.stringify(data));
          
          if (data.data?.create_webhook?.id) {
            webhookIds.push(data.data.create_webhook.id.toString());
          }
        } catch (webhookError) {
          console.error(`Error creating webhook for ${event}:`, webhookError);
        }
      }

      // Save webhook IDs
      if (webhookIds.length > 0) {
        await supabase
          .from('monday_user_config')
          .update({ webhook_id: JSON.stringify(webhookIds) })
          .eq('user_id', user.id);
      }

      return new Response(
        JSON.stringify({ success: true, webhooksCreated: webhookIds.length }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'fetch_columns') {
      // Fetch columns for an already selected board
      const { data: config } = await supabase
        .from('monday_user_config')
        .select('monday_api_token_encrypted, board_id')
        .eq('user_id', user.id)
        .single();

      if (!config?.monday_api_token_encrypted || !config?.board_id) {
        return new Response(
          JSON.stringify({ error: 'Ingen board valgt' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const decryptedToken = atob(config.monday_api_token_encrypted);

      const boardResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `query { boards(ids: [${config.board_id}]) { columns { id title type } } }`
        }),
      });

      const boardData = await boardResponse.json();

      if (boardData.errors || !boardData.data.boards.length) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke hente kolonner' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          columns: boardData.data.boards[0].columns
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'fetch_boards_with_saved_token') {
      // Fetch boards using saved token - no need to re-enter
      const { data: config } = await supabase
        .from('monday_user_config')
        .select('monday_api_token_encrypted')
        .eq('user_id', user.id)
        .single();

      if (!config?.monday_api_token_encrypted) {
        return new Response(
          JSON.stringify({ error: 'Ingen gemt API token fundet', needsReauth: true }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const decryptedToken = atob(config.monday_api_token_encrypted);

      // Validate token and fetch boards
      const boardsResponse = await fetch('https://api.monday.com/v2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': decryptedToken,
        },
        body: JSON.stringify({
          query: `query { boards(limit: 50, board_kind: public) { id name board_kind } }`
        }),
      });

      const boardsData = await boardsResponse.json();

      if (boardsData.errors) {
        return new Response(
          JSON.stringify({ error: 'Token er ikke længere gyldig', needsReauth: true }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Filter out subitem boards
      const mainBoards = (boardsData.data.boards as MondayBoard[]).filter(
        (board: MondayBoard) => !board.name.toLowerCase().startsWith('subitems of')
      );

      return new Response(
        JSON.stringify({ success: true, boards: mainBoards }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'activate') {
      const { error } = await supabase
        .from('monday_user_config')
        .update({ is_active: true })
        .eq('user_id', user.id);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke aktivere sync' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'deactivate') {
      const { error } = await supabase
        .from('monday_user_config')
        .update({ is_active: false })
        .eq('user_id', user.id);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke deaktivere sync' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'disconnect') {
      // Fetch config to get webhook_id and token
      const { data: configToDelete } = await supabase
        .from('monday_user_config')
        .select('webhook_id, monday_api_token_encrypted')
        .eq('user_id', user.id)
        .single();

      // Delete webhooks from Monday.com
      if (configToDelete?.webhook_id && configToDelete?.monday_api_token_encrypted) {
        try {
          const decryptedToken = atob(configToDelete.monday_api_token_encrypted);
          const webhookIds = JSON.parse(configToDelete.webhook_id);
          
          for (const id of webhookIds) {
            await fetch('https://api.monday.com/v2', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': decryptedToken,
              },
              body: JSON.stringify({
                query: `mutation { delete_webhook(id: ${id}) { id } }`
              }),
            });
          }
        } catch (webhookError) {
          console.error('Error deleting webhooks:', webhookError);
        }
      }

      const { error } = await supabase
        .from('monday_user_config')
        .delete()
        .eq('user_id', user.id);

      if (error) {
        return new Response(
          JSON.stringify({ error: 'Kunne ikke fjerne forbindelse' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ success: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (action === 'recreate_webhook') {
      // Recreate webhook for existing users without one
      const { data: configForWebhook } = await supabase
        .from('monday_user_config')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (!configForWebhook?.board_id || !configForWebhook?.monday_api_token_encrypted) {
        return new Response(
          JSON.stringify({ error: 'Mangler board eller token' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const decryptedToken = atob(configForWebhook.monday_api_token_encrypted);
      const webhookUrl = `${supabaseUrl}/functions/v1/monday-user-webhook`;
      const events = ['create_item', 'change_column_value'];
      const webhookIds: string[] = [];

      for (const event of events) {
        try {
          const response = await fetch('https://api.monday.com/v2', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': decryptedToken,
            },
            body: JSON.stringify({
              query: `mutation { create_webhook(board_id: ${configForWebhook.board_id}, url: "${webhookUrl}", event: ${event}) { id } }`
            }),
          });
          
          const data = await response.json();
          console.log(`Webhook creation for ${event}:`, JSON.stringify(data));
          
          if (data.data?.create_webhook?.id) {
            webhookIds.push(data.data.create_webhook.id.toString());
          }
        } catch (webhookError) {
          console.error(`Error creating webhook for ${event}:`, webhookError);
        }
      }

      // Save webhook IDs
      if (webhookIds.length > 0) {
        await supabase
          .from('monday_user_config')
          .update({ webhook_id: JSON.stringify(webhookIds) })
          .eq('user_id', user.id);
      }

      return new Response(
        JSON.stringify({ success: true, webhookCount: webhookIds.length }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Ukendt handling' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Error in monday-connect:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: 'Intern serverfejl', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
