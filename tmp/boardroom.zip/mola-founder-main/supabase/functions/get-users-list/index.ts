import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verify admin status
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    const isAdmin = roles?.some(r => r.role === 'owner' || r.role === 'mola_admin');
    if (!isAdmin) {
      throw new Error('Forbidden: Admin access required');
    }

    // Get query params
    const url = new URL(req.url);
    const search = url.searchParams.get('search') || '';
    const roleFilter = url.searchParams.get('role');
    const statusFilter = url.searchParams.get('status');
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = parseInt(url.searchParams.get('limit') || '50');
    const offset = (page - 1) * limit;

    // Fetch all users from auth.users via service role
    const { data: authUsers, error: usersError } = await supabase.auth.admin.listUsers({
      page,
      perPage: limit,
    });

    if (usersError) throw usersError;

    // Get user IDs
    const userIds = authUsers.users.map(u => u.id);

    // Fetch profiles
    let profilesQuery = supabase
      .from('profiles')
      .select('*')
      .in('id', userIds);

    if (statusFilter === 'active') {
      profilesQuery = profilesQuery.eq('is_active', true);
    } else if (statusFilter === 'inactive') {
      profilesQuery = profilesQuery.eq('is_active', false);
    }

    const { data: profiles } = await profilesQuery;

    // Fetch user roles
    const { data: userRoles } = await supabase
      .from('user_roles')
      .select('user_id, role')
      .in('user_id', userIds);

    // Fetch companies
    const companyIds = profiles?.map(p => p.company_id).filter(Boolean) || [];
    const { data: companies } = companyIds.length > 0 
      ? await supabase.from('companies').select('id, name').in('id', companyIds)
      : { data: [] };

    // Combine data
    const users = authUsers.users.map(authUser => {
      const profile = profiles?.find(p => p.id === authUser.id);
      const roles = userRoles?.filter(r => r.user_id === authUser.id).map(r => r.role) || [];
      const company = companies?.find(c => c.id === profile?.company_id);

      return {
        id: authUser.id,
        email: authUser.email,
        full_name: profile?.full_name || '',
        company_name: profile?.company_name || company?.name || '',
        company_id: profile?.company_id,
        fund_id: profile?.fund_id,
        roles,
        is_active: profile?.is_active ?? true,
        last_sign_in_at: authUser.last_sign_in_at,
        created_at: authUser.created_at,
      };
    });

    // Apply filters
    let filteredUsers = users;

    if (search) {
      const searchLower = search.toLowerCase();
      filteredUsers = filteredUsers.filter(u =>
        u.email?.toLowerCase().includes(searchLower) ||
        u.full_name?.toLowerCase().includes(searchLower) ||
        u.company_name?.toLowerCase().includes(searchLower)
      );
    }

    if (roleFilter) {
      filteredUsers = filteredUsers.filter(u => u.roles.includes(roleFilter));
    }

    console.log(`Fetched ${filteredUsers.length} users`);

    return new Response(
      JSON.stringify({ 
        users: filteredUsers,
        total: filteredUsers.length,
        page,
        limit,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error fetching users:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
