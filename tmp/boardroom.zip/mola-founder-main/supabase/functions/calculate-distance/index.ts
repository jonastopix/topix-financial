import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GeocodeResult {
  lat: number;
  lon: number;
}

interface RouteResult {
  distance_km: number;
  duration_minutes: number;
}

// Helper: sleep for backoff
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Helper function to fetch with timeout
async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 10000): Promise<Response> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });
    return response;
  } finally {
    clearTimeout(timeoutId);
  }
}

function isUnexpectedEOF(error: unknown) {
  return error instanceof Error && error.message.toLowerCase().includes('unexpected end of file');
}

async function fetchJsonWithRetry<T>(
  url: string,
  options: RequestInit,
  timeoutMs: number,
  attempts = 3
): Promise<T> {
  let lastError: unknown;

  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      const response = await fetchWithTimeout(url, options, timeoutMs);

      if (!response.ok) {
        const statusText = `${response.status} ${response.statusText}`;
        // Retry on transient server errors / rate limiting
        if ((response.status >= 500 || response.status === 429) && attempt < attempts) {
          console.warn(`HTTP ${statusText} for ${url} (attempt ${attempt}/${attempts}) - retrying`);
          await sleep(250 * attempt);
          continue;
        }
        throw new Error(`HTTP ${statusText}`);
      }

      // Read as arrayBuffer to avoid some edge-runtime streaming quirks
      const buf = await response.arrayBuffer();
      const text = new TextDecoder().decode(buf);
      if (!text || text.trim() === '') {
        throw new Error('Empty response body');
      }
      return JSON.parse(text) as T;
    } catch (error) {
      lastError = error;

      // Retry on flaky connections / truncated responses
      if (isUnexpectedEOF(error) && attempt < attempts) {
        console.warn(`Unexpected EOF for ${url} (attempt ${attempt}/${attempts}) - retrying`);
        await sleep(250 * attempt);
        continue;
      }

      // Retry on timeouts
      if (error instanceof Error && error.name === 'AbortError' && attempt < attempts) {
        console.warn(`Timeout for ${url} (attempt ${attempt}/${attempts}) - retrying`);
        await sleep(250 * attempt);
        continue;
      }

      break;
    }
  }

  throw lastError instanceof Error ? lastError : new Error('Request failed');
}

// Primary: Use DAWA (Danmarks Adressers Web API) for Danish addresses
// NOTE: We use struktur=flad to reliably get WGS84 coordinates.
async function geocodeWithDAWA(address: string): Promise<GeocodeResult | null> {
  const cleanAddress = address.trim().replace(/\s+/g, ' ');
  const encodedAddress = encodeURIComponent(cleanAddress);

  // Setting Accept-Encoding: identity reduces the chance of truncated/compressed payload issues
  // in the edge runtime.
  const dawaHeaders = {
    'Accept': 'application/json',
    'User-Agent': 'MolaFounderApp/1.0 (mileage-calculation)',
    'Accept-Encoding': 'identity',
    'Connection': 'close',
  };

  const tryParseCoords = (row: any): GeocodeResult | null => {
    const lat = Number(row?.wgs84koordinat_bredde ?? row?.y ?? row?.adgangsadresse?.wgs84koordinat_bredde ?? row?.adgangsadresse?.y);
    const lon = Number(row?.["wgs84koordinat_længde"] ?? row?.x ?? row?.adgangsadresse?.["wgs84koordinat_længde"] ?? row?.adgangsadresse?.x);

    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
    return { lat, lon };
  };

  try {
    const url = `https://api.dataforsyningen.dk/adresser?q=${encodedAddress}&fuzzy&struktur=flad`;
    console.log(`DAWA url: ${url}`);

    const data = await fetchJsonWithRetry<any[]>(
      url,
      { headers: dawaHeaders },
      8000,
      3
    );

    if (Array.isArray(data) && data.length > 0) {
      const coords = tryParseCoords(data[0]);
      if (coords) {
        console.log(`DAWA: Found address: ${data[0].adressebetegnelse ?? data[0].betegnelse ?? cleanAddress}`);
        return coords;
      }
    }

    // Fallback: try adgangsadresser (can match even if floor/door is missing)
    const adgangUrl = `https://api.dataforsyningen.dk/adgangsadresser?q=${encodedAddress}&fuzzy&struktur=flad`;
    console.log(`DAWA adgangsadresser url: ${adgangUrl}`);

    const adgangData = await fetchJsonWithRetry<any[]>(
      adgangUrl,
      { headers: dawaHeaders },
      8000,
      3
    );

    if (Array.isArray(adgangData) && adgangData.length > 0) {
      const coords = tryParseCoords(adgangData[0]);
      if (coords) {
        console.log(`DAWA: Found adgangsadresse: ${adgangData[0].adressebetegnelse ?? adgangData[0].betegnelse ?? cleanAddress}`);
        return coords;
      }
    }

    console.log(`DAWA: No usable results for address: ${cleanAddress}`);
    return null;
  } catch (error) {
    console.error(`DAWA geocoding error for "${cleanAddress}":`, error);
    return null;
  }
}

// Fallback: Use Nominatim (OpenStreetMap) for non-Danish addresses
async function geocodeWithNominatim(address: string): Promise<GeocodeResult | null> {
  try {
    // Add ", Danmark" to improve results for Danish addresses
    const searchAddress = address.toLowerCase().includes('denmark') || address.toLowerCase().includes('danmark') 
      ? address 
      : `${address}, Danmark`;
    
    const encodedAddress = encodeURIComponent(searchAddress);
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodedAddress}&limit=1&addressdetails=1`;
    console.log(`Nominatim URL: ${url}`);
    
    const response = await fetchWithTimeout(
      url,
      {
        headers: {
          'User-Agent': 'MolaFounderApp/1.0 (mileage-calculation)',
          'Accept': 'application/json',
        },
      },
      10000
    );

    if (!response.ok) {
      console.error(`Nominatim error: ${response.status} ${response.statusText}`);
      return null;
    }

    const text = await response.text();
    if (!text || text.trim() === '') {
      console.error(`Nominatim: Empty response for address: ${address}`);
      return null;
    }

    const data = JSON.parse(text);
    
    if (!data || !Array.isArray(data) || data.length === 0) {
      console.error(`Nominatim: No results for address: ${address}`);
      return null;
    }

    console.log(`Nominatim: Found address: ${data[0].display_name}`);
    return {
      lat: parseFloat(data[0].lat),
      lon: parseFloat(data[0].lon),
    };
  } catch (error) {
    if (error instanceof Error && error.name === 'AbortError') {
      console.error(`Nominatim timeout for "${address}"`);
    } else {
      console.error(`Nominatim geocoding error for "${address}":`, error);
    }
    return null;
  }
}

// Combined function: Try DAWA first, then fall back to Nominatim
async function geocodeAddress(address: string): Promise<GeocodeResult | null> {
  console.log(`Geocoding address: ${address}`);

  // Try DAWA first (optimized for Danish addresses)
  const dawaResult = await geocodeWithDAWA(address);
  if (dawaResult && Number.isFinite(dawaResult.lat) && Number.isFinite(dawaResult.lon)) {
    console.log(`DAWA success: ${dawaResult.lat}, ${dawaResult.lon}`);
    return dawaResult;
  }

  // Fallback to Nominatim for non-Danish or unrecognized addresses
  console.log(`Falling back to Nominatim for: ${address}`);
  const nominatimResult = await geocodeWithNominatim(address);
  if (nominatimResult && Number.isFinite(nominatimResult.lat) && Number.isFinite(nominatimResult.lon)) {
    console.log(`Nominatim success: ${nominatimResult.lat}, ${nominatimResult.lon}`);
    return nominatimResult;
  }

  console.error(`Failed to geocode address: ${address}`);
  return null;
}

// Calculate driving route using OSRM
async function calculateRoute(from: GeocodeResult, to: GeocodeResult): Promise<RouteResult | null> {
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${from.lon},${from.lat};${to.lon},${to.lat}?overview=false`;
    console.log(`OSRM URL: ${url}`);
    
    const response = await fetchWithTimeout(
      url,
      {
        headers: {
          'User-Agent': 'MolaFounderApp/1.0 (mileage-calculation)',
        },
      },
      10000
    );

    if (!response.ok) {
      console.error(`OSRM error: ${response.status}`);
      return null;
    }

    const data = await response.json();

    if (data.code !== 'Ok' || !data.routes || data.routes.length === 0) {
      console.error('OSRM returned no routes:', data);
      return null;
    }

    const route = data.routes[0];
    
    return {
      distance_km: Math.round((route.distance / 1000) * 10) / 10, // Round to 1 decimal
      duration_minutes: Math.round(route.duration / 60),
    };
  } catch (error) {
    console.error('Route calculation error:', error);
    return null;
  }
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { fromAddress, toAddress } = await req.json();

    if (!fromAddress || !toAddress) {
      return new Response(
        JSON.stringify({ error: 'Both fromAddress and toAddress are required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Calculating distance from "${fromAddress}" to "${toAddress}"`);

    // Geocode both addresses in parallel
    const [fromCoords, toCoords] = await Promise.all([
      geocodeAddress(fromAddress),
      geocodeAddress(toAddress),
    ]);

    if (!fromCoords) {
      return new Response(
        JSON.stringify({ error: 'Could not geocode from-address', address: fromAddress }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!toCoords) {
      return new Response(
        JSON.stringify({ error: 'Could not geocode to-address', address: toAddress }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`From coords: ${fromCoords.lat}, ${fromCoords.lon}`);
    console.log(`To coords: ${toCoords.lat}, ${toCoords.lon}`);

    // Calculate route
    const route = await calculateRoute(fromCoords, toCoords);

    if (!route) {
      return new Response(
        JSON.stringify({ error: 'Could not calculate route between addresses' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Distance: ${route.distance_km} km, Duration: ${route.duration_minutes} min`);

    return new Response(
      JSON.stringify({
        distance_km: route.distance_km,
        duration_minutes: route.duration_minutes,
        from_coords: fromCoords,
        to_coords: toCoords,
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  } catch (error) {
    console.error('Error in calculate-distance:', error);
    const errorMessage = error instanceof Error ? error.message : 'Internal server error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
