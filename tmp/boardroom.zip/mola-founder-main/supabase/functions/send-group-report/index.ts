import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface SendGroupReportRequest {
  recipients: string[];
  subject: string;
  htmlContent: string;
  personalMessage?: string;
  senderName?: string;
  perspectiveLabel: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: "Missing authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !user) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const { 
      recipients, 
      subject, 
      htmlContent, 
      personalMessage,
      senderName,
      perspectiveLabel 
    }: SendGroupReportRequest = await req.json();

    // Validate recipients
    if (!recipients || recipients.length === 0) {
      return new Response(
        JSON.stringify({ error: "No recipients specified" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const invalidEmails = recipients.filter(email => !emailRegex.test(email.trim()));
    if (invalidEmails.length > 0) {
      return new Response(
        JSON.stringify({ error: `Invalid email addresses: ${invalidEmails.join(", ")}` }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Build email HTML with personal message wrapper
    const emailHtml = `
<!DOCTYPE html>
<html lang="da">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <div style="max-width: 800px; margin: 0 auto; background-color: #ffffff;">
    <!-- Header -->
    <div style="background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); padding: 30px; text-align: center;">
      <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
        MOLA Koncernoverblik
      </h1>
      <p style="color: #a0aec0; margin: 10px 0 0 0; font-size: 14px;">
        ${perspectiveLabel}
      </p>
    </div>

    ${personalMessage ? `
    <!-- Personal Message -->
    <div style="padding: 25px 30px; background-color: #f8fafc; border-bottom: 1px solid #e2e8f0;">
      <p style="margin: 0 0 10px 0; font-size: 14px; color: #64748b;">
        Besked fra ${senderName || 'afsender'}:
      </p>
      <p style="margin: 0; font-size: 15px; color: #1e293b; line-height: 1.6; white-space: pre-wrap;">
        ${personalMessage}
      </p>
    </div>
    ` : ''}

    <!-- Report Content -->
    <div style="padding: 0;">
      ${htmlContent}
    </div>

    <!-- Footer -->
    <div style="padding: 25px 30px; background-color: #f8fafc; border-top: 1px solid #e2e8f0; text-align: center;">
      <p style="margin: 0; font-size: 12px; color: #94a3b8;">
        Denne rapport er automatisk genereret og sendt fra MOLA Founder Portal
      </p>
      <p style="margin: 10px 0 0 0; font-size: 12px; color: #94a3b8;">
        Sendt af: ${senderName || user.email} • ${new Date().toLocaleDateString('da-DK', { 
          day: 'numeric', 
          month: 'long', 
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        })}
      </p>
    </div>
  </div>
</body>
</html>
    `;

    // Send email to all recipients
    const emailResponse = await resend.emails.send({
      from: "MOLA Portal <noreply@founder.molainvest.dk>",
      to: recipients.map(email => email.trim()),
      subject: subject,
      html: emailHtml,
    });

    console.log("Group report email sent successfully:", emailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Rapport sendt til ${recipients.length} modtager(e)`,
        emailId: emailResponse.data?.id 
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in send-group-report function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
