import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { cvr } = await req.json();

    // Validate CVR format (8 digits)
    if (!cvr || !/^\d{8}$/.test(cvr)) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: 'CVR skal være 8 cifre' 
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    console.log(`Looking up CVR: ${cvr}`);

    // Call CVRapi.dk without API key
    const response = await fetch(
      `https://cvrapi.dk/api?search=${cvr}&country=dk`,
      {
        headers: {
          'User-Agent': 'MOLA-Portfolio-System',
        },
      }
    );

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: 'For mange forespørgsler. Prøv igen om 1 minut' 
          }),
          { 
            status: 429, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }

      if (response.status === 404) {
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: 'CVR-nummer ikke fundet i CVR-registret' 
          }),
          { 
            status: 404, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }

      throw new Error(`CVR API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('CVR data fetched successfully:', data.name);

    // Return structured data
    return new Response(
      JSON.stringify({
        success: true,
        data: {
          name: data.name || '',
          startdate: data.startdate || '',
          companytype: data.companytype || '',
          address: data.address || '',
          city: data.city || '',
          zipcode: data.zipcode || '',
          email: data.email || '',
          phone: data.phone || '',
          industrycode: data.industrycode || '',
          industrydesc: data.industrydesc || '',
        },
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in lookup-cvr:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: (error as Error).message || 'Fejl ved hentning af CVR data' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
