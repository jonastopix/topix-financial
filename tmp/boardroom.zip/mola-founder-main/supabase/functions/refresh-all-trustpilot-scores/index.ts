import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log("Starting batch refresh of all Trustpilot scores...");

    // Get all profiles
    const { data: profiles, error: profilesError } = await supabase
      .from("company_trustpilot_profiles")
      .select("id, company_id, country_code");

    if (profilesError) {
      console.error("Failed to fetch profiles:", profilesError);
      return new Response(
        JSON.stringify({ error: "Failed to fetch profiles", details: profilesError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!profiles || profiles.length === 0) {
      console.log("No Trustpilot profiles found to refresh");
      return new Response(
        JSON.stringify({ success: true, message: "No profiles to refresh", profiles_updated: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Found ${profiles.length} profiles to refresh`);

    const results: Array<{ profile_id: string; success: boolean; error?: string }> = [];
    let successCount = 0;
    let errorCount = 0;

    for (const profile of profiles) {
      try {
        console.log(`Refreshing profile ${profile.id} (${profile.country_code})...`);
        
        const response = await supabase.functions.invoke("fetch-trustpilot-score", {
          body: { profile_id: profile.id },
        });

        if (response.error) {
          console.error(`Error refreshing profile ${profile.id}:`, response.error);
          results.push({ profile_id: profile.id, success: false, error: response.error.message });
          errorCount++;
        } else {
          console.log(`Successfully refreshed profile ${profile.id}`);
          results.push({ profile_id: profile.id, success: true });
          successCount++;
        }
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : "Unknown error";
        console.error(`Exception refreshing profile ${profile.id}:`, errorMessage);
        results.push({ profile_id: profile.id, success: false, error: errorMessage });
        errorCount++;
      }

      // Rate limiting - wait 500ms between requests to avoid overloading Firecrawl
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    console.log(`Batch refresh complete: ${successCount} success, ${errorCount} errors`);

    return new Response(
      JSON.stringify({
        success: true,
        total_profiles: profiles.length,
        profiles_updated: successCount,
        profiles_failed: errorCount,
        results,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    console.error("Batch refresh error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
