import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { company_id } = await req.json();

    if (!company_id) {
      return new Response(
        JSON.stringify({ error: "company_id is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get all profiles for this company
    const { data: profiles, error: profilesError } = await supabase
      .from("company_trustpilot_profiles")
      .select("id, country_code, country_name")
      .eq("company_id", company_id);

    if (profilesError) {
      return new Response(
        JSON.stringify({ error: "Failed to fetch profiles", details: profilesError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!profiles || profiles.length === 0) {
      return new Response(
        JSON.stringify({ error: "No Trustpilot profiles found for this company" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch scores for each profile
    const results = [];
    const errors = [];

    for (const profile of profiles) {
      try {
        const response = await supabase.functions.invoke("fetch-trustpilot-score", {
          body: { profile_id: profile.id },
        });

        if (response.error) {
          errors.push({
            profile_id: profile.id,
            country_code: profile.country_code,
            error: response.error.message,
          });
        } else {
          results.push({
            profile_id: profile.id,
            country_code: profile.country_code,
            ...response.data,
          });
        }
      } catch (err: unknown) {
        errors.push({
          profile_id: profile.id,
          country_code: profile.country_code,
          error: err instanceof Error ? err.message : "Unknown error",
        });
      }

      // Small delay between requests to avoid rate limiting
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    return new Response(
      JSON.stringify({
        success: true,
        company_id,
        profiles_updated: results.length,
        profiles_failed: errors.length,
        results,
        errors: errors.length > 0 ? errors : undefined,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
