import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface RatingBreakdown {
  five: number;
  four: number;
  three: number;
  two: number;
  one: number;
}

interface ParsedScore {
  score: number | null;
  totalReviews: number | null;
  ratingBreakdown: RatingBreakdown | null;
  recentScore: number | null;
  recentReviewsCount: number;
}

function parseMarkdownForScore(markdown: string): ParsedScore {
  const result: ParsedScore = {
    score: null,
    totalReviews: null,
    ratingBreakdown: null,
    recentScore: null,
    recentReviewsCount: 0,
  };

  console.log("Parsing markdown, length:", markdown.length);
  console.log("Markdown preview (first 3000 chars):", markdown.substring(0, 3000));

  // Parse TrustScore - various patterns including Danish
  const scorePatterns = [
    /TrustScore[:\s]*\**(\d+[,\.]?\d*)\**/i,
    /score[:\s]*\**(\d+[,\.]?\d*)\**/i,
    /(\d+[,\.]?\d*)\s*(?:out of|ud af)\s*5/i,
    /rating[:\s]*\**(\d+[,\.]?\d*)\**/i,
    // Danish patterns - look for score near "Fremragende", "Fantastisk" etc.
    /Fremragende[^]*?(\d+[,\.]?\d*)/i,
    // Look for bold numbers that could be scores
    /\*\*(\d+[,\.]?\d*)\*\*\s*(?:TrustScore|score)?/i,
    // Score in format "4,8" or "4.8"
    /(?:gennemsnit|average)[:\s]*(\d+[,\.]?\d*)/i,
  ];
  
  for (const pattern of scorePatterns) {
    const match = markdown.match(pattern);
    if (match && match[1]) {
      // Handle Danish decimal separator (comma)
      const score = parseFloat(match[1].replace(',', '.'));
      if (score >= 1 && score <= 5) {
        result.score = score;
        console.log("Found score:", score, "with pattern:", pattern.source);
        break;
      }
    }
  }

  // Parse total reviews - multiple patterns including Danish
  const reviewPatterns = [
    /(\d[\d\.\s,]*)\s*(?:total\s+)?(?:reviews?|anmeldelser)/i,
    /(?:based on|baseret på)\s*\**(\d[\d\.\s,]*)\**/i,
    /(\d[\d\.\s,]*)\s*bewertungen/i,
    // Pattern: "81 anmeldelser" or "1.234 anmeldelser"
    /\|\s*(\d[\d\.\s,]*)\s*(?:reviews?|anmeldelser)/i,
    // Look for review count in brackets or after vertical bar
    /(?:i alt|total)[:\s]*(\d[\d\.\s,]*)/i,
  ];
  
  for (const pattern of reviewPatterns) {
    const match = markdown.match(pattern);
    if (match && match[1]) {
      // Remove spaces, dots (as thousand separator), and commas
      const reviews = parseInt(match[1].replace(/[\s\.]/g, '').replace(',', ''));
      if (reviews > 0) {
        result.totalReviews = reviews;
        console.log("Found total reviews:", reviews, "with pattern:", pattern.source);
        break;
      }
    }
  }

  // Parse rating breakdown - Danish and English patterns
  const breakdown: RatingBreakdown = { five: 0, four: 0, three: 0, two: 0, one: 0 };
  
  // Danish rating labels mapping
  const breakdownPatterns = [
    { 
      key: 'five', 
      patterns: [
        /5\s*(?:stars?|stjerner?)[\s:]*(\d+)\s*%/i,
        /(?:Fremragende|Excellent|5-stjernet)[\s:]*(\d+)\s*%/i,
        /(\d+)\s*%\s*(?:Fremragende|Excellent)/i,
        /Fremragende\s*\n?\s*(\d+)%/i,
        /5\s*(?:stjerne|star)[^\d]*(\d+)%/i,
      ] 
    },
    { 
      key: 'four', 
      patterns: [
        /4\s*(?:stars?|stjerner?)[\s:]*(\d+)\s*%/i,
        /(?:Fantastisk|Great|4-stjernet)[\s:]*(\d+)\s*%/i,
        /(\d+)\s*%\s*(?:Fantastisk|Great)/i,
        /Fantastisk\s*\n?\s*(\d+)%/i,
        /4\s*(?:stjerne|star)[^\d]*(\d+)%/i,
      ] 
    },
    { 
      key: 'three', 
      patterns: [
        /3\s*(?:stars?|stjerner?)[\s:]*(\d+)\s*%/i,
        /(?:Gennemsnitlig|Average|3-stjernet)[\s:]*(\d+)\s*%/i,
        /(\d+)\s*%\s*(?:Gennemsnitlig|Average)/i,
        /Gennemsnitlig\s*\n?\s*(\d+)%/i,
        /3\s*(?:stjerne|star)[^\d]*(\d+)%/i,
      ] 
    },
    { 
      key: 'two', 
      patterns: [
        /2\s*(?:stars?|stjerner?)[\s:]*(\d+)\s*%/i,
        /(?:Dårlig|Poor|2-stjernet)[\s:]*(\d+)\s*%/i,
        /(\d+)\s*%\s*(?:Dårlig|Poor)/i,
        /Dårlig\s*\n?\s*(\d+)%/i,
        /2\s*(?:stjerne|star)[^\d]*(\d+)%/i,
      ] 
    },
    { 
      key: 'one', 
      patterns: [
        /1\s*(?:stars?|stjerner?)[\s:]*(\d+)\s*%/i,
        /(?:Elendig|Bad|1-stjernet)[\s:]*(\d+)\s*%/i,
        /(\d+)\s*%\s*(?:Elendig|Bad)/i,
        /Elendig\s*\n?\s*(\d+)%/i,
        /1\s*(?:stjerne|star)[^\d]*(\d+)%/i,
      ] 
    },
  ];

  for (const { key, patterns } of breakdownPatterns) {
    for (const pattern of patterns) {
      const match = markdown.match(pattern);
      if (match && match[1]) {
        breakdown[key as keyof RatingBreakdown] = parseInt(match[1]);
        console.log(`Found ${key} stars:`, match[1], "%");
        break;
      }
    }
  }

  // Alternative: Try to find breakdown in table format
  // Pattern: "Fremragende | 98%" or "5 stjerner | 98%"
  if (breakdown.five === 0) {
    const tablePattern = /(?:Fremragende|Excellent|5[- ]?stjerne?r?)\s*\|?\s*(\d+)\s*%/gi;
    const tableMatch = markdown.match(tablePattern);
    if (tableMatch && tableMatch[0]) {
      const pctMatch = tableMatch[0].match(/(\d+)\s*%/);
      if (pctMatch) {
        breakdown.five = parseInt(pctMatch[1]);
        console.log("Found 5-star from table format:", breakdown.five);
      }
    }
  }

  // Only set breakdown if we found at least some data
  if (breakdown.five > 0 || breakdown.four > 0 || breakdown.three > 0) {
    result.ratingBreakdown = breakdown;
    console.log("Rating breakdown:", breakdown);
  }

  // Parse recent reviews for trend analysis
  const recentReviews: number[] = [];
  
  // Look for individual review ratings with dates
  // Danish date patterns: "for X dage siden", "X timer siden", "i går"
  const reviewPatternsDanish = [
    // "For 2 dage siden" with star rating
    /(?:★{1,5}|(\d)\s*(?:stars?|stjerner?))[^]*?(?:for\s*)?(\d+)\s*(?:dag(?:e)?|time(?:r)?)\s*siden/gi,
    // "i går" = yesterday
    /(?:★{1,5}|(\d)\s*(?:stars?|stjerner?))[^]*?i\s*går/gi,
    // English patterns
    /(?:★{1,5}|(\d)\s*(?:stars?))[^]*?(\d+)\s*(?:days?|hours?)\s*ago/gi,
  ];

  // Also look for review blocks that mention recent dates
  // Pattern: "Bedømt med X stjerner" followed by date
  const ratedPattern = /(?:Bedømt med|Rated)\s*(\d)\s*(?:stjerner?|stars?)[^]*?(?:for\s*)?(\d+)\s*(?:dag|day|time|hour)/gi;
  
  let ratedMatch;
  while ((ratedMatch = ratedPattern.exec(markdown)) !== null) {
    const rating = parseInt(ratedMatch[1]);
    const timeValue = parseInt(ratedMatch[2]);
    
    if (rating >= 1 && rating <= 5 && timeValue <= 30) {
      recentReviews.push(rating);
      console.log("Found recent review rating:", rating, "from", timeValue, "days/hours ago");
    }
  }

  // Alternative: Look for star symbols followed by date indicators
  const starDatePattern = /(★{1,5})[^★]*?(?:(?:for\s*)?(\d+)\s*(?:dag|time|day|hour)|i\s*går|yesterday)/gi;
  let starMatch;
  while ((starMatch = starDatePattern.exec(markdown)) !== null) {
    const starCount = starMatch[1].length;
    if (starCount >= 1 && starCount <= 5 && recentReviews.length < 50) {
      recentReviews.push(starCount);
      console.log("Found recent review from star pattern:", starCount, "stars");
    }
  }

  // Look for explicit ratings like "5 out of 5" or "5 ud af 5" near dates
  const explicitRatingPattern = /(\d)\s*(?:out of|ud af)\s*5[^]*?(?:(?:for\s*)?(\d+)\s*(?:dag|time|day|hour)|i\s*går|yesterday)/gi;
  let explicitMatch;
  while ((explicitMatch = explicitRatingPattern.exec(markdown)) !== null) {
    const rating = parseInt(explicitMatch[1]);
    if (rating >= 1 && rating <= 5 && recentReviews.length < 50) {
      recentReviews.push(rating);
      console.log("Found recent review from explicit rating:", rating);
    }
  }

  // Fallback: If we have overall score but no recent reviews, 
  // look for any ratings that appear in review-like contexts
  if (recentReviews.length === 0 && result.score) {
    // Look for patterns like "Verified review" or "Bekræftet anmeldelse" with stars
    const verifiedPattern = /(?:Verified|Bekræftet)[^]*?(★{1,5}|(\d)\s*(?:stjerner?|stars?))/gi;
    let verifiedMatch;
    let count = 0;
    while ((verifiedMatch = verifiedPattern.exec(markdown)) !== null && count < 20) {
      const stars = verifiedMatch[1]?.match(/★/g)?.length || parseInt(verifiedMatch[2] || '0');
      if (stars >= 1 && stars <= 5) {
        recentReviews.push(stars);
        count++;
      }
    }
  }

  if (recentReviews.length > 0) {
    result.recentScore = Number((recentReviews.reduce((a, b) => a + b, 0) / recentReviews.length).toFixed(1));
    result.recentReviewsCount = recentReviews.length;
    console.log("Recent reviews found:", recentReviews.length, "Average:", result.recentScore);
  }

  console.log("Final parsed result:", JSON.stringify(result));
  return result;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { profile_id } = await req.json();

    if (!profile_id) {
      return new Response(
        JSON.stringify({ error: "profile_id is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const firecrawlApiKey = Deno.env.get("FIRECRAWL_API_KEY");

    if (!firecrawlApiKey) {
      return new Response(
        JSON.stringify({ error: "FIRECRAWL_API_KEY not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get the profile
    const { data: profile, error: profileError } = await supabase
      .from("company_trustpilot_profiles")
      .select("*")
      .eq("id", profile_id)
      .single();

    if (profileError || !profile) {
      return new Response(
        JSON.stringify({ error: "Profile not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Fetching Trustpilot data for:", profile.trustpilot_url);

    // Scrape the Trustpilot page using Firecrawl
    const scrapeResponse = await fetch("https://api.firecrawl.dev/v1/scrape", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${firecrawlApiKey}`,
      },
      body: JSON.stringify({
        url: profile.trustpilot_url,
        formats: ["markdown"],
        onlyMainContent: false, // Get full page to capture all review data
      }),
    });

    if (!scrapeResponse.ok) {
      const errorText = await scrapeResponse.text();
      console.error("Firecrawl error:", errorText);
      return new Response(
        JSON.stringify({ error: "Failed to scrape Trustpilot page", details: errorText }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const scrapeData = await scrapeResponse.json();
    const markdown = scrapeData.data?.markdown || "";

    if (!markdown) {
      return new Response(
        JSON.stringify({ error: "No content returned from Trustpilot page" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Received markdown content, length:", markdown.length);

    // Parse the markdown to extract score data
    const parsedScore = parseMarkdownForScore(markdown);

    // Upsert score into database
    const { data: scoreData, error: upsertError } = await supabase
      .from("trustpilot_scores")
      .upsert({
        profile_id: profile_id,
        score: parsedScore.score,
        total_reviews: parsedScore.totalReviews,
        rating_breakdown: parsedScore.ratingBreakdown,
        recent_score: parsedScore.recentScore,
        recent_reviews_count: parsedScore.recentReviewsCount,
        recent_period_days: 30,
        last_fetched_at: new Date().toISOString(),
      }, {
        onConflict: "profile_id",
      })
      .select()
      .single();

    if (upsertError) {
      console.error("Database error:", upsertError);
      return new Response(
        JSON.stringify({ error: "Failed to save score", details: upsertError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Add to history
    await supabase.from("trustpilot_score_history").insert({
      profile_id: profile_id,
      score: parsedScore.score,
      total_reviews: parsedScore.totalReviews,
      recent_score: parsedScore.recentScore,
    });

    return new Response(
      JSON.stringify({
        success: true,
        profile_id,
        country_code: profile.country_code,
        score: parsedScore,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
