import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

// Generate iCalendar file for meeting invitation or update
function generateICalFile(params: {
  uid: string;
  title: string;
  startTime: string;
  duration: number;
  participants: string[];
  organizer: string;
  description?: string;
}) {
  const start = new Date(params.startTime);
  const end = new Date(start.getTime() + params.duration * 60000);
  
  const formatICalDate = (date: Date) => {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };

  const attendees = params.participants
    .map(email => `ATTENDEE;CN=${email};RSVP=TRUE:mailto:${email}`)
    .join('\r\n');

  return `BEGIN:VCALENDAR\r
VERSION:2.0\r
PRODID:-//MOLA Portfolio//Meeting//EN\r
METHOD:REQUEST\r
BEGIN:VEVENT\r
UID:${params.uid}\r
DTSTAMP:${formatICalDate(new Date())}\r
DTSTART:${formatICalDate(start)}\r
DTEND:${formatICalDate(end)}\r
SUMMARY:${params.title}\r
DESCRIPTION:${params.description || ''}\r
ORGANIZER;CN=MOLA Portfolio:mailto:${params.organizer}\r
${attendees}\r
STATUS:CONFIRMED\r
SEQUENCE:0\r
END:VEVENT\r
END:VCALENDAR`;
}

// Generate iCalendar cancellation
function generateICalCancellation(params: {
  uid: string;
  title: string;
  startTime: string;
  participants: string[];
  organizer: string;
}) {
  const start = new Date(params.startTime);
  const formatICalDate = (date: Date) => {
    return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
  };

  const attendees = params.participants
    .map(email => `ATTENDEE;CN=${email}:mailto:${email}`)
    .join('\r\n');

  return `BEGIN:VCALENDAR\r
VERSION:2.0\r
PRODID:-//MOLA Portfolio//Meeting//EN\r
METHOD:CANCEL\r
BEGIN:VEVENT\r
UID:${params.uid}\r
DTSTAMP:${formatICalDate(new Date())}\r
DTSTART:${formatICalDate(start)}\r
SUMMARY:${params.title}\r
ORGANIZER;CN=MOLA Portfolio:mailto:${params.organizer}\r
${attendees}\r
STATUS:CANCELLED\r
SEQUENCE:1\r
END:VEVENT\r
END:VCALENDAR`;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const payload = await req.json();
    console.log('Calendly webhook received:', payload.event);

    const eventType = payload.event;
    const eventData = payload.payload;

    // Extract invitee information
    const inviteeEmail = eventData.email;
    const inviteeName = eventData.name;
    const eventUuid = eventData.uri?.split('/').pop() || eventData.event?.uri?.split('/').pop();
    const eventName = eventData.event?.name || eventData.name || 'Portfolio Møde';
    const startTime = eventData.scheduled_event?.start_time || eventData.start_time;
    const endTime = eventData.scheduled_event?.end_time || eventData.end_time;

    console.log(`Processing ${eventType} for ${inviteeEmail}`);

    // Handle invitee.created (new booking)
    if (eventType === 'invitee.created') {
      // Find founder by email
      const { data: founder, error: founderError } = await supabase
        .from('profiles')
        .select('id, full_name, company_id, email')
        .eq('email', inviteeEmail)
        .not('company_id', 'is', null)
        .maybeSingle();

      if (founderError || !founder) {
        console.error('Founder not found for email:', inviteeEmail, founderError);
        return new Response(
          JSON.stringify({ error: 'Founder not found' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get company and preferences
      const { data: company, error: companyError } = await supabase
        .from('companies')
        .select('*, responsible_partner_id')
        .eq('id', founder.company_id)
        .single();

      if (companyError) {
        console.error('Company not found:', companyError);
        throw companyError;
      }

      // Get fund partner (organizer)
      const { data: fundPartner, error: partnerError } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .not('calendly_link', 'is', null)
        .limit(1)
        .single();

      if (partnerError || !fundPartner) {
        console.error('Fund partner not found:', partnerError);
        throw new Error('Fund partner not configured');
      }

      // Build participants array
      const participants: any[] = [
        { id: fundPartner.id, name: fundPartner.full_name, email: fundPartner.email },
        { id: founder.id, name: founder.full_name, email: founder.email }
      ];

      // Auto-invite responsible partner
      if (company.auto_invite_responsible_partner && company.responsible_partner_id) {
        const { data: responsiblePartner } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .eq('id', company.responsible_partner_id)
          .single();
        
        if (responsiblePartner && responsiblePartner.email) {
          participants.push({
            id: responsiblePartner.id,
            name: responsiblePartner.full_name,
            email: responsiblePartner.email
          });
        }
      }

      // Auto-invite co-investors
      if (company.auto_invite_coinvestors) {
        const { data: coinvestors } = await supabase
          .from('company_cap_table')
          .select('user_id, owner_name, owner_email')
          .eq('company_id', company.id)
          .not('user_id', 'is', null)
          .not('owner_email', 'is', null);

        if (coinvestors) {
          for (const investor of coinvestors) {
            participants.push({
              id: investor.user_id,
              name: investor.owner_name,
              email: investor.owner_email
            });
          }
        }
      }

      // Auto-invite DD partners
      if (company.auto_invite_dd_partners) {
        const { data: ddPartners } = await supabase
          .from('dd_partner_assignments')
          .select('user_id, profiles!inner(full_name, email)')
          .eq('company_id', company.id);

        if (ddPartners) {
          for (const assignment of ddPartners) {
            const profile = assignment.profiles as any;
            if (profile && profile.email) {
              participants.push({
                id: assignment.user_id,
                name: profile.full_name,
                email: profile.email
              });
            }
          }
        }
      }

      // Calculate duration in minutes
      const duration = Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 60000);

      // Generate unique iCal UID
      const icalUid = `${eventUuid}@mola-portfolio`;

      // Create meeting in database
      const { data: meeting, error: meetingError } = await supabase
        .from('company_meetings')
        .insert({
          company_id: company.id,
          meeting_date: new Date(startTime).toISOString().split('T')[0],
          duration_minutes: duration,
          meeting_type: 'check_in',
          title: `${eventName}: ${company.name}`,
          participants: participants,
          calendly_event_uuid: eventUuid,
          ical_uid: icalUid,
          created_by: founder.id,
          notes: `Booket via Calendly af ${inviteeName}`
        })
        .select()
        .single();

      if (meetingError) {
        console.error('Error creating meeting:', meetingError);
        throw meetingError;
      }

      console.log(`Meeting created: ${meeting.id}`);

      // Generate iCal file
      const icsContent = generateICalFile({
        uid: icalUid,
        title: meeting.title,
        startTime: startTime,
        duration: duration,
        participants: participants.map(p => p.email),
        organizer: fundPartner.email,
        description: `Portfolio møde med ${company.name}`
      });

      // Get email template
      const { data: template } = await supabase
        .from('email_templates')
        .select('*')
        .eq('template_key', 'meeting_calendar_invite')
        .eq('is_active', true)
        .single();

      if (template) {
        // Send calendar invites to all participants except fund partner (who booked it)
        const recipientsToNotify = participants.filter(p => p.id !== fundPartner.id);

        for (const participant of recipientsToNotify) {
          const participantsHtml = participants.map(p => `<li>${p.name}</li>`).join('');
          const participantsText = participants.map(p => p.name).join(', ');

          let htmlBody = template.html_body
            .replace(/\{\{company_name\}\}/g, company.name)
            .replace(/\{\{meeting_title\}\}/g, meeting.title)
            .replace(/\{\{meeting_datetime\}\}/g, new Date(startTime).toLocaleString('da-DK'))
            .replace(/\{\{duration_minutes\}\}/g, duration.toString())
            .replace(/\{\{participants_html\}\}/g, participantsHtml)
            .replace(/\{\{participants_text\}\}/g, participantsText);

          let subject = template.subject
            .replace(/\{\{meeting_title\}\}/g, meeting.title);

          await resend.emails.send({
            from: `${template.from_name} <${template.from_email}>`,
            to: [participant.email],
            subject: subject,
            html: htmlBody,
            attachments: [{
              filename: 'meeting.ics',
              content: btoa(icsContent),
            }]
          });
        }
      }

      // Update meeting invitation status
      await supabase
        .from('meeting_invitations')
        .update({ status: 'booked' })
        .eq('company_id', company.id)
        .eq('status', 'sent');

      return new Response(
        JSON.stringify({ success: true, meetingId: meeting.id }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Handle invitee.rescheduled (meeting changed)
    if (eventType === 'invitee.rescheduled') {
      const { data: meeting, error: meetingError } = await supabase
        .from('company_meetings')
        .select('*, companies(name)')
        .eq('calendly_event_uuid', eventUuid)
        .single();

      if (meetingError || !meeting) {
        console.error('Meeting not found for reschedule:', eventUuid);
        return new Response(
          JSON.stringify({ error: 'Meeting not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const oldDateTime = new Date(meeting.meeting_date).toLocaleString('da-DK');
      const newDateTime = new Date(startTime).toLocaleString('da-DK');

      // Update meeting
      const { error: updateError } = await supabase
        .from('company_meetings')
        .update({
          meeting_date: new Date(startTime).toISOString().split('T')[0],
          calendly_reschedule_count: (meeting.calendly_reschedule_count || 0) + 1,
          notes: `${meeting.notes || ''}\n\n🔄 Omlagt ${new Date().toLocaleString('da-DK')}: Fra ${oldDateTime} til ${newDateTime}`
        })
        .eq('id', meeting.id);

      if (updateError) {
        console.error('Error updating meeting:', updateError);
        throw updateError;
      }

      // Generate updated iCal with SAME UID
      const duration = Math.round((new Date(endTime).getTime() - new Date(startTime).getTime()) / 60000);
      const icsContent = generateICalFile({
        uid: meeting.ical_uid,
        title: meeting.title,
        startTime: startTime,
        duration: duration,
        participants: meeting.participants.map((p: any) => p.email),
        organizer: meeting.participants[0].email,
        description: `Portfolio møde med ${(meeting.companies as any).name} (OMLAGT)`
      });

      // Send reschedule emails
      const { data: template } = await supabase
        .from('email_templates')
        .select('*')
        .eq('template_key', 'meeting_rescheduled')
        .eq('is_active', true)
        .single();

      if (template) {
        for (const participant of meeting.participants) {
          let htmlBody = template.html_body
            .replace(/\{\{company_name\}\}/g, (meeting.companies as any).name)
            .replace(/\{\{meeting_title\}\}/g, meeting.title)
            .replace(/\{\{old_datetime\}\}/g, oldDateTime)
            .replace(/\{\{new_datetime\}\}/g, newDateTime);

          let subject = template.subject
            .replace(/\{\{meeting_title\}\}/g, meeting.title);

          await resend.emails.send({
            from: `${template.from_name} <${template.from_email}>`,
            to: [participant.email],
            subject: subject,
            html: htmlBody,
            attachments: [{
              filename: 'meeting.ics',
              content: btoa(icsContent),
            }]
          });
        }
      }

      return new Response(
        JSON.stringify({ success: true, meetingId: meeting.id, action: 'rescheduled' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Handle invitee.canceled (meeting cancelled)
    if (eventType === 'invitee.canceled') {
      const { data: meeting, error: meetingError } = await supabase
        .from('company_meetings')
        .select('*, companies(name)')
        .eq('calendly_event_uuid', eventUuid)
        .single();

      if (meetingError || !meeting) {
        console.error('Meeting not found for cancellation:', eventUuid);
        return new Response(
          JSON.stringify({ error: 'Meeting not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Update meeting as cancelled
      const { error: updateError } = await supabase
        .from('company_meetings')
        .update({
          notes: `${meeting.notes || ''}\n\n❌ AFLYST: ${new Date().toLocaleString('da-DK')}`
        })
        .eq('id', meeting.id);

      if (updateError) {
        console.error('Error updating meeting:', updateError);
        throw updateError;
      }

      // Generate cancellation iCal with SAME UID
      const icsContent = generateICalCancellation({
        uid: meeting.ical_uid,
        title: meeting.title,
        startTime: meeting.meeting_date,
        participants: meeting.participants.map((p: any) => p.email),
        organizer: meeting.participants[0].email
      });

      // Send cancellation emails
      const { data: template } = await supabase
        .from('email_templates')
        .select('*')
        .eq('template_key', 'meeting_canceled')
        .eq('is_active', true)
        .single();

      if (template) {
        for (const participant of meeting.participants) {
          let htmlBody = template.html_body
            .replace(/\{\{company_name\}\}/g, (meeting.companies as any).name)
            .replace(/\{\{meeting_title\}\}/g, meeting.title)
            .replace(/\{\{meeting_datetime\}\}/g, new Date(meeting.meeting_date).toLocaleString('da-DK'));

          let subject = template.subject
            .replace(/\{\{meeting_title\}\}/g, meeting.title);

          await resend.emails.send({
            from: `${template.from_name} <${template.from_email}>`,
            to: [participant.email],
            subject: subject,
            html: htmlBody,
            attachments: [{
              filename: 'meeting.ics',
              content: btoa(icsContent),
            }]
          });
        }
      }

      return new Response(
        JSON.stringify({ success: true, meetingId: meeting.id, action: 'canceled' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Event type not handled' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in calendly-webhook:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
