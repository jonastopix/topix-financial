import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verify admin status
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    const isAdmin = roles?.some(r => r.role === 'owner' || r.role === 'mola_admin');
    if (!isAdmin) {
      throw new Error('Forbidden: Admin access required');
    }

    const { action, userId } = await req.json();

    if (!action || !userId) {
      throw new Error('Missing required fields: action, userId');
    }

    const isActive = action === 'activate';

    // Update profile status
    const { error: updateError } = await supabase
      .from('profiles')
      .update({ is_active: isActive })
      .eq('id', userId);

    if (updateError) throw updateError;

    // Log activity
    await supabase.from('user_activity_log').insert({
      user_id: userId,
      admin_user_id: user.id,
      action: isActive ? 'user_activated' : 'user_deactivated',
      details: { is_active: isActive },
    });

    console.log(`User ${userId} ${isActive ? 'activated' : 'deactivated'} by admin ${user.id}`);

    return new Response(
      JSON.stringify({ success: true, message: `User ${isActive ? 'activated' : 'deactivated'} successfully` }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error managing user status:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
