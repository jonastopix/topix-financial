import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
// @deno-types="https://esm.sh/jspdf@2.5.1"
import { jsPDF } from "https://esm.sh/jspdf@2.5.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const MONTHS_DA = [
  'januar', 'februar', 'marts', 'april', 'maj', 'juni',
  'juli', 'august', 'september', 'oktober', 'november', 'december'
];

interface MileageEntry {
  id: string;
  trip_date: string;
  from_address: string;
  to_address: string;
  purpose: string;
  distance_km: number;
  rate_per_km?: number;
  amount_dkk?: number;
}

interface CompanyInfo {
  name: string;
  cvr?: string | null;
  address?: string | null;
  zipcode?: string | null;
  city?: string | null;
}

// Helper to format date
const formatDate = (dateStr: string) => {
  const d = new Date(dateStr);
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
};

// Generate PDF for mileage report
function generateMileageReportPDF(
  company: CompanyInfo,
  entries: MileageEntry[],
  userName: string,
  ratePerKm: number,
  periodName: string,
  totalKm: number,
  totalAmount: number,
  testMode: boolean
): string {
  // @ts-ignore - jsPDF types
  const doc = new jsPDF();
  
  const pageWidth = doc.internal.pageSize.getWidth();
  
  // Header
  doc.setFontSize(22);
  doc.setFont("helvetica", "bold");
  doc.text("KØRSELSREGNSKAB", 14, 22);
  
  if (testMode) {
    doc.setFontSize(10);
    doc.setTextColor(200, 100, 0);
    doc.text("[TEST-RAPPORT - Dummy data]", 14, 30);
    doc.setTextColor(0, 0, 0);
  }
  
  // Company info box
  const boxY = testMode ? 38 : 32;
  doc.setFillColor(248, 249, 250);
  doc.rect(14, boxY, pageWidth - 28, 28, 'F');
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 100, 100);
  doc.text("BETALES AF", 18, boxY + 8);
  
  doc.setFontSize(14);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(0, 0, 0);
  doc.text(company.name, 18, boxY + 16);
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(80, 80, 80);
  let infoY = boxY + 22;
  if (company.cvr) {
    doc.text(`CVR: ${company.cvr}`, 18, infoY);
  }
  const companyAddress = [company.address, company.zipcode, company.city].filter(Boolean).join(", ");
  if (companyAddress) {
    doc.text(companyAddress, company.cvr ? 60 : 18, infoY);
  }
  
  // Period header
  const tableStartY = boxY + 38;
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(0, 0, 0);
  doc.text(`Kørsler - ${periodName}`, 14, tableStartY);
  
  // Manual table drawing (since autoTable doesn't work with esm.sh)
  const colWidths = [22, 48, 48, 18, 46];
  const headers = ['Dato', 'Fra', 'Til', 'Km', 'Formål'];
  const startX = 14;
  let currentY = tableStartY + 8;
  const rowHeight = 8;
  const cellPadding = 2;
  
  // Draw header row
  doc.setFillColor(50, 50, 50);
  doc.rect(startX, currentY - 5, colWidths.reduce((a, b) => a + b, 0), rowHeight, 'F');
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(255, 255, 255);
  
  let xPos = startX + cellPadding;
  headers.forEach((header, i) => {
    doc.text(header, xPos, currentY);
    xPos += colWidths[i];
  });
  
  currentY += rowHeight;
  
  // Draw data rows
  doc.setFont("helvetica", "normal");
  doc.setTextColor(0, 0, 0);
  
  entries.forEach((entry, rowIndex) => {
    // Alternate row background
    if (rowIndex % 2 === 0) {
      doc.setFillColor(250, 250, 250);
      doc.rect(startX, currentY - 5, colWidths.reduce((a, b) => a + b, 0), rowHeight, 'F');
    }
    
    const rowData = [
      formatDate(entry.trip_date),
      entry.from_address.length > 28 ? entry.from_address.substring(0, 28) + "..." : entry.from_address,
      entry.to_address.length > 28 ? entry.to_address.substring(0, 28) + "..." : entry.to_address,
      `${Number(entry.distance_km).toFixed(1)}`,
      entry.purpose.length > 22 ? entry.purpose.substring(0, 22) + "..." : entry.purpose
    ];
    
    xPos = startX + cellPadding;
    rowData.forEach((cell, i) => {
      // Right-align the Km column
      if (i === 3) {
        doc.text(cell, xPos + colWidths[i] - cellPadding - 5, currentY, { align: 'right' });
      } else {
        doc.text(cell, xPos, currentY);
      }
      xPos += colWidths[i];
    });
    
    // Draw bottom border
    doc.setDrawColor(229, 231, 235);
    doc.line(startX, currentY + 2, startX + colWidths.reduce((a, b) => a + b, 0), currentY + 2);
    
    currentY += rowHeight;
  });
  
  const finalY = currentY + 10;
  
  // Summary box
  doc.setFillColor(240, 253, 244);
  doc.setDrawColor(134, 239, 172);
  doc.rect(14, finalY, pageWidth - 28, 45, 'FD');
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(22, 101, 52);
  doc.text("OPSUMMERING", 18, finalY + 10);
  
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(0, 0, 0);
  doc.text(`Antal kørsler:`, 18, finalY + 20);
  doc.text(`${entries.length}`, pageWidth - 32, finalY + 20, { align: 'right' });
  
  doc.text(`Total km:`, 18, finalY + 27);
  doc.text(`${totalKm.toFixed(1)} km`, pageWidth - 32, finalY + 27, { align: 'right' });
  
  doc.text(`SKAT-sats (2026):`, 18, finalY + 34);
  doc.text(`${ratePerKm.toFixed(2)} kr/km`, pageWidth - 32, finalY + 34, { align: 'right' });
  
  doc.setFontSize(12);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(22, 101, 52);
  doc.text(`BELØB TIL UDBETALING:`, 18, finalY + 43);
  doc.text(`${totalAmount.toLocaleString('da-DK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} DKK`, pageWidth - 32, finalY + 43, { align: 'right' });
  
  // Footer
  const footerY = finalY + 60;
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(0, 0, 0);
  doc.text(`Medarbejder: ${userName}`, 14, footerY);
  
  const today = new Date();
  const todayFormatted = `${today.getDate()}. ${MONTHS_DA[today.getMonth()]} ${today.getFullYear()}`;
  doc.setTextColor(100, 100, 100);
  doc.text(`Dato: ${todayFormatted}`, 14, footerY + 7);
  
  // SKAT compliance note
  doc.setFontSize(8);
  doc.setTextColor(100, 100, 100);
  doc.text(
    "Dette kørselsregnskab er udarbejdet i overensstemmelse med SKATs regler for befordringsgodtgørelse",
    14, footerY + 18
  );
  doc.text("og opfylder kravene til dokumentation.", 14, footerY + 23);
  
  // Return as base64
  return doc.output('datauristring').split(',')[1];
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: { headers: { Authorization: req.headers.get("Authorization")! } },
      }
    );

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser();
    if (userError || !user) {
      console.error("Auth error:", userError);
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { companyId, emails, testMode = false } = await req.json();

    if (!emails || emails.length === 0) {
      return new Response(JSON.stringify({ error: "Missing emails" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Sending mileage report ${testMode ? '(TEST MODE)' : ''} to ${emails.join(", ")}`);

    let entries: MileageEntry[];
    let company: CompanyInfo;
    let userName: string;
    let ratePerKm: number;

    if (testMode) {
      // Use hardcoded test data
      company = { 
        name: "Demo Virksomhed ApS", 
        cvr: "12345678",
        address: "Testvej 42",
        zipcode: "1000",
        city: "København"
      };
      userName = "Test Medarbejder";
      ratePerKm = 3.94;
      entries = [
        {
          id: "test-1",
          trip_date: "2026-01-15",
          from_address: "Hovedgaden 1, 1000 København",
          to_address: "Industrivej 42, 2100 København Ø",
          purpose: "Kundemøde hos ABC Corp",
          distance_km: 24.5,
        },
        {
          id: "test-2", 
          trip_date: "2026-01-14",
          from_address: "Hovedgaden 1, 1000 København",
          to_address: "Strandvejen 100, 2900 Hellerup",
          purpose: "Leverandørbesøg",
          distance_km: 18.2,
        },
        {
          id: "test-3",
          trip_date: "2026-01-10",
          from_address: "Hovedgaden 1, 1000 København", 
          to_address: "Lyngby Hovedgade 55, 2800 Lyngby",
          purpose: "Projektmøde",
          distance_km: 31.0,
        },
      ];
    } else {
      // Require companyId for real mode
      if (!companyId) {
        return new Response(JSON.stringify({ error: "Missing companyId" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Get user's mileage settings
      const { data: settings, error: settingsError } = await supabaseClient
        .from("mileage_settings")
        .select("*")
        .eq("user_id", user.id)
        .single();

      if (settingsError || !settings) {
        console.error("Settings error:", settingsError);
        return new Response(JSON.stringify({ error: "Mileage settings not configured" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      userName = settings.employee_name;

      // Get unsubmitted entries for this company
      const { data: fetchedEntries, error: entriesError } = await supabaseClient
        .from("mileage_entries")
        .select("*")
        .eq("user_id", user.id)
        .eq("paying_company_id", companyId)
        .eq("is_submitted", false)
        .order("trip_date", { ascending: true });

      if (entriesError) {
        console.error("Entries error:", entriesError);
        return new Response(JSON.stringify({ error: "Could not fetch entries" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (!fetchedEntries || fetchedEntries.length === 0) {
        return new Response(JSON.stringify({ error: "No entries to submit" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      entries = fetchedEntries;
      ratePerKm = entries[0]?.rate_per_km || 3.94;

      // Get company details (including accountant info)
      const { data: fetchedCompany, error: companyError } = await supabaseClient
        .from("companies")
        .select("name, cvr, address, zipcode, city, accountant_name, accountant_email")
        .eq("id", companyId)
        .single();

      if (companyError || !fetchedCompany) {
        console.error("Company error:", companyError);
        return new Response(JSON.stringify({ error: "Company not found" }), {
          status: 404,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      company = fetchedCompany;
    }

    // Calculate totals
    const totalKm = entries.reduce((sum: number, e: MileageEntry) => sum + Number(e.distance_km), 0);
    const totalAmount = entries.reduce((sum: number, e: MileageEntry) => {
      if (e.amount_dkk) return sum + Number(e.amount_dkk);
      return sum + (Number(e.distance_km) * ratePerKm);
    }, 0);

    // Determine period from entries
    const dates = entries.map((e: MileageEntry) => new Date(e.trip_date));
    const minDate = new Date(Math.min(...dates.map(d => d.getTime())));
    const periodYear = minDate.getFullYear();
    const periodMonth = minDate.getMonth() + 1;
    const periodName = `${MONTHS_DA[periodMonth - 1]} ${periodYear}`;

    // Format entries for email
    const entriesRows = entries.map((e: MileageEntry) => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${formatDate(e.trip_date)}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${e.from_address}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${e.to_address}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${Number(e.distance_km).toFixed(1)}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${e.purpose}</td>
      </tr>
    `).join("");

    const companyAddress = [company.address, company.zipcode, company.city].filter(Boolean).join(", ");
    const today = new Date();
    const todayFormatted = `${today.getDate()}. ${MONTHS_DA[today.getMonth()]} ${today.getFullYear()}`;

    // SKAT-compliant HTML email
    const htmlBody = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Kørselsregnskab</title>
</head>
<body style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; color: #333;">
  ${testMode ? `
  <div style="background: #fef3c7; padding: 10px 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f59e0b;">
    <strong>⚠️ TEST-RAPPORT</strong> - Dette er en test med dummy-data. Ingen rigtige kørsler er indsendt.
  </div>
  ` : ''}
  
  <h1 style="color: #1a1a1a; border-bottom: 2px solid #333; padding-bottom: 10px;">
    KØRSELSREGNSKAB
  </h1>
  
  <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
    <h2 style="margin: 0 0 10px 0; font-size: 16px; color: #666;">BETALES AF</h2>
    <p style="margin: 0; font-size: 18px; font-weight: bold;">${company.name}</p>
    ${company.cvr ? `<p style="margin: 5px 0 0 0; color: #666;">CVR: ${company.cvr}</p>` : ""}
    ${companyAddress ? `<p style="margin: 5px 0 0 0; color: #666;">${companyAddress}</p>` : ""}
  </div>

  <h3 style="margin-top: 30px;">Kørsler - ${periodName}</h3>
  
  <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
    <thead>
      <tr style="background: #f1f5f9;">
        <th style="padding: 10px 8px; text-align: left; border-bottom: 2px solid #333;">DATO</th>
        <th style="padding: 10px 8px; text-align: left; border-bottom: 2px solid #333;">FRA</th>
        <th style="padding: 10px 8px; text-align: left; border-bottom: 2px solid #333;">TIL</th>
        <th style="padding: 10px 8px; text-align: right; border-bottom: 2px solid #333;">KM</th>
        <th style="padding: 10px 8px; text-align: left; border-bottom: 2px solid #333;">FORMÅL</th>
      </tr>
    </thead>
    <tbody>
      ${entriesRows}
    </tbody>
  </table>

  <div style="background: #f0fdf4; padding: 20px; border-radius: 8px; border: 1px solid #86efac;">
    <h3 style="margin: 0 0 15px 0; color: #166534;">OPSUMMERING</h3>
    <table style="width: 100%;">
      <tr>
        <td style="padding: 5px 0;">Antal kørsler:</td>
        <td style="padding: 5px 0; text-align: right; font-weight: bold;">${entries.length}</td>
      </tr>
      <tr>
        <td style="padding: 5px 0;">Total km:</td>
        <td style="padding: 5px 0; text-align: right; font-weight: bold;">${totalKm.toFixed(1)} km</td>
      </tr>
      <tr>
        <td style="padding: 5px 0;">SKAT-sats (2026):</td>
        <td style="padding: 5px 0; text-align: right;">${ratePerKm.toFixed(2)} kr/km</td>
      </tr>
      <tr style="font-size: 18px;">
        <td style="padding: 15px 0 5px 0; font-weight: bold;">BELØB TIL UDBETALING:</td>
        <td style="padding: 15px 0 5px 0; text-align: right; font-weight: bold; color: #166534;">
          ${totalAmount.toLocaleString('da-DK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} DKK
        </td>
      </tr>
    </table>
  </div>

  <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
    <p style="margin: 0;"><strong>Medarbejder:</strong> ${userName}</p>
    <p style="margin: 10px 0 0 0; color: #666;">Dato: ${todayFormatted}</p>
  </div>

  <p style="margin-top: 30px; font-size: 12px; color: #666;">
    Dette kørselsregnskab er udarbejdet i overensstemmelse med SKATs regler for 
    befordringsgodtgørelse og opfylder kravene til dokumentation.
  </p>
  
  <p style="margin-top: 15px; font-size: 12px; color: #666;">
    <em>📎 PDF-version vedhæftet til arkivering.</em>
  </p>
</body>
</html>
    `;

    // Generate PDF
    console.log("Generating PDF...");
    const pdfBase64 = generateMileageReportPDF(
      company,
      entries,
      userName,
      ratePerKm,
      periodName,
      totalKm,
      totalAmount,
      testMode
    );
    console.log("PDF generated successfully");

    // Create filename
    const sanitizedCompanyName = company.name.replace(/[^a-zA-Z0-9æøåÆØÅ]/g, '_').replace(/_+/g, '_');
    const fileName = `Korselsregnskab_${sanitizedCompanyName}_${String(periodMonth).padStart(2, '0')}_${periodYear}.pdf`;

    // Send email via Resend with PDF attachment
    const resendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "MOLA Kørselsregnskab <onboarding@resend.dev>",
        to: emails,
        subject: `${testMode ? '[TEST] ' : ''}Kørselsregnskab - ${company.name} - ${periodName}`,
        html: htmlBody,
        attachments: [
          {
            filename: fileName,
            content: pdfBase64,
          }
        ],
      }),
    });

    const emailResponse = await resendRes.json();
    console.log("Email sent:", emailResponse);

    if (!resendRes.ok) {
      console.error("Resend error:", emailResponse);
      return new Response(
        JSON.stringify({ error: emailResponse.message || "Failed to send email" }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Only update database for real submissions
    if (!testMode) {
      // Get user's mileage settings for submission record
      const { data: settings } = await supabaseClient
        .from("mileage_settings")
        .select("employee_name")
        .eq("user_id", user.id)
        .single();

      // Create submission record
      const { error: submissionError } = await supabaseClient
        .from("mileage_submissions")
        .insert({
          user_id: user.id,
          paying_company_id: companyId,
          period_year: periodYear,
          period_month: periodMonth,
          total_km: totalKm,
          total_amount_dkk: totalAmount,
          entries_snapshot: entries,
          employee_name: settings?.employee_name || userName,
          sent_to_emails: emails,
        })
        .select()
        .single();

      if (submissionError) {
        console.error("Submission error:", submissionError);
        // Don't fail - email was sent, just log the error
      }

      // Mark entries as submitted
      const entryIds = entries.map((e: MileageEntry) => e.id);
      const { error: updateError } = await supabaseClient
        .from("mileage_entries")
        .update({ 
          is_submitted: true, 
          submitted_at: new Date().toISOString() 
        })
        .in("id", entryIds);

      if (updateError) {
        console.error("Update error:", updateError);
      }
    }

    console.log(`Successfully sent ${testMode ? 'TEST ' : ''}mileage report with ${entries.length} entries and PDF attachment`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        testMode,
        entriesCount: entries.length,
        totalKm,
        totalAmount,
        pdfAttached: true,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );

  } catch (error: any) {
    console.error("Error in send-mileage-report:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
