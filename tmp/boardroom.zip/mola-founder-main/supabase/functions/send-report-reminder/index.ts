import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.7";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendReminderRequest {
  companyId: string;
  targetMonth?: number;
  targetYear?: number;
}

function getMonthName(month: number): string {
  const months = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];
  return months[month - 1];
}

function replaceTemplateVariables(template: string, variables: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(variables)) {
    const placeholder = `{{${key}}}`;
    result = result.replaceAll(placeholder, value);
  }
  return result;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Verify user is admin
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authToken = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(authToken);

    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user is admin
    const { data: userRoles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["owner", "mola_admin"]);

    if (!userRoles || userRoles.length === 0) {
      return new Response(JSON.stringify({ error: "Forbidden - Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { companyId, targetMonth, targetYear }: SendReminderRequest = await req.json();

    // Calculate target period (default to previous month)
    const now = new Date();
    let month = targetMonth || now.getMonth() + 1 - 1;
    let year = targetYear || now.getFullYear();
    
    if (month === 0) {
      month = 12;
      year--;
    }

    console.log(`📧 Sending manual reminder for company ${companyId} - Period: ${month}/${year}`);

    // Fetch company info
    const { data: company, error: companyError } = await supabaseAdmin
      .from("companies")
      .select("id, name")
      .eq("id", companyId)
      .eq("is_active", true)
      .single();

    if (companyError || !company) {
      console.error(`❌ Company not found or inactive: ${companyId}`);
      return new Response(JSON.stringify({ error: "Company not found or inactive" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Fetch founders for this company
    const { data: founderUsers, error: foundersError } = await supabaseAdmin
      .from("profiles")
      .select("id")
      .eq("company_id", company.id);

    if (foundersError || !founderUsers || founderUsers.length === 0) {
      console.error(`❌ No founders found for ${company.name}`);
      return new Response(JSON.stringify({ error: "No founders found for company" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const founderIds = founderUsers.map(u => u.id);

    // Get active founders with founder role
    const { data: founders, error: foundersProfileError } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, email:id(email:email)")
      .in("id", founderIds)
      .eq("is_active", true);

    if (foundersProfileError || !founders || founders.length === 0) {
      console.error(`❌ No active founders for ${company.name}`);
      return new Response(JSON.stringify({ error: "No active founders found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get founder roles
    const { data: founderRoles } = await supabaseAdmin
      .from("user_roles")
      .select("user_id")
      .in("user_id", founderIds)
      .eq("role", "founder");

    const activeFounderRoleIds = new Set(founderRoles?.map(r => r.user_id) || []);
    const activeFounders = founders.filter(f => activeFounderRoleIds.has(f.id));

    if (activeFounders.length === 0) {
      console.error(`❌ No active founders with founder role for ${company.name}`);
      return new Response(JSON.stringify({ error: "No active founders with founder role" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get founder emails
    const founderEmails: string[] = [];
    for (const founder of activeFounders) {
      const { data: authUser } = await supabaseAdmin.auth.admin.getUserById(founder.id);
      if (authUser?.user?.email) {
        founderEmails.push(authUser.user.email);
      }
    }

    if (founderEmails.length === 0) {
      console.error(`❌ No founder emails found for ${company.name}`);
      return new Response(JSON.stringify({ error: "No founder emails found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check for existing active token or generate new one
    let token: string;
    const { data: existingTokens, error: tokenQueryError } = await supabaseAdmin
      .from("monthly_report_tokens")
      .select("token")
      .eq("company_id", company.id)
      .eq("period_month", month)
      .eq("period_year", year)
      .eq("status", "active")
      .maybeSingle();

    if (tokenQueryError) {
      console.error(`❌ Error querying tokens for ${company.name}:`, tokenQueryError);
      return new Response(JSON.stringify({ error: "Error checking tokens" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (existingTokens) {
      token = existingTokens.token;
      console.log(`♻️ Reusing existing token for ${company.name}`);
    } else {
      token = crypto.randomUUID();
      const expiresAt = new Date();
      expiresAt.setFullYear(expiresAt.getFullYear() + 10);

      const { error: tokenError } = await supabaseAdmin
        .from("monthly_report_tokens")
        .insert({
          company_id: company.id,
          token: token,
          period_month: month,
          period_year: year,
          expires_at: expiresAt.toISOString(),
          status: "active"
        });

      if (tokenError) {
        console.error(`❌ Error creating token for ${company.name}:`, tokenError);
        return new Response(JSON.stringify({ error: "Error creating token" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      console.log(`🔑 Generated new token for ${company.name}`);
    }

    // Fetch email template
    const { data: template, error: templateError } = await supabaseAdmin
      .from("email_templates")
      .select("*")
      .eq("template_key", "monthly_report_reminder")
      .eq("is_active", true)
      .maybeSingle();

    if (templateError || !template) {
      console.error("❌ Email template not found or inactive");
      return new Response(JSON.stringify({ error: "Email template not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Prepare template variables
    const monthName = getMonthName(month);
    const deadlineDate = `20. ${monthName} ${year}`;
    
    const variables = {
      company_name: company.name,
      month_name: monthName,
      year: year.toString(),
      report_link: `https://founder.molainvest.dk/report/${token}`,
      deadline_date: deadlineDate
    };

    const emailSubject = replaceTemplateVariables(template.subject, variables);
    const emailHtml = replaceTemplateVariables(template.html_body, variables);

    // Send email
    const { error: emailError } = await resend.emails.send({
      from: `${template.from_name} <${template.from_email}>`,
      to: founderEmails,
      subject: emailSubject,
      html: emailHtml,
    });

    if (emailError) {
      console.error(`❌ Error sending email to ${company.name}:`, emailError);
      return new Response(JSON.stringify({ error: "Error sending email" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`✅ Manual reminder sent to ${company.name} (${founderEmails.length} recipients)`);

    // Log notification
    await supabaseAdmin
      .from("monthly_report_notifications")
      .insert({
        company_id: company.id,
        notification_type: "manual_reminder",
        period_month: month,
        period_year: year,
        sent_to: founderEmails,
        email_subject: emailSubject,
      });

    // Log activity
    await supabaseAdmin
      .from("company_activity_log")
      .insert({
        company_id: company.id,
        user_id: user.id,
        activity_type: "manual_report_reminder_sent",
        description: `Manuel rapport-påmindelse sendt for ${monthName} ${year}`,
        metadata: {
          period_month: month,
          period_year: year,
          recipients: founderEmails,
          token_reused: !!existingTokens
        }
      });

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Reminder sent to ${founderEmails.length} founder(s)`,
        company: company.name,
        period: `${monthName} ${year}`
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );

  } catch (error: any) {
    console.error("❌ Error in send-report-reminder function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

serve(handler);
