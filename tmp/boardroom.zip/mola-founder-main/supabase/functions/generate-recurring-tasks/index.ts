import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RecurringTask {
  id: string;
  title: string;
  description: string | null;
  priority: string;
  assigned_to: string | null;
  company_id: string | null;
  created_by: string;
  recurrence_pattern: 'daily' | 'weekly' | 'monthly' | 'yearly';
  recurrence_interval: number;
  recurrence_end_date: string | null;
  recurrence_count: number | null;
  recurrence_day_of_week: number | null;
  recurrence_day_of_month: number | null;
  next_occurrence_date: string;
  due_date: string | null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    // Create service role client for admin operations
    const supabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    // Authenticate user with JWT
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error('Missing Authorization header');
      return new Response(
        JSON.stringify({ error: 'Unauthorized - Missing token' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Verify user is authenticated using service role client
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );
    
    if (authError || !user) {
      console.error('Authentication failed:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized - Invalid token' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Check if user is admin
    const { data: isAdmin, error: roleError } = await supabase.rpc('is_admin', {
      _user_id: user.id,
    });

    if (roleError || !isAdmin) {
      console.error('Admin check failed:', roleError);
      return new Response(
        JSON.stringify({ error: 'Forbidden - Admin access required' }),
        {
          status: 403,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    console.log(`Admin user ${user.id} starting recurring tasks generation...`);

    // Find all recurring tasks that need to generate new instances
    const { data: recurringTasks, error: fetchError } = await supabase
      .from('tasks')
      .select('*')
      .eq('is_recurring', true)
      .lte('next_occurrence_date', new Date().toISOString().split('T')[0])
      .is('completed_at', null);

    if (fetchError) {
      console.error('Error fetching recurring tasks:', fetchError);
      throw fetchError;
    }

    console.log(`Found ${recurringTasks?.length || 0} recurring tasks to process`);

    const results = [];

    for (const task of (recurringTasks as RecurringTask[]) || []) {
      try {
        // Check if recurrence has ended
        if (task.recurrence_end_date && new Date(task.recurrence_end_date) < new Date()) {
          console.log(`Task ${task.id} has reached end date, skipping`);
          continue;
        }

        // Check recurrence count (would need to count existing child tasks)
        if (task.recurrence_count) {
          const { count } = await supabase
            .from('tasks')
            .select('*', { count: 'exact', head: true })
            .eq('parent_task_id', task.id);

          if (count && count >= task.recurrence_count) {
            console.log(`Task ${task.id} has reached max count (${task.recurrence_count}), skipping`);
            continue;
          }
        }

        // Calculate next due date
        const nextDueDate = calculateNextDueDate(task);

        // Create new task instance
        const { data: newTask, error: createError } = await supabase
          .from('tasks')
          .insert({
            title: task.title,
            description: task.description,
            priority: task.priority,
            assigned_to: task.assigned_to,
            company_id: task.company_id,
            created_by: task.created_by,
            status: 'todo',
            due_date: nextDueDate,
            parent_task_id: task.id,
            is_recurring: false,
          })
          .select()
          .single();

        if (createError) {
          console.error(`Error creating child task for ${task.id}:`, createError);
          continue;
        }

        console.log(`Created new task instance: ${newTask.id} with due date ${nextDueDate}`);

        // Calculate next occurrence date
        const nextOccurrence = calculateNextOccurrence(task);

        // Update parent task with next occurrence date
        const { error: updateError } = await supabase
          .from('tasks')
          .update({ next_occurrence_date: nextOccurrence })
          .eq('id', task.id);

        if (updateError) {
          console.error(`Error updating parent task ${task.id}:`, updateError);
        }

        // Log activity
        if (task.company_id) {
          await supabase.from('company_activity_log').insert({
            company_id: task.company_id,
            user_id: task.created_by,
            activity_type: 'task_created',
            description: `Automatisk gentagende opgave oprettet: ${task.title}`,
            metadata: {
              task_id: newTask.id,
              parent_task_id: task.id,
              due_date: nextDueDate,
              is_recurring_instance: true,
            },
          });
        }

        results.push({
          parentTaskId: task.id,
          newTaskId: newTask.id,
          nextOccurrence,
        });
      } catch (error) {
        console.error(`Error processing task ${task.id}:`, error);
      }
    }

    console.log(`Successfully generated ${results.length} recurring task instances`);

    return new Response(
      JSON.stringify({
        success: true,
        generated: results.length,
        results,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    console.error('Error in generate-recurring-tasks:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

function calculateNextDueDate(task: RecurringTask): string {
  const currentDate = new Date(task.next_occurrence_date);
  const interval = task.recurrence_interval;

  switch (task.recurrence_pattern) {
    case 'daily':
      currentDate.setDate(currentDate.getDate() + interval);
      break;
    case 'weekly':
      currentDate.setDate(currentDate.getDate() + (interval * 7));
      break;
    case 'monthly':
      currentDate.setMonth(currentDate.getMonth() + interval);
      // Handle months with fewer days
      if (task.recurrence_day_of_month) {
        const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
        currentDate.setDate(Math.min(task.recurrence_day_of_month, lastDayOfMonth));
      }
      break;
    case 'yearly':
      currentDate.setFullYear(currentDate.getFullYear() + interval);
      break;
  }

  return currentDate.toISOString().split('T')[0];
}

function calculateNextOccurrence(task: RecurringTask): string {
  const currentDate = new Date(task.next_occurrence_date);
  const interval = task.recurrence_interval;

  switch (task.recurrence_pattern) {
    case 'daily':
      currentDate.setDate(currentDate.getDate() + interval);
      break;
    case 'weekly':
      currentDate.setDate(currentDate.getDate() + (interval * 7));
      // Adjust to specific day of week if set
      if (task.recurrence_day_of_week !== null) {
        const currentDay = currentDate.getDay();
        const targetDay = task.recurrence_day_of_week;
        const daysToAdd = (targetDay - currentDay + 7) % 7;
        if (daysToAdd > 0) {
          currentDate.setDate(currentDate.getDate() + daysToAdd);
        }
      }
      break;
    case 'monthly':
      currentDate.setMonth(currentDate.getMonth() + interval);
      // Handle day of month
      if (task.recurrence_day_of_month) {
        const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
        currentDate.setDate(Math.min(task.recurrence_day_of_month, lastDayOfMonth));
      }
      break;
    case 'yearly':
      currentDate.setFullYear(currentDate.getFullYear() + interval);
      break;
  }

  return currentDate.toISOString().split('T')[0];
}
