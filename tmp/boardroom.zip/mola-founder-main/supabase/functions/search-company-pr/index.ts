import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// AI Sentiment Analysis Function
async function analyzeSentiment(
  title: string, 
  snippet: string, 
  companyName: string
): Promise<"positive" | "neutral" | "negative"> {
  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  if (!LOVABLE_API_KEY) {
    console.log('No LOVABLE_API_KEY found, defaulting to neutral');
    return "neutral";
  }

  const prompt = `Analyser sentiment for denne nyhedsartikel om virksomheden "${companyName}":

Titel: ${title}
Uddrag: ${snippet}

Kategoriser som:
- "positive" - God omtale, succes, vækst, priser, investeringer, nye produkter, ansættelser, partnerskaber
- "negative" - Kritik, problemer, afskedigelser, tab, skandaler, konkurser, retssager, dårlige resultater
- "neutral" - Faktuel information, neutrale nyheder, branchenyheder uden klar vinkel

Svar KUN med ét ord: positive, neutral, eller negative`;

  try {
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash-lite',
        messages: [{ role: 'user', content: prompt }],
        max_completion_tokens: 10,
      }),
    });

    if (!response.ok) {
      console.log('AI sentiment analysis failed:', response.status);
      return "neutral";
    }
    
    const data = await response.json();
    const result = data.choices?.[0]?.message?.content?.toLowerCase().trim() || '';
    
    console.log(`Sentiment for "${title.substring(0, 50)}...": ${result}`);
    
    if (result.includes('positive')) return "positive";
    if (result.includes('negative')) return "negative";
    return "neutral";
  } catch (error) {
    console.error('Sentiment analysis error:', error);
    return "neutral";
  }
}

// Domains to filter out from search results (social media, job portals, databases)
const EXCLUDED_DOMAINS = [
  // Social media
  'facebook.com',
  'instagram.com',
  'twitter.com',
  'x.com',
  'linkedin.com',
  'tiktok.com',
  'youtube.com',
  'pinterest.com',
  'threads.net',
  
  // Job portals
  'jobindex.dk',
  'ofir.dk',
  'jobnet.dk',
  'indeed.com',
  'glassdoor.com',
  'graduateland.com',
  
  // Business databases
  'cvr.dk',
  'proff.dk',
  'krak.dk',
  'degulesider.dk',
  'eniro.dk',
  'cvr-api.dk',
  'datacvr.virk.dk',
  'virk.dk',
  'crunchbase.com',
  'dnb.com',
  'bisnode.dk',
  'risika.dk',
  
  // Other non-news
  'trustpilot.com',
  'yelp.com',
  'google.com',
  'maps.google.com',
  'amazon.com',
  'apple.com',
  
  // International domains (non-Danish)
  'rte.ie',
  'irishtimes.com',
  'independent.ie',
  'irishexaminer.com',
  'thejournal.ie',
  'siliconrepublic.com',
  'fora.ie',
  'businesspost.ie',
  'bbc.com',
  'bbc.co.uk',
  'theguardian.com',
  'telegraph.co.uk',
  'ft.com',
  'reuters.com',
  'bloomberg.com',
  'techcrunch.com',
  'wired.com',
  'forbes.com',
  'inc.com',
  'entrepreneur.com',
];

// Irish/International context indicators to filter out
const INTERNATIONAL_INDICATORS = [
  'ireland', 'irish', 'dublin', 'cork', 'galway', 'limerick', 'belfast',
  'united kingdom', 'uk-based', 'london-based', 'british',
  'american', 'us-based', 'silicon valley', 'san francisco',
];

// Danish context indicators (positive signals)
const DANISH_INDICATORS = [
  'danmark', 'danish', 'dansk', 'danske', 
  'københavn', 'copenhagen', 'aarhus', 'odense', 'aalborg',
  'cvr', 'aps', 'a/s', 'iværksætter', 'startup danmark',
];

// Check if result has international (non-Danish) context
function hasInternationalContext(result: any): boolean {
  const content = ((result.title || '') + ' ' + (result.description || '') + ' ' + (result.markdown || '')).toLowerCase();
  
  // Check for international indicators
  const hasIntl = INTERNATIONAL_INDICATORS.some(ind => content.includes(ind));
  
  // Check for Danish indicators
  const hasDanish = DANISH_INDICATORS.some(ind => content.includes(ind));
  
  // If it has international context but NO Danish context, filter it out
  if (hasIntl && !hasDanish) {
    return true;
  }
  
  return false;
}

// Check if URL is from international TLD (non-.dk, non-global news)
function isInternationalDomain(url: string): boolean {
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    
    // Irish domains
    if (hostname.endsWith('.ie')) return true;
    
    // UK domains
    if (hostname.endsWith('.co.uk') || hostname.endsWith('.uk')) return true;
    
    // Check for country-specific paths
    if (url.includes('/ie/') || url.includes('/ireland/')) return true;
    if (url.includes('/uk/') || url.includes('/gb/')) return true;
    
    return false;
  } catch {
    return false;
  }
}

// Check if URL should be excluded
function isExcludedUrl(url: string, excludedDomains: string[]): boolean {
  try {
    const domain = new URL(url).hostname.replace('www.', '').toLowerCase();
    return excludedDomains.some(excluded => 
      domain === excluded || domain.endsWith('.' + excluded)
    );
  } catch {
    return false;
  }
}

// Extract domain from URL for filtering
function extractDomainForFilter(websiteUrl: string): string | null {
  try {
    return new URL(websiteUrl).hostname.replace('www.', '').toLowerCase();
  } catch {
    return null;
  }
}

interface SearchResult {
  title: string;
  source: string;
  url: string;
  snippet: string;
  published_at: string | null;
}

interface AnalyzedArticle extends SearchResult {
  ai_summary: string | null;
  sentiment: "positive" | "neutral" | "negative";
  relevance_score: number;
}

// Helper function to extract published date from various sources
function extractPublishedDate(result: any): string | null {
  // 1. Direct from API (news results have date field)
  if (result.date) {
    const parsed = new Date(result.date);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString();
    }
  }
  
  // 2. From metadata (scrape endpoint)
  if (result.metadata?.publishedDate) {
    const parsed = new Date(result.metadata.publishedDate);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString();
    }
  }
  
  // 3. Parse from URL (many Danish news sites use date in URL)
  const urlPatterns = [
    // YYYY-MM-DD format
    /\/(\d{4})-(\d{2})-(\d{2})\//,
    // YYYY/MM/DD format  
    /\/(\d{4})\/(\d{2})\/(\d{2})\//,
    // YYYYMMDD format
    /\/(\d{4})(\d{2})(\d{2})\//,
  ];
  
  for (const pattern of urlPatterns) {
    const match = result.url?.match(pattern);
    if (match) {
      const [, year, month, day] = match;
      const date = new Date(`${year}-${month}-${day}`);
      if (!isNaN(date.getTime())) {
        return date.toISOString();
      }
    }
  }
  
  // 4. Fallback: Try to parse from snippet/description
  const textContent = result.description || result.snippet || '';
  const danishDateMatch = textContent.match(
    /(\d{1,2})\.\s*(jan|feb|mar|apr|maj|jun|jul|aug|sep|okt|nov|dec)[a-z]*\.?\s*(\d{4})/i
  );
  if (danishDateMatch) {
    const monthMap: Record<string, string> = {
      'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
      'maj': '05', 'jun': '06', 'jul': '07', 'aug': '08',
      'sep': '09', 'okt': '10', 'nov': '11', 'dec': '12'
    };
    const [, day, month, year] = danishDateMatch;
    const monthNum = monthMap[month.toLowerCase().substring(0, 3)];
    if (monthNum) {
      const date = new Date(`${year}-${monthNum}-${day.padStart(2, '0')}`);
      if (!isNaN(date.getTime())) {
        return date.toISOString();
      }
    }
  }
  
  // 5. Try ISO date pattern in text (e.g., "2024-12-15")
  const isoDateMatch = textContent.match(/(\d{4})-(\d{2})-(\d{2})/);
  if (isoDateMatch) {
    const [fullMatch] = isoDateMatch;
    const date = new Date(fullMatch);
    if (!isNaN(date.getTime())) {
      return date.toISOString();
    }
  }
  
  return null;
}

// Generate multiple search variants from company name
function getSearchVariants(name: string): string[] {
  // Remove company type suffix
  const cleaned = name.replace(/\s*(ApS|A\/S|IVS|K\/S|P\/S|I\/S)\s*$/i, '').trim();
  const variants = new Set<string>();
  
  // Add original cleaned name (preserves special chars like &)
  variants.add(cleaned);
  
  // Add variant without special characters
  const noSpecial = cleaned.replace(/[&@#]/g, ' ').replace(/\s+/g, ' ').trim();
  if (noSpecial !== cleaned && noSpecial.length > 2) {
    variants.add(noSpecial);
  }
  
  // Add variant with "and" instead of "&"
  if (cleaned.includes('&')) {
    variants.add(cleaned.replace(/&/g, 'and'));
  }
  
  return Array.from(variants);
}

// Extract domain name from URL for source display
function extractSource(url: string): string {
  try {
    const domain = new URL(url).hostname.replace('www.', '');
    const sourceMap: Record<string, string> = {
      'borsen.dk': 'Børsen',
      'finans.dk': 'Finans',
      'dr.dk': 'DR',
      'tv2.dk': 'TV2',
      'bt.dk': 'BT',
      'eb.dk': 'Ekstra Bladet',
      'politiken.dk': 'Politiken',
      'berlingske.dk': 'Berlingske',
      'jyllands-posten.dk': 'Jyllands-Posten',
      'jp.dk': 'Jyllands-Posten',
      'information.dk': 'Information',
      'computerworld.dk': 'Computerworld',
      'version2.dk': 'Version2',
      'techsavvy.dk': 'TechSavvy',
      'idag.dk': 'Idag.dk',
      'startupworld.dk': 'StartupWorld',
      'startup-magazin.dk': 'Startup Magazin',
      'linkedin.com': 'LinkedIn',
      'proleap.dk': 'ProLeap',
      'cphbusiness.dk': 'CPH Business',
    };
    return sourceMap[domain] || domain;
  } catch {
    return 'Ukendt kilde';
  }
}

// Deduplicate results by URL
function deduplicateResults(results: any[]): any[] {
  const seen = new Set<string>();
  return results.filter(r => {
    const url = r.url?.toLowerCase();
    if (!url || seen.has(url)) return false;
    seen.add(url);
    return true;
  });
}

// Call Firecrawl search API
async function searchFirecrawl(query: string, apiKey: string): Promise<any[]> {
  console.log(`Firecrawl search: "${query}"`);
  
  try {
    const response = await fetch('https://api.firecrawl.dev/v1/search', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query,
        limit: 10,
        lang: 'da',
        country: 'dk',
        tbs: 'qdr:y', // Last year
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error(`Firecrawl error for "${query}":`, errorData);
      return [];
    }

    const data = await response.json();
    console.log(`Firecrawl found ${data.data?.length || 0} results for "${query}"`);
    return data.data || [];
  } catch (error) {
    console.error(`Firecrawl exception for "${query}":`, error);
    return [];
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const firecrawlApiKey = Deno.env.get("FIRECRAWL_API_KEY");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Verify user
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user is admin
    const { data: roles } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .in("role", ["owner", "mola_admin"]);

    if (!roles || roles.length === 0) {
      return new Response(JSON.stringify({ error: "Forbidden - Admin access required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { company_id, additional_terms, blocked_domains, trusted_domains } = await req.json();

    if (!company_id) {
      return new Response(JSON.stringify({ error: "company_id is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get company details including website and brand_aliases for filtering
    const { data: company, error: companyError } = await supabase
      .from("companies")
      .select("name, cvr, industry, description, email, brand_aliases")
      .eq("id", company_id)
      .single();

    if (companyError || !company) {
      return new Response(JSON.stringify({ error: "Company not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build dynamic exclusion list including company's own domain and user-blocked domains
    const excludedDomains = [...EXCLUDED_DOMAINS];
    
    // Add user-blocked domains
    if (blocked_domains && Array.isArray(blocked_domains)) {
      excludedDomains.push(...blocked_domains);
      console.log(`Added ${blocked_domains.length} user-blocked domains to exclusions`);
    }
    
    // Extract company domain from email if available (e.g., info@company.dk -> company.dk)
    if (company.email) {
      const emailDomain = company.email.split('@')[1];
      if (emailDomain && !emailDomain.includes('gmail') && !emailDomain.includes('hotmail') && !emailDomain.includes('yahoo')) {
        excludedDomains.push(emailDomain.toLowerCase());
        console.log(`Added company email domain to exclusions: ${emailDomain}`);
      }
    }

    // Check if Firecrawl is configured
    if (!firecrawlApiKey) {
      console.log("Firecrawl API key not configured");
      return new Response(JSON.stringify({ 
        company_name: company.name,
        articles: [],
        message: "PR-søgning kræver Firecrawl integration. Kontakt administrator.",
        requires_api_key: true,
        searched_at: new Date().toISOString()
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Generate search variants from official company name
    const nameVariants = getSearchVariants(company.name);
    console.log(`Company: "${company.name}", Variants:`, nameVariants);

    // Build search queries - multiple strategies with Danish context
    const searchQueries: string[] = [];
    
    // PRIORITY 1: Brand aliases (the names the company is known by in media)
    const brandAliases = company.brand_aliases || [];
    if (brandAliases.length > 0) {
      console.log(`Using brand aliases for search:`, brandAliases);
      
      // Brand aliases get priority - these are the names media actually uses
      for (const alias of brandAliases.slice(0, 2)) {
        // Search with brand name + Danmark
        searchQueries.push(`"${alias}" Danmark`);
        
        // Search in Danish news sites specifically
        const danishNewsSites = 'site:borsen.dk OR site:finans.dk OR site:business.dk OR site:tv2.dk OR site:dr.dk';
        searchQueries.push(`"${alias}" ${danishNewsSites}`);
      }
    }

    // PRIORITY 2: If user provided additional terms, use with brand name or company name
    if (additional_terms?.trim()) {
      const searchName = brandAliases.length > 0 ? brandAliases[0] : nameVariants[0];
      searchQueries.push(`"${searchName}" ${additional_terms.trim()} Danmark`);
    }

    // PRIORITY 3: Original company name with Danish context (lower priority if brand exists)
    if (brandAliases.length === 0) {
      // Only if no brand aliases, use the CVR name as primary
      searchQueries.push(`"${nameVariants[0]}" Danmark`);

      // Secondary: Name + Danish business context
      if (nameVariants[1]) {
        searchQueries.push(`"${nameVariants[1]}" dansk virksomhed`);
      }
      
      // Danish news sites specific search
      const danishNewsSites = 'site:borsen.dk OR site:finans.dk OR site:business.dk OR site:tv2.dk OR site:dr.dk OR site:computerworld.dk OR site:version2.dk';
      searchQueries.push(`"${nameVariants[0]}" ${danishNewsSites}`);
    }

    // CVR search (inherently Danish) - always useful as supplementary
    if (company.cvr) {
      searchQueries.push(`CVR ${company.cvr}`);
    }

    // Add trusted domain specific searches if user has learned preferences
    if (trusted_domains && Array.isArray(trusted_domains) && trusted_domains.length > 0) {
      const searchName = brandAliases.length > 0 ? brandAliases[0] : nameVariants[0];
      const trustedSiteQuery = trusted_domains.slice(0, 3).map(d => `site:${d}`).join(' OR ');
      searchQueries.push(`"${searchName}" ${trustedSiteQuery}`);
      console.log(`Added trusted domains search: ${trustedSiteQuery}`);
    }

    // Limit to max 5 parallel searches
    const queriesToRun = searchQueries.slice(0, 5);
    console.log(`Running ${queriesToRun.length} parallel searches:`, queriesToRun);

    // Run searches in parallel
    const searchPromises = queriesToRun.map(q => searchFirecrawl(q, firecrawlApiKey));
    const allSearchResults = await Promise.all(searchPromises);

    // Flatten and deduplicate results
    const flatResults = allSearchResults.flat();
    const uniqueResults = deduplicateResults(flatResults);
    console.log(`Total unique results before filtering: ${uniqueResults.length}`);

    // Filter out excluded domains (social media, company website, job portals, etc.)
    let filteredResults = uniqueResults.filter(r => !isExcludedUrl(r.url, excludedDomains));
    console.log(`After domain filtering: ${filteredResults.length} results`);

    // Filter out international domains (.ie, .uk, etc.)
    filteredResults = filteredResults.filter(r => !isInternationalDomain(r.url));
    console.log(`After international domain filtering: ${filteredResults.length} results`);

    // Filter out results with international context (Ireland, UK mentions without Danish context)
    filteredResults = filteredResults.filter(r => !hasInternationalContext(r));
    const filteredCount = uniqueResults.length - filteredResults.length;
    console.log(`After content filtering: ${filteredResults.length} results (removed ${filteredCount} total non-relevant)`);

    // Transform to our format
    // Analyze sentiment for each article using AI (batch of 5 at a time to avoid rate limits)
    const limitedResults = filteredResults.slice(0, 15);
    const articles: AnalyzedArticle[] = [];
    
    for (let i = 0; i < limitedResults.length; i += 5) {
      const batch = limitedResults.slice(i, i + 5);
      const analyzedBatch = await Promise.all(
        batch.map(async (result: any) => {
          const title = result.title || 'Ingen titel';
          const snippet = result.description || result.markdown?.substring(0, 300) || '';
          const sentiment = await analyzeSentiment(title, snippet, company.name);
          
          return {
            title,
            source: extractSource(result.url),
            url: result.url,
            snippet,
            published_at: extractPublishedDate(result),
            ai_summary: null,
            sentiment,
            relevance_score: 80,
          };
        })
      );
      articles.push(...analyzedBatch);
    }

    return new Response(JSON.stringify({ 
      company_name: company.name,
      articles,
      search_variants_used: queriesToRun,
      filtered_count: filteredCount,
      searched_at: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error in search-company-pr:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
