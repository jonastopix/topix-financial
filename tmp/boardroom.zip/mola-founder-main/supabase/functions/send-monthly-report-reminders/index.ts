import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Helper function to get month name in Danish
const getMonthName = (month: number): string => {
  const months = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];
  return months[month - 1];
};

// Helper function to replace template variables
const replaceTemplateVariables = (template: string, variables: Record<string, string>): string => {
  let result = template;
  Object.entries(variables).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
  });
  return result;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🚀 Starting monthly report reminder function...');

    // Create Supabase client with service role
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Check if reminder system is enabled
    const { data: settings, error: settingsError } = await supabaseAdmin
      .from('system_settings')
      .select('setting_value, is_active')
      .eq('setting_key', 'monthly_report_reminders')
      .single();

    if (settingsError) {
      console.error('❌ Error fetching system settings:', settingsError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch settings' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const isEnabled = settings?.setting_value?.enabled && settings?.is_active;
    if (!isEnabled) {
      console.log('⏸️ Monthly report reminders are disabled. Skipping email send.');
      return new Response(
        JSON.stringify({ message: 'Reminders disabled', emailsSent: 0 }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Reminders enabled. Proceeding to send emails...');

    // Calculate target month (previous month)
    const now = new Date();
    let targetMonth = now.getMonth(); // 0-indexed
    let targetYear = now.getFullYear();
    
    if (targetMonth === 0) {
      targetMonth = 12;
      targetYear = targetYear - 1;
    }

    console.log(`📅 Target period: ${getMonthName(targetMonth)} ${targetYear}`);

    // Fetch email template
    const { data: template, error: templateError } = await supabaseAdmin
      .from('email_templates')
      .select('*')
      .eq('template_key', 'monthly_report_reminder')
      .eq('is_active', true)
      .single();

    if (templateError || !template) {
      console.error('❌ Error fetching email template:', templateError);
      return new Response(
        JSON.stringify({ error: 'Email template not found' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch all active companies
    const { data: companies, error: companiesError } = await supabaseAdmin
      .from('companies')
      .select('id, name')
      .eq('status', 'active')
      .eq('is_active', true);

    if (companiesError) {
      console.error('❌ Error fetching companies:', companiesError);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch companies' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`📊 Found ${companies?.length || 0} active companies`);

    let emailsSent = 0;
    const monthName = getMonthName(targetMonth);

    // Process each company
    for (const company of companies || []) {
      console.log(`📤 Processing company: ${company.name}`);

      // Fetch founder role user IDs first
      const { data: founderRoles, error: rolesError } = await supabaseAdmin
        .from('user_roles')
        .select('user_id')
        .eq('role', 'founder');

      if (rolesError || !founderRoles || founderRoles.length === 0) {
        console.log(`⚠️ No founder roles found`);
        continue;
      }

      const founderUserIds = founderRoles.map(r => r.user_id);

      // Fetch active founders for this company
      const { data: founders, error: foundersError } = await supabaseAdmin
        .from('profiles')
        .select('id, email:email, full_name')
        .eq('company_id', company.id)
        .eq('is_active', true)
        .in('id', founderUserIds);

      if (foundersError || !founders || founders.length === 0) {
        console.log(`⚠️ No active founders found for ${company.name}`);
        continue;
      }

      const recipientEmails = founders
        .map(f => f.email)
        .filter(email => email !== null) as string[];

      if (recipientEmails.length === 0) {
        console.log(`⚠️ No valid emails for ${company.name}`);
        continue;
      }

      // Generate unique token for this company and period (single use only)
      const token = crypto.randomUUID();
      const expiresAt = new Date();
      expiresAt.setFullYear(expiresAt.getFullYear() + 10); // Set far future expiry - only single use matters

      // Insert token into database
      const { error: tokenError } = await supabaseAdmin
        .from('monthly_report_tokens')
        .insert({
          company_id: company.id,
          token,
          period_month: targetMonth,
          period_year: targetYear,
          expires_at: expiresAt.toISOString(),
          status: 'active'
        });

      if (tokenError) {
        console.error(`❌ Error creating token for ${company.name}:`, tokenError);
        continue;
      }

      console.log(`🔑 Generated token for ${company.name}`);

      // Prepare template variables with tokenized link
      const deadlineDate = `20. ${getMonthName(now.getMonth() + 1)} ${now.getFullYear()}`;
      const tokenizedLink = `https://founder.molainvest.dk/report/${token}`;
      
      const variables = {
        company_name: company.name,
        month_name: monthName,
        year: targetYear.toString(),
        report_link: tokenizedLink,
        deadline_date: deadlineDate
      };

      const subject = replaceTemplateVariables(template.subject, variables);
      const htmlBody = replaceTemplateVariables(template.html_body, variables);

      // Send emails to all founders
      for (const email of recipientEmails) {
        try {
          const emailResponse = await resend.emails.send({
            from: `${template.from_name} <${template.from_email}>`,
            to: [email],
            subject,
            html: htmlBody,
          });

          console.log(`✅ Email sent to ${email}:`, emailResponse);
          emailsSent++;
        } catch (emailError) {
          console.error(`❌ Error sending email to ${email}:`, emailError);
        }
      }

      // Log notification
      await supabaseAdmin
        .from('monthly_report_notifications')
        .insert({
          company_id: company.id,
          notification_type: 'reminder',
          target_month: targetMonth,
          target_year: targetYear,
          recipient_emails: recipientEmails,
          email_status: 'sent'
        });
    }

    console.log(`🎉 Total emails sent: ${emailsSent}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        emailsSent,
        targetMonth: monthName,
        targetYear 
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('❌ Error in send-monthly-report-reminders:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
