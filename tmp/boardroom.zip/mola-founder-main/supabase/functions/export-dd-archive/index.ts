import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';
import JSZip from 'https://esm.sh/jszip@3.10.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Document {
  id: string;
  file_name: string;
  file_path: string;
  file_size: number;
  uploaded_at: string;
  uploaded_by: string;
  category_id: string;
  document_type: string;
  mime_type: string;
  status: string;
  notes: string | null;
  dd_document_categories: {
    category_name: string;
    category_code: string;
  } | null;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          persistSession: false,
        },
      }
    );

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);

    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    console.log('Export DD archive request from user:', user.id);

    const { caseId, deleteFilesFromPortal = false } = await req.json();

    if (!caseId) {
      throw new Error('Case ID is required');
    }

    console.log('Exporting DD case:', caseId, 'Delete files:', deleteFilesFromPortal);

    // Fetch DD case details
    const { data: ddCase, error: caseError } = await supabase
      .from('due_diligence_cases')
      .select('*, companies(name, cvr)')
      .eq('id', caseId)
      .single();

    if (caseError || !ddCase) {
      throw new Error('DD case not found');
    }

    // Fetch all documents for this case with category info
    const { data: documents, error: docsError } = await supabase
      .from('dd_documents')
      .select('*, dd_document_categories(category_name, category_code)')
      .eq('case_id', caseId)
      .is('archived_at', null);

    if (docsError) {
      throw new Error('Failed to fetch documents');
    }

    console.log(`Found ${documents?.length || 0} documents to export`);

    // Fetch all categories for manifest
    const { data: categories, error: catsError } = await supabase
      .from('dd_document_categories')
      .select('*')
      .order('sort_order');

    if (catsError) {
      console.error('Failed to fetch categories:', catsError);
    }

    // Fetch category progress with notes
    const { data: categoryProgress, error: progressError } = await supabase
      .from('dd_category_progress')
      .select('*, dd_document_categories(category_name, category_code)')
      .eq('case_id', caseId);

    if (progressError) {
      console.error('Failed to fetch category progress:', progressError);
    }

    // Create ZIP file
    const zip = new JSZip();

    // Download and add each document to ZIP
    let successCount = 0;
    let failCount = 0;

    for (const doc of (documents as Document[]) || []) {
      try {
        const categoryCode = doc.dd_document_categories?.category_code || 'other';
        const categoryName = doc.dd_document_categories?.category_name || 'Andre';
        
        // Create folder structure: CategoryCode-CategoryName/filename
        const folderName = `${categoryCode}-${categoryName}`.replace(/[^a-zA-Z0-9æøåÆØÅ\-\s]/g, '_');
        
        // Download file from storage
        const { data: fileData, error: downloadError } = await supabase.storage
          .from('company-documents')
          .download(doc.file_path);

        if (downloadError) {
          console.error(`Failed to download file ${doc.file_path}:`, downloadError);
          failCount++;
          continue;
        }

        // Add file to ZIP
        const arrayBuffer = await fileData.arrayBuffer();
        zip.file(`${folderName}/${doc.file_name}`, arrayBuffer);
        successCount++;
        
        console.log(`Added file to ZIP: ${folderName}/${doc.file_name}`);
      } catch (fileError) {
        console.error(`Error processing file ${doc.file_name}:`, fileError);
        failCount++;
      }
    }

    console.log(`ZIP creation: ${successCount} files added, ${failCount} failed`);

    // Create manifest data
    const manifest = {
      export_date: new Date().toISOString(),
      case_id: caseId,
      company_name: ddCase.companies?.name || 'Unknown Company',
      company_cvr: ddCase.companies?.cvr || 'N/A',
      dd_status: ddCase.status,
      dd_started_at: ddCase.started_at,
      dd_completed_at: ddCase.completed_at,
      exported_by: user.id,
      total_documents: documents?.length || 0,
      documents_exported: successCount,
      documents_failed: failCount,
      total_size_bytes: documents?.reduce((sum, doc) => sum + Number(doc.file_size || 0), 0) || 0,
      categories: categories || [],
      category_progress: categoryProgress?.map(cp => ({
        category: cp.dd_document_categories?.category_name || 'Unknown',
        category_code: cp.dd_document_categories?.category_code || 'unknown',
        status: cp.status,
        notes: cp.notes,
        completed_at: cp.completed_at,
      })) || [],
      documents: documents?.map(doc => ({
        file_name: doc.file_name,
        category: doc.dd_document_categories?.category_name || 'Other',
        category_code: doc.dd_document_categories?.category_code || 'other',
        uploaded_at: doc.uploaded_at,
        file_size: doc.file_size,
        document_type: doc.document_type,
        mime_type: doc.mime_type,
        status: doc.status,
        notes: doc.notes,
      })) || [],
    };

    // Add manifest to ZIP
    zip.file('manifest.json', JSON.stringify(manifest, null, 2));

    // Generate ZIP as blob
    console.log('Generating ZIP file...');
    const zipBlob = await zip.generateAsync({ 
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 }
    });

    // Generate archive filename
    const timestamp = new Date().toISOString().split('T')[0];
    const companyName = ddCase.companies?.name?.replace(/[^a-z0-9æøåÆØÅ]/gi, '_') || 'Company';
    const archiveFileName = `${companyName}_DD_Arkiv_${timestamp}.zip`;
    const archivePath = `${caseId}/${archiveFileName}`;

    console.log('Uploading ZIP archive to storage:', archivePath, 'Size:', zipBlob.size);

    // Upload ZIP to dd-archives bucket
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('dd-archives')
      .upload(archivePath, zipBlob, {
        contentType: 'application/zip',
        upsert: true,
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      throw new Error('Failed to upload archive: ' + uploadError.message);
    }

    console.log('Archive uploaded successfully:', uploadData);

    // Get signed URL for download (valid for 7 days)
    const { data: urlData, error: urlError } = await supabase.storage
      .from('dd-archives')
      .createSignedUrl(archivePath, 7 * 24 * 60 * 60);

    if (urlError) {
      console.error('URL generation error:', urlError);
      throw new Error('Failed to generate download URL');
    }

    console.log('Generated signed URL');

    // Update DD case with export info
    const { error: updateError } = await supabase
      .from('due_diligence_cases')
      .update({
        exported_at: new Date().toISOString(),
        exported_by: user.id,
        export_location: `dd-archives/${archivePath}`,
        files_deleted_from_portal: deleteFilesFromPortal,
      })
      .eq('id', caseId);

    if (updateError) {
      console.error('Failed to update case:', updateError);
    }

    // If delete files option is enabled, mark documents as archived
    if (deleteFilesFromPortal && documents && documents.length > 0) {
      console.log('Marking documents as archived and deleting from storage...');

      for (const doc of documents) {
        // Update document metadata
        await supabase
          .from('dd_documents')
          .update({
            archived_at: new Date().toISOString(),
            archived_by: user.id,
            archive_location: `dd-archives/${archivePath}`,
            original_file_size: doc.file_size,
            file_path: `ARCHIVED: ${doc.file_path}`,
          })
          .eq('id', doc.id);

        // Delete file from storage
        const { error: deleteError } = await supabase.storage
          .from('company-documents')
          .remove([doc.file_path]);

        if (deleteError) {
          console.error(`Failed to delete file ${doc.file_path}:`, deleteError);
        }
      }

      console.log('Files deleted from portal storage');
    }

    // Log activity
    await supabase.from('company_activity_log').insert({
      company_id: ddCase.company_id,
      user_id: user.id,
      activity_type: 'dd_exported',
      description: `Eksporterede DD arkiv (${successCount} filer)${deleteFilesFromPortal ? ' og slettede filer fra portal' : ''}`,
      metadata: {
        case_id: caseId,
        document_count: documents?.length || 0,
        documents_exported: successCount,
        documents_failed: failCount,
        files_deleted: deleteFilesFromPortal,
        archive_location: archivePath,
        archive_size_bytes: zipBlob.size,
      },
    });

    console.log('Export completed successfully');

    return new Response(
      JSON.stringify({
        success: true,
        archive_url: urlData.signedUrl,
        archive_location: archivePath,
        archive_size_bytes: zipBlob.size,
        document_count: documents?.length || 0,
        documents_exported: successCount,
        documents_failed: failCount,
        files_deleted: deleteFilesFromPortal,
        expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error: any) {
    console.error('Export error:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Failed to export DD archive',
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    );
  }
});
