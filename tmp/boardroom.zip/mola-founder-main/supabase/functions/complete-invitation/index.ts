import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CompleteInvitationRequest {
  token: string;
  user_id: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, user_id }: CompleteInvitationRequest = await req.json();

    if (!token || !user_id) {
      return new Response(
        JSON.stringify({ error: 'Token og user_id er påkrævet' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Completing invitation for user:', user_id);

    // Initialize Supabase client with service role key to bypass RLS
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Query invitation by token
    const { data: invitation, error: invitationError } = await supabaseAdmin
      .from('user_invitations')
      .select('*')
      .eq('invitation_token', token)
      .single();

    if (invitationError || !invitation) {
      console.error('Invitation not found:', invitationError);
      return new Response(
        JSON.stringify({ error: 'Ugyldig invitation token' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if invitation is still pending
    if (invitation.status !== 'pending') {
      return new Response(
        JSON.stringify({ error: `Invitation er allerede ${invitation.status}` }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if invitation has expired
    const expiresAt = new Date(invitation.expires_at);
    const now = new Date();
    if (expiresAt < now) {
      return new Response(
        JSON.stringify({ error: 'Invitation er udløbet' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Verify email matches
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(user_id);
    if (userError || !userData.user) {
      console.error('User not found:', userError);
      return new Response(
        JSON.stringify({ error: 'Bruger ikke fundet' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (userData.user.email !== invitation.email) {
      return new Response(
        JSON.stringify({ error: 'Email matcher ikke invitation' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Assign role to user (use upsert to handle case where handle_new_user trigger already assigned it)
    console.log('Assigning role:', invitation.invited_role, 'to user:', user_id);
    const { error: roleError } = await supabaseAdmin
      .from('user_roles')
      .upsert(
        {
          user_id: user_id,
          role: invitation.invited_role
        },
        { 
          onConflict: 'user_id,role',
          ignoreDuplicates: true 
        }
      );

    if (roleError) {
      console.error('Error assigning role (non-fatal):', roleError);
      // Don't return error - continue to update profile and invitation status
    }

    // Update profile with company_id or fund_id
    console.log('Updating profile with company_id:', invitation.company_id, 'fund_id:', invitation.fund_id);
    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .update({
        company_id: invitation.company_id,
        fund_id: invitation.fund_id
      })
      .eq('id', user_id);

    if (profileError) {
      console.error('Error updating profile:', profileError);
      return new Response(
        JSON.stringify({ error: 'Kunne ikke opdatere profil: ' + profileError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Mark invitation as accepted
    console.log('Marking invitation as accepted');
    const { error: updateError } = await supabaseAdmin
      .from('user_invitations')
      .update({
        status: 'accepted',
        accepted_at: new Date().toISOString()
      })
      .eq('invitation_token', token);

    if (updateError) {
      console.error('Error updating invitation status:', updateError);
      return new Response(
        JSON.stringify({ error: 'Kunne ikke opdatere invitation status: ' + updateError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Invitation completed successfully');
    return new Response(
      JSON.stringify({ 
        success: true,
        role: invitation.invited_role,
        company_id: invitation.company_id,
        fund_id: invitation.fund_id
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in complete-invitation:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Intern server fejl' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
