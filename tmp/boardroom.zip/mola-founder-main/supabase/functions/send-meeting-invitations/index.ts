import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';
import { Resend } from 'https://esm.sh/resend@2.0.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

interface MeetingFrequencyDays {
  weekly: number;
  biweekly: number;
  monthly: number;
  quarterly: number;
}

const FREQUENCY_DAYS: MeetingFrequencyDays = {
  weekly: 7,
  biweekly: 14,
  monthly: 30,
  quarterly: 90,
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log('Starting meeting invitation check...');

    // Get fund partner with Calendly link (assuming Morten Larsen)
    const { data: fundPartner, error: partnerError } = await supabase
      .from('profiles')
      .select('id, full_name, calendly_link')
      .not('calendly_link', 'is', null)
      .limit(1)
      .single();

    if (partnerError || !fundPartner) {
      console.error('No fund partner with Calendly link found:', partnerError);
      return new Response(
        JSON.stringify({ error: 'No fund partner with Calendly link configured' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found fund partner: ${fundPartner.full_name} with Calendly link`);

    // Get active companies with meeting frequency set
    const { data: companies, error: companiesError } = await supabase
      .from('companies')
      .select('id, name, meeting_frequency, last_meeting_invitation_sent_at')
      .eq('is_active', true)
      .neq('meeting_frequency', 'never');

    if (companiesError) {
      console.error('Error fetching companies:', companiesError);
      throw companiesError;
    }

    console.log(`Found ${companies?.length || 0} companies with meeting frequency set`);

    const results = [];
    const today = new Date();

    for (const company of companies || []) {
      try {
        // Get last meeting for this company
        const { data: lastMeeting, error: meetingError } = await supabase
          .from('company_meetings')
          .select('meeting_date')
          .eq('company_id', company.id)
          .order('meeting_date', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (meetingError) {
          console.error(`Error fetching last meeting for ${company.name}:`, meetingError);
          continue;
        }

        if (!lastMeeting) {
          console.log(`No previous meetings for ${company.name}, skipping`);
          continue;
        }

        // Calculate next meeting due date
        const lastMeetingDate = new Date(lastMeeting.meeting_date);
        const frequencyDays = FREQUENCY_DAYS[company.meeting_frequency as keyof MeetingFrequencyDays];
        const nextDueDate = new Date(lastMeetingDate);
        nextDueDate.setDate(nextDueDate.getDate() + frequencyDays);

        console.log(`${company.name}: Last meeting ${lastMeetingDate.toISOString().split('T')[0]}, Next due ${nextDueDate.toISOString().split('T')[0]}`);

        // Check if it's time to send invitation
        const shouldSendInvitation = today >= nextDueDate;
        
        // Check if we already sent invitation after last meeting
        const alreadySentAfterLastMeeting = company.last_meeting_invitation_sent_at && 
          new Date(company.last_meeting_invitation_sent_at) > lastMeetingDate;

        if (!shouldSendInvitation || alreadySentAfterLastMeeting) {
          console.log(`Skipping ${company.name}: shouldSend=${shouldSendInvitation}, alreadySent=${alreadySentAfterLastMeeting}`);
          continue;
        }

        // Get founder emails for this company
        const { data: founders, error: foundersError } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .eq('company_id', company.id)
          .not('email', 'is', null);

        if (foundersError || !founders || founders.length === 0) {
          console.error(`No founders found for ${company.name}`);
          continue;
        }

        const founderEmails = founders.map(f => f.email).filter(Boolean) as string[];

        // Get email template
        const { data: template, error: templateError } = await supabase
          .from('email_templates')
          .select('*')
          .eq('template_key', 'meeting_invitation')
          .eq('is_active', true)
          .single();

        if (templateError || !template) {
          console.error('Email template not found:', templateError);
          continue;
        }

        // Replace variables in email
        const meetingFrequencyText = {
          weekly: 'ugentlige',
          biweekly: 'to-ugentlige',
          monthly: 'månedlige',
          quarterly: 'kvartalsvise'
        }[company.meeting_frequency as string] || company.meeting_frequency;

        let htmlBody = template.html_body
          .replace(/\{\{company_name\}\}/g, company.name)
          .replace(/\{\{calendly_link\}\}/g, fundPartner.calendly_link)
          .replace(/\{\{fund_partner_name\}\}/g, fundPartner.full_name)
          .replace(/\{\{last_meeting_date\}\}/g, lastMeetingDate.toLocaleDateString('da-DK'))
          .replace(/\{\{meeting_frequency\}\}/g, meetingFrequencyText);

        let subject = template.subject
          .replace(/\{\{meeting_frequency\}\}/g, meetingFrequencyText);

        // Send email to all founders
        const { data: emailResult, error: emailError } = await resend.emails.send({
          from: `${template.from_name} <${template.from_email}>`,
          to: founderEmails,
          subject: subject,
          html: htmlBody,
        });

        if (emailError) {
          console.error(`Failed to send email to ${company.name}:`, emailError);
          results.push({ company: company.name, status: 'failed', error: emailError.message });
          continue;
        }

        if (!emailResult) {
          console.error(`No email result for ${company.name}`);
          results.push({ company: company.name, status: 'failed', error: 'No email result' });
          continue;
        }

        console.log(`Email sent to ${company.name}: ${emailResult.id}`);

        // Update company last invitation sent timestamp
        await supabase
          .from('companies')
          .update({ last_meeting_invitation_sent_at: today.toISOString() })
          .eq('id', company.id);

        // Log invitation in meeting_invitations table
        await supabase
          .from('meeting_invitations')
          .insert({
            company_id: company.id,
            sent_to_emails: founderEmails,
            calendly_link: fundPartner.calendly_link,
            last_meeting_date: lastMeeting.meeting_date,
            next_expected_meeting_date: nextDueDate.toISOString().split('T')[0],
            status: 'sent'
          });

        results.push({ 
          company: company.name, 
          status: 'sent', 
          emailId: emailResult.id,
          recipients: founderEmails 
        });

      } catch (error: any) {
        console.error(`Error processing ${company.name}:`, error);
        results.push({ company: company.name, status: 'error', error: error.message });
      }
    }

    console.log(`Completed. Sent ${results.filter(r => r.status === 'sent').length} invitations`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        results,
        summary: {
          total: companies?.length || 0,
          sent: results.filter(r => r.status === 'sent').length,
          failed: results.filter(r => r.status === 'failed').length,
          errors: results.filter(r => r.status === 'error').length
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in send-meeting-invitations:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
