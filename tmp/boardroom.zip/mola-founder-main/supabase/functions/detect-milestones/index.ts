import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.80.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MonthlyReport {
  id: string;
  company_id: string;
  period_year: number;
  period_month: number;
  revenue_dkk: number;
  ebitda_dkk: number;
  new_customers: number;
  cash_dkk: number;
}

interface Milestone {
  company_id: string;
  milestone_type: string;
  milestone_value: number;
  previous_best?: number;
  metadata: Record<string, any>;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { reportId } = await req.json();

    if (!reportId) {
      throw new Error('reportId is required');
    }

    // Fetch the newly submitted report
    const { data: newReport, error: reportError } = await supabase
      .from('monthly_reports')
      .select('*')
      .eq('id', reportId)
      .single();

    if (reportError || !newReport) {
      throw new Error('Report not found');
    }

    // Fetch all historical reports for this company
    const { data: historicalReports, error: histError } = await supabase
      .from('monthly_reports')
      .select('*')
      .eq('company_id', newReport.company_id)
      .order('period_year', { ascending: true })
      .order('period_month', { ascending: true });

    if (histError) {
      throw new Error('Failed to fetch historical reports');
    }

    const milestones: Milestone[] = [];

    // 1. Best month ever - Revenue
    const previousBestRevenue = Math.max(
      ...historicalReports
        .filter(r => r.id !== newReport.id)
        .map(r => r.revenue_dkk || 0)
    );
    
    if (newReport.revenue_dkk > previousBestRevenue && previousBestRevenue > 0) {
      milestones.push({
        company_id: newReport.company_id,
        milestone_type: 'best_month_revenue',
        milestone_value: newReport.revenue_dkk,
        previous_best: previousBestRevenue,
        metadata: {
          period_year: newReport.period_year,
          period_month: newReport.period_month,
          improvement_pct: ((newReport.revenue_dkk - previousBestRevenue) / previousBestRevenue * 100).toFixed(1)
        }
      });
    }

    // 2. Best month ever - EBITDA
    const previousBestEbitda = Math.max(
      ...historicalReports
        .filter(r => r.id !== newReport.id)
        .map(r => r.ebitda_dkk || 0)
    );
    
    if (newReport.ebitda_dkk > previousBestEbitda && previousBestEbitda > 0) {
      milestones.push({
        company_id: newReport.company_id,
        milestone_type: 'best_month_ebitda',
        milestone_value: newReport.ebitda_dkk,
        previous_best: previousBestEbitda,
        metadata: {
          period_year: newReport.period_year,
          period_month: newReport.period_month,
          improvement_pct: ((newReport.ebitda_dkk - previousBestEbitda) / previousBestEbitda * 100).toFixed(1)
        }
      });
    }

    // 3. Best month ever - New Customers
    const previousBestCustomers = Math.max(
      ...historicalReports
        .filter(r => r.id !== newReport.id)
        .map(r => r.new_customers || 0)
    );
    
    if (newReport.new_customers > previousBestCustomers && previousBestCustomers > 0) {
      milestones.push({
        company_id: newReport.company_id,
        milestone_type: 'best_month_customers',
        milestone_value: newReport.new_customers,
        previous_best: previousBestCustomers,
        metadata: {
          period_year: newReport.period_year,
          period_month: newReport.period_month,
          improvement: newReport.new_customers - previousBestCustomers
        }
      });
    }

    // 4. Fastest growth month-over-month
    const previousMonth = historicalReports
      .filter(r => {
        const reportDate = new Date(r.period_year, r.period_month - 1);
        const newReportDate = new Date(newReport.period_year, newReport.period_month - 1);
        const prevMonthDate = new Date(newReportDate);
        prevMonthDate.setMonth(prevMonthDate.getMonth() - 1);
        return reportDate.getTime() === prevMonthDate.getTime();
      })[0];

    if (previousMonth && previousMonth.revenue_dkk > 0) {
      const growthPct = ((newReport.revenue_dkk - previousMonth.revenue_dkk) / previousMonth.revenue_dkk * 100);
      
      // Calculate historical max growth
      let maxHistoricalGrowth = 0;
      for (let i = 1; i < historicalReports.length; i++) {
        if (historicalReports[i].id === newReport.id) continue;
        const prev = historicalReports[i - 1];
        const curr = historicalReports[i];
        if (prev.revenue_dkk > 0) {
          const growth = ((curr.revenue_dkk - prev.revenue_dkk) / prev.revenue_dkk * 100);
          maxHistoricalGrowth = Math.max(maxHistoricalGrowth, growth);
        }
      }

      if (growthPct > maxHistoricalGrowth && growthPct > 10) {
        milestones.push({
          company_id: newReport.company_id,
          milestone_type: 'fastest_growth',
          milestone_value: growthPct,
          previous_best: maxHistoricalGrowth,
          metadata: {
            period_year: newReport.period_year,
            period_month: newReport.period_month,
            growth_pct: growthPct.toFixed(1)
          }
        });
      }
    }

    // 5. First profitable month
    if (newReport.ebitda_dkk > 0) {
      const previousProfitableMonths = historicalReports.filter(
        r => r.id !== newReport.id && r.ebitda_dkk > 0
      );
      
      if (previousProfitableMonths.length === 0) {
        milestones.push({
          company_id: newReport.company_id,
          milestone_type: 'first_profitable',
          milestone_value: newReport.ebitda_dkk,
          metadata: {
            period_year: newReport.period_year,
            period_month: newReport.period_month
          }
        });
      }
    }

    // 6. Revenue milestones (1M, 2M, 5M, 10M, etc.)
    const revenueMilestones = [1000000, 2000000, 5000000, 10000000, 20000000, 50000000];
    for (const threshold of revenueMilestones) {
      const previouslyReached = historicalReports.some(
        r => r.id !== newReport.id && r.revenue_dkk >= threshold
      );
      
      if (newReport.revenue_dkk >= threshold && !previouslyReached) {
        milestones.push({
          company_id: newReport.company_id,
          milestone_type: 'revenue_milestone',
          milestone_value: threshold,
          metadata: {
            period_year: newReport.period_year,
            period_month: newReport.period_month,
            threshold_label: `${(threshold / 1000000).toFixed(0)}M DKK`
          }
        });
      }
    }

    // Insert detected milestones
    if (milestones.length > 0) {
      const { error: insertError } = await supabase
        .from('founder_milestones')
        .insert(milestones);

      if (insertError) {
        console.error('Error inserting milestones:', insertError);
        throw insertError;
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        milestones: milestones.length,
        detected: milestones 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error detecting milestones:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
