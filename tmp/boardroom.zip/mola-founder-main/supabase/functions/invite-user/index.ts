import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface InviteUserRequest {
  email: string;
  role: string;
  companyId?: string;
  fundId?: string;
  notes?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Get the user from the Authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    // Check if user is admin
    const { data: userRoles, error: rolesError } = await supabaseAdmin
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    if (rolesError) {
      console.error('Error checking user roles:', rolesError);
      throw new Error('Error checking permissions');
    }

    const isAdmin = userRoles?.some((r) => r.role === 'owner' || r.role === 'mola_admin');
    if (!isAdmin) {
      return new Response(
        JSON.stringify({ error: 'Kun administratorer kan invitere brugere' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse request body
    const { email, role, companyId, fundId, notes }: InviteUserRequest = await req.json();

    if (!email || !role) {
      return new Response(
        JSON.stringify({ error: 'Email og rolle er påkrævet' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if user already exists
    const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers();
    const userExists = existingUser.users.some(u => u.email === email);

    if (userExists) {
      return new Response(
        JSON.stringify({ error: 'Bruger med denne email findes allerede' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create invitation record
    const { data: invitation, error: invitationError } = await supabaseAdmin
      .from('user_invitations')
      .insert({
        email,
        invited_role: role,
        invited_by: user.id,
        company_id: companyId || null,
        fund_id: fundId || null,
        notes: notes || null,
        status: 'pending',
      })
      .select()
      .single();

    if (invitationError) {
      console.error('Error creating invitation:', invitationError);
      throw new Error('Kunne ikke oprette invitation');
    }

    // Get inviter's name for the email
    const { data: inviterProfile } = await supabaseAdmin
      .from('profiles')
      .select('full_name')
      .eq('id', user.id)
      .single();

    const inviterName = inviterProfile?.full_name || user.email || 'MOLA Admin';

    // Get company or fund name if applicable
    let companyName, fundName;
    if (companyId) {
      const { data: company } = await supabaseAdmin
        .from('companies')
        .select('name')
        .eq('id', companyId)
        .single();
      companyName = company?.name;
    }
    if (fundId) {
      const { data: fund } = await supabaseAdmin
        .from('funds')
        .select('name')
        .eq('id', fundId)
        .single();
      fundName = fund?.name;
    }

    // Send styled invitation email using our custom function
    const acceptUrl = `${req.headers.get('origin')}/accept-invitation?token=${invitation.invitation_token}`;
    
    const { error: emailError } = await supabaseAdmin.functions.invoke('send-invitation', {
      body: {
        email,
        invitedRole: role,
        inviterName,
        acceptUrl,
        companyName,
        fundName,
      }
    });

    if (emailError) {
      console.error('Error sending invitation email:', emailError);
      
      // Rollback invitation
      await supabaseAdmin
        .from('user_invitations')
        .delete()
        .eq('id', invitation.id);
      
      throw new Error('Kunne ikke sende invitation email');
    }

    // Log activity (optional - if you have an activity log table)
    // await supabaseAdmin
    //   .from('user_activity_log')
    //   .insert({
    //     user_id: user.id,
    //     action: 'invite_user',
    //     entity: 'user',
    //     entity_id: invitation.id,
    //   });

    console.log(`User invited successfully: ${email} with role ${role}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Invitation sendt succesfuldt',
        invitation 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error: any) {
    console.error('Error in invite-user function:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Intern serverfejl' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});