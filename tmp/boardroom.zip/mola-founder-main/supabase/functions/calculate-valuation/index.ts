import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MonthlyReport {
  period_year: number;
  period_month: number;
  revenue_dkk: number;
  ebitda_dkk: number;
}

interface LTMMetrics {
  ltmRevenue: number;
  ltmEBITDA: number;
  monthsUsed: number;
  isAnnualized: boolean;
}

interface ValuationBreakdown {
  revenueComponent: number;
  ebitdaComponent: number;
  totalValuation: number;
  revenueWeight: number;
  ebitdaWeight: number;
  ltmRevenue: number;
  ltmEBITDA: number;
  revenueMultiple: number;
  ebitdaMultiple: number;
}

/**
 * Calculate Last Twelve Months (LTM) metrics from monthly reports
 */
function calculateLTMMetrics(reports: MonthlyReport[]): LTMMetrics {
  if (!reports || reports.length === 0) {
    return {
      ltmRevenue: 0,
      ltmEBITDA: 0,
      monthsUsed: 0,
      isAnnualized: false,
    };
  }

  // Sort reports by date (newest first)
  const sortedReports = [...reports].sort((a, b) => {
    const dateA = new Date(a.period_year, a.period_month - 1);
    const dateB = new Date(b.period_year, b.period_month - 1);
    return dateB.getTime() - dateA.getTime();
  });

  // Take last 12 months (or whatever is available)
  const reportsToUse = sortedReports.slice(0, Math.min(12, sortedReports.length));
  const monthsUsed = reportsToUse.length;

  // Sum up the metrics
  let totalRevenue = 0;
  let totalEBITDA = 0;

  reportsToUse.forEach((report) => {
    totalRevenue += Number(report.revenue_dkk) || 0;
    totalEBITDA += Number(report.ebitda_dkk) || 0;
  });

  // If less than 12 months, annualize
  let ltmRevenue = totalRevenue;
  let ltmEBITDA = totalEBITDA;
  let isAnnualized = false;

  if (monthsUsed < 12) {
    ltmRevenue = (totalRevenue / monthsUsed) * 12;
    ltmEBITDA = (totalEBITDA / monthsUsed) * 12;
    isAnnualized = true;
  }

  return {
    ltmRevenue,
    ltmEBITDA,
    monthsUsed,
    isAnnualized,
  };
}

/**
 * Calculate market-based valuation using weighted revenue and EBITDA multiples
 */
function calculateMarketBasedValuation(params: {
  ltmRevenue: number;
  ltmEBITDA: number;
  revenueMultiple: number;
  ebitdaMultiple: number;
  revenueWeight: number;
}): ValuationBreakdown {
  const { ltmRevenue, ltmEBITDA, revenueMultiple, ebitdaMultiple, revenueWeight } = params;

  const ebitdaWeight = 100 - revenueWeight;

  // Calculate weighted components
  const revenueComponent = ltmRevenue * revenueMultiple * (revenueWeight / 100);
  const ebitdaComponent = ltmEBITDA * ebitdaMultiple * (ebitdaWeight / 100);
  const totalValuation = revenueComponent + ebitdaComponent;

  return {
    revenueComponent,
    ebitdaComponent,
    totalValuation,
    revenueWeight,
    ebitdaWeight,
    ltmRevenue,
    ltmEBITDA,
    revenueMultiple,
    ebitdaMultiple,
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    const { company_id } = await req.json();

    if (!company_id) {
      throw new Error('company_id is required');
    }

    console.log(`Calculating valuation for company: ${company_id}`);

    // 1. Check if company has valuation settings
    const { data: settings, error: settingsError } = await supabaseClient
      .from('company_valuation_settings')
      .select('*')
      .eq('company_id', company_id)
      .single();

    if (settingsError || !settings) {
      console.log(`No valuation settings found for company ${company_id}, skipping auto-calculation`);
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'No valuation settings configured for this company' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    console.log(`Found valuation settings: revenue_multiple=${settings.revenue_multiple}, ebitda_multiple=${settings.ebitda_multiple}`);

    // 2. Fetch monthly reports
    const { data: reports, error: reportsError } = await supabaseClient
      .from('monthly_reports')
      .select('period_year, period_month, revenue_dkk, ebitda_dkk')
      .eq('company_id', company_id)
      .order('period_year', { ascending: false })
      .order('period_month', { ascending: false });

    if (reportsError) {
      throw new Error(`Failed to fetch reports: ${reportsError.message}`);
    }

    if (!reports || reports.length === 0) {
      console.log(`No monthly reports found for company ${company_id}, skipping auto-calculation`);
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'No monthly reports available for valuation calculation' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    console.log(`Found ${reports.length} monthly reports`);

    // 3. Calculate LTM metrics
    const ltmMetrics = calculateLTMMetrics(reports as MonthlyReport[]);
    
    if (ltmMetrics.ltmRevenue === 0 && ltmMetrics.ltmEBITDA === 0) {
      console.log(`LTM metrics are zero, skipping valuation calculation`);
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'LTM metrics are zero, cannot calculate valuation' 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    console.log(`LTM Metrics: Revenue=${ltmMetrics.ltmRevenue}, EBITDA=${ltmMetrics.ltmEBITDA}, Months=${ltmMetrics.monthsUsed}, Annualized=${ltmMetrics.isAnnualized}`);

    // 4. Calculate market-based valuation
    const valuation = calculateMarketBasedValuation({
      ltmRevenue: ltmMetrics.ltmRevenue,
      ltmEBITDA: ltmMetrics.ltmEBITDA,
      revenueMultiple: Number(settings.revenue_multiple),
      ebitdaMultiple: Number(settings.ebitda_multiple),
      revenueWeight: Number(settings.valuation_weight_revenue_pct),
    });

    console.log(`Calculated valuation: ${valuation.totalValuation}`);

    // 5. Get current date for valuation
    const today = new Date();
    const valuationDate = today.toISOString().split('T')[0];
    const currentMonth = today.getMonth() + 1;
    const currentYear = today.getFullYear();

    // 6. Check if there's already a market-based valuation for this month
    const { data: existingValuation } = await supabaseClient
      .from('valuations')
      .select('id')
      .eq('company_id', company_id)
      .like('source', '%Market-based%')
      .gte('as_of_date', `${currentYear}-${String(currentMonth).padStart(2, '0')}-01`)
      .lt('as_of_date', `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-01`)
      .single();

    const source = `Auto-calculated (Market-based) - ${ltmMetrics.monthsUsed} months${ltmMetrics.isAnnualized ? ' annualized' : ''}`;

    if (existingValuation) {
      // Update existing valuation
      console.log(`Updating existing market-based valuation: ${existingValuation.id}`);
      
      const { error: updateError } = await supabaseClient
        .from('valuations')
        .update({
          post_money_valuation_dkk: valuation.totalValuation,
          as_of_date: valuationDate,
          source,
        })
        .eq('id', existingValuation.id);

      if (updateError) {
        throw new Error(`Failed to update valuation: ${updateError.message}`);
      }

      console.log('Valuation updated successfully');
    } else {
      // Create new valuation
      console.log('Creating new market-based valuation');
      
      const { error: insertError } = await supabaseClient
        .from('valuations')
        .insert({
          company_id,
          post_money_valuation_dkk: valuation.totalValuation,
          as_of_date: valuationDate,
          source,
        });

      if (insertError) {
        throw new Error(`Failed to insert valuation: ${insertError.message}`);
      }

      console.log('Valuation created successfully');
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        valuation: valuation.totalValuation,
        ltmMetrics,
        message: existingValuation ? 'Valuation updated' : 'Valuation created'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('Error calculating valuation:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
