import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// AI Sentiment Analysis Function
async function analyzeSentiment(
  title: string, 
  snippet: string, 
  companyName: string
): Promise<"positive" | "neutral" | "negative"> {
  const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
  if (!LOVABLE_API_KEY) {
    return "neutral";
  }

  const prompt = `Analyser sentiment for denne nyhedsartikel om virksomheden "${companyName}":

Titel: ${title}
Uddrag: ${snippet}

Kategoriser som:
- "positive" - God omtale, succes, vækst, priser, investeringer, nye produkter, ansættelser, partnerskaber
- "negative" - Kritik, problemer, afskedigelser, tab, skandaler, konkurser, retssager, dårlige resultater
- "neutral" - Faktuel information, neutrale nyheder, branchenyheder uden klar vinkel

Svar KUN med ét ord: positive, neutral, eller negative`;

  try {
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash-lite',
        messages: [{ role: 'user', content: prompt }],
        max_completion_tokens: 10,
      }),
    });

    if (!response.ok) return "neutral";
    
    const data = await response.json();
    const result = data.choices?.[0]?.message?.content?.toLowerCase().trim() || '';
    
    if (result.includes('positive')) return "positive";
    if (result.includes('negative')) return "negative";
    return "neutral";
  } catch {
    return "neutral";
  }
}

// Domains to filter out from search results
const EXCLUDED_DOMAINS = [
  'facebook.com', 'instagram.com', 'twitter.com', 'x.com', 'linkedin.com',
  'tiktok.com', 'youtube.com', 'pinterest.com', 'threads.net',
  'jobindex.dk', 'ofir.dk', 'jobnet.dk', 'indeed.com', 'glassdoor.com',
  'cvr.dk', 'proff.dk', 'krak.dk', 'degulesider.dk', 'virk.dk',
  'trustpilot.com', 'google.com', 'amazon.com',
  'rte.ie', 'bbc.com', 'bbc.co.uk', 'theguardian.com', 'reuters.com',
];

const DANISH_INDICATORS = ['danmark', 'danish', 'dansk', 'danske', 'københavn', 'aarhus', 'odense', 'aalborg'];
const INTERNATIONAL_INDICATORS = ['ireland', 'irish', 'dublin', 'united kingdom', 'london', 'british', 'american', 'us-based'];

function extractDomain(url: string): string {
  try {
    return new URL(url).hostname.replace('www.', '').toLowerCase();
  } catch {
    return '';
  }
}

function isExcludedUrl(url: string, excludedDomains: string[]): boolean {
  const domain = extractDomain(url);
  return excludedDomains.some(excluded => domain === excluded || domain.endsWith('.' + excluded));
}

function hasInternationalContext(result: any): boolean {
  const content = ((result.title || '') + ' ' + (result.description || '')).toLowerCase();
  const hasIntl = INTERNATIONAL_INDICATORS.some(ind => content.includes(ind));
  const hasDanish = DANISH_INDICATORS.some(ind => content.includes(ind));
  return hasIntl && !hasDanish;
}

function extractPublishedDate(result: any): string | null {
  if (result.date) {
    const parsed = new Date(result.date);
    if (!isNaN(parsed.getTime())) return parsed.toISOString();
  }
  
  const urlPatterns = [/\/(\d{4})-(\d{2})-(\d{2})\//, /\/(\d{4})\/(\d{2})\/(\d{2})\//];
  for (const pattern of urlPatterns) {
    const match = result.url?.match(pattern);
    if (match) {
      const [, year, month, day] = match;
      const date = new Date(`${year}-${month}-${day}`);
      if (!isNaN(date.getTime())) return date.toISOString();
    }
  }
  return null;
}

function extractSource(url: string): string {
  const domain = extractDomain(url);
  const sourceMap: Record<string, string> = {
    'borsen.dk': 'Børsen', 'finans.dk': 'Finans', 'dr.dk': 'DR',
    'tv2.dk': 'TV2', 'bt.dk': 'BT', 'eb.dk': 'Ekstra Bladet',
    'politiken.dk': 'Politiken', 'berlingske.dk': 'Berlingske',
    'jyllands-posten.dk': 'Jyllands-Posten', 'jp.dk': 'Jyllands-Posten',
    'computerworld.dk': 'Computerworld', 'version2.dk': 'Version2',
  };
  return sourceMap[domain] || domain;
}

async function searchFirecrawl(query: string, apiKey: string): Promise<any[]> {
  try {
    const response = await fetch('https://api.firecrawl.dev/v1/search', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        query,
        limit: 10,
        lang: 'da',
        country: 'dk',
        tbs: 'qdr:w', // Last week for scheduled scans
      }),
    });

    if (!response.ok) return [];
    const data = await response.json();
    return data.data || [];
  } catch {
    return [];
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const firecrawlApiKey = Deno.env.get("FIRECRAWL_API_KEY");

    if (!firecrawlApiKey) {
      return new Response(JSON.stringify({ 
        error: "Firecrawl not configured",
        scanned: 0,
        articles_found: 0 
      }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    // Parse request body for optional parameters
    let companyIds: string[] | null = null;
    let scanType = 'scheduled';
    
    try {
      const body = await req.json();
      companyIds = body.company_ids || null;
      scanType = body.scan_type || 'scheduled';
    } catch {
      // No body provided, scan all companies
    }

    // Get active companies
    let companiesQuery = supabase
      .from("companies")
      .select("id, name, cvr, email")
      .eq("is_active", true);
    
    if (companyIds && companyIds.length > 0) {
      companiesQuery = companiesQuery.in("id", companyIds);
    }

    const { data: companies, error: companiesError } = await companiesQuery;

    if (companiesError || !companies) {
      console.error("Failed to fetch companies:", companiesError);
      return new Response(JSON.stringify({ error: "Failed to fetch companies" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Scanning ${companies.length} companies...`);

    // Get global blocked sources
    const { data: blockedSources } = await supabase
      .from("pr_blocked_sources")
      .select("domain");
    
    const globalBlockedDomains = blockedSources?.map(s => s.domain).filter(Boolean) || [];
    const excludedDomains = [...EXCLUDED_DOMAINS, ...globalBlockedDomains];

    // Get global learned sources for auto-approval threshold
    const { data: learnedSources } = await supabase
      .from("pr_learned_sources")
      .select("domain, trust_score")
      .gte("trust_score", 8);
    
    const trustedDomains = new Set(learnedSources?.map(s => s.domain) || []);

    let totalArticlesFound = 0;
    let totalNewArticles = 0;

    // Process companies with rate limiting (2 per second)
    for (const company of companies) {
      try {
        // Clean company name for search
        const cleanName = company.name.replace(/\s*(ApS|A\/S|IVS|K\/S|P\/S|I\/S)\s*$/i, '').trim();
        
        // Build search query
        const searchQuery = `"${cleanName}" Danmark`;
        
        console.log(`Scanning: ${company.name}`);
        
        // Search for articles
        const results = await searchFirecrawl(searchQuery, firecrawlApiKey);
        
        // Get existing article URLs for this company
        const { data: existingArticles } = await supabase
          .from("company_pr_articles")
          .select("url")
          .eq("company_id", company.id);
        
        const existingUrls = new Set(existingArticles?.map(a => a.url.toLowerCase()) || []);
        
        // Filter and process results
        const newArticles = results
          .filter(r => r.url && !existingUrls.has(r.url.toLowerCase()))
          .filter(r => !isExcludedUrl(r.url, excludedDomains))
          .filter(r => !hasInternationalContext(r))
          .slice(0, 10);
        
        totalArticlesFound += newArticles.length;

        // Insert new articles as pending (or auto_approved if from trusted source)
        // Process articles with AI sentiment analysis (batch to avoid rate limits)
        for (let i = 0; i < newArticles.length; i += 3) {
          const batch = newArticles.slice(i, i + 3);
          
          await Promise.all(batch.map(async (article) => {
            const domain = extractDomain(article.url);
            const isTrusted = trustedDomains.has(domain);
            const title = article.title || "Uden titel";
            const snippet = article.description || "";
            
            // Analyze sentiment using AI
            const sentiment = await analyzeSentiment(title, snippet, company.name);
            
            const { error: insertError } = await supabase
              .from("company_pr_articles")
              .upsert({
                company_id: company.id,
                title,
                source: extractSource(article.url),
                url: article.url,
                published_at: extractPublishedDate(article),
                snippet: snippet || null,
                sentiment,
                relevance_score: 50,
                is_saved: isTrusted,
                article_status: isTrusted ? 'auto_approved' : 'pending',
              }, {
                onConflict: 'company_id,url',
                ignoreDuplicates: true,
              });

            if (!insertError) {
              totalNewArticles++;
            }
          }));
        }

        // Log scan result
        await supabase.from("pr_scan_logs").insert({
          company_id: company.id,
          articles_found: results.length,
          articles_new: newArticles.length,
          scan_type: scanType,
        });

        // Rate limiting: wait 500ms between companies
        await new Promise(resolve => setTimeout(resolve, 500));
        
      } catch (companyError) {
        console.error(`Error scanning ${company.name}:`, companyError);
        
        // Log error
        await supabase.from("pr_scan_logs").insert({
          company_id: company.id,
          articles_found: 0,
          articles_new: 0,
          scan_type: scanType,
          error_message: companyError instanceof Error ? companyError.message : "Unknown error",
        });
      }
    }

    console.log(`Scan complete: ${totalArticlesFound} articles found, ${totalNewArticles} new articles saved`);

    return new Response(JSON.stringify({
      success: true,
      companies_scanned: companies.length,
      articles_found: totalArticlesFound,
      articles_new: totalNewArticles,
      scanned_at: new Date().toISOString(),
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Scan error:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Unknown error" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
