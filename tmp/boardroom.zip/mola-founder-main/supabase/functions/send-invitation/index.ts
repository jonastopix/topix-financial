import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendInvitationRequest {
  email: string;
  invitedRole: string;
  inviterName: string;
  acceptUrl: string;
  companyName?: string;
  fundName?: string;
}

const getRoleName = (role: string) => {
  const roleMap: { [key: string]: string } = {
    'mola_admin': 'MOLA Administrator',
    'owner': 'Partner',
    'fund_partner': 'Fund Partner',
    'company_manager': 'Virksomhedsleder',
    'investor': 'Investor',
    'founder': 'Founder'
  };
  return roleMap[role] || role;
};

// Helper function to replace template variables
const replaceTemplateVariables = (template: string, variables: Record<string, string>): string => {
  let result = template;
  Object.entries(variables).forEach(([key, value]) => {
    // Handle both {{variable}} and {{#if variable}} syntax
    result = result.replace(new RegExp(`{{${key}}}`, 'g'), value);
    // Handle conditional blocks - simple implementation
    const ifRegex = new RegExp(`{{#if ${key}}}([\\s\\S]*?){{/if}}`, 'g');
    if (value) {
      result = result.replace(ifRegex, '$1');
    } else {
      result = result.replace(ifRegex, '');
    }
  });
  return result;
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Parse request body
    const { 
      email, 
      invitedRole, 
      inviterName, 
      acceptUrl,
      companyName,
      fundName 
    }: SendInvitationRequest = await req.json();

    console.log('Sending invitation email to:', email);

    // Fetch email template
    const { data: template, error: templateError } = await supabaseClient
      .from('email_templates')
      .select('*')
      .eq('template_key', 'user_invitation')
      .eq('is_active', true)
      .single();

    if (templateError || !template) {
      console.error('Could not find email template:', templateError);
      return new Response(
        JSON.stringify({ error: 'Email template not found' }), 
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get invitee name from email (part before @)
    const inviteeName = email.split('@')[0];

    // Prepare template variables
    const variables = {
      invitee_name: inviteeName,
      inviter_name: inviterName,
      role_name: getRoleName(invitedRole),
      accept_url: acceptUrl,
      company_name: companyName || '',
      fund_name: fundName || '',
      year: new Date().getFullYear().toString()
    };

    const subject = replaceTemplateVariables(template.subject, variables);
    const htmlBody = replaceTemplateVariables(template.html_body, variables);

    // Send email via Resend
    const resend = new Resend(Deno.env.get('RESEND_API_KEY') as string);
    const { data, error } = await resend.emails.send({
      from: `${template.from_name} <${template.from_email}>`,
      to: [email],
      subject,
      html: htmlBody,
    });

    if (error) {
      console.error('Error sending email:', error);
      throw error;
    }

    console.log('Email sent successfully:', data);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Invitation email sendt succesfuldt',
        emailId: data?.id 
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error: any) {
    console.error('Error in send-invitation function:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Kunne ikke sende invitation email' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
