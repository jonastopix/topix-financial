import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.80.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verify admin status
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { data: roles } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id);

    const isAdmin = roles?.some(r => r.role === 'owner' || r.role === 'mola_admin');
    if (!isAdmin) {
      throw new Error('Forbidden: Admin access required');
    }

    const { action, userId, role } = await req.json();

    // Additional check: Only owners can assign/remove owner role
    if (role === 'owner') {
      const isOwner = roles?.some(r => r.role === 'owner');
      if (!isOwner) {
        throw new Error('Forbidden: Only owners can manage owner role');
      }
    }

    if (!action || !userId || !role) {
      throw new Error('Missing required fields: action, userId, role');
    }

    let result;

    if (action === 'add_role') {
      // Add role
      const { error } = await supabase
        .from('user_roles')
        .insert({ user_id: userId, role });

      if (error && !error.message.includes('duplicate')) throw error;

      // Log activity
      await supabase.from('user_activity_log').insert({
        user_id: userId,
        admin_user_id: user.id,
        action: 'role_added',
        details: { role },
      });

      result = { success: true, message: 'Role added successfully' };
      console.log(`Role ${role} added to user ${userId} by admin ${user.id}`);
    } else if (action === 'remove_role') {
      // Remove role
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId)
        .eq('role', role);

      if (error) throw error;

      // Log activity
      await supabase.from('user_activity_log').insert({
        user_id: userId,
        admin_user_id: user.id,
        action: 'role_removed',
        details: { role },
      });

      result = { success: true, message: 'Role removed successfully' };
      console.log(`Role ${role} removed from user ${userId} by admin ${user.id}`);
    } else {
      throw new Error('Invalid action. Must be add_role or remove_role');
    }

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error managing user roles:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
