import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signUp: (email: string, password: string, fullName: string, companyName: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  updatePassword: (newPassword: string) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const SESSION_MAX_AGE_DAYS = 30;
  const SESSION_STARTED_KEY = 'session_started_at';

  const checkSessionExpiry = async () => {
    try {
      const sessionStarted = localStorage.getItem(SESSION_STARTED_KEY);
      if (sessionStarted) {
        const startDate = new Date(sessionStarted);
        const now = new Date();
        const daysDiff = (now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24);
        
        if (daysDiff > SESSION_MAX_AGE_DAYS) {
          // Session expired - sign out
          localStorage.removeItem(SESSION_STARTED_KEY);
          await supabase.auth.signOut();
          toast({
            title: "Session udløbet",
            description: "Din session er udløbet efter 30 dage. Log venligst ind igen.",
          });
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('localStorage error in checkSessionExpiry:', error);
      return false;
    }
  };

  useEffect(() => {
    let isMounted = true;
    
    // Fallback timeout - ensures loading never hangs indefinitely
    const loadingTimeout = setTimeout(() => {
      if (isMounted) {
        console.warn('Auth loading timeout reached after 5 seconds');
        setLoading(false);
      }
    }, 5000);

    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (!isMounted) return;
        
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);
        clearTimeout(loadingTimeout);
        
        // Set session start time for new logins
        if (event === 'SIGNED_IN' && session) {
          try {
            if (!localStorage.getItem(SESSION_STARTED_KEY)) {
              localStorage.setItem(SESSION_STARTED_KEY, new Date().toISOString());
            }
          } catch (error) {
            console.error('localStorage error:', error);
          }
        }
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (!isMounted) return;
      
      if (session) {
        // Check if session has expired
        const expired = await checkSessionExpiry();
        if (expired) {
          setSession(null);
          setUser(null);
          setLoading(false);
          clearTimeout(loadingTimeout);
          return;
        }
        
        // Set session start time for existing users who don't have it
        try {
          if (!localStorage.getItem(SESSION_STARTED_KEY)) {
            localStorage.setItem(SESSION_STARTED_KEY, new Date().toISOString());
          }
        } catch (error) {
          console.error('localStorage error:', error);
        }
      }
      
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
      clearTimeout(loadingTimeout);
    }).catch((error) => {
      console.error('Error getting session:', error);
      if (isMounted) {
        setLoading(false);
        clearTimeout(loadingTimeout);
      }
    });

    return () => {
      isMounted = false;
      clearTimeout(loadingTimeout);
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    // Create AbortController for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 12000);
    
    try {
      // Use rate-limited login edge function with timeout
      const { data: fnData, error: fnError } = await supabase.functions.invoke('rate-limited-login', {
        body: { email, password }
      });

      clearTimeout(timeoutId);

      if (fnError) {
        toast({
          title: "Login fejlede",
          description: fnError.message || "Der opstod en fejl ved login",
          variant: "destructive",
        });
        return { error: fnError };
      }

      // Check for rate limiting
      if (fnData?.rateLimited) {
        const rateLimitError = new Error(fnData.error);
        toast({
          title: "For mange loginforsøg",
          description: fnData.error,
          variant: "destructive",
        });
        return { error: rateLimitError };
      }

      // Check for auth errors from the function
      if (fnData?.error && !fnData?.session) {
        const authError = new Error(fnData.error);
        const remainingMsg = fnData.remainingAttempts !== undefined 
          ? ` (${fnData.remainingAttempts} forsøg tilbage)`
          : '';
        toast({
          title: "Login fejlede",
          description: `${fnData.error}${remainingMsg}`,
          variant: "destructive",
        });
        return { error: authError };
      }

      // Successfully authenticated via backend function - now set the session locally
      if (fnData?.session) {
        const { error: setSessionError } = await supabase.auth.setSession({
          access_token: fnData.session.access_token,
          refresh_token: fnData.session.refresh_token,
        });

        if (setSessionError) {
          toast({
            title: "Session fejl",
            description: setSessionError.message,
            variant: "destructive",
          });
          return { error: setSessionError };
        }

        // Ensure UI updates immediately even if onAuthStateChange is delayed on some devices
        setSession(fnData.session);
        setUser(fnData.user ?? fnData.session.user ?? null);
        setLoading(false);

        // Check if user is active (don’t block login if profile fetch errors)
        const userId = (fnData.user?.id ?? fnData.session.user?.id) as string | undefined;
        if (userId) {
          const { data: profile, error: profileError } = await supabase
            .from('profiles')
            .select('is_active, company_id')
            .eq('id', userId)
            .maybeSingle();

          if (profileError) {
            console.error('Error fetching profile:', profileError);
          }

          if (profile && profile.is_active === false) {
            // User is deactivated - sign them out
            await supabase.auth.signOut();
            setSession(null);
            setUser(null);

            const deactivationError = new Error(
              'Din konto er blevet deaktiveret. Kontakt MOLA support for mere information.'
            );

            toast({
              title: "Adgang nægtet",
              description: deactivationError.message,
              variant: "destructive",
            });

            return { error: deactivationError };
          }
        }
      }

      return { error: null };
    } catch (err: any) {
      clearTimeout(timeoutId);
      
      // Håndter timeout specifikt
      if (err.name === 'AbortError') {
        console.error('Login timeout');
        toast({
          title: "Timeout",
          description: "Login svar blev ikke modtaget. Prøv igen.",
          variant: "destructive",
        });
        return { error: new Error('Timeout') };
      }
      
      console.error('Login error:', err);
      toast({
        title: "Login fejlede",
        description: err.message || "Der opstod en uventet fejl",
        variant: "destructive",
      });
      return { error: err };
    }
  };

  const signUp = async (email: string, password: string, fullName: string, companyName: string) => {
    const redirectUrl = `${window.location.origin}/`;
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          full_name: fullName,
          company_name: companyName,
        },
      },
    });

    if (error) {
      toast({
        title: "Registrering fejlede",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Registrering gennemført",
        description: "Du er nu logget ind!",
      });
    }

    return { error };
  };

  const signOut = async () => {
    localStorage.removeItem(SESSION_STARTED_KEY);
    await supabase.auth.signOut();
    toast({
      title: "Logget ud",
      description: "Du er nu logget ud.",
    });
  };

  const resetPassword = async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });

    if (error) {
      toast({
        title: "Fejl",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Email sendt",
        description: "Tjek din indbakke for at nulstille dit password.",
      });
    }

    return { error };
  };

  const updatePassword = async (newPassword: string) => {
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    });

    if (error) {
      toast({
        title: "Fejl",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Password opdateret",
        description: "Dit password er nu opdateret.",
      });
    }

    return { error };
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, signIn, signUp, signOut, resetPassword, updatePassword }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
