import React, { createContext, useContext, ReactNode } from 'react';
import { useGlobalKeyboardShortcuts } from '@/hooks/useGlobalKeyboardShortcuts';
import CreateTaskDialog from '@/components/CreateTaskDialog';
import { GlobalSearchDialog } from '@/components/GlobalSearchDialog';
import { ActivityShortcutDialog } from '@/components/ActivityShortcutDialog';

interface KeyboardShortcutContextType {
  isCreateTaskOpen: boolean;
  setIsCreateTaskOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isActivityOpen: boolean;
  setIsActivityOpen: (open: boolean) => void;
}

const KeyboardShortcutContext = createContext<KeyboardShortcutContextType | undefined>(undefined);

export const useKeyboardShortcuts = () => {
  const context = useContext(KeyboardShortcutContext);
  if (!context) {
    throw new Error('useKeyboardShortcuts must be used within a KeyboardShortcutProvider');
  }
  return context;
};

interface KeyboardShortcutProviderProps {
  children: ReactNode;
}

export const KeyboardShortcutProvider = ({ children }: KeyboardShortcutProviderProps) => {
  const { 
    isCreateTaskOpen, 
    setIsCreateTaskOpen, 
    isSearchOpen, 
    setIsSearchOpen,
    isActivityOpen,
    setIsActivityOpen,
  } = useGlobalKeyboardShortcuts();

  return (
    <KeyboardShortcutContext.Provider value={{ 
      isCreateTaskOpen, 
      setIsCreateTaskOpen, 
      isSearchOpen, 
      setIsSearchOpen,
      isActivityOpen,
      setIsActivityOpen,
    }}>
      {children}
      <CreateTaskDialog 
        open={isCreateTaskOpen} 
        onOpenChange={setIsCreateTaskOpen}
      />
      <GlobalSearchDialog
        open={isSearchOpen}
        onOpenChange={setIsSearchOpen}
      />
      <ActivityShortcutDialog
        open={isActivityOpen}
        onOpenChange={setIsActivityOpen}
      />
    </KeyboardShortcutContext.Provider>
  );
};
