import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useLocation } from 'react-router-dom';

type UserRole = 'founder' | 'mola_admin' | 'fund_partner' | 'owner' | 'dd_partner' | 'external_viewer' | 'investor';

interface RoleContextType {
  activeRole: UserRole;
  availableRoles: UserRole[];
  switchRole: (role: UserRole) => void;
  isAdmin: boolean;
  isOwner: boolean;
  hasAdminAccess: boolean;
  selectedCompanyId: string | null;
  setSelectedCompanyId: (id: string | null) => void;
}

const RoleContext = createContext<RoleContextType | undefined>(undefined);

export const RoleProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const location = useLocation();
  const [activeRole, setActiveRole] = useState<UserRole>('founder');
  const [availableRoles, setAvailableRoles] = useState<UserRole[]>(['founder']);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setAvailableRoles(['founder']);
      setActiveRole('founder');
      setSelectedCompanyId(null);
      return;
    }

    const fetchUserRoles = async () => {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);

      if (!error && data) {
        const roles = data.map(r => r.role as UserRole);
        setAvailableRoles(roles);
        
        // Priority: owner > mola_admin > fund_partner > founder > investor > others
        if (roles.includes('owner')) {
          setActiveRole('owner');
        } else if (roles.includes('mola_admin')) {
          setActiveRole('mola_admin');
        } else if (roles.includes('fund_partner')) {
          setActiveRole('fund_partner');
        } else if (roles.includes('investor')) {
          setActiveRole('investor');
          // For investors, fetch their company from cap table
          const { data: capEntry } = await supabase
            .from('company_cap_table')
            .select('company_id')
            .eq('user_id', user.id)
            .maybeSingle();
          if (capEntry) {
            setSelectedCompanyId(capEntry.company_id);
          }
        } else {
          setActiveRole(roles[0] || 'founder');
        }
      }
    };

    fetchUserRoles();
  }, [user]);

  // Reset company selection only on specific routes
  useEffect(() => {
    const userHasAdminAccess = availableRoles.includes('owner') || availableRoles.includes('mola_admin');
    
    // Don't reset if:
    // 1. On financial-dashboard route
    // 2. User has admin access and is in founder view (simulating founder)
    if (location.pathname !== '/financial-dashboard') {
      // Only reset if user is not an admin simulating founder view
      if (!(userHasAdminAccess && activeRole === 'founder')) {
        setSelectedCompanyId(null);
      }
    }
  }, [location.pathname, activeRole, availableRoles]);

  const switchRole = async (role: UserRole) => {
    if (availableRoles.includes(role)) {
      setActiveRole(role);
      // Check if user has admin access
      const userHasAdminAccess = availableRoles.includes('owner') || availableRoles.includes('mola_admin');
      
      // Reset company selection when switching to roles that don't need it
      if (role === 'fund_partner') {
        setSelectedCompanyId(null);
      } else if (role === 'founder') {
        // For admins simulating founder view, set their own company
        if (userHasAdminAccess && user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('company_id')
            .eq('id', user.id)
            .maybeSingle();
          if (profile?.company_id) {
            setSelectedCompanyId(profile.company_id);
          }
        } else {
          setSelectedCompanyId(null);
        }
      } else if (role === 'investor' && user) {
        // For investors, fetch their company from cap table
        const { data: capEntry } = await supabase
          .from('company_cap_table')
          .select('company_id')
          .eq('user_id', user.id)
          .maybeSingle();
        if (capEntry) {
          setSelectedCompanyId(capEntry.company_id);
        }
      }
    }
  };

  const isAdmin = activeRole === 'owner' || activeRole === 'mola_admin';
  const isOwner = activeRole === 'owner';
  const hasAdminAccess = availableRoles.includes('owner') || availableRoles.includes('mola_admin');

  return (
    <RoleContext.Provider
      value={{
        activeRole,
        availableRoles,
        switchRole,
        isAdmin,
        isOwner,
        hasAdminAccess,
        selectedCompanyId,
        setSelectedCompanyId,
      }}
    >
      {children}
    </RoleContext.Provider>
  );
};

export const useRole = () => {
  const context = useContext(RoleContext);
  if (!context) {
    throw new Error('useRole must be used within RoleProvider');
  }
  return context;
};