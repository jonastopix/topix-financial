import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Info, AlertCircle } from 'lucide-react';

const Version = () => {
  return (
    <Layout>
      <div className="max-w-2xl mx-auto">
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <Info className="h-5 w-5" />
              Version Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-foreground">Current Version:</span>
                <Badge variant="secondary" className="text-base">V1 Draft</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Dette er første version af MOLA Founder Portal
              </p>
            </div>

            <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                <div className="space-y-1">
                  <p className="font-semibold text-destructive">Ikke publiceret</p>
                  <p className="text-sm text-foreground">
                    Denne version er endnu ikke publiceret og kører kun som draft.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Features i V1:</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-accent">✓</span>
                  <span>Login og rollebaseret adgang (Founder, MOLA Admin)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent">✓</span>
                  <span>Dashboard med progress tracking</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent">✓</span>
                  <span>5 upload-kategorier med dokumenthåndtering</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent">✓</span>
                  <span>Status-tracking (færdig/delvist/mangler)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent">✓</span>
                  <span>Kontaktformular</span>
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Kommer i V2:</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-primary">○</span>
                  <span>Integration med Monday.com</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">○</span>
                  <span>Integration med Google Drive</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">○</span>
                  <span>AI-genereret due diligence rapport</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary">○</span>
                  <span>Realtid notifikationer</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Version;
