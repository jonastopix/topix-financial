import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Plus, AlertCircle, Target, BarChart3, Edit3, LineChart } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AddValuationDialog } from '@/components/AddValuationDialog';
import { ValuationHistoryChart } from '@/components/ValuationHistoryChart';
import { formatCurrency } from '@/lib/formatters';
import { format } from 'date-fns';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const PortfolioValuations = () => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedCompanyForHistory, setSelectedCompanyForHistory] = useState<string>('');
  const queryClient = useQueryClient();

  // Real-time subscriptions for valuations and funding rounds
  useEffect(() => {
    const valuationsChannel = supabase
      .channel('valuations-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valuations'
        },
        () => {
          // Invalidate queries to refetch data
          queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
          queryClient.invalidateQueries({ queryKey: ['company-valuation-history'] });
        }
      )
      .subscribe();

    const fundingRoundsChannel = supabase
      .channel('funding-rounds-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'funding_rounds'
        },
        () => {
          // Invalidate queries since funding rounds affect valuations
          queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
        }
      )
      .subscribe();

    const settingsChannel = supabase
      .channel('valuation-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'company_valuation_settings'
        },
        () => {
          queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(valuationsChannel);
      supabase.removeChannel(fundingRoundsChannel);
      supabase.removeChannel(settingsChannel);
    };
  }, [queryClient]);

  // Fetch companies with their latest valuations
  const { data: companiesWithValuations, isLoading } = useQuery({
    queryKey: ['companies-valuations'],
    queryFn: async () => {
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, fund_id, total_equity_share_pct, equity_share_pct, status')
        .eq('is_active', true)
        .not('status', 'in', '("exited","bankruptcy","rejected","archived")')
        .order('name');
      
      if (companiesError) throw companiesError;

      // Get all valuations
      const { data: valuations, error: valuationsError } = await supabase
        .from('valuations')
        .select('*')
        .order('as_of_date', { ascending: false });
      
      if (valuationsError) throw valuationsError;

      // Get all valuation settings
      const { data: settings, error: settingsError } = await supabase
        .from('company_valuation_settings')
        .select('*');
      
      if (settingsError) throw settingsError;

      // Get funds
      const { data: funds, error: fundsError } = await supabase
        .from('funds')
        .select('id, name');
      
      if (fundsError) throw fundsError;

      // Get funding rounds to calculate actual equity
      const { data: fundingRounds, error: fundingRoundsError } = await supabase
        .from('funding_rounds')
        .select('company_id, equity_acquired_pct');
      
      if (fundingRoundsError) throw fundingRoundsError;

      return companies.map(company => {
        const companyValuations = valuations.filter(v => v.company_id === company.id);
        const latestValuation = companyValuations[0];
        const companySetting = settings?.find(s => s.company_id === company.id);
        const fund = funds?.find(f => f.id === company.fund_id);
        
        // Calculate equity with priority: sum of funding_rounds > total_equity_share_pct > equity_share_pct
        const companyFundingRounds = fundingRounds?.filter(f => f.company_id === company.id) || [];
        let equityPct = 0;
        if (companyFundingRounds.length > 0) {
          equityPct = companyFundingRounds.reduce((sum, r) => sum + (r.equity_acquired_pct || 0), 0);
        } else {
          equityPct = company.total_equity_share_pct || company.equity_share_pct || 0;
        }

        return {
          ...company,
          fund_name: fund?.name || '-',
          latest_valuation: latestValuation,
          valuation_settings: companySetting,
          equity_pct: equityPct,
        };
      });
    },
  });

  const companiesForDialog = companiesWithValuations?.map(c => ({ id: c.id, name: c.name })) || [];
  const companiesWithoutValuation = companiesWithValuations?.filter(c => !c.latest_valuation) || [];

  // Fetch all valuations for the selected company
  const { data: selectedCompanyValuations, isLoading: isLoadingHistory } = useQuery({
    queryKey: ['company-valuation-history', selectedCompanyForHistory],
    queryFn: async () => {
      if (!selectedCompanyForHistory) return [];
      
      const { data, error } = await supabase
        .from('valuations')
        .select('*')
        .eq('company_id', selectedCompanyForHistory)
        .order('as_of_date', { ascending: true });
      
      if (error) throw error;
      return data;
    },
    enabled: !!selectedCompanyForHistory,
  });

  const selectedCompany = companiesWithValuations?.find(c => c.id === selectedCompanyForHistory);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold">Valuations</h1>
            <p className="text-muted-foreground mt-1">
              Administrer valuations for alle selskaber i porteføljen
            </p>
          </div>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Valuation
          </Button>
        </div>

        {/* Warning if companies missing valuations */}
        {companiesWithoutValuation.length > 0 && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              {companiesWithoutValuation.length} {companiesWithoutValuation.length === 1 ? 'selskab mangler' : 'selskaber mangler'} valuation. 
              TVPI vil være unøjagtig uden valuations.
            </AlertDescription>
          </Alert>
        )}

        {/* Tabs for Portfolio Presets vs Company Valuations */}
        <Tabs defaultValue="companies" className="space-y-6">
          <TabsList>
            <TabsTrigger value="companies">Company Valuations</TabsTrigger>
            <TabsTrigger value="history">Valuation History</TabsTrigger>
            <TabsTrigger value="presets">Portfolio Presets</TabsTrigger>
          </TabsList>

          {/* Valuation History Tab */}
          <TabsContent value="history" className="space-y-4">
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <LineChart className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Valuation History</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Se udvikling i valuations over tid og sammenlign funding rounds med market-based beregninger
              </p>
              
              <div className="mb-6">
                <label className="text-sm font-medium mb-2 block">Select Company</label>
                <Select value={selectedCompanyForHistory} onValueChange={setSelectedCompanyForHistory}>
                  <SelectTrigger className="w-full md:w-[400px]">
                    <SelectValue placeholder="Vælg et selskab..." />
                  </SelectTrigger>
                  <SelectContent>
                    {companiesWithValuations?.map((company) => (
                      <SelectItem key={company.id} value={company.id}>
                        {company.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedCompanyForHistory && (
                isLoadingHistory ? (
                  <div className="text-center py-8 text-muted-foreground">Loading history...</div>
                ) : (
                  <ValuationHistoryChart 
                    valuations={selectedCompanyValuations || []} 
                    companyName={selectedCompany?.name || ''}
                  />
                )
              )}

              {!selectedCompanyForHistory && (
                <div className="text-center py-12 text-muted-foreground">
                  <LineChart className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Vælg et selskab for at se valuation historie</p>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Portfolio Presets Tab */}
          <TabsContent value="presets" className="space-y-4">
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Standard Multipler</h2>
              </div>
              <p className="text-muted-foreground">
                Definer standard revenue og EBITDA multipler som kan anvendes på tværs af porteføljen
              </p>
              <div className="mt-6">
                <p className="text-sm text-muted-foreground">Portfolio presets funktionalitet kommer her</p>
              </div>
            </Card>
          </TabsContent>

          {/* Company Valuations Tab */}
          <TabsContent value="companies" className="space-y-4">
            <Card className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-5 w-5 text-primary" />
                <h2 className="text-xl font-bold">Company Valuations</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Oversigt over alle selskaber med deres nuværende valuations
              </p>
              {isLoading ? (
                <div className="text-center py-8 text-muted-foreground">Loading...</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2 font-semibold">Company</th>
                        <th className="text-left p-2 font-semibold">Fund</th>
                        <th className="text-right p-2 font-semibold">Equity %</th>
                        <th className="text-right p-2 font-semibold">Latest Valuation</th>
                        <th className="text-left p-2 font-semibold">Source</th>
                        <th className="text-left p-2 font-semibold">Date</th>
                        <th className="text-right p-2 font-semibold">MOLA Value</th>
                        <th className="text-left p-2 font-semibold">Settings</th>
                      </tr>
                    </thead>
                    <tbody>
                      {companiesWithValuations && companiesWithValuations.length > 0 ? (
                        companiesWithValuations.map((company) => {
                          const molaValue = company.latest_valuation 
                            ? company.latest_valuation.post_money_valuation_dkk * (company.equity_pct / 100)
                            : 0;
                          
                          return (
                            <tr key={company.id} className="border-b hover:bg-muted/50">
                              <td className="p-2">
                                <div className="font-medium">{company.name}</div>
                              </td>
                              <td className="p-2 text-sm text-muted-foreground">{company.fund_name}</td>
                              <td className="p-2 text-right">{company.equity_pct.toFixed(2)}%</td>
                              <td className="p-2 text-right font-medium">
                                {company.latest_valuation ? (
                                  formatCurrency(company.latest_valuation.post_money_valuation_dkk, 0)
                                ) : (
                                  <Badge variant="outline">No valuation</Badge>
                                )}
                              </td>
                              <td className="p-2 text-sm">
                                {company.latest_valuation?.source ? (
                                  company.latest_valuation.source.includes('Funding Round') ? (
                                    <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                                      <Target className="h-3 w-3" />
                                      Funding Round
                                    </Badge>
                                  ) : company.latest_valuation.source.includes('Market-based') || company.latest_valuation.source.includes('Auto-calculated') ? (
                                    <Badge variant="outline" className="flex items-center gap-1 w-fit">
                                      <BarChart3 className="h-3 w-3" />
                                      Market-based
                                    </Badge>
                                  ) : (
                                    <Badge variant="default" className="flex items-center gap-1 w-fit">
                                      <Edit3 className="h-3 w-3" />
                                      Manual
                                    </Badge>
                                  )
                                ) : '-'}
                              </td>
                              <td className="p-2 text-sm">
                                {company.latest_valuation 
                                  ? format(new Date(company.latest_valuation.as_of_date), 'dd MMM yyyy')
                                  : '-'
                                }
                              </td>
                              <td className="p-2 text-right font-bold text-primary">
                                {company.latest_valuation ? formatCurrency(molaValue, 0) : '-'}
                              </td>
                              <td className="p-2">
                                <Link to={`/company/${company.id}`}>
                                  {company.valuation_settings ? (
                                    <Badge 
                                      variant="secondary" 
                                      className="hover:bg-primary/20 cursor-pointer"
                                      title={`Revenue: ${company.valuation_settings.revenue_multiple}x, EBITDA: ${company.valuation_settings.ebitda_multiple}x`}
                                    >
                                      Configured
                                    </Badge>
                                  ) : (
                                    <Badge variant="outline" className="hover:bg-primary/10 cursor-pointer">
                                      Not set
                                    </Badge>
                                  )}
                                </Link>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={8} className="p-4 text-center text-muted-foreground">
                            Ingen selskaber fundet
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </TabsContent>
        </Tabs>

        <AddValuationDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          companies={companiesForDialog}
        />
      </div>
    </Layout>
  );
};

export default PortfolioValuations;
