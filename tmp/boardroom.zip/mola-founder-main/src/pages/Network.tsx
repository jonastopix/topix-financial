import { useState, useMemo } from 'react';
import Layout from '@/components/Layout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { TrustedPartnerCard } from '@/components/TrustedPartnerCard';
import { TrustedPartnersTable } from '@/components/TrustedPartnersTable';
import { CreateTrustedPartnerDialog } from '@/components/CreateTrustedPartnerDialog';
import { EditTrustedPartnerDialog } from '@/components/EditTrustedPartnerDialog';
import { useTrustedPartners, useTrustedPartnerCategories, TrustedPartner } from '@/hooks/useTrustedPartners';
import { usePartnerRatingStats } from '@/hooks/usePartnerRatings';
import { useRole } from '@/contexts/RoleContext';
import { Handshake, Search, Building2, Plus, ArrowUpDown, LayoutList, LayoutGrid } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

const Network = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingPartner, setEditingPartner] = useState<TrustedPartner | null>(null);
  const [sortBy, setSortBy] = useState<'name' | 'rating'>('name');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  
  const { hasAdminAccess } = useRole();
  const { data: categories, isLoading: categoriesLoading } = useTrustedPartnerCategories();
  const { data: partners, isLoading: partnersLoading } = useTrustedPartners();
  const { data: ratingStats, isLoading: ratingsLoading } = usePartnerRatingStats();

  const getRatingStatsForPartner = (partnerId: string) => {
    return ratingStats?.find(s => s.partner_id === partnerId);
  };

  const filteredAndSortedPartners = useMemo(() => {
    if (!partners) return [];
    
    let filtered = partners.filter(partner => {
      const matchesSearch = searchQuery === '' || 
        partner.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        partner.contact_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        partner.description?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'all' || partner.category_id === selectedCategory;
      
      return matchesSearch && matchesCategory;
    });

    // Sort partners
    if (sortBy === 'rating') {
      filtered = [...filtered].sort((a, b) => {
        const aStats = getRatingStatsForPartner(a.id);
        const bStats = getRatingStatsForPartner(b.id);
        const aRating = aStats?.average_rating ?? 0;
        const bRating = bStats?.average_rating ?? 0;
        return bRating - aRating; // Highest first
      });
    } else {
      filtered = [...filtered].sort((a, b) => 
        a.company_name.localeCompare(b.company_name, 'da')
      );
    }

    return filtered;
  }, [partners, searchQuery, selectedCategory, sortBy, ratingStats]);

  const getIcon = (iconName: string) => {
    const IconComponent = (LucideIcons as any)[iconName];
    return IconComponent ? <IconComponent className="h-4 w-4" /> : <Building2 className="h-4 w-4" />;
  };

  const handleEditPartner = (partner: TrustedPartner) => {
    setEditingPartner(partner);
    setEditDialogOpen(true);
  };

  const isLoading = categoriesLoading || partnersLoading || ratingsLoading;

  const totalRatedPartners = ratingStats?.filter(s => s.rating_count > 0).length ?? 0;

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Handshake className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">MOLA Netværk</h1>
              <p className="text-muted-foreground">Trusted partners fra vores netværk</p>
            </div>
          </div>
          
          {/* Search + Add button */}
          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <div className="relative flex-1 md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Søg efter partnere..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            {hasAdminAccess && (
              <Button onClick={() => setCreateDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Tilføj Partner
              </Button>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full max-w-2xl" />
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-48" />
              ))}
            </div>
          </div>
        ) : (
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <TabsList className="flex-wrap h-auto gap-1 bg-muted/50 p-1">
                <TabsTrigger value="all" className="gap-1.5">
                  <Building2 className="h-4 w-4" />
                  Alle
                </TabsTrigger>
                {categories?.map((category) => (
                  <TabsTrigger key={category.id} value={category.id} className="gap-1.5">
                    {getIcon(category.icon_name)}
                    {category.name}
                  </TabsTrigger>
                ))}
              </TabsList>

              <div className="flex items-center gap-3">
                {totalRatedPartners > 0 && (
                  <span className="text-sm text-muted-foreground hidden sm:inline">
                    {totalRatedPartners} partner{totalRatedPartners !== 1 ? 'e' : ''} har ratings
                  </span>
                )}
                
                {/* View mode toggle */}
                <ToggleGroup 
                  type="single" 
                  value={viewMode} 
                  onValueChange={(value) => value && setViewMode(value as 'table' | 'cards')}
                  className="border rounded-lg"
                >
                  <ToggleGroupItem value="table" aria-label="Tabel-visning" className="px-3">
                    <LayoutList className="h-4 w-4" />
                  </ToggleGroupItem>
                  <ToggleGroupItem value="cards" aria-label="Kort-visning" className="px-3">
                    <LayoutGrid className="h-4 w-4" />
                  </ToggleGroupItem>
                </ToggleGroup>
                
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as 'name' | 'rating')}>
                  <SelectTrigger className="w-[180px]">
                    <ArrowUpDown className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Sortering" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Navn (A-Å)</SelectItem>
                    <SelectItem value="rating">Bedst ratede først</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <TabsContent value={selectedCategory} className="mt-0">
              {viewMode === 'table' ? (
                <TrustedPartnersTable
                  partners={filteredAndSortedPartners}
                  ratingStats={ratingStats}
                  onEdit={handleEditPartner}
                  hasAdminAccess={hasAdminAccess}
                />
              ) : (
                filteredAndSortedPartners.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16 text-center">
                    <div className="p-4 rounded-full bg-muted mb-4">
                      <Building2 className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <h3 className="text-lg font-medium mb-1">Ingen partnere fundet</h3>
                    <p className="text-muted-foreground max-w-sm">
                      {searchQuery 
                        ? 'Prøv at justere din søgning'
                        : 'Der er ingen partnere i denne kategori endnu'}
                    </p>
                  </div>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {filteredAndSortedPartners.map((partner) => (
                      <TrustedPartnerCard 
                        key={partner.id} 
                        partner={partner} 
                        ratingStats={getRatingStatsForPartner(partner.id)}
                        onEdit={hasAdminAccess ? () => handleEditPartner(partner) : undefined}
                      />
                    ))}
                  </div>
                )
              )}
            </TabsContent>
          </Tabs>
        )}

        {/* Create Partner Dialog */}
        <CreateTrustedPartnerDialog
          open={createDialogOpen}
          onOpenChange={setCreateDialogOpen}
          categories={categories}
        />

        {/* Edit Partner Dialog */}
        <EditTrustedPartnerDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          partner={editingPartner}
          categories={categories}
        />
      </div>
    </Layout>
  );
};

export default Network;
