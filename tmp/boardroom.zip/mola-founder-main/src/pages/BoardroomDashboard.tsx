import { useEffect, useMemo, useState } from 'react';
import Layout from '@/components/Layout';
import { useRole } from '@/contexts/RoleContext';
import { useCompanyData } from '@/hooks/useCompanyData';
import CompanySelector from '@/components/CompanySelector';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';

type Report = {
  id: string;
  company_id: string;
  period_month: number;
  period_year: number;
  status: string;
  submitted_at: string | null;
};

type AIFeedback = {
  slack_line: string;
};

export default function BoardroomDashboard() {
  const { isAdmin, selectedCompanyId } = useRole();
  const { data: myCompany } = useCompanyData();

  const effectiveCompanyId = useMemo(() => {
    if (isAdmin) return selectedCompanyId;
    return myCompany?.id ?? null;
  }, [isAdmin, selectedCompanyId, myCompany?.id]);

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;

  const [latestReport, setLatestReport] = useState<Report | null>(null);
  const [ai, setAi] = useState<AIFeedback | null>(null);
  const [adminStats, setAdminStats] = useState<{ total: number; submitted: number; missing: number } | null>(null);

  const loadMember = async () => {
    if (!effectiveCompanyId) {
      setLatestReport(null);
      setAi(null);
      return;
    }

    const { data: r } = await supabase
      .from('monthly_reports')
      .select('id, company_id, period_month, period_year, status, submitted_at')
      .eq('company_id', effectiveCompanyId)
      .order('period_year', { ascending: false })
      .order('period_month', { ascending: false })
      .limit(1)
      .maybeSingle();

    setLatestReport((r as any) || null);

    if (r?.id) {
      const { data: f } = await supabase
        .from('ai_feedback')
        .select('slack_line')
        .eq('report_id', r.id)
        .maybeSingle();
      setAi((f as any) || null);
    } else {
      setAi(null);
    }
  };

  const loadAdmin = async () => {
    const { data: companies } = await supabase
      .from('companies')
      .select('id')
      .eq('is_active', true);

    const { data: reports } = await supabase
      .from('monthly_reports')
      .select('company_id, status')
      .eq('period_year', currentYear)
      .eq('period_month', currentMonth);

    const total = companies?.length ?? 0;
    const submitted = (reports || []).filter((r: any) => r.status && r.status !== 'draft').length;
    const missing = Math.max(0, total - submitted);

    setAdminStats({ total, submitted, missing });
  };

  useEffect(() => {
    if (isAdmin) {
      loadAdmin().catch(() => null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin]);

  useEffect(() => {
    loadMember().catch(() => null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveCompanyId]);

  const ym = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">Rapportering, feedback og milestones – samme sted.</p>
          </div>
          {isAdmin && <CompanySelector />}
        </div>

        {isAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Periode</CardTitle></CardHeader>
              <CardContent><div className="text-2xl font-semibold">{ym}</div></CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Indsendt</CardTitle></CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">
                  {adminStats ? `${adminStats.submitted} / ${adminStats.total}` : '—'}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3"><CardTitle className="text-base">Mangler</CardTitle></CardHeader>
              <CardContent>
                <div className="text-2xl font-semibold">{adminStats ? adminStats.missing : '—'}</div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Rapportering</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {!effectiveCompanyId && isAdmin && (
                <div className="text-sm text-muted-foreground">
                  Vælg et selskab for at se seneste rapport.
                </div>
              )}

              {effectiveCompanyId && (
                <>
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Seneste</div>
                      <div className="text-lg font-semibold">
                        {latestReport ? `${latestReport.period_year}-${String(latestReport.period_month).padStart(2, '0')}` : 'Ingen rapport endnu'}
                      </div>
                    </div>
                    <div>
                      {latestReport?.status === 'submitted' && <Badge>Indsendt</Badge>}
                      {latestReport?.status === 'reviewed' && <Badge variant="outline">Gennemgået</Badge>}
                      {latestReport?.status === 'draft' && <Badge variant="secondary">Kladde</Badge>}
                    </div>
                  </div>

                  {ai?.slack_line && (
                    <div className="text-sm bg-muted rounded-md p-3 font-mono">{ai.slack_line}</div>
                  )}

                  <div className="flex gap-2">
                    <Button asChild>
                      <Link to="/monthly-report">Åbn rapportering</Link>
                    </Button>
                    {isAdmin && (
                      <Button asChild variant="outline">
                        <Link to="/admin/reporting">Admin overblik</Link>
                      </Button>
                    )}
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Milestones</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="text-sm text-muted-foreground">
                Hold 3-7 aktive milestones. Alt andet er støj.
              </div>
              <Button asChild>
                <Link to="/milestones">Åbn milestones</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
