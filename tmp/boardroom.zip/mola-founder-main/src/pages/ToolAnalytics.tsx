import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useToolUsageStats } from '@/hooks/useToolUsageTracking';
import { BarChart3, Users, TrendingUp, Clock, Calculator, Calendar } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { da } from 'date-fns/locale';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { DateRange } from 'react-day-picker';

const TOOL_LABELS: Record<string, string> = {
  roas_calculator: 'ROAS Beregner',
  ecommerce_tools: 'E-commerce Tools',
};

const TOOL_ICONS: Record<string, React.ReactNode> = {
  roas_calculator: <Calculator className="h-4 w-4" />,
  ecommerce_tools: <BarChart3 className="h-4 w-4" />,
};

export default function ToolAnalytics() {
  const [dateRange, setDateRange] = useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const { stats, dailyUsage, topUsers, isLoading } = useToolUsageStats(
    dateRange?.from && dateRange?.to
      ? { from: dateRange.from, to: dateRange.to }
      : undefined
  );

  // Calculate totals
  const totalViews = stats.reduce((sum, s) => sum + s.total_views, 0);
  const totalUniqueUsers = new Set(topUsers.map((u) => u.user_id)).size;
  const mostPopularTool = stats[0]?.tool_name || 'Ingen data';

  // Prepare chart data
  const chartData = dailyUsage.reduce((acc, item) => {
    const existing = acc.find((d) => d.date === item.date);
    if (existing) {
      existing[item.tool_name] = item.count;
      existing.total = (existing.total || 0) + item.count;
    } else {
      acc.push({
        date: item.date,
        [item.tool_name]: item.count,
        total: item.count,
      });
    }
    return acc;
  }, [] as Array<Record<string, any>>);

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="h-8 w-64" />
          <div className="grid gap-4 md:grid-cols-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
          <Skeleton className="h-80" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Tool Analytics</h1>
            <p className="text-muted-foreground">
              Se hvordan dine tools bliver brugt på tværs af platformen
          </p>
        </div>

        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="gap-2">
              <Calendar className="h-4 w-4" />
              {dateRange?.from && dateRange?.to
                ? `${format(dateRange.from, 'd. MMM', { locale: da })} - ${format(dateRange.to, 'd. MMM yyyy', { locale: da })}`
                : 'Vælg periode'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <CalendarComponent
              initialFocus
              mode="range"
              defaultMonth={dateRange?.from}
              selected={dateRange}
              onSelect={setDateRange}
              numberOfMonths={2}
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Overview Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Totale visninger</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalViews}</div>
            <p className="text-xs text-muted-foreground">
              I valgte periode
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unikke brugere</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUniqueUsers}</div>
            <p className="text-xs text-muted-foreground">
              Har brugt mindst ét tool
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Mest populære tool</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {TOOL_LABELS[mostPopularTool] || mostPopularTool}
            </div>
            <p className="text-xs text-muted-foreground">
              {stats[0]?.total_views || 0} visninger
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Usage Trend Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Brug over tid</CardTitle>
          <CardDescription>Daglig tool-brug i den valgte periode</CardDescription>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  tickFormatter={(date) => format(new Date(date), 'd/M')}
                  className="text-xs"
                />
                <YAxis className="text-xs" />
                <Tooltip
                  labelFormatter={(date) => format(new Date(date), 'd. MMMM yyyy', { locale: da })}
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="total"
                  name="Total"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-[300px] items-center justify-center text-muted-foreground">
              Ingen data i den valgte periode
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="tools" className="space-y-4">
        <TabsList>
          <TabsTrigger value="tools">Tools</TabsTrigger>
          <TabsTrigger value="users">Top brugere</TabsTrigger>
        </TabsList>

        <TabsContent value="tools" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Tool breakdown</CardTitle>
              <CardDescription>Visninger og brugere per tool</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.length > 0 ? (
                <div className="space-y-4">
                  {stats.map((tool) => (
                    <div
                      key={tool.tool_name}
                      className="flex items-center justify-between rounded-lg border p-4"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                          {TOOL_ICONS[tool.tool_name] || <BarChart3 className="h-5 w-5" />}
                        </div>
                        <div>
                          <p className="font-medium">
                            {TOOL_LABELS[tool.tool_name] || tool.tool_name}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Sidst brugt: {format(new Date(tool.last_used), "d. MMM 'kl.' HH:mm", { locale: da })}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="text-right">
                          <p className="text-2xl font-bold">{tool.total_views}</p>
                          <p className="text-xs text-muted-foreground">visninger</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="secondary">{tool.unique_users} brugere</Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  Ingen tool-brug registreret endnu
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top 10 brugere</CardTitle>
              <CardDescription>Brugere med mest tool-aktivitet</CardDescription>
            </CardHeader>
            <CardContent>
              {topUsers.length > 0 ? (
                <div className="space-y-3">
                  {topUsers.map((user, index) => (
                    <div
                      key={user.user_id}
                      className="flex items-center justify-between rounded-lg border p-3"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                          {index + 1}
                        </div>
                        <div>
                          <p className="font-medium">{user.full_name}</p>
                          {user.company_name && (
                            <p className="text-sm text-muted-foreground">{user.company_name}</p>
                          )}
                        </div>
                      </div>
                      <Badge>{user.usage_count} handlinger</Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  Ingen brugerdata tilgængelig
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </Layout>
  );
}
