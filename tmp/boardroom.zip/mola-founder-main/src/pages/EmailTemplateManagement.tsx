import { useState } from 'react';
import Layout from '@/components/Layout';
import { useEmailTemplates } from '@/hooks/useEmailTemplates';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Mail } from 'lucide-react';
import { EmailTemplateList } from '@/components/EmailTemplateList';
import { EmailTemplateEditor } from '@/components/EmailTemplateEditor';
import { SendTestEmailDialog } from '@/components/SendTestEmailDialog';
import { Skeleton } from '@/components/ui/skeleton';

const EmailTemplateManagement = () => {
  const { data: templates, isLoading } = useEmailTemplates();
  const [selectedTemplateId, setSelectedTemplateId] = useState<string | null>(null);
  const [isTestEmailOpen, setIsTestEmailOpen] = useState(false);
  const [testTemplateId, setTestTemplateId] = useState<string>('');

  const handleSendTest = (templateId: string) => {
    setTestTemplateId(templateId);
    setIsTestEmailOpen(true);
  };

  const selectedTemplate = templates?.find(t => t.id === selectedTemplateId);

  return (
    <Layout>
      <div className="space-y-6 max-w-full">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Email Template Administration</h1>
            <p className="text-muted-foreground mt-2">
              Administrer email templates med preview og variable system
            </p>
          </div>
          <Button onClick={() => setSelectedTemplateId('new')} className="gap-2">
            <Plus className="w-4 h-4" />
            Ny Template
          </Button>
        </div>

        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 w-full max-w-full">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                  <Skeleton className="h-20 w-full" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[400px] w-full" />
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 w-full max-w-full">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5" />
                  Email Templates
                </CardTitle>
              </CardHeader>
              <CardContent>
                <EmailTemplateList
                  templates={templates || []}
                  selectedId={selectedTemplateId}
                  onSelect={setSelectedTemplateId}
                  onSendTest={handleSendTest}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>
                  {selectedTemplateId === 'new' ? 'Ny Template' : 'Rediger Template'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedTemplateId ? (
                  <EmailTemplateEditor
                    templateId={selectedTemplateId === 'new' ? undefined : selectedTemplateId}
                    onClose={() => setSelectedTemplateId(null)}
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
                    <Mail className="w-16 h-16 mb-4 opacity-50" />
                    <p>Vælg en template fra listen for at redigere</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        <SendTestEmailDialog
          templateId={testTemplateId}
          templateName={selectedTemplate?.template_name || ''}
          open={isTestEmailOpen}
          onOpenChange={setIsTestEmailOpen}
        />
      </div>
    </Layout>
  );
};

export default EmailTemplateManagement;
