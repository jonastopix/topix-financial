import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { useCompanyData, useShippingPrices, usePortfolioBenchmarks, useBadges } from '@/hooks/useCompanyData';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Package, TrendingDown, TrendingUp, Award, Trophy } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { useQuery } from '@tanstack/react-query';
import {
  Tooltip as UITooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const Shipping = () => {
  const { data: company } = useCompanyData();
  const { data: shippingPrices, refetch } = useShippingPrices(company?.id);
  const { data: benchmarks } = usePortfolioBenchmarks();
  const { data: badges, refetch: refetchBadges } = useBadges(company?.id);
  const { toast } = useToast();

  const [homeDelivery, setHomeDelivery] = useState('');
  const [pickupPoint, setPickupPoint] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const latestPrice = shippingPrices?.[0];

  // Get all companies with shipping prices for ranking
  const { data: allShippingPrices } = useQuery({
    queryKey: ['all-shipping-prices'],
    queryFn: async () => {
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true);

      if (companiesError) throw companiesError;

      const { data: prices, error: pricesError } = await supabase
        .from('shipping_prices')
        .select('*')
        .order('effective_from', { ascending: false });

      if (pricesError) throw pricesError;

      // Get latest price per company
      const latestByCompany = new Map();
      prices?.forEach(price => {
        if (!latestByCompany.has(price.company_id)) {
          const company = companies.find(c => c.id === price.company_id);
          latestByCompany.set(price.company_id, {
            ...price,
            company_name: company?.name || 'Unknown',
          });
        }
      });

      return Array.from(latestByCompany.values());
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!company || !homeDelivery || !pickupPoint) {
      toast({
        title: 'Udfyld alle felter',
        description: 'Indtast priser for både hjemmelevering og pakkeshop',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    const homeDel = parseFloat(homeDelivery);
    const pickup = parseFloat(pickupPoint);

    const { error } = await supabase.from('shipping_prices').insert({
      company_id: company.id,
      country_code: 'DK',
      home_delivery_dkk: homeDel,
      pickup_point_dkk: pickup,
    });

    if (error) {
      setSubmitting(false);
      toast({
        title: 'Fejl',
        description: 'Kunne ikke gemme fragtpriser',
        variant: 'destructive',
      });
      return;
    }

    // Check if both prices are below portfolio average and award badge
    if (benchmarks) {
      const isBelowAvg = 
        homeDel < benchmarks.shipping.avgHomeDelivery && 
        pickup < benchmarks.shipping.avgPickupPoint;

      if (isBelowAvg) {
        // Check if badge already exists
        const { data: existingBadge } = await supabase
          .from('badges')
          .select('id')
          .eq('company_id', company.id)
          .eq('code', 'cheapest_shipping')
          .single();

        if (!existingBadge) {
          await supabase.from('badges').insert({
            company_id: company.id,
            code: 'cheapest_shipping',
            label: 'Billigste Fragt',
          });

          refetchBadges();

          toast({
            title: '🏆 Badge Optjent!',
            description: 'Du har optjent "Billigste Fragt" badge',
          });
        }
      }
    }

    setSubmitting(false);

    toast({
      title: 'Fragtpriser gemt',
      description: 'Dine fragtpriser er blevet opdateret',
    });

    setHomeDelivery('');
    setPickupPoint('');
    refetch();
  };

  const chartData = latestPrice && benchmarks ? [
    {
      name: 'Hjemmelevering',
      'Din pris': Number(latestPrice.home_delivery_dkk),
      'Porteføljesnit': benchmarks.shipping.avgHomeDelivery,
    },
    {
      name: 'Pakkeshop',
      'Din pris': Number(latestPrice.pickup_point_dkk),
      'Porteføljesnit': benchmarks.shipping.avgPickupPoint,
    },
  ] : [];

  const homeDeliveryDiff = latestPrice && benchmarks
    ? ((Number(latestPrice.home_delivery_dkk) - benchmarks.shipping.avgHomeDelivery) / benchmarks.shipping.avgHomeDelivery) * 100
    : 0;

  const pickupPointDiff = latestPrice && benchmarks
    ? ((Number(latestPrice.pickup_point_dkk) - benchmarks.shipping.avgPickupPoint) / benchmarks.shipping.avgPickupPoint) * 100
    : 0;

  const hasCheapestBadge = badges?.some(b => b.code === 'cheapest_shipping');

  // Get top 3 cheapest for each category
  const top3Home = allShippingPrices
    ?.sort((a, b) => Number(a.home_delivery_dkk) - Number(b.home_delivery_dkk))
    .slice(0, 3) || [];

  const top3Pickup = allShippingPrices
    ?.sort((a, b) => Number(a.pickup_point_dkk) - Number(b.pickup_point_dkk))
    .slice(0, 3) || [];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Shipping Benchmark</h1>
          <p className="text-muted-foreground">Sammenlign dine fragtpriser med porteføljen (DK)</p>
        </div>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Package className="h-6 w-6 text-blue-500" />
            <h2 className="text-xl font-semibold">Registrer Fragtpriser</h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="homeDelivery">Hjemmelevering (kr.)</Label>
              <Input
                id="homeDelivery"
                type="number"
                step="0.01"
                value={homeDelivery}
                onChange={(e) => setHomeDelivery(e.target.value)}
                placeholder="49.00"
              />
            </div>

            <div>
              <Label htmlFor="pickupPoint">Pakkeshop (kr.)</Label>
              <Input
                id="pickupPoint"
                type="number"
                step="0.01"
                value={pickupPoint}
                onChange={(e) => setPickupPoint(e.target.value)}
                placeholder="39.00"
              />
            </div>

            <Button type="submit" disabled={submitting}>
              Gem Fragtpriser
            </Button>
          </form>
        </Card>

        {latestPrice && benchmarks && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TooltipProvider>
                <UITooltip>
                  <TooltipTrigger asChild>
                    <Card className={`p-6 cursor-help transition-all duration-300 ${homeDeliveryDiff < 0 ? 'border-green-500/50 bg-green-500/5' : 'border-red-500/50 bg-red-500/5'}`}>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">Hjemmelevering</h3>
                        {homeDeliveryDiff < 0 && <Award className="h-5 w-5 text-green-500" />}
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-3xl font-bold">{Number(latestPrice.home_delivery_dkk).toFixed(2)} kr.</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Snit: {benchmarks.shipping.avgHomeDelivery.toFixed(2)} kr.
                          </p>
                        </div>
                        <div className="text-right">
                          <div className={`flex items-center gap-1 justify-end ${homeDeliveryDiff < 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {homeDeliveryDiff < 0 ? <TrendingDown className="h-6 w-6" /> : <TrendingUp className="h-6 w-6" />}
                            <span className="text-3xl font-bold">{Math.abs(homeDeliveryDiff).toFixed(1)}%</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {homeDeliveryDiff < 0 ? 'under' : 'over'} snit
                          </p>
                        </div>
                      </div>
                    </Card>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Beregnet mod seneste registrerede pris pr. selskab</p>
                  </TooltipContent>
                </UITooltip>
              </TooltipProvider>

              <TooltipProvider>
                <UITooltip>
                  <TooltipTrigger asChild>
                    <Card className={`p-6 cursor-help transition-all duration-300 ${pickupPointDiff < 0 ? 'border-green-500/50 bg-green-500/5' : 'border-red-500/50 bg-red-500/5'}`}>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold">Pakkeshop</h3>
                        {pickupPointDiff < 0 && <Award className="h-5 w-5 text-green-500" />}
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-3xl font-bold">{Number(latestPrice.pickup_point_dkk).toFixed(2)} kr.</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Snit: {benchmarks.shipping.avgPickupPoint.toFixed(2)} kr.
                          </p>
                        </div>
                        <div className="text-right">
                          <div className={`flex items-center gap-1 justify-end ${pickupPointDiff < 0 ? 'text-green-500' : 'text-red-500'}`}>
                            {pickupPointDiff < 0 ? <TrendingDown className="h-6 w-6" /> : <TrendingUp className="h-6 w-6" />}
                            <span className="text-3xl font-bold">{Math.abs(pickupPointDiff).toFixed(1)}%</span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {pickupPointDiff < 0 ? 'under' : 'over'} snit
                          </p>
                        </div>
                      </div>
                    </Card>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Beregnet mod seneste registrerede pris pr. selskab</p>
                  </TooltipContent>
                </UITooltip>
              </TooltipProvider>
            </div>

            {hasCheapestBadge && (
              <Card className="p-6 bg-gradient-to-r from-green-500/10 to-emerald-500/10 border-green-500/50">
                <div className="flex items-center gap-3">
                  <Trophy className="h-8 w-8 text-green-500" />
                  <div>
                    <h3 className="text-lg font-semibold">🏆 Billigste Fragt Badge</h3>
                    <p className="text-sm text-muted-foreground">
                      Begge dine fragtpriser er under porteføljens gennemsnit!
                    </p>
                  </div>
                </div>
              </Card>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-xl font-semibold mb-6">Prissammenligning</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Din pris" fill="#3b82f6" />
                    <Bar dataKey="Porteføljesnit" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
                <p className="text-sm text-muted-foreground mt-4 text-center">
                  Sammenligning baseret på seneste registrerede priser pr. selskab i porteføljen
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-xl font-semibold mb-6">Top 3 Billigste</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      Hjemmelevering
                    </h4>
                    <div className="space-y-2">
                      {top3Home.map((item, idx) => (
                        <div key={item.company_id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-3">
                            <Badge 
                              variant={idx === 0 ? 'default' : 'secondary'}
                              className={idx === 0 ? 'bg-green-500 hover:bg-green-600' : ''}
                            >
                              #{idx + 1}
                            </Badge>
                            <span className="font-medium">{item.company_name}</span>
                          </div>
                          <span className="text-lg font-bold">{Number(item.home_delivery_dkk).toFixed(2)} kr.</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      Pakkeshop
                    </h4>
                    <div className="space-y-2">
                      {top3Pickup.map((item, idx) => (
                        <div key={item.company_id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center gap-3">
                            <Badge 
                              variant={idx === 0 ? 'default' : 'secondary'}
                              className={idx === 0 ? 'bg-green-500 hover:bg-green-600' : ''}
                            >
                              #{idx + 1}
                            </Badge>
                            <span className="font-medium">{item.company_name}</span>
                          </div>
                          <span className="text-lg font-bold">{Number(item.pickup_point_dkk).toFixed(2)} kr.</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
};

export default Shipping;