import { useParams, Navigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useCompanyFinancials } from '@/hooks/useCompanyFinancials';
import { DollarSign, Activity, TrendingUp, Users } from 'lucide-react';
import { CompanyMeetingsView } from '@/components/CompanyMeetingsView';
import { InvestorNotesSection } from '@/components/InvestorNotesSection';

export default function InvestorCompanyView() {
  const { companyId } = useParams<{ companyId: string }>();
  const { user } = useAuth();

  // Verify investor has access to this company
  const { data: capEntry, isLoading: capLoading } = useQuery({
    queryKey: ['investor-cap-entry', companyId, user?.id],
    queryFn: async () => {
      if (!user || !companyId) return null;

      const { data, error } = await supabase
        .from('company_cap_table')
        .select('*')
        .eq('company_id', companyId)
        .eq('user_id', user.id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!user && !!companyId,
  });

  // Fetch company details
  const { data: company, isLoading: companyLoading } = useQuery({
    queryKey: ['investor-company', companyId],
    queryFn: async () => {
      if (!companyId) return null;

      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', companyId)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!companyId && !!capEntry,
  });

  const { data: financials } = useCompanyFinancials(companyId);

  if (!companyId) {
    return <Navigate to="/investor-dashboard" />;
  }

  if (capLoading || companyLoading) {
    return (
      <Layout>
        <div className="p-8">Indlæser...</div>
      </Layout>
    );
  }

  if (!capEntry) {
    return <Navigate to="/investor-dashboard" />;
  }

  if (!company) {
    return (
      <Layout>
        <div className="p-8">Virksomhed ikke fundet</div>
      </Layout>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      maximumFractionDigits: 0,
    }).format(value);
  };

  const latestMetrics = financials?.latestMonth;

  return (
    <Layout>
      <div className="space-y-8 p-8">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            {company.logo_url && (
              <img
                src={company.logo_url}
                alt={company.name}
                className="h-16 w-16 rounded-lg object-contain"
              />
            )}
            <div>
              <h1 className="text-3xl font-bold">{company.name}</h1>
              <p className="text-muted-foreground">
                CVR: {company.cvr} • Din ejerandel: {capEntry.ownership_pct}%
              </p>
            </div>
          </div>
        </div>

        {/* Quick Stats */}
        {latestMetrics && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Omsætning</p>
                    <p className="text-2xl font-bold">{formatCurrency(latestMetrics.revenue)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">EBITDA</p>
                    <p className="text-2xl font-bold">{formatCurrency(latestMetrics.ebitda)}</p>
                  </div>
                  <Activity className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Nye kunder</p>
                    <p className="text-2xl font-bold">{latestMetrics.newCustomers}</p>
                  </div>
                  <Users className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Vækst</p>
                    <p className="text-2xl font-bold">
                      {latestMetrics.revenueChange ? `${latestMetrics.revenueChange.toFixed(1)}%` : 'N/A'}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Oversigt</TabsTrigger>
            <TabsTrigger value="financials">Finansiel</TabsTrigger>
            <TabsTrigger value="meetings">Møder</TabsTrigger>
            <TabsTrigger value="notes">Mine noter</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Virksomhedsinfo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">CVR</p>
                    <p className="font-medium">{company.cvr}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Branche</p>
                    <p className="font-medium">{company.industry || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <p className="font-medium">{company.status}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Din ejerandel</p>
                    <p className="font-medium text-primary">{capEntry.ownership_pct}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="financials" className="space-y-6">
            {financials?.ytd ? (
              <Card>
                <CardHeader>
                  <CardTitle>Year-to-Date (YTD) Metrics</CardTitle>
                  <CardDescription>Akkumulerede tal for indeværende år</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Omsætning</p>
                      <p className="text-2xl font-bold">{formatCurrency(financials.ytd.revenue)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">EBITDA</p>
                      <p className="text-2xl font-bold">{formatCurrency(financials.ytd.ebitda)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Margin</p>
                      <p className="text-2xl font-bold">{(financials.ytd.margin * 100).toFixed(1)}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-muted-foreground">Ingen finansielle data tilgængelig endnu</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="meetings" className="space-y-6">
            <CompanyMeetingsView companyId={companyId} />
          </TabsContent>

          <TabsContent value="notes" className="space-y-6">
            <InvestorNotesSection companyId={companyId} />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
