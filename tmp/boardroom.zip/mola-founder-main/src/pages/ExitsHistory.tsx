import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAllExits } from '@/hooks/useAllExits';
import { calculateRealizedProceeds, formatDKK, formatPercentage } from '@/lib/returnsCalculations';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { TrendingDown, TrendingUp, Search, FileText, ArrowUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

type SortField = 'closing_date' | 'company_name' | 'realized_proceeds' | 'roi';
type SortDirection = 'asc' | 'desc';

export default function ExitsHistory() {
  const { data: exits, isLoading, error } = useAllExits();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('closing_date');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const navigate = useNavigate();

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="h-4 w-4 ml-1 opacity-30" />;
    return <ArrowUpDown className={cn("h-4 w-4 ml-1", sortDirection === 'desc' && "rotate-180")} />;
  };

  // Calculate realized proceeds and ROI for each exit
  const exitsWithCalculations = exits?.map(exit => {
    const realizedProceeds = calculateRealizedProceeds({
      id: exit.id,
      company_id: exit.company_id,
      fund_id: exit.fund_id,
      closing_date: exit.closing_date,
      gross_sale_amount_dkk: exit.gross_sale_amount_dkk,
      mola_ownership_pct_at_exit: exit.mola_ownership_pct_at_exit,
      transaction_costs_dkk: exit.transaction_costs_dkk,
      retained_shares_pct: exit.retained_shares_pct,
      earnout_possible: exit.earnout_possible,
      earnout_amount_potential_dkk: exit.earnout_amount_potential_dkk,
      note: exit.note,
    });

    const investedAmount = exit.invested_amount_dkk || 0;
    const roi = investedAmount > 0 ? ((realizedProceeds - investedAmount) / investedAmount) * 100 : 0;
    const isLoss = realizedProceeds < 0;
    const isNegativeROI = roi < 0;

    return {
      ...exit,
      realizedProceeds,
      roi,
      isLoss,
      isNegativeROI,
    };
  }) || [];

  // Filter by search term
  const filteredExits = exitsWithCalculations.filter(exit =>
    exit.company_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (exit.fund_name && exit.fund_name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Sort exits
  const sortedExits = [...filteredExits].sort((a, b) => {
    let aValue: any;
    let bValue: any;

    switch (sortField) {
      case 'closing_date':
        aValue = new Date(a.closing_date).getTime();
        bValue = new Date(b.closing_date).getTime();
        break;
      case 'company_name':
        aValue = a.company_name;
        bValue = b.company_name;
        break;
      case 'realized_proceeds':
        aValue = a.realizedProceeds;
        bValue = b.realizedProceeds;
        break;
      case 'roi':
        aValue = a.roi;
        bValue = b.roi;
        break;
      default:
        return 0;
    }

    if (sortDirection === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });

  // Calculate summary statistics
  const totalExits = exitsWithCalculations.length;
  const totalRealizedProceeds = exitsWithCalculations.reduce((sum, exit) => sum + exit.realizedProceeds, 0);
  const profitableExits = exitsWithCalculations.filter(exit => exit.roi >= 0).length;
  const lossExits = exitsWithCalculations.filter(exit => exit.roi < 0).length;

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <p className="text-muted-foreground">Indlæser exits historik...</p>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <p className="text-destructive">Fejl ved indlæsning af exits data</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Exits Historik</h1>
          <p className="text-muted-foreground mt-2">
            Komplet oversigt over alle exits med detaljer om realized proceeds og performance
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Exits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalExits}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Realized Proceeds</CardTitle>
            </CardHeader>
            <CardContent>
              <div className={cn(
                "text-2xl font-bold",
                totalRealizedProceeds >= 0 ? "text-primary" : "text-destructive"
              )}>
                {formatDKK(totalRealizedProceeds)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Profitable Exits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                <span className="text-2xl font-bold">{profitableExits}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Loss Exits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5 text-destructive" />
                <span className="text-2xl font-bold">{lossExits}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Exits Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Alle Exits</CardTitle>
                <CardDescription>
                  Klik på et selskab for at se flere detaljer
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Søg selskab eller fond..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8 w-[250px]"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {sortedExits.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchTerm ? 'Ingen exits matcher din søgning' : 'Ingen exits registreret endnu'}
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          className="hover:bg-transparent p-0 h-auto font-semibold"
                          onClick={() => handleSort('closing_date')}
                        >
                          Closing Date
                          {getSortIcon('closing_date')}
                        </Button>
                      </TableHead>
                      <TableHead>
                        <Button
                          variant="ghost"
                          className="hover:bg-transparent p-0 h-auto font-semibold"
                          onClick={() => handleSort('company_name')}
                        >
                          Selskab
                          {getSortIcon('company_name')}
                        </Button>
                      </TableHead>
                      <TableHead>Fund</TableHead>
                      <TableHead className="text-right">Gross Sale</TableHead>
                      <TableHead className="text-right">Ownership %</TableHead>
                      <TableHead className="text-right">Transaction Costs</TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          className="hover:bg-transparent p-0 h-auto font-semibold ml-auto flex"
                          onClick={() => handleSort('realized_proceeds')}
                        >
                          Realized Proceeds
                          {getSortIcon('realized_proceeds')}
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          className="hover:bg-transparent p-0 h-auto font-semibold ml-auto flex"
                          onClick={() => handleSort('roi')}
                        >
                          ROI
                          {getSortIcon('roi')}
                        </Button>
                      </TableHead>
                      <TableHead className="text-center">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedExits.map((exit) => (
                      <TableRow
                        key={exit.id}
                        className="cursor-pointer hover:bg-muted/50"
                        onClick={() => navigate(`/company/${exit.company_id}`)}
                      >
                        <TableCell className="font-medium">
                          {format(new Date(exit.closing_date), 'dd MMM yyyy', { locale: da })}
                        </TableCell>
                        <TableCell className="font-medium">{exit.company_name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {exit.fund_name || '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatDKK(exit.gross_sale_amount_dkk)}
                        </TableCell>
                        <TableCell className="text-right">
                          {formatPercentage(exit.mola_ownership_pct_at_exit)}
                        </TableCell>
                        <TableCell className="text-right text-muted-foreground">
                          {formatDKK(exit.transaction_costs_dkk)}
                        </TableCell>
                        <TableCell className={cn(
                          "text-right font-bold",
                          exit.isNegativeROI ? "text-destructive" : "text-primary"
                        )}>
                          {formatDKK(exit.realizedProceeds)}
                        </TableCell>
                        <TableCell className={cn(
                          "text-right font-semibold",
                          exit.isNegativeROI ? "text-destructive" : "text-primary"
                        )}>
                          {formatPercentage(exit.roi, 1)}
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge variant={exit.isNegativeROI ? "destructive" : "default"}>
                            {exit.isNegativeROI ? (
                              <span className="flex items-center gap-1">
                                <TrendingDown className="h-3 w-3" />
                                Tab
                              </span>
                            ) : (
                              <span className="flex items-center gap-1">
                                <TrendingUp className="h-3 w-3" />
                                Gevinst
                              </span>
                            )}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}

            <div className="mt-4 flex items-start gap-2 text-sm text-muted-foreground">
              <FileText className="h-4 w-4 mt-0.5" />
              <p>Klik på en række for at se eventuelle noter og detaljer for exit'et</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
