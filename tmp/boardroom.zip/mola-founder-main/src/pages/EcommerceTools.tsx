import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ROASCalculator } from '@/components/ROASCalculator';
import { ROASCalculationHistory } from '@/components/ROASCalculationHistory';
import { CLVAnalyzer } from '@/components/CLVAnalyzer';
import { Calculator, History, ShoppingCart, Users, CircleDot, AlertTriangle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useToolUsageTracking } from '@/hooks/useToolUsageTracking';

export default function EcommerceTools() {
  const { user } = useAuth();
  const { trackToolUsage } = useToolUsageTracking();

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['founder-profile-ecommerce', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Track page view on mount
  useEffect(() => {
    trackToolUsage('ecommerce_tools', 'page_view', undefined, profile?.company_id || undefined);
  }, [profile?.company_id]);

  const handleTabChange = (value: string) => {
    trackToolUsage('ecommerce_tools', 'tab_change', { tab: value }, profile?.company_id || undefined);
  };

  if (profileLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-6 w-96" />
          <Skeleton className="h-[600px] w-full" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <ShoppingCart className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Mola Tool Stack</h1>
              <p className="text-xs text-muted-foreground">E-commerce Tools – Mola Invest</p>
            </div>
          </div>
          <p className="text-muted-foreground">
            Værktøjer til at optimere din e-commerce forretning
          </p>
        </div>

        {/* Instructions Section */}
        <div className="rounded-lg border border-border/50 bg-muted/30 p-4">
          <h3 className="text-sm font-semibold mb-3 text-foreground">Sådan bruger du værktøjerne</h3>
          <div className="grid gap-3 md:grid-cols-3">
            <div className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">1</span>
              <div>
                <p className="text-sm font-medium text-foreground">Start med ROAS-beregneren</p>
                <p className="text-xs text-muted-foreground">Fastlæg din contribution margin og break-even ROAS (first-order economics).</p>
              </div>
            </div>
            <div className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">2</span>
              <div>
                <p className="text-sm font-medium text-foreground">Gå derefter til CLV Analyzer</p>
                <p className="text-xs text-muted-foreground">Brug CLV til at vurdere hvor meget du kan betale i CAC og stadig have en sund forretning.</p>
              </div>
            </div>
            <div className="flex gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">3</span>
              <div>
                <p className="text-sm font-medium text-foreground">Brug resultaterne til beslutninger</p>
                <p className="text-xs text-muted-foreground">ROAS styrer profit pr. ordre. CLV styrer vækst over tid.</p>
              </div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-border/50 flex items-center gap-2 text-xs text-muted-foreground">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
            <span>CLV giver kun mening, hvis contribution margin er positiv.</span>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="calculator" className="space-y-6" onValueChange={handleTabChange}>
          <TabsList>
            <TabsTrigger value="calculator" className="gap-2">
              <Calculator className="h-4 w-4" />
              ROAS Beregner
            </TabsTrigger>
            <TabsTrigger value="clv" className="gap-2">
              <Users className="h-4 w-4" />
              CLV Analyzer
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="h-4 w-4" />
              Historik
            </TabsTrigger>
          </TabsList>

          <TabsContent value="calculator">
            <ROASCalculator companyId={profile?.company_id} />
          </TabsContent>

          <TabsContent value="clv">
            <CLVAnalyzer companyId={profile?.company_id} />
          </TabsContent>

          <TabsContent value="history">
            <ROASCalculationHistory companyId={profile?.company_id} />
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
}
