import { useState } from "react";
import { useRole } from "@/contexts/RoleContext";
import { Navigate } from "react-router-dom";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { UserManagementTable } from "@/components/UserManagementTable";
import { UserRoleDialog } from "@/components/UserRoleDialog";
import { InviteUserDialog } from "@/components/InviteUserDialog";
import { InvitationsTable } from "@/components/InvitationsTable";
import { PendingInvitationsCard } from "@/components/PendingInvitationsCard";
import { useUserManagement } from "@/hooks/useUserManagement";
import { useInvitations } from "@/hooks/useInvitations";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPlus } from "lucide-react";

const UserManagement = () => {
  const { isAdmin } = useRole();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);

  const { users, isLoading, addRole, removeRole, updateStatus } = useUserManagement({
    search,
    role: roleFilter === "all" ? undefined : roleFilter,
    status: statusFilter === "all" ? undefined : statusFilter,
  });
  
  const { invitations, resendInvitation, cancelInvitation } = useInvitations();

  if (!isAdmin) {
    return <Navigate to="/" replace />;
  }

  return (
    <Layout>
      <div className="space-y-8 max-w-full">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Brugeradministration</h1>
            <p className="text-muted-foreground mt-2">
              Administrer brugere, invitationer, roller og adgangsniveauer
            </p>
          </div>
          <Button onClick={() => setInviteDialogOpen(true)} size="lg">
            <UserPlus className="mr-2 h-5 w-5" />
            Inviter bruger
          </Button>
        </div>

        {/* Main Content with Tabs */}
        <Tabs defaultValue="users" className="space-y-6">
          <TabsList>
            <TabsTrigger value="users">
              Brugere ({users.length})
            </TabsTrigger>
            <TabsTrigger value="invitations">
              Invitationer ({invitations.filter(i => i.status === 'pending').length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-6">
            {/* Filters */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Filtrer brugere</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Søg</label>
                    <Input
                      placeholder="Søg efter navn eller email..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="border-border"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Rolle</label>
                    <Select value={roleFilter} onValueChange={setRoleFilter}>
                      <SelectTrigger className="border-border">
                        <SelectValue placeholder="Alle roller" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Alle roller</SelectItem>
                        <SelectItem value="founder">Founder</SelectItem>
                        <SelectItem value="investor">Investor</SelectItem>
                        <SelectItem value="fund_partner">Fund Partner</SelectItem>
                        <SelectItem value="mola_admin">MOLA Admin</SelectItem>
                        <SelectItem value="dd_partner">DD Partner</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Status</label>
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="border-border">
                        <SelectValue placeholder="Alle statuser" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Alle statuser</SelectItem>
                        <SelectItem value="active">Aktiv</SelectItem>
                        <SelectItem value="inactive">Inaktiv</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <Card className="border-border bg-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Totale brugere
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <Skeleton className="h-8 w-16" />
                  ) : (
                    <div className="text-2xl font-bold text-foreground">{users.length}</div>
                  )}
                </CardContent>
              </Card>
              <Card className="border-border bg-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Aktive brugere
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <Skeleton className="h-8 w-16" />
                  ) : (
                    <div className="text-2xl font-bold text-foreground">
                      {users.filter((u) => u.is_active).length}
                    </div>
                  )}
                </CardContent>
              </Card>
              <Card className="border-border bg-card">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Administratorer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <Skeleton className="h-8 w-16" />
                  ) : (
                    <div className="text-2xl font-bold text-foreground">
                      {users.filter((u) => u.roles.some((r) => r === "owner" || r === "mola_admin")).length}
                    </div>
                  )}
                </CardContent>
              </Card>
              <Card className="border-yellow-500/50 bg-yellow-500/10">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-yellow-700">
                    Afventende
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-yellow-700">
                    {invitations.filter(i => i.status === 'pending').length}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Pending Invitations */}
            <PendingInvitationsCard
              invitations={invitations}
              onResend={(invitation) => resendInvitation(invitation)}
              onCancel={(id) => cancelInvitation(id)}
            />

            {/* Users Table */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Brugere</CardTitle>
                <CardDescription>Administrer brugere og deres roller</CardDescription>
              </CardHeader>
              <CardContent>
                <UserManagementTable
                  users={users}
                  onManageRoles={(userId) => setSelectedUserId(userId)}
                  onToggleStatus={(userId, isActive) =>
                    updateStatus({ userId, action: isActive ? "deactivate" : "activate" })
                  }
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="invitations" className="space-y-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle>Invitationer</CardTitle>
                <CardDescription>
                  Administrer udestående og historiske invitationer
                </CardDescription>
              </CardHeader>
              <CardContent>
                <InvitationsTable />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Dialogs */}
        <InviteUserDialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen} />
        
        {selectedUserId && (() => {
          const selectedUser = users.find(u => u.id === selectedUserId);
          if (!selectedUser) return null;
          
          return (
            <UserRoleDialog
              userId={selectedUserId}
              open={true}
              onOpenChange={(open) => !open && setSelectedUserId(null)}
              currentRoles={selectedUser.roles}
              userName={selectedUser.full_name || selectedUser.email}
              userFundId={selectedUser.fund_id}
              onAddRole={(args) => addRole(args)}
              onRemoveRole={(args) => removeRole(args)}
            />
          );
        })()}
      </div>
    </Layout>
  );
};

export default UserManagement;