import { useState } from "react";
import { useIncomeReports } from "@/hooks/useIncomeReports";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { IncomeStatsCard } from "@/components/IncomeStatsCard";
import { MonthlyIncomeChart } from "@/components/MonthlyIncomeChart";
import { QuarterlyIncomeChart } from "@/components/QuarterlyIncomeChart";
import { YearlyIncomeChart } from "@/components/YearlyIncomeChart";
import { IncomeOverviewCard } from "@/components/IncomeOverviewCard";
import Layout from "@/components/Layout";

export default function IncomeReports() {
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const { monthlyData, quarterlyData, yearlyData, isLoading } = useIncomeReports(selectedYear);

  return (
    <Layout>
      <div className="container mx-auto py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Indkomst Rapporter</h1>
        <p className="text-muted-foreground">Analyse af indkomst og fakturaer</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <IncomeStatsCard />
      </div>

      <IncomeOverviewCard className="mb-6" />

      <Tabs defaultValue="monthly" className="space-y-4">
        <TabsList>
          <TabsTrigger value="monthly">Månedlig</TabsTrigger>
          <TabsTrigger value="quarterly">Kvartalsvis</TabsTrigger>
          <TabsTrigger value="yearly">Årlig</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly">
          <Card className="p-6">
            {isLoading ? (
              <div className="h-80 bg-muted animate-pulse rounded-lg" />
            ) : (
              <MonthlyIncomeChart data={monthlyData} year={selectedYear} />
            )}
          </Card>
        </TabsContent>

        <TabsContent value="quarterly">
          <Card className="p-6">
            {isLoading ? (
              <div className="h-80 bg-muted animate-pulse rounded-lg" />
            ) : (
              <QuarterlyIncomeChart data={quarterlyData} year={selectedYear} />
            )}
          </Card>
        </TabsContent>

        <TabsContent value="yearly">
          <Card className="p-6">
            {isLoading ? (
              <div className="h-80 bg-muted animate-pulse rounded-lg" />
            ) : (
              <YearlyIncomeChart data={yearlyData} />
            )}
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </Layout>
  );
}
