import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Shield, Lock, Eye, Database, UserCheck, Mail } from "lucide-react";

const DataProtection = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
            <Shield className="h-10 w-10 text-primary" />
            Databeskyttelse & GDPR
          </h1>
          <p className="text-lg text-muted-foreground">
            Beskyttelse af dine personoplysninger er vores højeste prioritet
          </p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Dataansvarlige
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Platformens services leveres af følgende investeringsselskaber, der hver især er dataansvarlige for de investeringer og relationer, de administrerer:
              </p>
              <div className="space-y-3 pl-4">
                <div>
                  <h4 className="font-semibold">MOLA Invest ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 31944937</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
                <div>
                  <h4 className="font-semibold">Viking Capital ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 43500848</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
                <div>
                  <h4 className="font-semibold">Mola LH Invest ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 45180212</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserCheck className="h-5 w-5 text-primary" />
                Hvilke oplysninger indsamler vi?
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Personoplysninger</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>Navn, email og telefonnummer</li>
                  <li>Virksomhedsoplysninger (CVR, adresse, branche)</li>
                  <li>Investeringsdata og porteføljeinformation</li>
                  <li>Finansielle rapporter og dokumenter</li>
                  <li>Mødenotater og kommunikation</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Tekniske data</h4>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  <li>Login-oplysninger og adgangstidspunkter</li>
                  <li>IP-adresse og browserinformation</li>
                  <li>Anvendelse af platformens funktioner</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-primary" />
                Formål med databehandling
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Administration af investeringsporteføljer og relationer</li>
                <li>Kommunikation mellem investorer, stiftere og rådgivere</li>
                <li>Opfyldelse af juridiske og regulatoriske krav</li>
                <li>Sikring af platformens funktionalitet og sikkerhed</li>
                <li>Analyse og forbedring af vores services</li>
                <li>Rapportering til investorer og interessenter</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-primary" />
                Dine rettigheder under GDPR
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                I henhold til GDPR har du følgende rettigheder:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li><strong>Indsigtsret:</strong> Du kan anmode om en kopi af dine personoplysninger</li>
                <li><strong>Ret til berigtigelse:</strong> Du kan få rettet forkerte eller ufuldstændige oplysninger</li>
                <li><strong>Ret til sletning:</strong> Du kan anmode om sletning af dine personoplysninger under visse betingelser</li>
                <li><strong>Ret til dataportabilitet:</strong> Du kan få dine data i et struktureret, almindeligt anvendt format</li>
                <li><strong>Ret til indsigelse:</strong> Du kan gøre indsigelse mod behandling af dine personoplysninger</li>
                <li><strong>Ret til begrænsning:</strong> Du kan anmode om begrænsning af behandlingen</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Datasikkerhed
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Vi beskytter dine data med følgende sikkerhedsforanstaltninger:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Kryptering af data under transmission og opbevaring</li>
                <li>Sikker autentificering og adgangskontrol</li>
                <li>Regelmæssige sikkerhedsopdateringer og overvågning</li>
                <li>Begrænsning af adgang til kun autoriseret personale</li>
                <li>Backup og disaster recovery procedurer</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-primary" />
                Opbevaring af data
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Vi opbevarer dine personoplysninger så længe det er nødvendigt for:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Opfyldelse af investeringsforhold og kontraktlige forpligtelser</li>
                <li>Overholdelse af bogføringslov og øvrige juridiske krav (typisk 5 år efter investeringens afslutning)</li>
                <li>Håndtering af potentielle tvister eller krav</li>
              </ul>
              <p className="text-muted-foreground mt-4">
                Data slettes når det ikke længere er nødvendigt, medmindre lovgivning kræver længere opbevaring.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                Kontakt vedrørende databeskyttelse
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Hvis du har spørgsmål om vores behandling af personoplysninger eller ønsker at gøre brug af dine rettigheder, kan du kontakte os:
              </p>
              <div className="space-y-2">
                <p className="font-semibold">Email:</p>
                <a href="mailto:kontakt@molainvest.dk" className="text-primary hover:underline">
                  kontakt@molainvest.dk
                </a>
              </div>
              <Separator className="my-4" />
              <p className="text-sm text-muted-foreground">
                Du har også ret til at indgive en klage til Datatilsynet, hvis du mener, at behandlingen af dine personoplysninger er i strid med databeskyttelsesforordningen.
              </p>
              <div className="mt-3">
                <p className="text-sm font-semibold">Datatilsynet</p>
                <p className="text-sm text-muted-foreground">Carl Jacobsens Vej 35</p>
                <p className="text-sm text-muted-foreground">2500 Valby</p>
                <a href="mailto:dt@datatilsynet.dk" className="text-sm text-primary hover:underline">
                  dt@datatilsynet.dk
                </a>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">
                <strong>Senest opdateret:</strong> {new Date().toLocaleDateString('da-DK')}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Vi forbeholder os retten til at opdatere denne databeskyttelsespolitik. Væsentlige ændringer vil blive kommunikeret til brugerne.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default DataProtection;
