import { useState, useMemo, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import Layout from '@/components/Layout';
import CompanyCard from '@/components/CompanyCard';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ExcelImportDialog } from '@/components/ExcelImportDialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import {
  Building2,
  Search,
  Plus,
  Upload,
  LayoutGrid,
  List,
  TableIcon,
  SlidersHorizontal,
  ExternalLink,
} from 'lucide-react';
import { useRole } from '@/contexts/RoleContext';
import { CreateCompanyDialog } from '@/components/CreateCompanyDialog';
import { EditCompanyDialog } from '@/components/EditCompanyDialog';
import { CompanyStatusSelector } from '@/components/CompanyStatusSelector';
import { CompanyStatusBadge } from '@/components/CompanyStatusBadge';
import { useCompanyManagement, CompanyStatus } from '@/hooks/useCompanyManagement';
import { formatDKK } from '@/lib/returnsCalculations';

type ViewMode = 'grid' | 'list' | 'table';
type SortOption = 'name' | 'health' | 'invested' | 'report';

const PortfolioCompanies = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { isAdmin } = useRole();
  const { createCompany, updateCompany, archiveCompany, updateCompanyStatus } = useCompanyManagement();
  const [searchQuery, setSearchQuery] = useState('');
  const [fundFilter, setFundFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('active');
  const [industryFilter, setIndustryFilter] = useState('all');
  const [healthFilter, setHealthFilter] = useState('all');
  const [sortBy, setSortBy] = useState<SortOption>('name');
  const [viewMode, setViewMode] = useState<ViewMode>('table');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showExcelImport, setShowExcelImport] = useState(false);
  const [missingReportsFilter, setMissingReportsFilter] = useState<string[]>([]);

  // Handle URL parameters for missing reports and status filter
  useEffect(() => {
    const missingReportsParam = searchParams.get('missingReports');
    if (missingReportsParam) {
      const companyIds = missingReportsParam.split(',');
      setMissingReportsFilter(companyIds);
      // Clear the URL parameter after applying the filter
      searchParams.delete('missingReports');
      setSearchParams(searchParams, { replace: true });
    }
    
    const statusParam = searchParams.get('status');
    if (statusParam) {
      setStatusFilter(statusParam);
      // Clear the URL parameter after applying the filter
      searchParams.delete('status');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  // Fetch companies with fund data
  const { data: companies, isLoading } = useQuery({
    queryKey: ['companies-all'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select(`
          *, 
          funds(name),
          company_trustpilot_profiles(
            is_primary,
            trustpilot_scores(score, total_reviews)
          )
        `)
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return data;
    },
  });

  // Fetch funds for filter
  const { data: funds } = useQuery({
    queryKey: ['funds-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('id, name')
        .order('name');

      if (error) throw error;
      return data;
    },
  });

  // Calculate health scores (simplified - in real app, this would come from a function)
  const companiesWithHealth = useMemo(() => {
    if (!companies) return [];
    
    return companies.map((company) => ({
      ...company,
      healthScore: Math.floor(Math.random() * 40) + 60, // Mock for now
      latestReportDate: '2024-02', // Mock for now
      dpi: 1.2, // Mock DPI
      tvpi: 2.5, // Mock TVPI
    }));
  }, [companies]);

  // Filter and sort companies
  const filteredCompanies = useMemo(() => {
    let filtered = companiesWithHealth;

    // Missing reports filter (takes priority)
    if (missingReportsFilter.length > 0) {
      filtered = filtered.filter((company) => missingReportsFilter.includes(company.id));
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (company) =>
          company.name.toLowerCase().includes(query) ||
          company.cvr?.toLowerCase().includes(query)
      );
    }

    // Fund filter
    if (fundFilter !== 'all') {
      filtered = filtered.filter((company) => company.fund_id === fundFilter);
    }

    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((company) => company.status === statusFilter);
    }

    // Industry filter
    if (industryFilter !== 'all') {
      filtered = filtered.filter((company) => company.industry === industryFilter);
    }

    // Health filter
    if (healthFilter !== 'all') {
      filtered = filtered.filter((company) => {
        const score = company.healthScore;
        switch (healthFilter) {
          case 'good':
            return score >= 80;
          case 'warning':
            return score >= 60 && score < 80;
          case 'critical':
            return score < 60;
          default:
            return true;
        }
      });
    }

    // Sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'health':
          return b.healthScore - a.healthScore;
        case 'invested':
          return (b.total_invested_amount_dkk || b.invested_amount_dkk || 0) - (a.total_invested_amount_dkk || a.invested_amount_dkk || 0);
        case 'report':
          return (b.latestReportDate || '').localeCompare(a.latestReportDate || '');
        default:
          return 0;
      }
    });

    return filtered;
  }, [companiesWithHealth, searchQuery, fundFilter, statusFilter, industryFilter, healthFilter, sortBy, missingReportsFilter]);

  // Get unique industries
  const industries = useMemo(() => {
    if (!companies) return [];
    const uniqueIndustries = [...new Set(companies.map((c) => c.industry).filter(Boolean))];
    return uniqueIndustries.sort();
  }, [companies]);

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Building2 className="h-8 w-8 text-primary" />
              Selskaber
            </h1>
            <p className="text-muted-foreground mt-1">
              Oversigt over {filteredCompanies.length} selskaber i porteføljen
            </p>
          </div>
          {isAdmin && (
            <div className="flex gap-2">
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Nyt selskab
              </Button>
              <Button variant="outline" onClick={() => setShowExcelImport(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Import Excel
              </Button>
            </div>
          )}
        </div>

        {/* Filters */}
        <Card className="p-4">
          <div className="space-y-4">
            {/* Search and View Toggle */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Søg efter selskab eller CVR..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  title="Grid visning"
                >
                  <LayoutGrid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  title="Liste visning"
                >
                  <List className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'table' ? 'default' : 'outline'}
                  size="icon"
                  onClick={() => setViewMode('table')}
                  title="Tabel visning"
                >
                  <TableIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Filter Options */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <SlidersHorizontal className="h-4 w-4" />
              <span className="font-medium">Filtre:</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <Select value={fundFilter} onValueChange={setFundFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Fond" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle fonde</SelectItem>
                  {funds?.map((fund) => (
                    <SelectItem key={fund.id} value={fund.id}>
                      {fund.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle statuser</SelectItem>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="exited">Solgt</SelectItem>
                  <SelectItem value="new_investment">Ny investering</SelectItem>
                  <SelectItem value="due_diligence">Due Diligence</SelectItem>
                  <SelectItem value="bankruptcy">Konkurs</SelectItem>
                  <SelectItem value="rejected">Afvist</SelectItem>
                </SelectContent>
              </Select>

              <Select value={industryFilter} onValueChange={setIndustryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Branche" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle brancher</SelectItem>
                  {industries.map((industry) => (
                    <SelectItem key={industry} value={industry!}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={healthFilter} onValueChange={setHealthFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Sundhed" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle</SelectItem>
                  <SelectItem value="good">God (80+)</SelectItem>
                  <SelectItem value="warning">Advarsel (60-79)</SelectItem>
                  <SelectItem value="critical">Kritisk (&lt;60)</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                <SelectTrigger>
                  <SelectValue placeholder="Sorter efter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="name">Navn</SelectItem>
                  <SelectItem value="health">Sundhedsindeks</SelectItem>
                  <SelectItem value="invested">Investeret beløb</SelectItem>
                  <SelectItem value="report">Seneste rapport</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Companies Display */}
        {isLoading ? (
          <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="p-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Skeleton className="h-12 w-12 rounded-lg" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-5 w-32" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                  </div>
                  <Skeleton className="h-2 w-full" />
                  <div className="grid grid-cols-2 gap-4">
                    <Skeleton className="h-12 w-full" />
                    <Skeleton className="h-12 w-full" />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : filteredCompanies.length === 0 ? (
          <Card className="p-12 text-center">
            <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Ingen selskaber fundet</h3>
            <p className="text-muted-foreground">
              Prøv at justere dine filtre eller søgning
            </p>
          </Card>
        ) : viewMode === 'table' ? (
          <Card>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Navn</TableHead>
                    <TableHead>CVR</TableHead>
                    <TableHead>Fond</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-center">Trustpilot</TableHead>
                    <TableHead className="text-right">Investeret</TableHead>
                    <TableHead className="text-right">Ejerandel</TableHead>
                    <TableHead className="text-right">DPI</TableHead>
                    <TableHead className="text-right">TVPI</TableHead>
                    <TableHead>Sundhed</TableHead>
                    <TableHead>Seneste rapport</TableHead>
                    {isAdmin && <TableHead>Google Drive</TableHead>}
                    {isAdmin && <TableHead className="text-right">Handlinger</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCompanies.map((company: any) => (
                    <TableRow 
                      key={company.id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => navigate(`/company/${company.id}`)}
                    >
                      <TableCell className="font-medium">{company.name}</TableCell>
                      <TableCell>{company.cvr || '-'}</TableCell>
                      <TableCell>{company.funds?.name || '-'}</TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        {isAdmin ? (
                          <CompanyStatusSelector
                            status={company.status as CompanyStatus}
                            companyId={company.id}
                            onStatusChange={(status) => updateCompanyStatus.mutate({ id: company.id, status })}
                          />
                        ) : (
                          <CompanyStatusBadge status={company.status} />
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {(() => {
                          const profiles = company.company_trustpilot_profiles;
                          const profile = profiles?.find((p: any) => p.is_primary) || profiles?.[0];
                          const scoreData = Array.isArray(profile?.trustpilot_scores) 
                            ? profile.trustpilot_scores[0] 
                            : profile?.trustpilot_scores;
                          
                          if (!scoreData?.score) return <span className="text-muted-foreground">-</span>;
                          
                          const score = scoreData.score;
                          const reviews = scoreData.total_reviews;
                          const colorClass = score >= 4.5 ? 'text-green-600' : score >= 3.5 ? 'text-yellow-600' : 'text-red-600';
                          
                          return (
                            <span className={`font-medium ${colorClass}`}>
                              ⭐ {score.toFixed(1)} ({reviews})
                            </span>
                          );
                        })()}
                      </TableCell>
                      <TableCell className="text-right">
                        {company.total_invested_amount_dkk ? formatDKK(company.total_invested_amount_dkk) : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        {company.total_equity_share_pct ? `${company.total_equity_share_pct}%` : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        {company.dpi ? company.dpi.toFixed(2) + 'x' : '-'}
                      </TableCell>
                      <TableCell className="text-right">
                        {company.tvpi ? company.tvpi.toFixed(2) + 'x' : '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 min-w-[120px]">
                          <Progress value={company.healthScore} className="h-2" />
                          <span className="text-sm text-muted-foreground whitespace-nowrap">
                            {company.healthScore}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>{company.latestReportDate || '-'}</TableCell>
                      {isAdmin && (
                        <TableCell onClick={(e) => e.stopPropagation()}>
                          {company.google_drive_url ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              asChild
                            >
                              <a
                                href={company.google_drive_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center gap-1"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </Button>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                      )}
                      {isAdmin && (
                        <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                          <EditCompanyDialog
                            company={company}
                            onSubmit={async (id, data) => {
                              await updateCompany.mutateAsync({ id, data });
                            }}
                            onArchive={async (id) => {
                              await archiveCompany.mutateAsync(id);
                            }}
                          />
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </Card>
        ) : (
          <div
            className={
              viewMode === 'grid'
                ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
                : 'space-y-4'
            }
          >
            {filteredCompanies.map((company) => (
              <CompanyCard
                key={company.id}
                id={company.id}
                name={company.name}
                cvr={company.cvr || undefined}
                logo_url={company.logo_url || undefined}
                industry={company.industry || undefined}
                status={company.status}
                invested_amount_dkk={company.invested_amount_dkk || undefined}
                equity_share_pct={company.equity_share_pct || undefined}
                total_invested_amount_dkk={company.total_invested_amount_dkk || undefined}
                total_equity_share_pct={company.total_equity_share_pct || undefined}
                fund_id={company.fund_id || undefined}
                healthScore={company.healthScore}
                latestReportDate={company.latestReportDate}
              />
            ))}
          </div>
        )}
      </div>

      {/* Create Company Dialog */}
      {isAdmin && (
        <>
          <CreateCompanyDialog 
            open={showCreateDialog} 
            onOpenChange={setShowCreateDialog}
            onSubmit={(data) => {
              createCompany.mutate(data);
              setShowCreateDialog(false);
            }}
          />
          <ExcelImportDialog
            open={showExcelImport}
            onOpenChange={setShowExcelImport}
          />
        </>
      )}
    </Layout>
  );
};

export default PortfolioCompanies;
