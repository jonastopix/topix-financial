import { useState, useMemo } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useGroupOverview } from '@/hooks/useGroupOverview';
import { GroupSummaryCards } from '@/components/group-overview/GroupSummaryCards';
import { GroupStructureChart } from '@/components/group-overview/GroupStructureChart';
import { GroupCompaniesTable } from '@/components/group-overview/GroupCompaniesTable';
import { ExportGroupReportDialog } from '@/components/group-overview/ExportGroupReportDialog';
import { PerspectiveSelector, type PerspectiveType } from '@/components/group-overview/PerspectiveSelector';
import { Building2, CalendarDays } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

const GroupOverview = () => {
  const { data, isLoading, error } = useGroupOverview();
  const [perspective, setPerspective] = useState<PerspectiveType>('total');
  const [selectedFundId, setSelectedFundId] = useState<string | null>(null);

  // Calculate metrics based on selected perspective
  const displayMetrics = useMemo(() => {
    if (!data) return null;

    if (perspective === 'mola') {
      // Mola Invest ApS perspective - weighted by ownership in each fund
      return {
        activeCompanyCount: data.activeCompanyCount,
        activeInvested: data.molaActiveInvested,
        activeValue: data.molaActiveValue,
        exitedCompanyCount: data.exitedCompanyCount,
        exitedInvested: data.molaExitedInvested,
        totalInvestedAllTime: data.molaActiveInvested + data.molaExitedInvested,
        totalDividends: data.molaTotalDividends,
        totalExitProceeds: data.molaTotalExitProceeds,
        dpi: data.molaDpi,
        tvpi: data.molaTvpi,
      };
    }

    if (perspective === 'fund' && selectedFundId) {
      // Fund-specific perspective
      const fund = data.funds.find(f => f.id === selectedFundId);
      if (!fund) return null;

      const fundExitedCompanies = fund.companies.filter(c => c.status === 'exited');
      const fundExitedInvested = fundExitedCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
      
      // Calculate fund-specific dividends and exit proceeds
      const fundDividends = data.totalDividends; // Would need fund_id on dividends to filter properly
      const fundExitProceeds = fundExitedCompanies.reduce((sum, c) => sum + (c.exitProceeds || 0), 0);
      
      const fundTotalInvested = fund.activeInvested + fundExitedInvested;
      const fundDistributions = fundExitProceeds; // Simplified - dividends would need filtering
      
      return {
        activeCompanyCount: fund.activeCompanyCount,
        activeInvested: fund.activeInvested,
        activeValue: fund.totalValue,
        exitedCompanyCount: fundExitedCompanies.length,
        exitedInvested: fundExitedInvested,
        totalInvestedAllTime: fundTotalInvested,
        totalDividends: 0, // Would need fund_id filtering
        totalExitProceeds: fundExitProceeds,
        dpi: fundTotalInvested > 0 ? fundDistributions / fundTotalInvested : 0,
        tvpi: fundTotalInvested > 0 ? (fundDistributions + fund.totalValue) / fundTotalInvested : 0,
      };
    }

    // Default: Total perspective
    return {
      activeCompanyCount: data.activeCompanyCount,
      activeInvested: data.activeInvested,
      activeValue: data.activeValue,
      exitedCompanyCount: data.exitedCompanyCount,
      exitedInvested: data.exitedInvested,
      totalInvestedAllTime: data.totalInvestedAllTime,
      totalDividends: data.totalDividends,
      totalExitProceeds: data.totalExitProceeds,
      dpi: data.dpi,
      tvpi: data.tvpi,
    };
  }, [data, perspective, selectedFundId]);

  // Filter funds/companies for display based on perspective
  const displayFunds = useMemo(() => {
    if (!data) return [];
    if (perspective === 'fund' && selectedFundId) {
      return data.funds.filter(f => f.id === selectedFundId);
    }
    return data.funds;
  }, [data, perspective, selectedFundId]);

  const displayCompanies = useMemo(() => {
    if (!data) return [];
    if (perspective === 'fund' && selectedFundId) {
      const fund = data.funds.find(f => f.id === selectedFundId);
      return fund?.companies || [];
    }
    return data.companies;
  }, [data, perspective, selectedFundId]);

  // Get perspective label for display
  const perspectiveLabel = useMemo(() => {
    if (perspective === 'mola') return 'Mola Invest ApS';
    if (perspective === 'fund' && selectedFundId) {
      const fund = data?.funds.find(f => f.id === selectedFundId);
      return fund?.name || 'Fond';
    }
    return 'Koncern Total';
  }, [perspective, selectedFundId, data?.funds]);

  if (error) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <Card className="p-8 text-center">
            <p className="text-destructive">Fejl ved indlæsning af data</p>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 md:py-8 space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-4xl font-bold flex items-center gap-3">
                <Building2 className="h-8 w-8 text-primary" />
                Koncernoverblik
              </h1>
              <p className="text-muted-foreground mt-1 flex items-center gap-2">
                <CalendarDays className="h-4 w-4" />
                Genereret {format(new Date(), 'd. MMMM yyyy', { locale: da })}
              </p>
            </div>
            {data && (
              <ExportGroupReportDialog 
                data={data} 
                perspective={perspective}
                perspectiveLabel={perspectiveLabel}
                selectedFundId={selectedFundId}
              />
            )}
          </div>

          {/* Perspective selector */}
          {data && (
            <PerspectiveSelector
              perspective={perspective}
              onPerspectiveChange={setPerspective}
              selectedFundId={selectedFundId}
              onSelectedFundChange={setSelectedFundId}
              funds={data.funds}
            />
          )}
        </div>

        {isLoading ? (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              {Array.from({ length: 7 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-20 mb-2" />
                    <Skeleton className="h-6 w-24" />
                  </CardContent>
                </Card>
              ))}
            </div>
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-64 w-full" />
              </CardContent>
            </Card>
          </div>
        ) : data && displayMetrics ? (
          <>
            {/* Summary cards with perspective-based metrics */}
            <GroupSummaryCards
              activeCompanyCount={displayMetrics.activeCompanyCount}
              activeInvested={displayMetrics.activeInvested}
              activeValue={displayMetrics.activeValue}
              exitedCompanyCount={displayMetrics.exitedCompanyCount}
              exitedInvested={displayMetrics.exitedInvested}
              totalInvestedAllTime={displayMetrics.totalInvestedAllTime}
              totalDividends={displayMetrics.totalDividends}
              totalExitProceeds={displayMetrics.totalExitProceeds}
              dpi={displayMetrics.dpi}
              tvpi={displayMetrics.tvpi}
              perspectiveLabel={perspectiveLabel}
              isMolaPerspective={perspective === 'mola'}
            />

            {/* Structure chart - filtered by perspective */}
            <GroupStructureChart funds={displayFunds} />

            {/* Companies table - filtered by perspective */}
            <GroupCompaniesTable companies={displayCompanies} />
          </>
        ) : null}
      </div>
    </Layout>
  );
};

export default GroupOverview;
