import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useIncomeEntries } from "@/hooks/useIncomeEntries";
import { InvoiceCard } from "@/components/InvoiceCard";
import { InvoiceDialog } from "@/components/InvoiceDialog";
import Layout from "@/components/Layout";

export default function Invoices() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { incomeEntries, isLoading } = useIncomeEntries();

  const pendingInvoices = incomeEntries?.filter(e => e.status === 'sent' || e.status === 'draft') || [];
  const paidInvoices = incomeEntries?.filter(e => e.status === 'paid') || [];
  const overdueInvoices = incomeEntries?.filter(e => e.status === 'cancelled') || [];

  return (
    <Layout>
      <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Fakturaer & Indkomst</h1>
          <p className="text-muted-foreground">Administrer fakturaer og indkomst</p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Ny Faktura
        </Button>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">Alle ({incomeEntries?.length || 0})</TabsTrigger>
          <TabsTrigger value="pending">Afventer ({pendingInvoices.length})</TabsTrigger>
          <TabsTrigger value="paid">Betalt ({paidInvoices.length})</TabsTrigger>
          <TabsTrigger value="overdue">Forfalden ({overdueInvoices.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          {isLoading ? (
            <div className="grid gap-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-32 bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid gap-4">
              {incomeEntries?.map((entry) => (
                <InvoiceCard key={entry.id} entry={entry} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          <div className="grid gap-4">
            {pendingInvoices.map((entry) => (
              <InvoiceCard key={entry.id} entry={entry} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="paid" className="space-y-4">
          <div className="grid gap-4">
            {paidInvoices.map((entry) => (
              <InvoiceCard key={entry.id} entry={entry} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="overdue" className="space-y-4">
          <div className="grid gap-4">
            {overdueInvoices.map((entry) => (
              <InvoiceCard key={entry.id} entry={entry} />
            ))}
          </div>
        </TabsContent>
      </Tabs>

      <InvoiceDialog open={isDialogOpen} onOpenChange={setIsDialogOpen} />
      </div>
    </Layout>
  );
}
