import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { useDDCase, useDDCategories, useDDCategoryProgress, useDDDocuments } from '@/hooks/useDueDiligence';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEffect } from 'react';
import { toast } from 'sonner';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DDStatusBadge } from '@/components/DDStatusBadge';
import { DDDocumentChecklist } from '@/components/DDDocumentChecklist';
import { ArrowLeft, HelpCircle, Clock, AlertTriangle } from 'lucide-react';

export default function FounderDueDiligence() {
  const { user } = useAuth();
  const { hasAdminAccess } = useRole();
  const navigate = useNavigate();
  const { caseId: urlCaseId } = useParams<{ caseId?: string }>();
  
  // If admin provides a caseId via URL, use that instead
  const isAdminPreview = !!urlCaseId && hasAdminAccess;

  // Fetch user's company (only if not in admin preview mode)
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user && !isAdminPreview,
  });

  // Fetch DD case directly by ID (for admin preview)
  const { data: ddCaseByUrl } = useDDCase(urlCaseId);

  // Fetch DD case for user's company (for founders)
  const { data: ddCaseByCompany } = useQuery({
    queryKey: ['dd-case-by-company', profile?.company_id],
    queryFn: async () => {
      if (!profile?.company_id) return null;
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .select('*, companies(id, name, status)')
        .eq('company_id', profile.company_id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.company_id && !isAdminPreview,
  });

  // Use URL-based case for admin, company-based case for founders
  const ddCase = isAdminPreview ? ddCaseByUrl : ddCaseByCompany;

  // Fetch company info (only if not in admin preview mode)
  const { data: company } = useQuery({
    queryKey: ['company', profile?.company_id],
    queryFn: async () => {
      if (!profile?.company_id) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', profile.company_id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.company_id && !isAdminPreview,
  });

  const { data: categories = [] } = useDDCategories();
  const { data: categoryProgress = [] } = useDDCategoryProgress(ddCase?.id);
  const { data: documents = [] } = useDDDocuments(ddCase?.id);

  // Redirect if company is already active (only for founders, not admin preview)
  useEffect(() => {
    if (!isAdminPreview && company?.status === 'active') {
      toast.info('Din virksomhed er allerede aktiv');
      navigate('/');
    }
  }, [company?.status, navigate, isAdminPreview]);

  if (!ddCase) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <Card>
            <CardHeader>
              <CardTitle>Due Diligence</CardTitle>
              <CardDescription>
                Der er ikke startet en due diligence proces for din virksomhed endnu.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Kontakt venligst MOLA for at starte processen.
              </p>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold">Due Diligence</h1>
              <DDStatusBadge status={ddCase.status} />
            </div>
            <p className="text-muted-foreground">
              Upload de nødvendige dokumenter for at fuldføre due diligence processen
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => isAdminPreview ? navigate(`/portfolio/due-diligence/${urlCaseId}`) : navigate('/')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            {isAdminPreview ? 'Tilbage til admin' : 'Tilbage'}
          </Button>
        </div>

        {/* Overview Cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold capitalize">
                {ddCase.status.replace('_', ' ')}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Nuværende DD status
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Startet</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {ddCase.started_at 
                  ? new Date(ddCase.started_at).toLocaleDateString('da-DK')
                  : 'Ikke startet'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Start dato
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Dokumenter</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{documents.length}</div>
              <p className="text-xs text-muted-foreground mt-1">
                Uploadede dokumenter
              </p>
            </CardContent>
          </Card>

          <Card className={ddCase.deadline ? (() => {
            const deadlineDate = new Date(ddCase.deadline);
            const today = new Date();
            const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
            if (daysUntil < 0) return 'border-destructive bg-destructive/5';
            if (daysUntil <= 7) return 'border-yellow-500 bg-yellow-50 dark:bg-yellow-900/10';
            return '';
          })() : ''}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Deadline
              </CardTitle>
              {ddCase.deadline && (() => {
                const deadlineDate = new Date(ddCase.deadline);
                const today = new Date();
                const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                if (daysUntil < 0) {
                  return <AlertTriangle className="h-4 w-4 text-destructive" />;
                }
                if (daysUntil <= 7) {
                  return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
                }
                return null;
              })()}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {ddCase.deadline 
                  ? new Date(ddCase.deadline).toLocaleDateString('da-DK')
                  : 'Ingen deadline'}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {ddCase.deadline 
                  ? (() => {
                      const deadlineDate = new Date(ddCase.deadline);
                      const today = new Date();
                      const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                      if (daysUntil < 0) return `${Math.abs(daysUntil)} dage overskredet`;
                      if (daysUntil === 0) return 'I dag!';
                      if (daysUntil === 1) return '1 dag tilbage';
                      return `${daysUntil} dage tilbage`;
                    })()
                  : 'Der er ikke sat en deadline endnu'}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Document Checklist */}
        <DDDocumentChecklist
          caseId={ddCase.id}
          categories={categories}
          categoryProgress={categoryProgress}
          documents={documents}
        />

        {/* Help Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-primary" />
              <CardTitle>Brug for hjælp?</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Hvis du har spørgsmål til due diligence processen eller brug for hjælp med at uploade dokumenter,
              er du velkommen til at kontakte os.
            </p>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => navigate('/support')}>
                Kontakt Support
              </Button>
              {/* Resource Hub - midlertidigt skjult
              <Button variant="outline" onClick={() => navigate('/resources')}>
                Se Ressourcer
              </Button>
              */}
            </div>
          </CardContent>
        </Card>

        {/* Notes from MOLA */}
        {ddCase.notes && (
          <Card>
            <CardHeader>
              <CardTitle>Noter fra MOLA</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap">{ddCase.notes}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
