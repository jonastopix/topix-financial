import { useState } from 'react';
import { format } from 'date-fns';
import { Download, AlertCircle } from 'lucide-react';
import Layout from '@/components/Layout';
import SupportTeamCard from '@/components/SupportTeamCard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useDataAccessRequests } from '@/hooks/useDataAccessRequests';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const Support = () => {
  const [requestType, setRequestType] = useState('personal_data');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { requests, createRequest } = useDataAccessRequests();

  const handleSubmitDataRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      await createRequest.mutateAsync({
        request_type: requestType,
        reason: reason.trim() || undefined
      });
      setReason('');
      setRequestType('personal_data');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async (filePath: string, requestId: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('data-exports')
        .download(filePath);
      
      if (error) throw error;
      
      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = filePath.split('/').pop() || 'mola_data_export.json';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      await supabase
        .from('data_access_requests')
        .update({ downloaded_at: new Date().toISOString() })
        .eq('id', requestId);
      
      toast.success('Data downloadet');
    } catch (error: any) {
      toast.error('Download fejlede', {
        description: error.message
      });
    }
  };

  const formatRequestType = (type: string) => {
    const types = {
      personal_data: 'Personlige oplysninger',
      company_data: 'Virksomhedsdata',
      full_export: 'Fuld export'
    };
    return types[type as keyof typeof types] || type;
  };

  const formatStatus = (status: string) => {
    const statuses = {
      pending: 'Afventer',
      approved: 'Godkendt',
      rejected: 'Afvist',
      completed: 'Færdig'
    };
    return statuses[status as keyof typeof statuses] || status;
  };

  const getStatusVariant = (status: string) => {
    const variants = {
      pending: 'outline' as const,
      approved: 'default' as const,
      rejected: 'destructive' as const,
      completed: 'default' as const
    };
    return variants[status as keyof typeof variants] || 'outline' as const;
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Support & Kontakt</h1>
          <p className="text-muted-foreground">Vi er her for at hjælpe dig</p>
        </div>

        <div className="space-y-6">
          <SupportTeamCard />

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Anmod om Dine Data
              </CardTitle>
              <CardDescription>
                I henhold til databeskyttelsesregler kan du anmode om en kopi af dine data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Sådan fungerer det</AlertTitle>
                <AlertDescription>
                  <ol className="list-decimal list-inside space-y-1 mt-2">
                    <li>Vælg hvilken type data du ønsker</li>
                    <li>Send anmodning til MOLA support</li>
                    <li>MOLA gennemgår din anmodning (typisk 1-3 hverdage)</li>
                    <li>Du modtager en email når data er klar til download</li>
                    <li>Download link er gyldigt i 7 dage</li>
                  </ol>
                </AlertDescription>
              </Alert>

              <form onSubmit={handleSubmitDataRequest}>
                <div className="space-y-4">
                  <div>
                    <Label>Type af data</Label>
                    <Select value={requestType} onValueChange={setRequestType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="personal_data">
                          Kun mine personlige oplysninger (navn, email, profil)
                        </SelectItem>
                        <SelectItem value="company_data">
                          Mine virksomhedsdata (rapporter, opgaver, møder)
                        </SelectItem>
                        <SelectItem value="full_export">
                          Fuld data export
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label>Begrundelse (valgfri)</Label>
                    <Textarea
                      placeholder="Beskriv hvorfor du har brug for disse data..."
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Sender...' : 'Send Anmodning'}
                  </Button>
                </div>
              </form>

              {requests && requests.length > 0 && (
                <div className="mt-6 pt-6 border-t">
                  <h4 className="font-semibold mb-3">Dine Anmodninger</h4>
                  <div className="space-y-3">
                    {requests.map((req) => (
                      <div key={req.id} className="p-4 border rounded-lg space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{formatRequestType(req.request_type)}</div>
                            <div className="text-sm text-muted-foreground">
                              {format(new Date(req.requested_at), 'dd/MM/yyyy HH:mm')}
                            </div>
                          </div>
                          <Badge variant={getStatusVariant(req.status)}>
                            {formatStatus(req.status)}
                          </Badge>
                        </div>

                        {req.status === 'completed' && req.file_path && (
                          <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
                            <div className="flex items-center justify-between">
                              <div>
                                <div className="font-medium text-primary">Dine data er klar!</div>
                                <div className="text-sm text-muted-foreground">
                                  Download link udløber: {format(new Date(req.download_expires_at!), 'dd/MM/yyyy')}
                                </div>
                              </div>
                              <Button 
                                size="sm" 
                                onClick={() => handleDownload(req.file_path!, req.id)}
                              >
                                <Download className="mr-2 h-4 w-4" />
                                Download
                              </Button>
                            </div>
                          </div>
                        )}

                        {req.status === 'rejected' && req.rejection_reason && (
                          <Alert variant="destructive">
                            <AlertDescription>
                              <strong>Afvist:</strong> {req.rejection_reason}
                            </AlertDescription>
                          </Alert>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Support;
