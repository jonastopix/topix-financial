import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, 
  Building2, 
  Search, 
  DollarSign, 
  Target,
  Trophy,
  Package
} from 'lucide-react';
import { useCompanyStatus } from '@/hooks/useCompanyStatus';
import { FounderDueDiligenceDashboard } from './FounderDueDiligenceDashboard';
import { FounderActiveDashboard } from './FounderActiveDashboard';
import { DashboardTasksSection } from '@/components/DashboardTasksSection';
import { PortfolioHealthOverview } from '@/components/PortfolioHealthOverview';
import { TrendAnalysisChart } from '@/components/TrendAnalysisChart';
import { RiskAlertsWidget } from '@/components/RiskAlertsWidget';
import { CustomReportsGenerator } from '@/components/CustomReportsGenerator';
import { FundDistributionChart } from '@/components/FundDistributionChart';
import { ReturnsEventsTable } from '@/components/ReturnsEventsTable';
import { TopCompaniesLeaderboard } from '@/components/TopCompaniesLeaderboard';
import { usePortfolioMetrics } from '@/hooks/usePortfolioMetrics';
import { ExitPerformanceWidgets } from '@/components/ExitPerformanceWidgets';
import { MissingReportsWidget } from '@/components/MissingReportsWidget';
import { PortfolioValuationTrendsWidget } from '@/components/PortfolioValuationTrendsWidget';
import DocumentStatusWidget from '@/components/DocumentStatusWidget';
import { ActivityTicker } from '@/components/ActivityTicker';
import { PortfolioPulseWidget } from '@/components/PortfolioPulseWidget';
import PendingPRAlertWidget from '@/components/PendingPRAlertWidget';
import { MobileDashboard } from '@/components/MobileDashboard';
import { useIsMobile } from '@/hooks/use-mobile';


const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin, activeRole, hasAdminAccess, selectedCompanyId } = useRole();
  const isMobile = useIsMobile();
  const [fundFilter, setFundFilter] = useState('all');
  const [timeFilter, setTimeFilter] = useState('ytd');

  // Fetch portfolio metrics - always call hook
  const { data: metrics, isLoading: metricsLoading } = usePortfolioMetrics(fundFilter);

  // Fetch portfolio funds - always call hook
  const { data: funds } = useQuery({
    queryKey: ['funds'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('*')
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // For admins in founder view, use selectedCompanyId; otherwise fetch actual founder profile
  const effectiveCompanyId = hasAdminAccess && activeRole === 'founder' && selectedCompanyId 
    ? selectedCompanyId 
    : null;

  // Fetch founder's DD case - always call hook
  const { data: founderProfile } = useQuery({
    queryKey: ['founder-profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !hasAdminAccess && !effectiveCompanyId,
  });

  // Determine which company ID to use
  const companyIdToUse = effectiveCompanyId || founderProfile?.company_id;

  const { data: founderDDCase } = useQuery({
    queryKey: ['founder-dd-case', companyIdToUse],
    queryFn: async () => {
      if (!companyIdToUse) return null;
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .select('*, companies(name)')
        .eq('company_id', companyIdToUse)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
    enabled: (activeRole === 'founder') && !!companyIdToUse,
  });

  const { data: founderDDProgress = [] } = useQuery({
    queryKey: ['founder-dd-progress', founderDDCase?.id],
    queryFn: async () => {
      if (!founderDDCase?.id) return [];
      const { data, error } = await supabase
        .from('dd_checklist_progress')
        .select('*')
        .eq('case_id', founderDDCase.id);
      if (error) throw error;
      return data;
    },
    enabled: (activeRole === 'founder') && !!founderDDCase?.id,
  });

  const { data: founderTemplates = [] } = useQuery({
    queryKey: ['dd-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dd_checklist_templates')
        .select('*')
        .order('sort_order');
      if (error) throw error;
      return data;
    },
    enabled: activeRole === 'founder',
  });

  // Fetch company data for founder view
  const { data: company } = useQuery({
    queryKey: ['founder-company', companyIdToUse],
    queryFn: async () => {
      if (!companyIdToUse) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', companyIdToUse)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: (activeRole === 'founder') && !!companyIdToUse,
  });

  // Use company status hook to determine view
  const { data: companyStatus } = useCompanyStatus(companyIdToUse);

  // ============ ALL HOOKS ABOVE - CONDITIONAL RETURNS BELOW ============

  // Redirect fund partners to their dedicated dashboard
  if (activeRole === 'fund_partner') {
    navigate('/fund-partner-dashboard');
    return null;
  }

  // Show mobile dashboard for admins on mobile
  if (isMobile && isAdmin) {
    return (
      <Layout>
        <MobileDashboard />
      </Layout>
    );
  }

  // For founder role (real founders or admins simulating), show founder dashboard
  if (activeRole === 'founder') {
    // Show DD Dashboard if in due diligence phase
    if (companyStatus?.isInDueDiligence && founderDDCase) {
      return (
        <Layout>
          <FounderDueDiligenceDashboard 
            ddCase={founderDDCase}
            templates={founderTemplates}
            progress={founderDDProgress}
            companyId={companyIdToUse}
          />
        </Layout>
      );
    }

    // Show Active Dashboard if company is active
    if (companyStatus?.isActive && company) {
      return (
        <Layout>
          <FounderActiveDashboard 
            companyId={company.id}
            companyName={company.name}
          />
        </Layout>
      );
    }

    // Fallback: loading or no company
    return (
      <Layout>
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground mt-1">Velkommen til dit dashboard</p>
          </div>
          <Card className="p-6">
            <p className="text-muted-foreground">Indlæser...</p>
          </Card>
        </div>
      </Layout>
    );
  }

  const handleCompanyClick = (companyId: string) => {
    navigate(`/company/${companyId}`);
  };

  const formatCurrency = (amount: number | null) => {
    if (!amount) return 'N/A';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getDPIBadge = (dpi: number) => {
    if (dpi >= 1.0) return { variant: 'default' as const, label: 'Great', color: 'bg-green-500/10 text-green-700' };
    if (dpi >= 0.5) return { variant: 'secondary' as const, label: 'Good', color: 'bg-yellow-500/10 text-yellow-700' };
    return { variant: 'destructive' as const, label: 'Early', color: 'bg-blue-500/10 text-blue-700' };
  };

  const getTVPIBadge = (tvpi: number) => {
    if (tvpi >= 2.0) return { variant: 'default' as const, label: 'Great', color: 'bg-green-500/10 text-green-700' };
    if (tvpi >= 1.5) return { variant: 'secondary' as const, label: 'Good', color: 'bg-yellow-500/10 text-yellow-700' };
    return { variant: 'destructive' as const, label: 'Fair', color: 'bg-orange-500/10 text-orange-700' };
  };

  return (
    <Layout>
      <ActivityTicker />
      <div className="space-y-6">
        {/* Pending PR Alert */}
        <PendingPRAlertWidget />

        {/* Tasks Section - Priority Work Screen */}
        <DashboardTasksSection />

        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Portfolio Oversigt</h1>
            <p className="text-muted-foreground mt-1">
              Samlet oversigt over alle investeringer og porteføljens performance
            </p>
          </div>
        </div>

        {/* Filter Bar */}
        <Card className="p-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
            <div className="flex items-center gap-2 flex-1">
              <span className="text-sm font-medium text-muted-foreground">Fond:</span>
              <Select value={fundFilter} onValueChange={setFundFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Vælg fond" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle fonde</SelectItem>
                  {funds?.map((fund) => (
                    <SelectItem key={fund.id} value={fund.id}>
                      {fund.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-muted-foreground">Periode:</span>
              <Tabs value={timeFilter} onValueChange={setTimeFilter}>
                <TabsList>
                  <TabsTrigger value="ytd">YTD</TabsTrigger>
                  <TabsTrigger value="12m">Sidste 12m</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
        </Card>

        {/* KPI Hero Section */}
        {metricsLoading ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="p-4">
                <div className="h-20 animate-pulse bg-muted rounded" />
              </Card>
            ))}
          </div>
        ) : metrics ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card 
              className="p-4 min-h-[120px] flex flex-col cursor-pointer hover:bg-accent/50 transition-colors overflow-hidden min-w-0"
              onClick={() => navigate('/portfolio/companies?status=active')}
            >
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Aktive investeringer</p>
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{metrics.activeInvestments}</p>
              </div>
              <div className="h-5"></div>
            </Card>

            <Card 
              className="p-4 min-h-[120px] flex flex-col cursor-pointer hover:bg-accent/50 transition-colors overflow-hidden min-w-0"
              onClick={() => navigate('/portfolio/companies?status=due_diligence')}
            >
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">I due diligence</p>
                <Search className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{metrics.dueDiligenceCases}</p>
              </div>
              <div className="h-5"></div>
            </Card>

            <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Total investeret</p>
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{formatCurrency(metrics.totalInvested)}</p>
              </div>
              <div className="h-5">
                <p className="text-xs text-muted-foreground">Historisk total</p>
              </div>
            </Card>

            <Card className="p-4 min-h-[120px] flex flex-col bg-accent/20 overflow-hidden min-w-0">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">Aktivt investeret</p>
                <DollarSign className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{formatCurrency(metrics.activeInvested)}</p>
              </div>
              <div className="h-5">
                <p className="text-xs text-muted-foreground">Ekskl. exits & konkurs</p>
              </div>
            </Card>

            <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">DPI</p>
                <Target className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{metrics.dpi.toFixed(2)}x</p>
              </div>
              <div className="h-5 flex items-center">
                <Badge variant="secondary" className={getDPIBadge(metrics.dpi).color}>
                  {getDPIBadge(metrics.dpi).label}
                </Badge>
              </div>
            </Card>

            <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm text-muted-foreground">TVPI</p>
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1 flex items-center">
                <p className="text-2xl lg:text-3xl font-bold truncate">{metrics.tvpi.toFixed(2)}x</p>
              </div>
              <div className="h-5 flex items-center">
                <Badge variant="secondary" className={getTVPIBadge(metrics.tvpi).color}>
                  {getTVPIBadge(metrics.tvpi).label}
                </Badge>
              </div>
            </Card>
          </div>
        ) : null}

        {/* Fund Distribution */}
        <FundDistributionChart fundFilter={fundFilter} />

        {/* Portfolio Pulse */}
        <PortfolioPulseWidget />

        {/* Valuation Trends */}
        <PortfolioValuationTrendsWidget />

        {/* Portfolio Health Overview */}
        <PortfolioHealthOverview />

        {/* Risk Alerts */}
        <RiskAlertsWidget />

        {/* Missing Reports Alert */}
        <MissingReportsWidget />

        {/* Document Status Widget */}
        <DocumentStatusWidget />

        {/* Exit Performance Widgets */}
        <ExitPerformanceWidgets />

        {/* Trend Analysis */}
        <TrendAnalysisChart />

        {/* Returns Snapshot */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold">Returns Snapshot (YTD)</h2>
          </div>
          {metricsLoading ? (
            <div className="animate-pulse space-y-4">
              <div className="grid gap-4 md:grid-cols-2 mb-6">
                <div className="h-20 bg-muted rounded" />
                <div className="h-20 bg-muted rounded" />
              </div>
            </div>
          ) : metrics ? (
            <>
              <div className="grid gap-4 md:grid-cols-2 mb-6">
                <Card className="p-4 bg-muted/30">
                  <p className="text-sm text-muted-foreground mb-1">Dividende YTD</p>
                  <p className="text-2xl font-bold">{formatCurrency(metrics.ytdDividends)}</p>
                </Card>
                <Card className="p-4 bg-muted/30">
                  <p className="text-sm text-muted-foreground mb-1">Realiseret Exit YTD</p>
                  <p className="text-2xl font-bold">{formatCurrency(metrics.ytdExits)}</p>
                </Card>
              </div>
              <div className="space-y-4">
                <h3 className="font-semibold">Seneste 5 events</h3>
                <ReturnsEventsTable limit={5} />
              </div>
            </>
          ) : null}
        </Card>

        {/* Custom Reports Generator */}
        <CustomReportsGenerator />

        {/* Shipping Benchmark */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Package className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">Shipping Benchmark</h2>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/shipping')}>
              Åbn Shipping
            </Button>
          </div>
          <p className="text-muted-foreground text-sm">Sammenligning af leveringspriser på tværs af portfolio</p>
        </Card>

        {/* Leaderboard */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-bold">Top 5 selskaber</h2>
          </div>
          <TopCompaniesLeaderboard fundFilter={fundFilter} limit={5} />
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;
