import Layout from "@/components/Layout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { 
  usePartnerDealsAdmin, 
  useCompanyPricesAdmin, 
  useProcurementAdoptionsAdmin,
  useAuditLog,
  useArchivePartnerDeal,
  useDeletePartnerDeal,
  useDeleteCompanyPrice,
  useBulkArchiveCompanyPrices,
  useUpdateAdoptionStatus,
} from "@/hooks/useProcurementAdmin";
import { useState } from "react";
import { PartnerDealDialog } from "@/components/procurement/PartnerDealDialog";
import { CSVImportDialog } from "@/components/procurement/CSVImportDialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Plus, Archive, Trash2, Upload, Download, Eye, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { da } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";

export default function ProcurementAdmin() {
  const [dealDialogOpen, setDealDialogOpen] = useState(false);
  const [selectedDeal, setSelectedDeal] = useState<any>(null);
  const [csvDialogOpen, setCSVDialogOpen] = useState(false);
  const [csvEntity, setCSVEntity] = useState<'partner_deals' | 'company_prices' | 'procurement_adoptions'>('partner_deals');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ id: string; type: 'deal' | 'price' } | null>(null);
  const [selectedPrices, setSelectedPrices] = useState<string[]>([]);

  const { data: deals, isLoading: dealsLoading } = usePartnerDealsAdmin();
  const { data: prices, isLoading: pricesLoading } = useCompanyPricesAdmin();
  const { data: adoptions, isLoading: adoptionsLoading } = useProcurementAdoptionsAdmin();
  const { data: auditLog, isLoading: auditLoading } = useAuditLog();
  
  const archiveDeal = useArchivePartnerDeal();
  const deleteDeal = useDeletePartnerDeal();
  const deletePrice = useDeleteCompanyPrice();
  const bulkArchivePrices = useBulkArchiveCompanyPrices();
  const updateAdoptionStatus = useUpdateAdoptionStatus();
  const { toast } = useToast();

  const handleEditDeal = (deal: any) => {
    setSelectedDeal(deal);
    setDealDialogOpen(true);
  };

  const handleNewDeal = () => {
    setSelectedDeal(null);
    setDealDialogOpen(true);
  };

  const handleArchiveDeal = async (id: string, archived: boolean) => {
    await archiveDeal.mutateAsync({ id, archived });
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;

    try {
      if (itemToDelete.type === 'deal') {
        await deleteDeal.mutateAsync(itemToDelete.id);
      } else {
        await deletePrice.mutateAsync(itemToDelete.id);
      }
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const handleBulkArchive = async () => {
    if (selectedPrices.length === 0) return;
    await bulkArchivePrices.mutateAsync(selectedPrices);
    setSelectedPrices([]);
  };

  const handleExportCSV = (data: any[], filename: string) => {
    if (!data || data.length === 0) return;

    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).join(',')).join('\n');
    const csv = `${headers}\n${rows}`;

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${filename}-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Procurement Administration</h1>
          <p className="text-muted-foreground">Administrer partneraftaler, priser og adoptioner</p>
        </div>

        <Tabs defaultValue="deals" className="w-full">
          <TabsList>
            <TabsTrigger value="deals">Partneraftaler</TabsTrigger>
            <TabsTrigger value="prices">Selskabspriser</TabsTrigger>
            <TabsTrigger value="adoptions">Adoptioner</TabsTrigger>
            <TabsTrigger value="audit">Audit Log</TabsTrigger>
          </TabsList>

          {/* Partner Deals */}
          <TabsContent value="deals" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Partneraftaler</CardTitle>
                    <CardDescription>Administrer MOLA partneraftaler</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={() => { setCSVEntity('partner_deals'); setCSVDialogOpen(true); }} variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Import CSV
                    </Button>
                    <Button onClick={() => handleExportCSV(deals || [], 'partner-deals')} variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </Button>
                    <Button onClick={handleNewDeal} size="sm">
                      <Plus className="w-4 h-4 mr-2" />
                      Ny aftale
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {dealsLoading ? (
                  <p className="text-center text-muted-foreground py-8">Indlæser...</p>
                ) : !deals || deals.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Ingen partneraftaler endnu</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Leverandør</TableHead>
                        <TableHead>Plan</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead>MOLA Pris</TableHead>
                        <TableHead>Listepris</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Handlinger</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deals.map((deal) => (
                        <TableRow key={deal.id}>
                          <TableCell className="font-medium">{deal.vendor}</TableCell>
                          <TableCell>{deal.plan_name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{deal.category}</Badge>
                          </TableCell>
                          <TableCell>{deal.mola_price} {deal.unit}</TableCell>
                          <TableCell className="line-through text-muted-foreground">
                            {deal.list_price} {deal.unit}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Badge variant={deal.is_active ? "default" : "secondary"}>
                                {deal.is_active ? 'Aktiv' : 'Inaktiv'}
                              </Badge>
                              {deal.archived && <Badge variant="destructive">Arkiveret</Badge>}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button onClick={() => handleEditDeal(deal)} variant="ghost" size="sm">
                                Rediger
                              </Button>
                              <Button 
                                onClick={() => handleArchiveDeal(deal.id, !deal.archived)} 
                                variant="ghost" 
                                size="sm"
                              >
                                <Archive className="w-4 h-4" />
                              </Button>
                              <Button 
                                onClick={() => {
                                  setItemToDelete({ id: deal.id, type: 'deal' });
                                  setDeleteDialogOpen(true);
                                }}
                                variant="ghost" 
                                size="sm"
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Company Prices */}
          <TabsContent value="prices" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Selskabspriser</CardTitle>
                    <CardDescription>Administrer indlæste selskabspriser</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {selectedPrices.length > 0 && (
                      <Button onClick={handleBulkArchive} variant="outline" size="sm">
                        <Archive className="w-4 h-4 mr-2" />
                        Arkiver ({selectedPrices.length})
                      </Button>
                    )}
                    <Button onClick={() => { setCSVEntity('company_prices'); setCSVDialogOpen(true); }} variant="outline" size="sm">
                      <Upload className="w-4 h-4 mr-2" />
                      Import CSV
                    </Button>
                    <Button onClick={() => handleExportCSV(prices || [], 'company-prices')} variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Export CSV
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {pricesLoading ? (
                  <p className="text-center text-muted-foreground py-8">Indlæser...</p>
                ) : !prices || prices.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Ingen selskabspriser endnu</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">
                          <input
                            type="checkbox"
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedPrices(prices.map(p => p.id));
                              } else {
                                setSelectedPrices([]);
                              }
                            }}
                            checked={selectedPrices.length === prices.length}
                          />
                        </TableHead>
                        <TableHead>Selskab</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead>Subkategori</TableHead>
                        <TableHead>Pris</TableHead>
                        <TableHead>Volumen</TableHead>
                        <TableHead>Opdateret</TableHead>
                        <TableHead>Handlinger</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {prices.map((price) => (
                        <TableRow key={price.id}>
                          <TableCell>
                            <input
                              type="checkbox"
                              checked={selectedPrices.includes(price.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedPrices([...selectedPrices, price.id]);
                                } else {
                                  setSelectedPrices(selectedPrices.filter(id => id !== price.id));
                                }
                              }}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{price.companies?.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{price.category}</Badge>
                          </TableCell>
                          <TableCell>{price.subcategory}</TableCell>
                          <TableCell>{price.value_numeric} {price.unit}</TableCell>
                          <TableCell>{price.sample_volume_monthly || '-'}</TableCell>
                          <TableCell>
                            {format(new Date(price.updated_at), 'dd MMM yyyy', { locale: da })}
                          </TableCell>
                          <TableCell>
                            <Button 
                              onClick={() => {
                                setItemToDelete({ id: price.id, type: 'price' });
                                setDeleteDialogOpen(true);
                              }}
                              variant="ghost" 
                              size="sm"
                            >
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Adoptions */}
          <TabsContent value="adoptions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Adoptioner</CardTitle>
                <CardDescription>Status på partneraftale-adoptioner</CardDescription>
              </CardHeader>
              <CardContent>
                {adoptionsLoading ? (
                  <p className="text-center text-muted-foreground py-8">Indlæser...</p>
                ) : !adoptions || adoptions.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Ingen adoptioner endnu</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Selskab</TableHead>
                        <TableHead>Deal</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Noter</TableHead>
                        <TableHead>Aktiveret</TableHead>
                        <TableHead>Handlinger</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {adoptions.map((adoption) => (
                        <TableRow key={adoption.id}>
                          <TableCell className="font-medium">{adoption.companies?.name}</TableCell>
                          <TableCell>
                            {adoption.partner_deals?.vendor} - {adoption.partner_deals?.plan_name}
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant={
                                adoption.status === 'active' ? 'default' :
                                adoption.status === 'pending' ? 'secondary' :
                                adoption.status === 'cancelled' ? 'destructive' :
                                'outline'
                              }
                            >
                              {adoption.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-xs truncate">{adoption.notes || '-'}</TableCell>
                          <TableCell>
                            {adoption.activated_at 
                              ? format(new Date(adoption.activated_at), 'dd MMM yyyy', { locale: da })
                              : '-'
                            }
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              {adoption.status !== 'active' && (
                                <Button 
                                  onClick={() => updateAdoptionStatus.mutate({ id: adoption.id, status: 'active' })}
                                  variant="outline" 
                                  size="sm"
                                >
                                  Aktiver
                                </Button>
                              )}
                              {adoption.status === 'pending' && (
                                <Button 
                                  onClick={() => updateAdoptionStatus.mutate({ id: adoption.id, status: 'cancelled' })}
                                  variant="outline" 
                                  size="sm"
                                >
                                  Annuller
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Audit Log */}
          <TabsContent value="audit" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Audit Log</CardTitle>
                <CardDescription>Seneste 100 ændringer</CardDescription>
              </CardHeader>
              <CardContent>
                {auditLoading ? (
                  <p className="text-center text-muted-foreground py-8">Indlæser...</p>
                ) : !auditLog || auditLog.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">Ingen log endnu</p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tidspunkt</TableHead>
                        <TableHead>Bruger</TableHead>
                        <TableHead>Entity</TableHead>
                        <TableHead>Action</TableHead>
                        <TableHead>Diff</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {auditLog.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell>
                            {format(new Date(log.created_at), 'dd MMM yyyy HH:mm', { locale: da })}
                          </TableCell>
                          <TableCell className="font-mono text-xs">{log.actor_user_id.slice(0, 8)}...</TableCell>
                          <TableCell>
                            <Badge variant="outline">{log.entity}</Badge>
                          </TableCell>
                          <TableCell>
                            <Badge>{log.action}</Badge>
                          </TableCell>
                          <TableCell>
                            {log.diff ? (
                              <Button variant="ghost" size="sm" onClick={() => {
                                toast({
                                  title: "Diff",
                                  description: (
                                    <pre className="text-xs overflow-auto max-h-64">
                                      {JSON.stringify(log.diff, null, 2)}
                                    </pre>
                                  ),
                                });
                              }}>
                                <Eye className="w-4 h-4" />
                              </Button>
                            ) : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <PartnerDealDialog
        open={dealDialogOpen}
        onOpenChange={setDealDialogOpen}
        deal={selectedDeal}
      />

      <CSVImportDialog
        open={csvDialogOpen}
        onOpenChange={setCSVDialogOpen}
        entity={csvEntity}
      />

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil permanent slette {itemToDelete?.type === 'deal' ? 'partneraftalen' : 'prisen'}. 
              Denne handling kan ikke fortrydes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90">
              Slet permanent
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}