import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import * as LucideIcons from 'lucide-react';
import { useSupportContacts } from '@/hooks/useSupportContacts';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const { toast } = useToast();
  const { data: contacts, isLoading } = useSupportContacts();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Dummy submission for V1
    toast({
      title: "Besked sendt",
      description: "Vi vender tilbage hurtigst muligt.",
    });
    
    setFormData({ name: '', email: '', message: '' });
  };

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Kopieret!",
      description: `${type} blev kopieret til udklipsholder`,
    });
  };

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName] || LucideIcons.User;
    return Icon;
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8">
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <LucideIcons.Mail className="h-5 w-5" />
              Kontakt MOLA
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Har du spørgsmål eller brug for hjælp? Send os en besked.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Navn</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Dit navn"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="din@email.dk"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Besked</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Skriv din besked her..."
                  rows={6}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Send besked
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <LucideIcons.Users className="h-5 w-5" />
              Kontakt os direkte
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Du kan også kontakte vores team direkte
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-24 rounded-lg bg-card/50 animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {contacts?.map((member) => {
                  const Icon = getIcon(member.icon_name);
                  return (
                    <div 
                      key={member.id}
                      className="flex items-start justify-between gap-4 p-4 rounded-lg bg-card/50 border border-border/50 hover:bg-card transition-all duration-300"
                    >
                      <div className="flex items-start gap-4">
                        <Avatar className="w-12 h-12 flex-shrink-0">
                          <AvatarImage src={member.avatar_url || undefined} />
                          <AvatarFallback className="bg-primary/10">
                            <Icon className="h-6 w-6 text-primary" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-semibold">{member.name}</h4>
                          <p className="text-sm text-muted-foreground">{member.role}</p>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1 text-sm text-right">
                        {member.email && (
                          <button
                            onClick={() => copyToClipboard(member.email!, "Email")}
                            className="hover:text-primary transition-colors flex items-center justify-end gap-1 group"
                          >
                            <LucideIcons.Mail className="h-3 w-3" />
                            <span className="group-hover:underline">{member.email}</span>
                          </button>
                        )}
                        {member.phone && (
                          <button
                            onClick={() => copyToClipboard(member.phone!, "Telefon")}
                            className="hover:text-primary transition-colors flex items-center justify-end gap-1 group"
                          >
                            <LucideIcons.Phone className="h-3 w-3" />
                            <span className="group-hover:underline">{member.phone}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Contact;
