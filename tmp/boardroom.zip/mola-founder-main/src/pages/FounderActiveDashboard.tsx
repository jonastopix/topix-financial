import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useCompanyFinancials } from '@/hooks/useCompanyFinancials';
import { usePortfolioBenchmarks } from '@/hooks/useCompanyData';
import { useShippingPrices, useNPSResponses } from '@/hooks/useCompanyData';
import { calculateScorecard, calculateNPSMetrics } from '@/lib/metricsCalculations';
import { FinancialTrendChart } from '@/components/FinancialTrendChart';
import { QuickActionsPanel } from '@/components/QuickActionsPanel';
import { StatCard } from '@/components/StatCard';
import MyTasksWidget from '@/components/MyTasksWidget';
import { Activity, TrendingUp, Package, Users, DollarSign, Eye, Heart, Sparkles, HelpCircle, Wallet } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Progress } from '@/components/ui/progress';
import { formatNumber, formatPercentage } from '@/lib/formatters';
import MilestoneInsightsWidget from '@/components/MilestoneInsightsWidget';
import ThisMonthLastYearWidget from '@/components/ThisMonthLastYearWidget';
import { MyRankingWidget } from '@/components/MyRankingWidget';
import { PortfolioPulseWidget } from '@/components/PortfolioPulseWidget';
import { ActivityTicker } from '@/components/ActivityTicker';
import { TrustpilotScoreCard } from '@/components/TrustpilotScoreCard';
import NPSPromptBanner from '@/components/NPSPromptBanner';
import { GamificationWidget } from '@/components/GamificationWidget';
import { DailyChallenges } from '@/components/DailyChallenges';
import { BadgesShowcase } from '@/components/BadgesShowcase';

interface FounderActiveDashboardProps {
  companyId: string;
  companyName: string;
}

export function FounderActiveDashboard({ companyId, companyName }: FounderActiveDashboardProps) {
  const { data: financials } = useCompanyFinancials(companyId);
  const { data: benchmarks } = usePortfolioBenchmarks();
  const { data: shippingPrices = [] } = useShippingPrices(companyId);
  const { data: npsResponses = [], refetch: refetchNPS } = useNPSResponses(companyId);

  const formatCurrency = (amount: number | null | undefined) => {
    if (!amount) return 'N/A';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  // Calculate scorecard if we have data
  const currentYear = new Date().getFullYear();
  const scorecard = financials?.reports 
    ? calculateScorecard(financials.reports, npsResponses, currentYear)
    : null;

  // Calculate NPS metrics
  const npsMetrics = npsResponses.length > 0 
    ? calculateNPSMetrics(npsResponses)
    : null;

  // Prepare chart data (last 12 months)
  const chartData = financials?.reports
    ?.slice(0, 12)
    .reverse()
    .map(r => ({
      period: `${r.period_month}/${r.period_year}`,
      revenue: Number(r.revenue_dkk) || 0,
      ebitda: Number(r.ebitda_dkk) || 0,
    })) || [];

  // Check for missing reports (current month)
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const hasMissingReport = !financials?.reports?.some(
    r => r.period_month === currentMonth && r.period_year === currentYear
  );

  // Check if shipping prices need update (> 3 months old)
  const latestShipping = shippingPrices[0];
  const needsShippingUpdate = latestShipping 
    ? new Date(latestShipping.effective_from).getTime() < Date.now() - (90 * 24 * 60 * 60 * 1000)
    : true;

  // Check if NPS response needed for current quarter
  const currentQuarter = Math.floor((currentMonth - 1) / 3) + 1;
  const needsNPSResponse = !npsResponses.some(
    r => r.period_quarter === currentQuarter && r.period_year === currentYear
  );

  // Calculate shipping benchmark comparison
  const myLatestShipping = latestShipping 
    ? (Number(latestShipping.home_delivery_dkk) + Number(latestShipping.pickup_point_dkk)) / 2
    : null;
  const portfolioAvgShipping = benchmarks 
    ? (benchmarks.shipping.avgHomeDelivery + benchmarks.shipping.avgPickupPoint) / 2
    : null;

  const shippingDifference = myLatestShipping && portfolioAvgShipping
    ? ((myLatestShipping - portfolioAvgShipping) / portfolioAvgShipping) * 100
    : null;

  return (
    <>
      <ActivityTicker />
      
      {/* Prominent NPS Banner when response needed */}
      {needsNPSResponse && (
        <div className="mb-6">
          <NPSPromptBanner companyId={companyId} onSubmit={() => refetchNPS()} />
        </div>
      )}

      {/* Gamification Section */}
      <div className="grid gap-4 md:grid-cols-3 mb-6">
        <GamificationWidget />
        <DailyChallenges />
        <BadgesShowcase />
      </div>
      
      <div className="space-y-8 animate-fade-up">
        {/* Hero Section */}
      <div className="relative rounded-2xl glass-card p-8 md:p-12">
        <div className="absolute inset-0 gradient-hero opacity-10" />
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-2">{companyName}</h1>
              <p className="text-muted-foreground text-lg">Din portfolio dashboard</p>
            </div>
            <Badge variant="success" className="w-fit text-base px-4 py-2 flex-shrink-0 whitespace-nowrap">
              <Sparkles className="h-4 w-4 mr-2" />
              Aktiv Investering
            </Badge>
          </div>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div className="grid gap-6 md:grid-cols-2">
        <StatCard
          title="Seneste måneds omsætning"
          value={financials?.latestMonth?.revenue || 0}
          prefix=""
          suffix=" DKK"
          decimals={0}
          icon={DollarSign}
          trend={financials?.latestMonth?.revenueChange ? {
            value: financials.latestMonth.revenueChange,
            isPositive: financials.latestMonth.revenueChange >= 0
          } : undefined}
          variant="glass"
          className="delay-100"
        />
        <StatCard
          title="YTD Omsætning"
          value={financials?.ytd.revenue || 0}
          prefix=""
          suffix=" DKK"
          decimals={0}
          icon={TrendingUp}
          variant="glass"
          className="delay-200"
        />
        <StatCard
          title="Seneste EBITDA"
          value={financials?.latestMonth?.ebitda || 0}
          prefix=""
          suffix=" DKK"
          decimals={0}
          icon={Activity}
          trend={financials?.latestMonth?.ebitdaChange ? {
            value: financials.latestMonth.ebitdaChange,
            isPositive: financials.latestMonth.ebitdaChange >= 0
          } : undefined}
          variant="glass"
          className="delay-300"
        />
        <StatCard
          title="Cash position"
          value={financials?.latestMonth?.cash || 0}
          prefix=""
          suffix=" DKK"
          decimals={0}
          icon={Wallet}
          variant="glass"
          className="hover:scale-105 transition-transform"
        />
      </div>

      {/* Financial Trend Chart */}
      <div className="animate-scale-in">
        <FinancialTrendChart data={chartData} />
      </div>

      {/* Portfolio Pulse Widget */}
      <div className="animate-slide-in">
        <PortfolioPulseWidget />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Milestone Insights Widget */}
        <div className="animate-slide-in">
          <MilestoneInsightsWidget companyId={companyId} />
        </div>

        {/* This Month Last Year Widget */}
        <div className="animate-slide-in delay-50">
          <ThisMonthLastYearWidget companyId={companyId} />
        </div>

        {/* My Tasks Widget */}
        <div className="animate-slide-in delay-100">
          <MyTasksWidget />
        </div>

        {/* Scorecard Overview */}
        <Card className="p-6 glass-card hover-lift animate-slide-in delay-100">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <Activity className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">MOLA Scorecard</h3>
            <Tooltip>
              <TooltipTrigger asChild>
                <button className="text-muted-foreground hover:text-foreground transition-colors">
                  <HelpCircle className="h-4 w-4" />
                </button>
              </TooltipTrigger>
              <TooltipContent className="max-w-md p-4" side="left">
                <div className="space-y-3">
                  <div>
                    <p className="font-semibold text-sm mb-1">Total Score</p>
                    <p className="text-xs text-muted-foreground">Gennemsnit af alle fire kategorier</p>
                  </div>
                  <div>
                    <p className="font-semibold text-sm mb-1 flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      Financial (0-100)
                    </p>
                    <p className="text-xs text-muted-foreground">Baseret på EBITDA margin (max 50 point) og årlig omsætningsvækst (max 50 point)</p>
                  </div>
                  <div>
                    <p className="font-semibold text-sm mb-1 flex items-center gap-1">
                      <TrendingUp className="h-3 w-3" />
                      Growth (0-100)
                    </p>
                    <p className="text-xs text-muted-foreground">Baseret på årlig omsætningsvækst. 50%+ vækst = 100 point, negativ vækst = 0 point</p>
                  </div>
                  <div>
                    <p className="font-semibold text-sm mb-1 flex items-center gap-1">
                      <Eye className="h-3 w-3" />
                      Transparency (0-100)
                    </p>
                    <p className="text-xs text-muted-foreground">Baseret på rettidig indlevering af de sidste 3 månedsrapporter. Rapporter skal indleveres <strong>senest den 20. i måneden efter</strong> rapporteringsperioden. 3/3 til tiden = 100 point</p>
                  </div>
                  <div>
                    <p className="font-semibold text-sm mb-1 flex items-center gap-1">
                      <Heart className="h-3 w-3" />
                      Relationship (0-100)
                    </p>
                    <p className="text-xs text-muted-foreground">Baseret på din seneste NPS score × 10</p>
                  </div>
                </div>
              </TooltipContent>
            </Tooltip>
          </div>
          {scorecard ? (
            <div className="space-y-6">
              {/* Overall Score Circle */}
              <div className="flex items-center justify-center mb-6">
                <div className="relative w-32 h-32">
                  <svg className="w-32 h-32 transform -rotate-90">
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      className="text-muted"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      strokeDasharray={`${2 * Math.PI * 56}`}
                      strokeDashoffset={`${2 * Math.PI * 56 * (1 - (scorecard.financial + scorecard.growth + scorecard.transparency + scorecard.relationship) / 400)}`}
                      className="text-primary transition-all duration-1000"
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-3xl font-bold">
                        {formatNumber((scorecard.financial + scorecard.growth + scorecard.transparency + scorecard.relationship) / 4, 0)}
                      </p>
                      <p className="text-xs text-muted-foreground">Total Score</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Individual Metrics */}
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <DollarSign className="h-4 w-4 text-success" />
                      <span className="text-sm font-medium">Financial</span>
                    </div>
                    <span className="font-bold text-success">{formatNumber(scorecard.financial, 0)}</span>
                  </div>
                  <Progress value={scorecard.financial} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium">Growth</span>
                    </div>
                    <span className="font-bold text-primary">{formatNumber(scorecard.growth, 0)}</span>
                  </div>
                  <Progress value={scorecard.growth} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Eye className="h-4 w-4 text-accent" />
                      <span className="text-sm font-medium">Transparency</span>
                    </div>
                    <span className="font-bold text-accent">{formatNumber(scorecard.transparency, 0)}</span>
                  </div>
                  <Progress value={scorecard.transparency} className="h-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Heart className="h-4 w-4 text-destructive" />
                      <span className="text-sm font-medium">Relationship</span>
                    </div>
                    <span className="font-bold text-destructive">{formatNumber(scorecard.relationship, 0)}</span>
                  </div>
                  <Progress value={scorecard.relationship} className="h-2" />
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-sm text-muted-foreground">
                Indberet månedlige rapporter for at se din scorecard
              </p>
            </div>
          )}
        </Card>
      </div>

      {/* Portfolio Rankings */}
      <div className="animate-slide-in delay-200">
        <MyRankingWidget companyId={companyId} />
      </div>

      {/* Trustpilot, Shipping Benchmark & NPS Score */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 animate-slide-in">
        {/* Trustpilot Score */}
        <TrustpilotScoreCard 
          companyId={companyId} 
          showManageButton={false} 
        />

        {/* Shipping Benchmark */}
        <Card className="p-6 glass-card hover-lift">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <Package className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">Shipping Benchmark</h3>
          </div>
          {myLatestShipping && portfolioAvgShipping && shippingDifference !== null ? (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground mb-2">Dine priser (gns.)</p>
                  <p className="text-2xl font-bold text-primary">{formatCurrency(myLatestShipping)}</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground mb-2">Portfolio gns.</p>
                  <p className="text-2xl font-bold">{formatCurrency(portfolioAvgShipping)}</p>
                </div>
              </div>
              <div className="flex items-center justify-center gap-3 p-4 rounded-lg bg-muted/30">
                <div className={`h-4 w-4 rounded-full ${
                  shippingDifference < -5 ? 'bg-success' : 
                  shippingDifference > 5 ? 'bg-destructive' : 
                  'bg-warning'
                } animate-pulse`} />
                <span className="font-semibold">
                  {shippingDifference > 0 ? '+' : ''}{formatPercentage(shippingDifference, 1)} vs. portfolio
                </span>
              </div>
              <p className="text-sm text-muted-foreground text-center">
                {shippingDifference < -5 
                  ? '🎉 Rigtig god pris! Du er under portfolio gennemsnit.' 
                  : shippingDifference > 5 
                  ? '⚠️ Dine priser er over portfolio gennemsnit.'
                  : '✓ Du ligger tæt på portfolio gennemsnit.'}
              </p>
            </div>
          ) : (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-sm text-muted-foreground">
                Opdater dine shipping priser for at se benchmark
              </p>
            </div>
          )}
        </Card>

        {/* NPS Score */}
        <Card className="p-6 glass-card hover-lift">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <Users className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">NPS Score</h3>
          </div>
          {npsMetrics ? (
            <div>
              <div className="flex items-center justify-center mb-6">
                <div className="text-center">
                  <p className="text-6xl font-bold text-primary mb-2">{npsMetrics.nps}</p>
                  <p className="text-sm text-muted-foreground">
                    Baseret på {npsResponses.length} svar
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="text-center p-4 rounded-lg bg-success/10 border border-success/20">
                  <p className="text-2xl font-bold text-success mb-1">{npsMetrics.promoters}%</p>
                  <p className="text-xs text-muted-foreground">Promoters</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-warning/10 border border-warning/20">
                  <p className="text-2xl font-bold text-warning mb-1">{npsMetrics.passives}%</p>
                  <p className="text-xs text-muted-foreground">Passives</p>
                </div>
                <div className="text-center p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-2xl font-bold text-destructive mb-1">{npsMetrics.detractors}%</p>
                  <p className="text-xs text-muted-foreground">Detractors</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-sm text-muted-foreground">
                Submit din første NPS feedback for at se score
              </p>
            </div>
          )}
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="animate-fade-up">
        <QuickActionsPanel 
          companyId={companyId}
          hasMissingReport={hasMissingReport}
          needsShippingUpdate={needsShippingUpdate}
          needsNPSResponse={needsNPSResponse}
        />
      </div>
    </div>
    </>
  );
}
