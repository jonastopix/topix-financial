import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';
import { useAuth } from '@/contexts/AuthContext';
import { Navigate, useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Building2, 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Users,
  FileText,
  ListTodo,
  AlertCircle,
  ArrowRight,
  Briefcase
} from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { GamificationWidget } from '@/components/GamificationWidget';
import { DailyChallenges } from '@/components/DailyChallenges';
import { StreakManager } from '@/components/StreakManager';

export default function FundPartnerDashboard() {
  const { activeRole } = useRole();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Only fund partners can access this page
  if (activeRole !== 'fund_partner') {
    return <Navigate to="/" replace />;
  }

  // Fetch user's fund
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('fund_id')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Fetch fund details
  const { data: fund, isLoading: fundLoading } = useQuery({
    queryKey: ['fund', profile?.fund_id],
    queryFn: async () => {
      if (!profile?.fund_id) return null;
      const { data, error } = await supabase
        .from('funds')
        .select('*')
        .eq('id', profile.fund_id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.fund_id,
  });

  // Fetch portfolio companies for this fund
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ['fund-companies', profile?.fund_id],
    queryFn: async () => {
      if (!profile?.fund_id) return [];
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('fund_id', profile.fund_id)
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.fund_id,
  });

  // Fetch latest monthly reports for each company
  const { data: latestReports } = useQuery({
    queryKey: ['fund-latest-reports', companies?.map(c => c.id)],
    queryFn: async () => {
      if (!companies || companies.length === 0) return [];
      
      const reports = await Promise.all(
        companies.map(async (company) => {
          const { data, error } = await supabase
            .from('monthly_reports')
            .select('*')
            .eq('company_id', company.id)
            .order('period_year', { ascending: false })
            .order('period_month', { ascending: false })
            .limit(1);
          
          if (error) throw error;
          return data?.[0] || null;
        })
      );
      
      return reports.filter(Boolean);
    },
    enabled: !!companies && companies.length > 0,
  });

  // Fetch tasks for fund companies
  const { data: tasks } = useQuery({
    queryKey: ['fund-tasks', companies?.map(c => c.id)],
    queryFn: async () => {
      if (!companies || companies.length === 0) return [];
      const companyIds = companies.map(c => c.id);
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .in('company_id', companyIds)
        .neq('status', 'done')
        .order('due_date', { ascending: true });
      if (error) throw error;
      return data;
    },
    enabled: !!companies && companies.length > 0,
  });

  // Fetch upcoming meetings
  const { data: upcomingMeetings } = useQuery({
    queryKey: ['fund-meetings', companies?.map(c => c.id)],
    queryFn: async () => {
      if (!companies || companies.length === 0) return [];
      const companyIds = companies.map(c => c.id);
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('company_meetings')
        .select('*, companies(name)')
        .in('company_id', companyIds)
        .gte('meeting_date', today)
        .order('meeting_date', { ascending: true })
        .limit(5);
      if (error) throw error;
      return data;
    },
    enabled: !!companies && companies.length > 0,
  });

  // Calculate aggregate metrics
  const calculateMetrics = () => {
    if (!companies || !latestReports) return null;

    const totalInvested = companies.reduce((sum, c) => sum + Number(c.total_invested_amount_dkk || 0), 0);
    const totalEquity = companies.reduce((sum, c) => sum + Number(c.total_equity_share_pct || 0), 0);
    
    const totalRevenue = latestReports.reduce((sum, r) => sum + Number(r.revenue_dkk || 0), 0);
    const totalEbitda = latestReports.reduce((sum, r) => sum + Number(r.ebitda_dkk || 0), 0);

    const companiesWithReports = latestReports.length;
    const companiesMissingReports = companies.length - companiesWithReports;

    return {
      totalInvested,
      totalEquity,
      totalRevenue,
      totalEbitda,
      avgEquity: companies.length > 0 ? totalEquity / companies.length : 0,
      companiesWithReports,
      companiesMissingReports,
    };
  };

  const metrics = calculateMetrics();

  const formatCurrency = (value: number | null) => {
    if (value === null) return 'N/A';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const isLoading = profileLoading || fundLoading || companiesLoading;

  if (isLoading) {
    return (
      <Layout>
        <div className="p-8 space-y-6">
          <Skeleton className="h-32 w-full" />
          <div className="grid gap-4 md:grid-cols-4">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </Layout>
    );
  }

  if (!fund) {
    return (
      <Layout>
        <div className="p-8">
          <Card>
            <CardContent className="py-12 text-center">
              <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Ingen fond tildelt</h3>
              <p className="text-muted-foreground">
                Kontakt venligst en administrator for at få tildelt en fond.
              </p>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="bg-gradient-to-br from-background via-background to-accent/5 p-4 sm:p-6 lg:p-8 animate-fade-up">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Gamification Section for Fund Partners */}
          <div className="grid gap-4 md:grid-cols-3">
            <GamificationWidget />
            <DailyChallenges />
            <StreakManager />
          </div>
          {/* Header */}
          <div className="glass-card p-6 sm:p-8 rounded-xl border border-border/50">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Briefcase className="h-6 w-6 text-primary" />
                  </div>
                  <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                    {fund.name}
                  </h1>
                </div>
                <p className="text-muted-foreground mb-4">
                  Portfolio Dashboard
                </p>
                <div className="flex flex-wrap gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">CVR:</span>
                    <span className="font-medium">{fund.cvr}</span>
                  </div>
                  {fund.inception_date && (
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground">Stiftet:</span>
                      <span className="font-medium">
                        {format(new Date(fund.inception_date), 'PPP', { locale: da })}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">Portfolio:</span>
                    <Badge variant="outline">
                      {companies?.length || 0} selskaber
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Investeret
                </CardTitle>
                <DollarSign className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(metrics?.totalInvested || 0)}</div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Ejerandel
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {metrics?.totalEquity.toFixed(1)}%
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Gns. {metrics?.avgEquity.toFixed(1)}% pr. selskab
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Seneste Omsætning
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-success" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(metrics?.totalRevenue || 0)}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Fra {metrics?.companiesWithReports || 0} rapporter
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Seneste EBITDA
                </CardTitle>
                <DollarSign className="h-4 w-4 text-success" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatCurrency(metrics?.totalEbitda || 0)}</div>
                {metrics && metrics.companiesMissingReports > 0 && (
                  <p className="text-xs text-destructive mt-1">
                    {metrics.companiesMissingReports} mangler rapport
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Portfolio Companies */}
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Selskaber</CardTitle>
            </CardHeader>
            <CardContent>
              {!companies || companies.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  Ingen selskaber i fonden endnu
                </div>
              ) : (
                <div className="space-y-3">
                  {companies.map((company) => {
                    const latestReport = latestReports?.find(r => r.company_id === company.id);
                    const companyTasks = tasks?.filter(t => t.company_id === company.id) || [];
                    const overdueTasks = companyTasks.filter(t => 
                      t.due_date && new Date(t.due_date) < new Date()
                    );

                    return (
                      <div 
                        key={company.id}
                        className="flex items-center justify-between p-4 rounded-lg border border-border hover:border-primary/50 transition-all cursor-pointer group"
                        onClick={() => navigate(`/company/${company.id}`)}
                      >
                        <div className="flex items-center gap-4 flex-1">
                          <div className="p-2 rounded-lg bg-primary/10">
                            <Building2 className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold group-hover:text-primary transition-colors">
                              {company.name}
                            </h4>
                            <div className="flex flex-wrap gap-4 mt-1 text-sm text-muted-foreground">
                              <span>Investeret: {formatCurrency(Number(company.total_invested_amount_dkk))}</span>
                              <span>Ejerandel: {Number(company.total_equity_share_pct).toFixed(1)}%</span>
                              {latestReport && (
                                <>
                                  <span>Oms: {formatCurrency(Number(latestReport.revenue_dkk))}</span>
                                  <span>EBITDA: {formatCurrency(Number(latestReport.ebitda_dkk))}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          {companyTasks.length > 0 && (
                            <Badge variant={overdueTasks.length > 0 ? "destructive" : "outline"}>
                              <ListTodo className="h-3 w-3 mr-1" />
                              {companyTasks.length}
                            </Badge>
                          )}
                          <Badge variant="outline">{company.status}</Badge>
                          <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Meetings */}
          {upcomingMeetings && upcomingMeetings.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Kommende Møder
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingMeetings.map((meeting) => (
                    <div key={meeting.id} className="flex items-center justify-between p-3 rounded-lg border border-border">
                      <div>
                        <h4 className="font-medium">{meeting.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {(meeting.companies as any)?.name}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {format(new Date(meeting.meeting_date), 'PPP', { locale: da })}
                        </div>
                        <Badge variant="outline" className="mt-1">
                          {meeting.meeting_type === 'admin' && 'Admin'}
                          {meeting.meeting_type === 'online' && 'Online'}
                          {meeting.meeting_type === 'physical' && 'Fysisk'}
                          {meeting.meeting_type === 'phone' && 'Telefon'}
                          {meeting.meeting_type === 'check_in' && 'Check-in'}
                          {!['admin', 'online', 'physical', 'phone', 'check_in'].includes(meeting.meeting_type) && meeting.meeting_type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Open Tasks Summary */}
          {tasks && tasks.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ListTodo className="h-5 w-5" />
                  Åbne Opgaver
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                    <span className="text-sm">Total åbne opgaver</span>
                    <Badge>{tasks.length}</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                    <span className="text-sm">Overskredet deadline</span>
                    <Badge variant="destructive">
                      {tasks.filter(t => t.due_date && new Date(t.due_date) < new Date()).length}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
                    <span className="text-sm">Høj prioritet</span>
                    <Badge variant="outline">
                      {tasks.filter(t => t.priority === 'high').length}
                    </Badge>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="w-full mt-4"
                  onClick={() => navigate('/tasks')}
                >
                  Se alle opgaver
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </Layout>
  );
}
