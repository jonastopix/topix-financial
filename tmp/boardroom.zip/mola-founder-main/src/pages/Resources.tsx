import Layout from '@/components/Layout';
import ResourceCard from '@/components/ResourceCard';
import { FileText, BarChart3, BookOpen, Lock, Target } from 'lucide-react';

const Resources = () => {
  const resources = [
    {
      title: 'Ansættelseskontrakt',
      icon: FileText,
      description: 'Juridisk godkendt skabelon til ansættelseskontrakter',
      category: 'legal' as const
    },
    {
      title: 'Budget-model',
      icon: BarChart3,
      description: 'Excel-skabelon til budgettering og forecasting',
      category: 'finance' as const
    },
    {
      title: 'Bestyrelsesrapport-template',
      icon: BookOpen,
      description: 'Professionel skabelon til bestyrelsesrapporter',
      category: 'finance' as const
    },
    {
      title: 'GDPR-pakke',
      icon: Lock,
      description: 'Komplet GDPR compliance dokumentation',
      category: 'legal' as const
    },
    {
      title: 'Marketingplan-skabelon',
      icon: Target,
      description: 'Strategisk framework til marketing planning',
      category: 'marketing' as const
    }
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Resource Hub</h1>
          <p className="text-muted-foreground">Skabeloner og værktøjer til din virksomhed</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, idx) => (
            <ResourceCard key={idx} {...resource} />
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Resources;
