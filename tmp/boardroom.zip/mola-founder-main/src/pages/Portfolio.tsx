import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { calculateScorecard, calculateHealthIndex, getHealthStatus } from '@/lib/metricsCalculations';
import { Trophy, TrendingUp, DollarSign, Eye, Heart, Activity, Filter } from 'lucide-react';
import { useRole } from '@/contexts/RoleContext';
import { useFunds } from '@/hooks/useFunds';
import { useIsMobile } from '@/hooks/use-mobile';
import PortfolioCompanyCard from '@/components/PortfolioCompanyCard';

type CompanyScore = {
  id: string;
  name: string;
  industry: string;
  financial: number;
  growth: number;
  transparency: number;
  relationship: number;
  healthIndex: number;
  latestValuation: number | null;
};

const Portfolio = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { setSelectedCompanyId } = useRole();
  const [industryFilter, setIndustryFilter] = useState<string>('all');
  const [fundFilter, setFundFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState(false);
  
  const { data: funds } = useFunds();

  const { data: portfolioData, isLoading } = useQuery({
    queryKey: ['portfolio-scores', fundFilter],
    queryFn: async () => {
      // Build query with optional fund filter
      let companiesQuery = supabase
        .from('companies')
        .select('*')
        .eq('is_active', true);

      // Add fund filter if selected
      if (fundFilter !== 'all') {
        companiesQuery = companiesQuery.eq('fund_id', fundFilter);
      }

      const { data: companies, error: companiesError } = await companiesQuery;

      if (companiesError) throw companiesError;

      // Get all data for scoring
      const scores: CompanyScore[] = [];

      for (const company of companies) {
        // Get monthly reports
        const { data: reports } = await supabase
          .from('monthly_reports')
          .select('*')
          .eq('company_id', company.id)
          .order('period_year', { ascending: false })
          .order('period_month', { ascending: false });

        // Get NPS responses
        const { data: npsResponses } = await supabase
          .from('nps_responses')
          .select('*')
          .eq('company_id', company.id)
          .order('period_year', { ascending: false })
          .order('period_quarter', { ascending: false });

        // Get latest valuation
        const { data: valuations } = await supabase
          .from('valuations')
          .select('post_money_valuation_dkk')
          .eq('company_id', company.id)
          .order('as_of_date', { ascending: false })
          .limit(1);

        if (reports && reports.length > 0) {
          const currentYear = new Date().getFullYear();
          const scorecard = calculateScorecard(reports, npsResponses || [], currentYear);
          const healthIndex = calculateHealthIndex(
            scorecard.financial,
            scorecard.growth,
            scorecard.transparency,
            scorecard.relationship
          );

          scores.push({
            id: company.id,
            name: company.name,
            industry: company.industry || 'other',
            financial: scorecard.financial,
            growth: scorecard.growth,
            transparency: scorecard.transparency,
            relationship: scorecard.relationship,
            healthIndex,
            latestValuation: valuations?.[0]?.post_money_valuation_dkk 
              ? Number(valuations[0].post_money_valuation_dkk) 
              : null,
          });
        }
      }

      // Sort by health index descending
      return scores.sort((a, b) => b.healthIndex - a.healthIndex);
    },
  });

  const filteredData = portfolioData?.filter(
    company => industryFilter === 'all' || company.industry === industryFilter
  ) || [];

  // Get top 3 for each category
  const getTop3 = (category: 'financial' | 'growth' | 'transparency' | 'relationship') => {
    return [...(filteredData || [])]
      .sort((a, b) => (b[category] as number) - (a[category] as number))
      .slice(0, 3)
      .map(c => c.id);
  };

  const top3Financial = getTop3('financial');
  const top3Growth = getTop3('growth');
  const top3Transparency = getTop3('transparency');
  const top3Relationship = getTop3('relationship');

  const handleCompanyClick = (companyId: string) => {
    navigate(`/company/${companyId}`);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('da-DK', { 
      style: 'currency', 
      currency: 'DKK', 
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getRankBadge = (index: number) => {
    if (index === 0) return <Badge className="bg-yellow-500">🥇 #1</Badge>;
    if (index === 1) return <Badge className="bg-gray-400">🥈 #2</Badge>;
    if (index === 2) return <Badge className="bg-orange-600">🥉 #3</Badge>;
    return null;
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-6 md:py-8 space-y-6 md:space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-4xl font-bold mb-1 md:mb-2">Portfolio Leaderboard</h1>
            <p className="text-sm md:text-base text-muted-foreground">Sammenligning af alle aktive porteføljeselskaber</p>
          </div>

          {/* Filters - Collapsible on mobile */}
          {isMobile ? (
            <Card className="w-full p-3">
              <Collapsible open={showFilters} onOpenChange={setShowFilters}>
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" className="w-full justify-between h-12 tap-safe">
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      <span>Filtre</span>
                    </div>
                    <span className="text-muted-foreground text-sm">
                      {fundFilter !== 'all' || industryFilter !== 'all' 
                        ? `${[fundFilter !== 'all', industryFilter !== 'all'].filter(Boolean).length} aktive` 
                        : ''}
                    </span>
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-3 space-y-3">
                  <Select value={fundFilter} onValueChange={setFundFilter}>
                    <SelectTrigger className="w-full h-12">
                      <SelectValue placeholder="Vælg fond" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle fonde</SelectItem>
                      {funds?.map((fund) => (
                        <SelectItem key={fund.id} value={fund.id}>
                          {fund.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={industryFilter} onValueChange={setIndustryFilter}>
                    <SelectTrigger className="w-full h-12">
                      <SelectValue placeholder="Filter industri" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle industrier</SelectItem>
                      <SelectItem value="ecommerce">E-commerce</SelectItem>
                      <SelectItem value="saas">SaaS</SelectItem>
                      <SelectItem value="other">Andet</SelectItem>
                    </SelectContent>
                  </Select>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ) : (
            <div className="flex gap-3">
              <Select value={fundFilter} onValueChange={setFundFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Vælg fond" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle fonde</SelectItem>
                  {funds?.map((fund) => (
                    <SelectItem key={fund.id} value={fund.id}>
                      {fund.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={industryFilter} onValueChange={setIndustryFilter}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Filter industri" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle industrier</SelectItem>
                  <SelectItem value="ecommerce">E-commerce</SelectItem>
                  <SelectItem value="saas">SaaS</SelectItem>
                  <SelectItem value="other">Andet</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {isLoading ? (
          <Card className="p-8 text-center">
            <p>Indlæser portfolio data...</p>
          </Card>
        ) : filteredData.length === 0 ? (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Ingen selskaber fundet</p>
          </Card>
        ) : (
          <>
            {/* Mobile: Card view / Desktop: Table view */}
            {isMobile ? (
              <div className="space-y-3">
                {filteredData.map((company, index) => (
                  <PortfolioCompanyCard 
                    key={company.id} 
                    company={company} 
                    rank={index + 1} 
                  />
                ))}
              </div>
            ) : (
              <Card>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">Rank</TableHead>
                      <TableHead>Selskab</TableHead>
                      <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <DollarSign className="h-4 w-4 text-green-500" />
                          Financial
                        </div>
                      </TableHead>
                      <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <TrendingUp className="h-4 w-4 text-blue-500" />
                          Growth
                        </div>
                      </TableHead>
                      <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Eye className="h-4 w-4 text-purple-500" />
                          Transparency
                        </div>
                      </TableHead>
                      <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Heart className="h-4 w-4 text-pink-500" />
                          Relationship
                        </div>
                      </TableHead>
                      <TableHead className="text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Activity className="h-4 w-4" />
                          Health Index
                        </div>
                      </TableHead>
                      <TableHead className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <DollarSign className="h-4 w-4 text-primary" />
                          Latest Valuation
                        </div>
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredData.map((company, index) => {
                      const healthStatus = getHealthStatus(company.healthIndex);
                      
                      return (
                        <TableRow 
                          key={company.id}
                          className="cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => handleCompanyClick(company.id)}
                        >
                          <TableCell>
                            {getRankBadge(index)}
                          </TableCell>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {company.name}
                              {company.industry === 'ecommerce' && (
                                <Badge variant="outline" className="text-xs">E-com</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className={`font-bold ${getScoreColor(company.financial)}`}>
                                {Math.round(company.financial)}
                              </span>
                              {top3Financial.includes(company.id) && (
                                <Trophy className="h-3 w-3 text-green-500" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className={`font-bold ${getScoreColor(company.growth)}`}>
                                {Math.round(company.growth)}
                              </span>
                              {top3Growth.includes(company.id) && (
                                <Trophy className="h-3 w-3 text-blue-500" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className={`font-bold ${getScoreColor(company.transparency)}`}>
                                {Math.round(company.transparency)}
                              </span>
                              {top3Transparency.includes(company.id) && (
                                <Trophy className="h-3 w-3 text-purple-500" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className={`font-bold ${getScoreColor(company.relationship)}`}>
                                {Math.round(company.relationship)}
                              </span>
                              {top3Relationship.includes(company.id) && (
                                <Trophy className="h-3 w-3 text-pink-500" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge className={`${healthStatus.bgColor} ${healthStatus.color} border-0`}>
                              {Math.round(company.healthIndex)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {company.latestValuation ? (
                              <span className="font-semibold">
                                {formatCurrency(company.latestValuation)}
                              </span>
                            ) : (
                              <span className="text-muted-foreground text-sm">-</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </Card>
            )}

            {/* Top performers cards - hidden on mobile for cleaner UX */}
            <div className="hidden md:grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-green-500" />
                  <h3 className="font-semibold">Top Financial</h3>
                </div>
                <div className="space-y-1">
                  {filteredData
                    .filter(c => top3Financial.includes(c.id))
                    .slice(0, 3)
                    .map((c, i) => (
                      <div key={c.id} className="text-sm flex items-center justify-between">
                        <span>{i + 1}. {c.name}</span>
                        <Badge variant="outline">{Math.round(c.financial)}</Badge>
                      </div>
                    ))}
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-blue-500" />
                  <h3 className="font-semibold">Top Growth</h3>
                </div>
                <div className="space-y-1">
                  {filteredData
                    .filter(c => top3Growth.includes(c.id))
                    .slice(0, 3)
                    .map((c, i) => (
                      <div key={c.id} className="text-sm flex items-center justify-between">
                        <span>{i + 1}. {c.name}</span>
                        <Badge variant="outline">{Math.round(c.growth)}</Badge>
                      </div>
                    ))}
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-purple-500" />
                  <h3 className="font-semibold">Top Transparency</h3>
                </div>
                <div className="space-y-1">
                  {filteredData
                    .filter(c => top3Transparency.includes(c.id))
                    .slice(0, 3)
                    .map((c, i) => (
                      <div key={c.id} className="text-sm flex items-center justify-between">
                        <span>{i + 1}. {c.name}</span>
                        <Badge variant="outline">{Math.round(c.transparency)}</Badge>
                      </div>
                    ))}
                </div>
              </Card>

              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-5 w-5 text-pink-500" />
                  <h3 className="font-semibold">Top Relationship</h3>
                </div>
                <div className="space-y-1">
                  {filteredData
                    .filter(c => top3Relationship.includes(c.id))
                    .slice(0, 3)
                    .map((c, i) => (
                      <div key={c.id} className="text-sm flex items-center justify-between">
                        <span>{i + 1}. {c.name}</span>
                        <Badge variant="outline">{Math.round(c.relationship)}</Badge>
                      </div>
                    ))}
                </div>
              </Card>
            </div>
          </>
        )}
      </div>
    </Layout>
  );
};

export default Portfolio;