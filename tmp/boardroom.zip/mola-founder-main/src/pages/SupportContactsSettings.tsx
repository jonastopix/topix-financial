import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Pencil, Trash2, User, Briefcase, Scale, Mail, Phone, Building, Landmark, MessageSquare, Upload, X, Linkedin } from 'lucide-react';
import { useSupportContactsAdmin, useCreateSupportContact, useUpdateSupportContact, useDeleteSupportContact, SupportContact } from '@/hooks/useSupportContacts';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const iconOptions = [
  { value: 'User', label: 'User', Icon: User },
  { value: 'Briefcase', label: 'Briefcase', Icon: Briefcase },
  { value: 'Scale', label: 'Scale', Icon: Scale },
  { value: 'Mail', label: 'Mail', Icon: Mail },
  { value: 'Phone', label: 'Phone', Icon: Phone },
  { value: 'Building', label: 'Building', Icon: Building },
  { value: 'Landmark', label: 'Landmark', Icon: Landmark },
  { value: 'MessageSquare', label: 'MessageSquare', Icon: MessageSquare },
];

const SupportContactsSettings = () => {
  const { data: contacts, isLoading } = useSupportContactsAdmin();
  const createContact = useCreateSupportContact();
  const updateContact = useUpdateSupportContact();
  const deleteContact = useDeleteSupportContact();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<SupportContact | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    role: '',
    email: '',
    phone: '',
    linkedin_url: '',
    icon_name: 'User',
    avatar_url: '',
    sort_order: 0,
    is_active: true,
  });
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);

  const resetForm = () => {
    setFormData({
      name: '',
      role: '',
      email: '',
      phone: '',
      linkedin_url: '',
      icon_name: 'User',
      avatar_url: '',
      sort_order: 0,
      is_active: true,
    });
    setEditingContact(null);
    setAvatarFile(null);
    setAvatarPreview(null);
  };

  // Resize and crop image to 200x200 square for avatar use
  const resizeImage = (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      img.onload = () => {
        URL.revokeObjectURL(img.src);
        
        const size = 200;
        canvas.width = size;
        canvas.height = size;

        // Calculate center crop (square from center of image)
        const minDimension = Math.min(img.width, img.height);
        const sx = (img.width - minDimension) / 2;
        const sy = (img.height - minDimension) / 2;

        // Draw cropped and resized image
        ctx.drawImage(
          img,
          sx, sy, minDimension, minDimension, // Source: center square
          0, 0, size, size // Destination: 200x200
        );

        canvas.toBlob(
          (blob) => blob ? resolve(blob) : reject(new Error('Failed to create blob')),
          'image/jpeg',
          0.9
        );
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Fil for stor",
          description: "Billede må maksimalt være 5MB",
          variant: "destructive",
        });
        return;
      }
      
      try {
        // Resize image and create preview
        const resizedBlob = await resizeImage(file);
        const resizedFile = new File([resizedBlob], 'avatar.jpg', { type: 'image/jpeg' });
        setAvatarFile(resizedFile);
        setAvatarPreview(URL.createObjectURL(resizedBlob));
      } catch (error) {
        console.error('Error resizing image:', error);
        toast({
          title: "Fejl",
          description: "Kunne ikke behandle billedet",
          variant: "destructive",
        });
      }
    }
  };

  const removeAvatar = () => {
    setAvatarFile(null);
    setAvatarPreview(null);
    setFormData({ ...formData, avatar_url: '' });
  };

  const uploadAvatar = async (contactId: string): Promise<string | null> => {
    if (!avatarFile) return formData.avatar_url || null;

    setUploadingAvatar(true);
    try {
      const fileName = `${contactId}.jpg`;
      const filePath = `support-contacts/${fileName}`;

      // Delete old avatar if exists
      if (editingContact?.avatar_url) {
        const oldPath = editingContact.avatar_url.split('/').pop();
        if (oldPath) {
          await supabase.storage
            .from('avatars')
            .remove([`support-contacts/${oldPath}`]);
        }
      }

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, avatarFile, { upsert: true });

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      // Add timestamp to bust browser cache
      return `${data.publicUrl}?t=${Date.now()}`;
    } catch (error) {
      console.error('Error uploading avatar:', error);
      toast({
        title: "Fejl ved upload",
        description: "Kunne ikke uploade billede",
        variant: "destructive",
      });
      return null;
    } finally {
      setUploadingAvatar(false);
    }
  };

  const handleEdit = (contact: SupportContact) => {
    setEditingContact(contact);
    setFormData({
      name: contact.name,
      role: contact.role,
      email: contact.email || '',
      phone: contact.phone || '',
      linkedin_url: contact.linkedin_url || '',
      icon_name: contact.icon_name,
      avatar_url: contact.avatar_url || '',
      sort_order: contact.sort_order,
      is_active: contact.is_active,
    });
    setAvatarPreview(contact.avatar_url);
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      let avatarUrl = formData.avatar_url;

      if (editingContact) {
        // Update existing contact
        if (avatarFile) {
          avatarUrl = await uploadAvatar(editingContact.id) || avatarUrl;
        }
        
        const contactData = {
          ...formData,
          email: formData.email || null,
          phone: formData.phone || null,
          linkedin_url: formData.linkedin_url || null,
          avatar_url: avatarUrl || null,
        };
        
        await updateContact.mutateAsync({ id: editingContact.id, ...contactData });
      } else {
        // Create new contact first to get ID
        const contactData = {
          ...formData,
          email: formData.email || null,
          phone: formData.phone || null,
          linkedin_url: formData.linkedin_url || null,
          avatar_url: null,
        };
        
        const newContact = await createContact.mutateAsync(contactData);
        
        // Upload avatar if provided
        if (avatarFile && newContact) {
          avatarUrl = await uploadAvatar(newContact.id) || null;
          if (avatarUrl) {
            await updateContact.mutateAsync({ 
              id: newContact.id, 
              avatar_url: avatarUrl 
            });
          }
        }
      }

      setIsDialogOpen(false);
      resetForm();
    } catch (error) {
      console.error('Error saving contact:', error);
    }
  };

  const handleDelete = async (id: string) => {
    await deleteContact.mutateAsync(id);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="max-w-full">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-card rounded w-64" />
            <div className="h-32 bg-card rounded" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-full">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Support Kontakter</h1>
            <p className="text-muted-foreground mt-1">Administrer support team kontakter</p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={(open) => {
            setIsDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Tilføj Kontakt
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {editingContact ? 'Redigér Kontakt' : 'Ny Kontakt'}
                </DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Profilbillede</Label>
                  <div className="flex items-center gap-4 mt-2">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={avatarPreview || formData.avatar_url || undefined} />
                      <AvatarFallback>
                        <User className="h-10 w-10" />
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Input
                        id="avatar"
                        type="file"
                        accept="image/*"
                        onChange={handleAvatarChange}
                        className="hidden"
                      />
                      <div className="flex gap-2">
                        <Label htmlFor="avatar" className="cursor-pointer">
                          <Button type="button" variant="outline" size="sm" asChild>
                            <span>
                              <Upload className="mr-2 h-4 w-4" />
                              Upload billede
                            </span>
                          </Button>
                        </Label>
                        {(avatarPreview || formData.avatar_url) && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={removeAvatar}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Maks 5MB. Croppes automatisk til 200x200px.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="name">Navn *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="role">Rolle *</Label>
                  <Input
                    id="role"
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="linkedin_url">LinkedIn URL</Label>
                  <Input
                    id="linkedin_url"
                    type="url"
                    placeholder="https://linkedin.com/in/..."
                    value={formData.linkedin_url}
                    onChange={(e) => setFormData({ ...formData, linkedin_url: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="icon">Ikon</Label>
                  <Select
                    value={formData.icon_name}
                    onValueChange={(value) => setFormData({ ...formData, icon_name: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {iconOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          <div className="flex items-center gap-2">
                            <option.Icon className="h-4 w-4" />
                            {option.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="sort_order">Sorteringsrækkefølge</Label>
                  <Input
                    id="sort_order"
                    type="number"
                    value={formData.sort_order}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="is_active">Aktiv</Label>
                  <Switch
                    id="is_active"
                    checked={formData.is_active}
                    onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Annuller
                  </Button>
                  <Button type="submit">
                    {editingContact ? 'Gem' : 'Opret'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Kontakter</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {contacts?.map((contact) => {
                const IconOption = iconOptions.find(i => i.value === contact.icon_name);
                const Icon = IconOption?.Icon || User;
                
                return (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border bg-card/50 hover:bg-card transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={contact.avatar_url || undefined} />
                        <AvatarFallback className="bg-primary/10">
                          <Icon className="h-5 w-5 text-primary" />
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold">{contact.name}</h4>
                          {!contact.is_active && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                              Inaktiv
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{contact.role}</p>
                        <div className="flex gap-3 mt-1 text-xs text-muted-foreground items-center">
                          {contact.email && <span>{contact.email}</span>}
                          {contact.phone && <span>{contact.phone}</span>}
                          {contact.linkedin_url && (
                            <a 
                              href={contact.linkedin_url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 hover:text-primary transition-colors"
                            >
                              <Linkedin className="h-3 w-3" />
                              <span>LinkedIn</span>
                            </a>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(contact)}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Dette vil permanent slette kontakten "{contact.name}".
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Annuller</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDelete(contact.id)}
                              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            >
                              Slet
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default SupportContactsSettings;
