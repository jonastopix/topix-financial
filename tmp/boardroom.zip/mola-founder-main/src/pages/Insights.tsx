import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import NPSForm from '@/components/NPSForm';
import { useCompanyData, useNPSResponses } from '@/hooks/useCompanyData';
import { calculateNPSMetrics } from '@/lib/metricsCalculations';
import { getNextQuarterStart, formatQuarter, getCurrentQuarter } from '@/lib/npsCalculations';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, TrendingUp, Users, AlertCircle, Building2 } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';

const Insights = () => {
  const { data: company } = useCompanyData();
  const { data: npsResponses, refetch } = useNPSResponses(company?.id);
  const { isAdmin, selectedCompanyId } = useRole();

  const currentQuarter = getCurrentQuarter();
  const nextQuarterDate = getNextQuarterStart();

  // Check if we're in portfolio view (admin with no company selected)
  const isPortfolioView = !company && isAdmin && !selectedCompanyId;

  // Get all NPS responses for portfolio view
  const { data: allNPSResponses } = useQuery({
    queryKey: ['all-nps-responses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('nps_responses')
        .select('score, period_quarter, period_year, company_id, created_at')
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    enabled: isPortfolioView,
  });

  // Get portfolio NPS for current quarter (for single company view)
  const { data: portfolioNPS } = useQuery({
    queryKey: ['portfolio-nps', currentQuarter.quarter, currentQuarter.year],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('nps_responses')
        .select('score')
        .eq('period_quarter', currentQuarter.quarter)
        .eq('period_year', currentQuarter.year);

      if (error) throw error;

      if (!data || data.length === 0) return null;

      return calculateNPSMetrics(data as any);
    },
    enabled: !isPortfolioView,
  });

  const npsMetrics = npsResponses && npsResponses.length > 0 ? calculateNPSMetrics(npsResponses) : null;

  const chartData = npsResponses
    ?.slice(0, 4)
    .reverse()
    .map(r => ({
      period: formatQuarter(r.period_quarter, r.period_year),
      score: r.score * 10,
    })) || [];

  const hasCurrentQuarterResponse = npsResponses?.some(
    r => r.period_quarter === currentQuarter.quarter && r.period_year === currentQuarter.year
  );

  // Calculate portfolio metrics for portfolio view
  const portfolioMetrics = (() => {
    if (!isPortfolioView || !allNPSResponses || allNPSResponses.length === 0) return null;

    // Group by month using created_at
    const monthGroups: Record<string, typeof allNPSResponses> = {};
    allNPSResponses.forEach(r => {
      if (!r.created_at) return;
      const date = new Date(r.created_at);
      const key = format(date, 'yyyy-MM');
      if (!monthGroups[key]) monthGroups[key] = [];
      monthGroups[key].push(r);
    });

    // Get last 12 months for trend
    const sortedMonths = Object.keys(monthGroups).sort().slice(-12);
    
    const trendData = sortedMonths.map(key => {
      const responses = monthGroups[key];
      const avgScore = responses.reduce((sum, r) => sum + r.score, 0) / responses.length;
      const metrics = calculateNPSMetrics(responses);
      const [year, month] = key.split('-');
      return {
        period: format(new Date(parseInt(year), parseInt(month) - 1), 'MMM yyyy', { locale: da }),
        score: metrics.nps,
        avgScore: Math.round(avgScore * 10),
        responseCount: responses.length,
        uniqueCompanies: new Set(responses.map(r => r.company_id)).size,
      };
    });

    // Current month stats
    const currentMonthKey = format(new Date(), 'yyyy-MM');
    const currentMonthResponses = monthGroups[currentMonthKey] || [];
    const currentMetrics = currentMonthResponses.length > 0 
      ? calculateNPSMetrics(currentMonthResponses) 
      : null;
    const currentUniqueCompanies = new Set(currentMonthResponses.map(r => r.company_id)).size;

    // All-time metrics
    const allTimeMetrics = calculateNPSMetrics(allNPSResponses);
    const allTimeUniqueCompanies = new Set(allNPSResponses.map(r => r.company_id)).size;

    return {
      current: currentMetrics,
      currentCompanyCount: currentUniqueCompanies,
      currentResponseCount: currentMonthResponses.length,
      allTime: allTimeMetrics,
      allTimeCompanyCount: allTimeUniqueCompanies,
      totalResponses: allNPSResponses.length,
      trendData,
      totalMonths: Object.keys(monthGroups).length,
    };
  })();

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2">Insights</h1>
            <p className="text-muted-foreground">NPS feedback og relationsdata</p>
          </div>
          <Badge variant="outline" className="gap-2">
            <Calendar className="h-4 w-4" />
            Næste NPS forfalder: {format(nextQuarterDate, 'd. MMMM yyyy', { locale: da })}
          </Badge>
        </div>

        {isPortfolioView ? (
          // Portfolio NPS Overview for admins
          <>
            <Card className="p-6 bg-primary/5 border-primary/20">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Portfolio NPS Overblik</h3>
                  <p className="text-sm text-muted-foreground">
                    Vælg et specifikt selskab i dropdown for at se detaljeret NPS for det selskab
                  </p>
                </div>
              </div>
            </Card>

            {portfolioMetrics ? (
              <>
                {/* Current Month Stats */}
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    {format(new Date(), 'MMMM yyyy', { locale: da })} - Portfolio NPS
                  </h3>
                  {portfolioMetrics.current ? (
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="text-center p-4 rounded-lg bg-primary/10">
                        <p className="text-4xl font-bold text-primary">{portfolioMetrics.current.nps}</p>
                        <p className="text-sm text-muted-foreground mt-1">Gns. NPS Score</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-green-500/10">
                        <p className="text-4xl font-bold text-green-500">{portfolioMetrics.current.promoters}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Promoters (9-10)</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-yellow-500/10">
                        <p className="text-4xl font-bold text-yellow-500">{portfolioMetrics.current.passives}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Passives (7-8)</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-red-500/10">
                        <p className="text-4xl font-bold text-red-500">{portfolioMetrics.current.detractors}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Detractors (0-6)</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/50">
                        <p className="text-4xl font-bold">{portfolioMetrics.currentCompanyCount}</p>
                        <p className="text-sm text-muted-foreground mt-1">Selskaber svaret</p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>Ingen NPS-svar modtaget dette kvartal endnu</p>
                    </div>
                  )}
                </Card>

                {/* Trend Chart */}
                {portfolioMetrics.trendData.length > 1 && (
                  <Card className="p-6">
                    <h3 className="text-xl font-semibold mb-6">Portfolio NPS Udvikling (månedlig)</h3>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={portfolioMetrics.trendData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="period" 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <YAxis 
                          domain={[-100, 100]} 
                          stroke="hsl(var(--muted-foreground))"
                          fontSize={12}
                        />
                        <Tooltip 
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px'
                          }}
                          formatter={(value: number, name: string) => {
                            if (name === 'score') return [value, 'NPS Score'];
                            if (name === 'uniqueCompanies') return [value, 'Selskaber'];
                            return [value, name];
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="score" 
                          stroke="hsl(var(--primary))" 
                          strokeWidth={3}
                          dot={{ fill: 'hsl(var(--primary))', r: 5 }}
                          activeDot={{ r: 7 }}
                          name="score"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                    <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-sm text-muted-foreground">
                      {portfolioMetrics.trendData.map((d, i) => (
                        <div key={i}>
                          <p className="font-medium">{d.period}</p>
                          <p>{d.uniqueCompanies} selskaber</p>
                        </div>
                      ))}
                    </div>
                  </Card>
                )}

                {/* All-time Stats */}
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-6">Samlet Statistik (alle perioder)</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <p className="text-3xl font-bold">{portfolioMetrics.allTime.nps}</p>
                      <p className="text-sm text-muted-foreground mt-1">Gns. NPS Score</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <p className="text-3xl font-bold">{portfolioMetrics.allTimeCompanyCount}</p>
                      <p className="text-sm text-muted-foreground mt-1">Selskaber med svar</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <p className="text-3xl font-bold">{portfolioMetrics.totalResponses}</p>
                      <p className="text-sm text-muted-foreground mt-1">Samlede svar</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <p className="text-3xl font-bold">{portfolioMetrics.totalMonths}</p>
                      <p className="text-sm text-muted-foreground mt-1">Måneder med data</p>
                    </div>
                  </div>
                </Card>
              </>
            ) : (
              <Card className="p-12 text-center">
                <div className="max-w-md mx-auto">
                  <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Ingen NPS-svar i porteføljen</h3>
                  <p className="text-muted-foreground">
                    Når selskaber indsender NPS-svar, vil du se en samlet oversigt her.
                  </p>
                </div>
              </Card>
            )}
          </>
        ) : !company ? (
          <Card className="p-8 text-center">
            <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Intet selskab fundet</h2>
            <p className="text-muted-foreground">Dit selskab er endnu ikke konfigureret.</p>
          </Card>
        ) : (
          <>
            {!hasCurrentQuarterResponse && <NPSForm companyId={company.id} onSubmit={refetch} />}

            {hasCurrentQuarterResponse && (
              <Card className="p-6 bg-green-500/10 border-green-500/50">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <TrendingUp className="h-6 w-6 text-green-500" />
                  </div>
                  <div>
                    <h3 className="font-semibold">NPS feedback indsendt for {formatQuarter(currentQuarter.quarter, currentQuarter.year)}</h3>
                    <p className="text-sm text-muted-foreground">
                      Tak for dit svar! Næste feedback kan indsendes fra {format(nextQuarterDate, 'd. MMMM yyyy', { locale: da })}
                    </p>
                  </div>
                </div>
              </Card>
            )}

            {npsMetrics ? (
              <>
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-6">Dine NPS Metrics</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="text-center p-4 rounded-lg bg-primary/10">
                      <p className="text-4xl font-bold text-primary">{npsMetrics.nps}</p>
                      <p className="text-sm text-muted-foreground mt-1">NPS Score</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-green-500/10">
                      <p className="text-4xl font-bold text-green-500">{npsMetrics.promoters}%</p>
                      <p className="text-sm text-muted-foreground mt-1">Promoters (9-10)</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-yellow-500/10">
                      <p className="text-4xl font-bold text-yellow-500">{npsMetrics.passives}%</p>
                      <p className="text-sm text-muted-foreground mt-1">Passives (7-8)</p>
                    </div>
                    <div className="text-center p-4 rounded-lg bg-red-500/10">
                      <p className="text-4xl font-bold text-red-500">{npsMetrics.detractors}%</p>
                      <p className="text-sm text-muted-foreground mt-1">Detractors (0-6)</p>
                    </div>
                  </div>

                  {chartData.length > 0 && (
                    <>
                      <h4 className="text-lg font-semibold mb-4">NPS Udvikling (seneste 4 kvartaler)</h4>
                      <ResponsiveContainer width="100%" height={250}>
                        <LineChart data={chartData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis 
                            dataKey="period" 
                            stroke="hsl(var(--muted-foreground))"
                            fontSize={12}
                          />
                          <YAxis 
                            domain={[0, 100]} 
                            stroke="hsl(var(--muted-foreground))"
                            fontSize={12}
                          />
                          <Tooltip 
                            contentStyle={{
                              backgroundColor: 'hsl(var(--card))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px'
                            }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="score" 
                            stroke="hsl(var(--primary))" 
                            strokeWidth={3}
                            dot={{ fill: 'hsl(var(--primary))', r: 5 }}
                            activeDot={{ r: 7 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </>
                  )}
                </Card>

                {portfolioNPS && (
                  <Card className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xl font-semibold flex items-center gap-2">
                        <Users className="h-5 w-5" />
                        Porteføljesnit ({formatQuarter(currentQuarter.quarter, currentQuarter.year)})
                      </h3>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-4 rounded-lg bg-muted/50">
                        <p className="text-3xl font-bold">{portfolioNPS.nps}</p>
                        <p className="text-sm text-muted-foreground mt-1">Portfolio NPS</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/50">
                        <p className="text-3xl font-bold text-green-500">{portfolioNPS.promoters}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Promoters</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/50">
                        <p className="text-3xl font-bold text-yellow-500">{portfolioNPS.passives}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Passives</p>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-muted/50">
                        <p className="text-3xl font-bold text-red-500">{portfolioNPS.detractors}%</p>
                        <p className="text-sm text-muted-foreground mt-1">Detractors</p>
                      </div>
                    </div>
                    <div className="mt-6 p-4 rounded-lg bg-muted/30">
                      <p className="text-sm text-muted-foreground text-center">
                        {npsMetrics.nps > portfolioNPS.nps ? (
                          <span className="text-green-500 font-semibold">
                            🎉 Du ligger {npsMetrics.nps - portfolioNPS.nps} point over porteføljesnittet!
                          </span>
                        ) : npsMetrics.nps < portfolioNPS.nps ? (
                          <span className="text-yellow-500 font-semibold">
                            Du ligger {portfolioNPS.nps - npsMetrics.nps} point under porteføljesnittet
                          </span>
                        ) : (
                          <span className="font-semibold">
                            Du ligger lige på porteføljesnittet
                          </span>
                        )}
                      </p>
                    </div>
                  </Card>
                )}
              </>
            ) : (
              <Card className="p-12 text-center">
                <div className="max-w-md mx-auto">
                  <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Ingen NPS-svar endnu</h3>
                  <p className="text-muted-foreground mb-6">
                    Når du indsender dit første NPS-svar, vil du se din udvikling og hvordan du placerer dig i forhold til andre selskaber i porteføljen.
                  </p>
                  <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    NPS indsamles hvert kvartal
                  </div>
                </div>
              </Card>
            )}
          </>
        )}
      </div>
    </Layout>
  );
};

export default Insights;
