import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Search, Eye, Clock, AlertTriangle, Filter } from 'lucide-react';
import { useDDCasesWithProgress, useCreateDDCase, DDStatus } from '@/hooks/useDueDiligence';
import { DDStatusBadge } from '@/components/DDStatusBadge';
import DDCaseCard from '@/components/DDCaseCard';
import { useCompanyData } from '@/hooks/useCompanyData';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { useDDStats } from '@/hooks/useDDStats';
import { useIsMobile } from '@/hooks/use-mobile';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

export default function DueDiligencePipeline() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<DDStatus | 'all'>('all');
  const [showFilters, setShowFilters] = useState(false);
  
  const { data: cases, isLoading } = useDDCasesWithProgress();
  const { data: stats, isLoading: statsLoading } = useDDStats();
  const createCaseMutation = useCreateDDCase();
  const { data: companies } = useQuery({
    queryKey: ['companies-for-dd'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data;
    },
  });

  const filteredCases = cases?.filter(c => {
    const matchesSearch = c.companies?.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <Layout>
      <div className="space-y-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Due Diligence Pipeline
          </h1>
          <p className="text-muted-foreground">
            Oversigt over alle due diligence processer
          </p>
        </div>
        {/* Filters - Collapsible on mobile */}
        <Card className="p-4">
          {isMobile ? (
            <Collapsible open={showFilters} onOpenChange={setShowFilters}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between h-12 tap-safe">
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    <span>Filtre</span>
                  </div>
                  <span className="text-muted-foreground text-sm">
                    {statusFilter !== 'all' ? '1 aktiv' : ''}
                  </span>
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-4 space-y-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Søg efter selskab..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12"
                  />
                </div>
                <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as DDStatus | 'all')}>
                  <SelectTrigger className="w-full h-12">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle statusser</SelectItem>
                    <SelectItem value="not_started">Ikke startet</SelectItem>
                    <SelectItem value="in_progress">I gang</SelectItem>
                    <SelectItem value="pending_review">Afventer gennemgang</SelectItem>
                    <SelectItem value="approved">Godkendt</SelectItem>
                    <SelectItem value="rejected">Afvist</SelectItem>
                  </SelectContent>
                </Select>
              </CollapsibleContent>
            </Collapsible>
          ) : (
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Søg efter selskab..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as DDStatus | 'all')}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle statusser</SelectItem>
                  <SelectItem value="not_started">Ikke startet</SelectItem>
                  <SelectItem value="in_progress">I gang</SelectItem>
                  <SelectItem value="pending_review">Afventer gennemgang</SelectItem>
                  <SelectItem value="approved">Godkendt</SelectItem>
                  <SelectItem value="rejected">Afvist</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </Card>

        {/* Stats Cards - 2 columns on mobile */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          <Card className="p-3 md:p-4">
            <p className="text-xs md:text-sm text-muted-foreground mb-1">Due Diligence</p>
            <p className="text-xs text-muted-foreground mb-1 md:mb-2">Dokument upload</p>
            <p className="text-xl md:text-2xl font-bold">
              {statsLoading ? '...' : stats?.documentUpload || 0}
            </p>
          </Card>
          <Card className="p-3 md:p-4">
            <p className="text-xs md:text-sm text-muted-foreground mb-1">Økonomisk DD</p>
            <div className="flex gap-2 md:gap-3 mt-1 md:mt-2">
              <div>
                <p className="text-xs text-muted-foreground">Afventer</p>
                <p className="text-lg md:text-xl font-bold text-yellow-600">
                  {statsLoading ? '...' : stats?.economicDD.pending || 0}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Godkendt</p>
                <p className="text-lg md:text-xl font-bold text-green-600">
                  {statsLoading ? '...' : stats?.economicDD.approved || 0}
                </p>
              </div>
            </div>
          </Card>
          <Card className="p-3 md:p-4">
            <p className="text-xs md:text-sm text-muted-foreground mb-1">Legal DD</p>
            <div className="flex gap-2 md:gap-3 mt-1 md:mt-2">
              <div>
                <p className="text-xs text-muted-foreground">Afventer</p>
                <p className="text-lg md:text-xl font-bold text-yellow-600">
                  {statsLoading ? '...' : stats?.legalDD.pending || 0}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Godkendt</p>
                <p className="text-lg md:text-xl font-bold text-green-600">
                  {statsLoading ? '...' : stats?.legalDD.approved || 0}
                </p>
              </div>
            </div>
          </Card>
          <Card className="p-3 md:p-4">
            <p className="text-xs md:text-sm text-muted-foreground mb-1">Klar til Signing</p>
            <p className="text-xs text-muted-foreground mb-1 md:mb-2">Begge DD godkendt</p>
            <p className="text-xl md:text-2xl font-bold text-green-600">
              {statsLoading ? '...' : stats?.readyForSigning || 0}
            </p>
          </Card>
        </div>

        {/* Cases - Cards on mobile, Table on desktop */}
        {isMobile ? (
          <div className="space-y-3">
            <h2 className="text-lg font-semibold px-1">Due Diligence Cases</h2>
            {isLoading ? (
              <p className="text-center text-muted-foreground py-8">Indlæser...</p>
            ) : filteredCases && filteredCases.length > 0 ? (
              <div className="space-y-3">
                {filteredCases.map((caseItem) => (
                  <DDCaseCard key={caseItem.id} caseItem={caseItem} />
                ))}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <p className="text-muted-foreground">
                  Ingen due diligence cases fundet
                </p>
              </Card>
            )}
          </div>
        ) : (
          <Card>
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Due Diligence Cases</h2>
              </div>

              {isLoading ? (
                <p className="text-center text-muted-foreground py-8">Indlæser...</p>
              ) : filteredCases && filteredCases.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Selskab</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Fremskridt</TableHead>
                      <TableHead>Deadline</TableHead>
                      <TableHead>Startet</TableHead>
                      <TableHead>Sidst opdateret</TableHead>
                      <TableHead className="text-right">Handling</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredCases.map((caseItem) => (
                      <TableRow key={caseItem.id}>
                        <TableCell className="font-medium">
                          {caseItem.companies?.name}
                        </TableCell>
                        <TableCell>
                          <DDStatusBadge status={caseItem.status} />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-muted rounded-full h-2">
                              <div
                                className={cn(
                                  "rounded-full h-2 transition-all",
                                  caseItem.status === 'approved' && "bg-green-600",
                                  caseItem.status === 'rejected' && "bg-red-600",
                                  caseItem.status === 'in_progress' && "bg-blue-600",
                                  caseItem.status === 'pending_review' && "bg-yellow-600",
                                  caseItem.status === 'not_started' && "bg-gray-400"
                                )}
                                style={{ width: `${caseItem.progressPercentage}%` }}
                              />
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {caseItem.progressPercentage}%
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {caseItem.completedCategories} af {caseItem.totalCategories} kategorier
                          </p>
                        </TableCell>
                        <TableCell>
                          {(() => {
                            if (!caseItem.deadline) return <span className="text-muted-foreground">-</span>;
                            const deadlineDate = new Date(caseItem.deadline);
                            const today = new Date();
                            const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                            const isOverdue = daysUntil < 0;
                            const isNear = daysUntil >= 0 && daysUntil <= 7;
                            return (
                              <div className="flex items-center gap-2">
                                {(isOverdue || isNear) && (
                                  <AlertTriangle className={cn(
                                    "h-4 w-4",
                                    isOverdue ? "text-destructive" : "text-yellow-600"
                                  )} />
                                )}
                                <span className={cn(
                                  isOverdue && "text-destructive font-medium",
                                  isNear && "text-yellow-600 font-medium"
                                )}>
                                  {deadlineDate.toLocaleDateString('da-DK')}
                                </span>
                              </div>
                            );
                          })()}
                        </TableCell>
                        <TableCell>
                          {caseItem.started_at
                            ? new Date(caseItem.started_at).toLocaleDateString('da-DK')
                            : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => navigate(`/portfolio/due-diligence/${caseItem.id}`)}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            Se detaljer
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-center text-muted-foreground py-8">
                  Ingen due diligence cases fundet
                </p>
              )}
            </div>
          </Card>
        )}
      </div>
    </Layout>
  );
}
