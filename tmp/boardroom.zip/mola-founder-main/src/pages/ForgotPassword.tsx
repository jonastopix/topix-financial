import { useState } from 'react';
import { Link, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { z } from 'zod';
import molaLogo from '@/assets/mola-logo.png';
import { ArrowLeft } from 'lucide-react';

const emailSchema = z.object({
  email: z.string().email({ message: "Ugyldig email adresse" }),
});

const ForgotPassword = () => {
  const { user, loading, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState<any>({});
  const [submitted, setSubmitted] = useState(false);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-foreground">Indlæser...</div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      emailSchema.parse({ email });
      const { error } = await resetPassword(email);
      if (!error) {
        setSubmitted(true);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const formattedErrors: any = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0]] = err.message;
          }
        });
        setErrors(formattedErrors);
      }
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border bg-card">
        <CardHeader className="space-y-4">
          <div className="flex justify-center">
            <img 
              src={molaLogo} 
              alt="MOLA" 
              className="h-16 w-auto"
            />
          </div>
          <CardTitle className="text-center">Glemt password</CardTitle>
          <CardDescription className="text-center text-muted-foreground">
            {submitted 
              ? "Vi har sendt dig en email med instruktioner til at nulstille dit password."
              : "Indtast din email adresse, så sender vi dig et link til at nulstille dit password."
            }
          </CardDescription>
        </CardHeader>
        <CardContent>
          {submitted ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Tjek din indbakke og følg linket for at nulstille dit password.
              </p>
              <Link to="/auth">
                <Button variant="outline" className="w-full">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Tilbage til login
                </Button>
              </Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="din@email.dk"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                {errors.email && <p className="text-sm text-destructive">{errors.email}</p>}
              </div>
              <Button type="submit" className="w-full">
                Send nulstillingslink
              </Button>
              <Link to="/auth">
                <Button variant="ghost" className="w-full">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Tilbage til login
                </Button>
              </Link>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ForgotPassword;
