import { useEffect, useMemo, useState } from 'react';
import Layout from '@/components/Layout';
import CompanySelector from '@/components/CompanySelector';
import { supabase } from '@/integrations/supabase/client';
import { useCompanyData } from '@/hooks/useCompanyData';
import { useRole } from '@/contexts/RoleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

type MilestoneStatus = 'backlog' | 'in_progress' | 'blocked' | 'done';

type Milestone = {
  id: string;
  company_id: string;
  title: string;
  description: string | null;
  status: MilestoneStatus;
  due_date: string | null;
  owner: string | null;
  created_at: string;
  updated_at: string;
};

const STATUS_LABEL: Record<MilestoneStatus, string> = {
  backlog: 'Backlog',
  in_progress: 'I gang',
  blocked: 'Blokeret',
  done: 'Done',
};

const STATUS_ORDER: MilestoneStatus[] = ['backlog', 'in_progress', 'blocked', 'done'];

export default function Milestones() {
  const { toast } = useToast();
  const { isAdmin, selectedCompanyId } = useRole();
  const { data: myCompany } = useCompanyData();

  const effectiveCompanyId = useMemo(() => {
    if (isAdmin) return selectedCompanyId;
    return myCompany?.id ?? null;
  }, [isAdmin, selectedCompanyId, myCompany?.id]);

  const [items, setItems] = useState<Milestone[]>([]);
  const [loading, setLoading] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [owner, setOwner] = useState('');
  const [status, setStatus] = useState<MilestoneStatus>('backlog');

  const load = async () => {
    if (!effectiveCompanyId) {
      setItems([]);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('milestones')
        .select('*')
        .eq('company_id', effectiveCompanyId)
        .order('updated_at', { ascending: false });
      if (error) throw error;
      setItems((data as any) || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load().catch(() => {
      toast({ title: 'Kunne ikke hente milestones', variant: 'destructive' });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveCompanyId]);

  const createMilestone = async () => {
    if (!effectiveCompanyId) return;
    if (!title.trim()) {
      toast({ title: 'Titel mangler', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from('milestones').insert({
        company_id: effectiveCompanyId,
        title: title.trim(),
        description: description.trim() || null,
        owner: owner.trim() || null,
        status,
      });
      if (error) throw error;

      setTitle('');
      setDescription('');
      setOwner('');
      setStatus('backlog');

      await load();
      toast({ title: 'Milestone oprettet' });
    } catch (e: any) {
      toast({ title: 'Kunne ikke oprette milestone', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const move = async (id: string, next: MilestoneStatus) => {
    setLoading(true);
    try {
      const { error } = await supabase.from('milestones').update({ status: next }).eq('id', id);
      if (error) throw error;
      await load();
    } catch (e: any) {
      toast({ title: 'Kunne ikke opdatere', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const remove = async (id: string) => {
    setLoading(true);
    try {
      const { error } = await supabase.from('milestones').delete().eq('id', id);
      if (error) throw error;
      await load();
      toast({ title: 'Slettet' });
    } catch (e: any) {
      toast({ title: 'Kunne ikke slette', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const grouped = useMemo(() => {
    const m = new Map<MilestoneStatus, Milestone[]>();
    STATUS_ORDER.forEach((s) => m.set(s, []));
    items.forEach((it) => m.get(it.status)?.push(it));
    return m;
  }, [items]);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Milestones</h1>
            <p className="text-muted-foreground">Hold styr på de få ting, der rykker virksomheden.</p>
          </div>
          {isAdmin && <CompanySelector />}
        </div>

        {!effectiveCompanyId && isAdmin && (
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">
              Vælg et selskab i toppen for at se og oprette milestones.
            </CardContent>
          </Card>
        )}

        {effectiveCompanyId && (
          <Card>
            <CardHeader>
              <CardTitle>Opret milestone</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <Input placeholder="Titel" value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div>
                <Input placeholder="Ansvarlig (valgfri)" value={owner} onChange={(e) => setOwner(e.target.value)} />
              </div>
              <div>
                <Select value={status} onValueChange={(v) => setStatus(v as MilestoneStatus)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUS_ORDER.map((s) => (
                      <SelectItem key={s} value={s}>
                        {STATUS_LABEL[s]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="md:col-span-4">
                <Textarea
                  placeholder="Beskrivelse (valgfri)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div className="md:col-span-4">
                <Button onClick={createMilestone} disabled={loading}>Opret</Button>
              </div>
            </CardContent>
          </Card>
        )}

        {effectiveCompanyId && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            {STATUS_ORDER.map((s) => (
              <Card key={s}>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{STATUS_LABEL[s]}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {(grouped.get(s) || []).length === 0 && (
                    <div className="text-sm text-muted-foreground">Ingen milestones.</div>
                  )}
                  {(grouped.get(s) || []).map((it) => (
                    <div key={it.id} className="rounded-lg border p-3 space-y-2">
                      <div className="text-sm font-medium">{it.title}</div>
                      {it.description && <div className="text-sm text-muted-foreground">{it.description}</div>}
                      <div className="flex items-center justify-between gap-2">
                        <Select value={it.status} onValueChange={(v) => move(it.id, v as MilestoneStatus)}>
                          <SelectTrigger className="h-8">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {STATUS_ORDER.map((x) => (
                              <SelectItem key={x} value={x}>{STATUS_LABEL[x]}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button variant="ghost" size="sm" onClick={() => remove(it.id)}>
                          Slet
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
