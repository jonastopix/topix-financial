import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import { PasswordStrengthMeter } from '@/components/PasswordStrengthMeter';
import { validatePassword } from '@/lib/passwordValidation';

interface InvitationData {
  email: string;
  role: string;
  company_name: string | null;
  fund_name: string | null;
}

const AcceptInvitation = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [invitationData, setInvitationData] = useState<InvitationData | null>(null);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadInvitation();
  }, [token]);

  const loadInvitation = async () => {
    if (!token) {
      setError('Intet invitation token fundet');
      setLoading(false);
      return;
    }

    try {
      console.log('Verifying invitation with token:', token);
      
      // Call verify-invitation edge function (public, no auth required)
      const { data, error } = await supabase.functions.invoke('verify-invitation', {
        body: { token }
      });

      if (error || !data) {
        console.error('Error verifying invitation:', error);
        setError(data?.error || 'Ugyldig invitation');
        setLoading(false);
        return;
      }

      console.log('Invitation verified:', data);

      setInvitationData({
        email: data.email,
        role: data.role,
        company_name: data.company_name,
        fund_name: data.fund_name,
      });

      setLoading(false);
    } catch (err: any) {
      console.error('Error in loadInvitation:', err);
      setError('Kunne ikke indlæse invitation');
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      toast.error('Adgangskoderne matcher ikke');
      return;
    }

    // Validate password strength
    const passwordValidation = validatePassword(password);
    
    // Debug logging
    console.log('Password validation:', {
      password: password,
      hasSpecial: passwordValidation.feedback.hasSpecial,
      hasNumber: passwordValidation.feedback.hasNumber,
      hasUppercase: passwordValidation.feedback.hasUppercase,
      hasLowercase: passwordValidation.feedback.hasLowercase,
      hasMinLength: passwordValidation.feedback.hasMinLength,
      score: passwordValidation.score,
      specialRegexTest: /[@$!%*?&#]/.test(password)
    });
    
    if (passwordValidation.score < 2) {
      toast.error('Adgangskoden er for svag. Vælg en stærkere adgangskode.');
      return;
    }
    
    // Check required character types
    if (!passwordValidation.feedback.hasMinLength) {
      toast.error('Adgangskoden skal være mindst 8 tegn');
      return;
    }
    if (!passwordValidation.feedback.hasUppercase || !passwordValidation.feedback.hasLowercase) {
      toast.error('Adgangskoden skal indeholde både store og små bogstaver');
      return;
    }
    if (!passwordValidation.feedback.hasNumber) {
      toast.error('Adgangskoden skal indeholde mindst ét tal');
      return;
    }
    if (!passwordValidation.feedback.hasSpecial) {
      toast.error('Adgangskoden skal indeholde mindst ét specialtegn (@$!%*?&#)');
      return;
    }

    if (!invitationData) {
      toast.error('Invitation data ikke fundet');
      return;
    }

    setSubmitting(true);

    try {
      console.log('Creating new user with email:', invitationData.email);

      // Create new user via signUp
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: invitationData.email,
        password: password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            invited: true
          }
        }
      });

      if (signUpError) {
        console.error('SignUp error:', signUpError);
        
        // Check if user already exists
        if (signUpError.message?.includes('User already registered') || 
            signUpError.message?.includes('already registered')) {
          toast.error('Du har allerede en konto. Log venligst ind i stedet.');
          setTimeout(() => navigate('/auth'), 2000);
          setSubmitting(false);
          return;
        }
        
        toast.error(`Kunne ikke oprette bruger: ${signUpError.message}`);
        setSubmitting(false);
        return;
      }

      if (!signUpData.user) {
        toast.error('Kunne ikke oprette bruger');
        setSubmitting(false);
        return;
      }

      console.log('User created successfully:', signUpData.user.id);

      // Complete invitation by assigning role and updating profile
      console.log('Completing invitation...');
      const { data: completeData, error: completeError } = await supabase.functions.invoke('complete-invitation', {
        body: { 
          token,
          user_id: signUpData.user.id 
        }
      });

      if (completeError || !completeData?.success) {
        console.error('Error completing invitation:', completeError);
        toast.error(completeData?.error || 'Kunne ikke færdiggøre invitation');
        setSubmitting(false);
        return;
      }

      console.log('Invitation completed successfully');
      toast.success('Din konto er blevet aktiveret!');

      // Redirect to root - Dashboard handles role-based routing automatically
      setTimeout(() => {
        navigate('/');
      }, 1500);

    } catch (err: any) {
      console.error('Error in handleSubmit:', err);
      toast.error('Der opstod en fejl under aktiveringen af din konto');
      setSubmitting(false);
    }
  };

  const getRoleName = (role: string): string => {
    const roleNames: Record<string, string> = {
      'founder': 'Founder',
      'investor': 'Investor',
      'fund_partner': 'Fund Partner',
      'mola_admin': 'MOLA Administrator',
      'owner': 'Ejer'
    };
    return roleNames[role] || role;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-destructive">Fejl</CardTitle>
            <CardDescription>{error}</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/auth')} className="w-full">
              Gå til login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Velkommen til MOLA Portal</CardTitle>
          <CardDescription>
            Opret din adgangskode for at aktivere din konto
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                value={invitationData?.email || ''}
                disabled
                className="bg-muted"
              />
            </div>

            <div className="space-y-2">
              <Label>Rolle</Label>
              <Input
                type="text"
                value={invitationData ? getRoleName(invitationData.role) : ''}
                disabled
                className="bg-muted"
              />
            </div>

            {invitationData?.company_name && (
              <div className="space-y-2">
                <Label>Virksomhed</Label>
                <Input
                  type="text"
                  value={invitationData.company_name}
                  disabled
                  className="bg-muted"
                />
              </div>
            )}

            {invitationData?.fund_name && (
              <div className="space-y-2">
                <Label>Fond</Label>
                <Input
                  type="text"
                  value={invitationData.fund_name}
                  disabled
                  className="bg-muted"
                />
              </div>
            )}

            <div className="border-t pt-4 mt-4">
              <h3 className="text-sm font-semibold mb-4">Opret din adgangskode</h3>
              
              <div className="space-y-2 mb-4">
                <Label htmlFor="password">Adgangskode</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => {
                    const newPassword = e.target.value;
                    console.log('Password onChange:', {
                      value: newPassword,
                      length: newPassword.length,
                      hasSpecialChar: /[@$!%*?&#]/.test(newPassword)
                    });
                    setPassword(newPassword);
                  }}
                  required
                  minLength={8}
                  autoComplete="new-password"
                />
                <PasswordStrengthMeter password={password} />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Bekræft adgangskode</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={8}
                  autoComplete="new-password"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={submitting}
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Aktiverer konto...
                </>
              ) : (
                'Aktiver konto'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AcceptInvitation;
