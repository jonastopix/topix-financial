import { useState } from "react";
import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  useFooterSettings, 
  useFooterLinks,
  useUpdateFooterSetting,
  useCreateFooterLink,
  useUpdateFooterLink,
  useDeleteFooterLink,
  FooterLink
} from "@/hooks/useFooterSettings";
import { Loader2, Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import * as LucideIcons from "lucide-react";

export default function FooterSettings() {
  const { data: settings, isLoading: settingsLoading } = useFooterSettings();
  const { data: navLinks } = useFooterLinks("navigation");
  const { data: resourceLinks } = useFooterLinks("resources");
  const { data: legalLinks } = useFooterLinks("legal");
  
  const updateSetting = useUpdateFooterSetting();
  const createLink = useCreateFooterLink();
  const updateLink = useUpdateFooterLink();
  const deleteLink = useDeleteFooterLink();

  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [linkToDelete, setLinkToDelete] = useState<string | null>(null);
  const [newLink, setNewLink] = useState<Partial<FooterLink>>({
    category: "navigation",
    title: "",
    url: "",
    icon_name: "",
    is_active: true,
    is_external: false,
    sort_order: 0,
  });

  const aboutSetting = settings?.find(s => s.section_key === "about");
  const contactSetting = settings?.find(s => s.section_key === "contact");
  const newsletterSetting = settings?.find(s => s.section_key === "newsletter");
  const ctaSetting = settings?.find(s => s.section_key === "cta");
  const copyrightSetting = settings?.find(s => s.section_key === "copyright");

  const handleUpdateAbout = (updates: any) => {
    if (!aboutSetting) return;
    updateSetting.mutate({
      id: aboutSetting.id,
      updates: {
        content: { ...aboutSetting.content, ...updates },
      },
    });
  };

  const handleUpdateContact = (updates: any) => {
    if (!contactSetting) return;
    updateSetting.mutate({
      id: contactSetting.id,
      updates: {
        content: { ...contactSetting.content, ...updates },
      },
    });
  };

  const handleUpdateNewsletter = (updates: any) => {
    if (!newsletterSetting) return;
    updateSetting.mutate({
      id: newsletterSetting.id,
      updates: {
        content: { ...newsletterSetting.content, ...updates },
      },
    });
  };

  const handleUpdateCta = (updates: any) => {
    if (!ctaSetting) return;
    updateSetting.mutate({
      id: ctaSetting.id,
      updates: {
        content: { ...ctaSetting.content, ...updates },
      },
    });
  };

  const handleUpdateCopyright = (text: string) => {
    if (!copyrightSetting) return;
    updateSetting.mutate({
      id: copyrightSetting.id,
      updates: {
        content: { text },
      },
    });
  };

  const handleCreateLink = () => {
    if (!newLink.title || !newLink.url || !newLink.category) return;
    
    const maxSortOrder = 
      newLink.category === "navigation" ? Math.max(0, ...(navLinks?.map(l => l.sort_order) || [])) :
      newLink.category === "resources" ? Math.max(0, ...(resourceLinks?.map(l => l.sort_order) || [])) :
      Math.max(0, ...(legalLinks?.map(l => l.sort_order) || []));

    createLink.mutate({
      ...newLink as Omit<FooterLink, "id" | "created_at" | "updated_at">,
      sort_order: maxSortOrder + 1,
    });

    setNewLink({
      category: newLink.category,
      title: "",
      url: "",
      icon_name: "",
      is_active: true,
      is_external: false,
      sort_order: 0,
    });
  };

  const handleMoveLink = (link: FooterLink, direction: "up" | "down") => {
    const links = 
      link.category === "navigation" ? navLinks :
      link.category === "resources" ? resourceLinks :
      legalLinks;

    if (!links) return;

    const currentIndex = links.findIndex(l => l.id === link.id);
    const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1;

    if (targetIndex < 0 || targetIndex >= links.length) return;

    const targetLink = links[targetIndex];

    updateLink.mutate({
      id: link.id,
      updates: { sort_order: targetLink.sort_order },
    });

    updateLink.mutate({
      id: targetLink.id,
      updates: { sort_order: link.sort_order },
    });
  };

  const handleDeleteLink = (id: string) => {
    setLinkToDelete(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (linkToDelete) {
      deleteLink.mutate(linkToDelete);
      setLinkToDelete(null);
      setDeleteDialogOpen(false);
    }
  };

  if (settingsLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  const iconOptions = Object.keys(LucideIcons).filter(
    key => typeof LucideIcons[key as keyof typeof LucideIcons] === "function"
  ).slice(0, 50);

  return (
    <Layout>
      <div className="space-y-8 max-w-full">
        <div>
          <h1 className="text-3xl font-bold mb-2">Footer Indstillinger</h1>
          <p className="text-muted-foreground">
            Administrer indholdet i sidens footer
          </p>
        </div>

        <Tabs defaultValue="about" className="space-y-6">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="about">Om</TabsTrigger>
            <TabsTrigger value="contact">Kontakt</TabsTrigger>
            <TabsTrigger value="navigation">Navigation</TabsTrigger>
            <TabsTrigger value="resources">Ressourcer</TabsTrigger>
            <TabsTrigger value="legal">Juridisk</TabsTrigger>
            <TabsTrigger value="newsletter">Nyhedsbrev</TabsTrigger>
            <TabsTrigger value="cta">CTA</TabsTrigger>
          </TabsList>

          {/* About Tab */}
          <TabsContent value="about">
            <Card>
              <CardHeader>
                <CardTitle>Om MOLA</CardTitle>
                <CardDescription>Rediger beskrivelse og sociale medier links</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="about-description">Beskrivelse</Label>
                  <Textarea
                    id="about-description"
                    value={aboutSetting?.content?.description || ""}
                    onChange={(e) => handleUpdateAbout({ description: e.target.value })}
                    rows={4}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Sociale Medier Links</h3>
                  {aboutSetting?.content?.social_links?.map((social: any, index: number) => (
                    <div key={social.platform} className="space-y-2">
                      <Label htmlFor={`social-${social.platform}`}>
                        {social.platform.charAt(0).toUpperCase() + social.platform.slice(1)} URL
                      </Label>
                      <Input
                        id={`social-${social.platform}`}
                        value={social.url}
                        onChange={(e) => {
                          const newSocialLinks = [...aboutSetting.content.social_links];
                          newSocialLinks[index] = { ...social, url: e.target.value };
                          handleUpdateAbout({ social_links: newSocialLinks });
                        }}
                        placeholder={`https://...`}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contact Tab */}
          <TabsContent value="contact">
            <Card>
              <CardHeader>
                <CardTitle>Kontakt Information</CardTitle>
                <CardDescription>Rediger kontaktoplysninger</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="contact-email">Email</Label>
                  <Input
                    id="contact-email"
                    type="email"
                    value={contactSetting?.content?.email || ""}
                    onChange={(e) => handleUpdateContact({ email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-phone">Telefon</Label>
                  <Input
                    id="contact-phone"
                    value={contactSetting?.content?.phone || ""}
                    onChange={(e) => handleUpdateContact({ phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contact-address">Adresse</Label>
                  <Input
                    id="contact-address"
                    value={contactSetting?.content?.address || ""}
                    onChange={(e) => handleUpdateContact({ address: e.target.value })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Navigation Tab */}
          <TabsContent value="navigation">
            <Card>
              <CardHeader>
                <CardTitle>Navigation Links</CardTitle>
                <CardDescription>Administrer navigation links i footer</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Tilføj Nyt Link</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Titel</Label>
                      <Input
                        value={newLink.title}
                        onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>URL</Label>
                      <Input
                        value={newLink.url}
                        onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Ikon</Label>
                      <Select
                        value={newLink.icon_name}
                        onValueChange={(value) => setNewLink({ ...newLink, icon_name: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Vælg ikon" />
                        </SelectTrigger>
                        <SelectContent>
                          {iconOptions.map((icon) => (
                            <SelectItem key={icon} value={icon}>
                              {icon}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button onClick={handleCreateLink} className="w-full">
                        <Plus className="h-4 w-4 mr-2" />
                        Tilføj Link
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Eksisterende Links</h3>
                  {navLinks?.map((link, index) => (
                    <div key={link.id} className="flex flex-col gap-3 p-3 border rounded-lg">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Titel</Label>
                          <Input
                            value={link.title}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { title: e.target.value } })
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">URL</Label>
                          <Input
                            value={link.url}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { url: e.target.value } })
                            }
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm">Aktiv</Label>
                          <Switch
                            checked={link.is_active}
                            onCheckedChange={(checked) =>
                              updateLink.mutate({ id: link.id, updates: { is_active: checked } })
                            }
                          />
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "up")}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "down")}
                            disabled={index === (navLinks?.length || 0) - 1}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteLink(link.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resources Tab */}
          <TabsContent value="resources">
            <Card>
              <CardHeader>
                <CardTitle>Ressource Links</CardTitle>
                <CardDescription>Administrer ressource links i footer</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Tilføj Nyt Link</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Titel</Label>
                      <Input
                        value={newLink.category === "resources" ? newLink.title : ""}
                        onChange={(e) => setNewLink({ ...newLink, category: "resources", title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>URL</Label>
                      <Input
                        value={newLink.category === "resources" ? newLink.url : ""}
                        onChange={(e) => setNewLink({ ...newLink, category: "resources", url: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Ikon</Label>
                      <Select
                        value={newLink.category === "resources" ? newLink.icon_name : ""}
                        onValueChange={(value) => setNewLink({ ...newLink, category: "resources", icon_name: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Vælg ikon" />
                        </SelectTrigger>
                        <SelectContent>
                          {iconOptions.map((icon) => (
                            <SelectItem key={icon} value={icon}>
                              {icon}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button onClick={handleCreateLink} className="w-full">
                        <Plus className="h-4 w-4 mr-2" />
                        Tilføj Link
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Eksisterende Links</h3>
                  {resourceLinks?.map((link, index) => (
                    <div key={link.id} className="flex flex-col gap-3 p-3 border rounded-lg">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Titel</Label>
                          <Input
                            value={link.title}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { title: e.target.value } })
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">URL</Label>
                          <Input
                            value={link.url}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { url: e.target.value } })
                            }
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm">Aktiv</Label>
                          <Switch
                            checked={link.is_active}
                            onCheckedChange={(checked) =>
                              updateLink.mutate({ id: link.id, updates: { is_active: checked } })
                            }
                          />
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "up")}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "down")}
                            disabled={index === (resourceLinks?.length || 0) - 1}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteLink(link.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Legal Tab */}
          <TabsContent value="legal">
            <Card>
              <CardHeader>
                <CardTitle>Juridiske Links</CardTitle>
                <CardDescription>Administrer juridiske links i footer</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Tilføj Nyt Link</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Titel</Label>
                      <Input
                        value={newLink.category === "legal" ? newLink.title : ""}
                        onChange={(e) => setNewLink({ ...newLink, category: "legal", title: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>URL</Label>
                      <Input
                        value={newLink.category === "legal" ? newLink.url : ""}
                        onChange={(e) => setNewLink({ ...newLink, category: "legal", url: e.target.value })}
                      />
                    </div>
                    <div className="flex items-end col-span-2">
                      <Button onClick={handleCreateLink} className="w-full">
                        <Plus className="h-4 w-4 mr-2" />
                        Tilføj Link
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-semibold">Eksisterende Links</h3>
                  {legalLinks?.map((link, index) => (
                    <div key={link.id} className="flex flex-col gap-3 p-3 border rounded-lg">
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Titel</Label>
                          <Input
                            value={link.title}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { title: e.target.value } })
                            }
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">URL</Label>
                          <Input
                            value={link.url}
                            onChange={(e) =>
                              updateLink.mutate({ id: link.id, updates: { url: e.target.value } })
                            }
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm">Aktiv</Label>
                          <Switch
                            checked={link.is_active}
                            onCheckedChange={(checked) =>
                              updateLink.mutate({ id: link.id, updates: { is_active: checked } })
                            }
                          />
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "up")}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleMoveLink(link, "down")}
                            disabled={index === (legalLinks?.length || 0) - 1}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDeleteLink(link.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Newsletter Tab */}
          <TabsContent value="newsletter">
            <Card>
              <CardHeader>
                <CardTitle>Nyhedsbrev Sektion</CardTitle>
                <CardDescription>Rediger nyhedsbrev indhold</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="newsletter-active">Aktiv</Label>
                  <Switch
                    id="newsletter-active"
                    checked={newsletterSetting?.is_active}
                    onCheckedChange={(checked) => {
                      if (newsletterSetting) {
                        updateSetting.mutate({
                          id: newsletterSetting.id,
                          updates: { is_active: checked },
                        });
                      }
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newsletter-title">Titel</Label>
                  <Input
                    id="newsletter-title"
                    value={newsletterSetting?.content?.title || ""}
                    onChange={(e) => handleUpdateNewsletter({ title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newsletter-description">Beskrivelse</Label>
                  <Textarea
                    id="newsletter-description"
                    value={newsletterSetting?.content?.description || ""}
                    onChange={(e) => handleUpdateNewsletter({ description: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="newsletter-placeholder">Email Placeholder</Label>
                  <Input
                    id="newsletter-placeholder"
                    value={newsletterSetting?.content?.placeholder || ""}
                    onChange={(e) => handleUpdateNewsletter({ placeholder: e.target.value })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* CTA Tab */}
          <TabsContent value="cta">
            <Card>
              <CardHeader>
                <CardTitle>Call-to-Action Sektion</CardTitle>
                <CardDescription>Rediger CTA indhold</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="cta-active">Aktiv</Label>
                  <Switch
                    id="cta-active"
                    checked={ctaSetting?.is_active}
                    onCheckedChange={(checked) => {
                      if (ctaSetting) {
                        updateSetting.mutate({
                          id: ctaSetting.id,
                          updates: { is_active: checked },
                        });
                      }
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cta-title">Titel</Label>
                  <Input
                    id="cta-title"
                    value={ctaSetting?.content?.title || ""}
                    onChange={(e) => handleUpdateCta({ title: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cta-description">Beskrivelse</Label>
                  <Textarea
                    id="cta-description"
                    value={ctaSetting?.content?.description || ""}
                    onChange={(e) => handleUpdateCta({ description: e.target.value })}
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Copyright</CardTitle>
                <CardDescription>Brug {"{year}"} for automatisk årstal</CardDescription>
              </CardHeader>
              <CardContent>
                <Input
                  value={copyrightSetting?.content?.text || ""}
                  onChange={(e) => handleUpdateCopyright(e.target.value)}
                  placeholder="© {year} MOLA. Alle rettigheder forbeholdes."
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil permanent slette linket. Handlingen kan ikke fortrydes.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Slet</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
