import { useEffect, useMemo, useState } from 'react';
import Layout from '@/components/Layout';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';

type Company = { id: string; name: string };

type ReportRow = {
  id: string;
  company_id: string;
  period_month: number;
  period_year: number;
  status: string;
  submitted_at: string | null;
};

function ymToLabel(year: number, month: number) {
  return `${year}-${String(month).padStart(2, '0')}`;
}

export default function AdminReporting() {
  const { toast } = useToast();
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const { data: c, error: cErr } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      if (cErr) throw cErr;

      const { data: r, error: rErr } = await supabase
        .from('monthly_reports')
        .select('id, company_id, period_month, period_year, status, submitted_at')
        .eq('period_year', year)
        .eq('period_month', month);
      if (rErr) throw rErr;

      setCompanies((c as any) || []);
      setReports((r as any) || []);
    } catch (e: any) {
      toast({ title: 'Kunne ikke hente data', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month]);

  const byCompany = useMemo(() => {
    const m = new Map<string, ReportRow>();
    reports.forEach((r) => m.set(r.company_id, r));
    return m;
  }, [reports]);

  const stats = useMemo(() => {
    const total = companies.length;
    const submitted = companies.filter((c) => {
      const r = byCompany.get(c.id);
      return r && r.status !== 'draft';
    }).length;
    return { total, submitted, missing: Math.max(0, total - submitted) };
  }, [companies, byCompany]);

  const years = Array.from({ length: 5 }).map((_, i) => now.getFullYear() - i);
  const months = Array.from({ length: 12 }).map((_, i) => i + 1);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Admin: Rapport-overblik</h1>
            <p className="text-muted-foreground">Hvem har indsendt, og hvem mangler.</p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={String(year)} onValueChange={(v) => setYear(Number(v))}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="År" />
              </SelectTrigger>
              <SelectContent>
                {years.map((y) => (
                  <SelectItem key={y} value={String(y)}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Måned" />
              </SelectTrigger>
              <SelectContent>
                {months.map((m) => (
                  <SelectItem key={m} value={String(m)}>
                    {String(m).padStart(2, '0')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button variant="outline" onClick={load} disabled={loading}>
              Opdatér
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Periode</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-semibold">{ymToLabel(year, month)}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Indsendt</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-semibold">{stats.submitted} / {stats.total}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Mangler</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-semibold">{stats.missing}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Virksomheder</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Virksomhed</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Indsendt</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {companies.map((c) => {
                  const r = byCompany.get(c.id);
                  const status = r?.status ?? 'missing';
                  const submittedAt = r?.submitted_at;

                  return (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell>
                        {status === 'missing' && <Badge variant="destructive">Mangler</Badge>}
                        {status === 'draft' && <Badge variant="secondary">Kladde</Badge>}
                        {status === 'submitted' && <Badge>Indsendt</Badge>}
                        {status === 'reviewed' && <Badge variant="outline">Gennemgået</Badge>}
                        {![ 'missing','draft','submitted','reviewed' ].includes(status) && (
                          <Badge variant="secondary">{status}</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {submittedAt ? new Date(submittedAt).toLocaleString('da-DK') : '—'}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
