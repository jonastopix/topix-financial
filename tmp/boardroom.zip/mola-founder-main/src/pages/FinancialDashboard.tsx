import { useState, useMemo } from 'react';
import Layout from '@/components/Layout';
import { useCompanyData, useMonthlyReports } from '@/hooks/useCompanyData';
import { usePortfolioFinancials } from '@/hooks/usePortfolioFinancials';
import { YTDPerformanceSection } from '@/components/YTDPerformanceSection';
import { ForecastSection } from '@/components/ForecastSection';
import { FinancialAnalysisSection } from '@/components/FinancialAnalysisSection';
import { ShippingBenchmarkCard } from '@/components/ShippingBenchmarkCard';
import { PortfolioFinancialOverview } from '@/components/PortfolioFinancialOverview';
import { PeriodSelector, PeriodType } from '@/components/PeriodSelector';
import { HistoricalTrendChart } from '@/components/HistoricalTrendChart';
import {
  calculateYTDPerformance, 
  calculateForecast, 
  calculateFinancialAnalysis,
  calculateLast12Months,
  calculateCustomPeriod,
  calculateMonthlyForecast
} from '@/lib/metricsCalculations';
import { Skeleton } from '@/components/ui/skeleton';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const FinancialDashboard = () => {
  const navigate = useNavigate();
  const { data: company, isLoading: companyLoading } = useCompanyData();
  const { data: reports, isLoading: reportsLoading } = useMonthlyReports(company?.id);
  const [selectedYear] = useState(new Date().getFullYear());
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodType>('ytd');
  const [customStartDate, setCustomStartDate] = useState<Date | undefined>();
  const [customEndDate, setCustomEndDate] = useState<Date | undefined>();

  // Portfolio data when no company is selected
  const { data: portfolioData, isLoading: portfolioLoading } = usePortfolioFinancials(selectedYear);

  const isLoading = company === undefined ? (companyLoading || portfolioLoading) : (companyLoading || reportsLoading);

  // Calculate metrics based on selected period (must be before any returns)
  const periodData = useMemo(() => {
    if (!reports || reports.length === 0) {
      return {
        ytdRevenue: 0,
        ytdEBITDA: 0,
        budgetYTDRevenue: 0,
        budgetYTDEBITDA: 0,
        revenueVsBudgetPct: 0,
        ebitdaVsBudgetPct: 0,
        ebitdaMarginYTD: 0,
        marketingPctYTD: 0,
        revenueROI: 0,
        ebitdaROI: 0,
        isOnTarget: false,
        reportedMonths: 0,
      };
    }
    if (selectedPeriod === 'ytd') {
      const ytdPerf = calculateYTDPerformance(reports, selectedYear);
      return {
        ytdRevenue: ytdPerf.ytdRevenue,
        ytdEBITDA: ytdPerf.ytdEBITDA,
        budgetYTDRevenue: ytdPerf.budgetYTDRevenue,
        budgetYTDEBITDA: ytdPerf.budgetYTDEBITDA,
        revenueVsBudgetPct: ytdPerf.revenueVsBudgetPct,
        ebitdaVsBudgetPct: ytdPerf.ebitdaVsBudgetPct,
        ebitdaMarginYTD: ytdPerf.ebitdaMarginYTD,
        marketingPctYTD: ytdPerf.marketingPctYTD,
        revenueROI: ytdPerf.revenueROI,
        ebitdaROI: ytdPerf.ebitdaROI,
        isOnTarget: ytdPerf.isOnTarget,
        reportedMonths: ytdPerf.reportedMonths,
      };
    } else if (selectedPeriod === 'last12') {
      const last12 = calculateLast12Months(reports);
      return {
        ytdRevenue: last12.totalRevenue,
        ytdEBITDA: last12.totalEBITDA,
        budgetYTDRevenue: last12.budgetRevenue,
        budgetYTDEBITDA: last12.budgetEBITDA,
        revenueVsBudgetPct: last12.revenueVsBudgetPct,
        ebitdaVsBudgetPct: last12.ebitdaVsBudgetPct,
        ebitdaMarginYTD: last12.ebitdaMargin,
        marketingPctYTD: last12.marketingPct,
        revenueROI: last12.revenueROI,
        ebitdaROI: last12.ebitdaROI,
        isOnTarget: last12.totalRevenue >= last12.budgetRevenue && last12.totalEBITDA >= last12.budgetEBITDA,
        reportedMonths: last12.reportedMonths,
      };
    } else if (selectedPeriod === 'custom' && customStartDate && customEndDate) {
      const custom = calculateCustomPeriod(reports, customStartDate, customEndDate);
      return {
        ytdRevenue: custom.totalRevenue,
        ytdEBITDA: custom.totalEBITDA,
        budgetYTDRevenue: custom.budgetRevenue,
        budgetYTDEBITDA: custom.budgetEBITDA,
        revenueVsBudgetPct: custom.revenueVsBudgetPct,
        ebitdaVsBudgetPct: custom.ebitdaVsBudgetPct,
        ebitdaMarginYTD: custom.ebitdaMargin,
        marketingPctYTD: custom.marketingPct,
        revenueROI: custom.revenueROI,
        ebitdaROI: custom.ebitdaROI,
        isOnTarget: custom.totalRevenue >= custom.budgetRevenue && custom.totalEBITDA >= custom.budgetEBITDA,
        reportedMonths: custom.reportedMonths,
      };
    }
    
    // Fallback to YTD
    const ytdPerf = calculateYTDPerformance(reports, selectedYear);
    return {
      ytdRevenue: ytdPerf.ytdRevenue,
      ytdEBITDA: ytdPerf.ytdEBITDA,
      budgetYTDRevenue: ytdPerf.budgetYTDRevenue,
      budgetYTDEBITDA: ytdPerf.budgetYTDEBITDA,
      revenueVsBudgetPct: ytdPerf.revenueVsBudgetPct,
      ebitdaVsBudgetPct: ytdPerf.ebitdaVsBudgetPct,
      ebitdaMarginYTD: ytdPerf.ebitdaMarginYTD,
      marketingPctYTD: ytdPerf.marketingPctYTD,
      revenueROI: ytdPerf.revenueROI,
      ebitdaROI: ytdPerf.ebitdaROI,
      isOnTarget: ytdPerf.isOnTarget,
      reportedMonths: ytdPerf.reportedMonths,
    };
  }, [reports, selectedYear, selectedPeriod, customStartDate, customEndDate]);

  const forecast = useMemo(() => {
    if (!reports || reports.length === 0) {
      return {
        reportedMonths: 0,
        avgMonthRevenue: 0,
        avgMonthEBITDA: 0,
        projectedRevenue: 0,
        projectedEBITDA: 0,
        projectedVsBudgetRevenuePct: 0,
        projectedVsBudgetEBITDAPct: 0,
        fullYearBudgetRevenue: 0,
        fullYearBudgetEBITDA: 0,
        confidenceLevel: 'low' as const,
        method: 'insufficient-data' as const,
        bestCaseRevenue: 0,
        worstCaseRevenue: 0,
        bestCaseEBITDA: 0,
        worstCaseEBITDA: 0,
      };
    }
    return calculateForecast(reports, selectedYear);
  }, [reports, selectedYear]);

  const financialAnalysis = useMemo(() => {
    if (!reports || reports.length === 0 || !company) {
      return {
        investmentMultipleRevenue: 0,
        avgMonthRevenue: 0,
        marketingEfficiency: 0,
        profitabilityPct: 0,
      };
    }
    return calculateFinancialAnalysis(
      reports, 
      selectedYear, 
      company.invested_amount_dkk ? Number(company.invested_amount_dkk) : undefined
    );
  }, [reports, selectedYear, company]);

  const getPeriodLabel = () => {
    if (selectedPeriod === 'ytd') return `YTD ${selectedYear}`;
    if (selectedPeriod === 'last12') return 'Sidste 12 måneder';
    if (selectedPeriod === 'custom' && customStartDate && customEndDate) {
      return `Custom periode`;
    }
    return 'Vælg periode';
  };

  // Filter reports based on selected period for trend chart
  const filteredReports = useMemo(() => {
    if (!reports || reports.length === 0) return [];
    
    if (selectedPeriod === 'ytd') {
      return reports.filter(r => r.period_year === selectedYear);
    } else if (selectedPeriod === 'last12') {
      const sortedReports = [...reports].sort((a, b) => {
        if (b.period_year !== a.period_year) return b.period_year - a.period_year;
        return b.period_month - a.period_month;
      });
      return sortedReports.slice(0, 12);
    } else if (selectedPeriod === 'custom' && customStartDate && customEndDate) {
      return reports.filter(r => {
        const reportDate = new Date(r.period_year, r.period_month - 1);
        return reportDate >= customStartDate && reportDate <= customEndDate;
      });
    }
    return reports.filter(r => r.period_year === selectedYear);
  }, [reports, selectedPeriod, selectedYear, customStartDate, customEndDate]);

  // Calculate monthly forecast for chart visualization (only for YTD period)
  const monthlyForecast = useMemo(() => {
    if (!reports || reports.length === 0 || selectedPeriod !== 'ytd') return [];
    return calculateMonthlyForecast(reports, selectedYear);
  }, [reports, selectedYear, selectedPeriod]);

  // Early returns AFTER all hooks
  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 space-y-8">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </Layout>
    );
  }

  // Show portfolio view when no company is selected
  if (!company && portfolioData) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 space-y-8">
          <PortfolioFinancialOverview 
            data={portfolioData.portfolioTotals}
            companies={portfolioData.companies}
            monthlyTrend={portfolioData.monthlyTrend}
            year={selectedYear}
          />
        </div>
      </Layout>
    );
  }

  // If no company and no portfolio data
  if (!company) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <Card className="p-6">
            <p className="text-center text-muted-foreground">
              Ingen selskaber fundet i portfolio.
            </p>
          </Card>
        </div>
      </Layout>
    );
  }

  if (!reports || reports.length === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <Card className="p-12 text-center">
            <FileText className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold mb-2">Ingen månedlige rapporter endnu</h2>
            <p className="text-muted-foreground mb-6">
              Upload din første månedlige rapport for at se YTD performance, forecast og finansiel analyse.
            </p>
            <Button onClick={() => navigate('/monthly-report')}>
              Upload Monthly Report
            </Button>
          </Card>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 pb-24 md:pb-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">Finansiel Dashboard</h1>
          <p className="text-muted-foreground">
            Oversigt over {company.name}'s performance og forecast
          </p>
        </div>

        <PeriodSelector
          selectedPeriod={selectedPeriod}
          onPeriodChange={setSelectedPeriod}
          customStartDate={customStartDate}
          customEndDate={customEndDate}
          onCustomStartDateChange={setCustomStartDate}
          onCustomEndDateChange={setCustomEndDate}
          currentYear={selectedYear}
        />

        {selectedPeriod === 'custom' && (!customStartDate || !customEndDate) ? (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">
              Vælg venligst start- og slutdato for at se data
            </p>
          </Card>
        ) : (
          <>
            <YTDPerformanceSection data={periodData} year={selectedYear} periodLabel={getPeriodLabel()} />
            
            <HistoricalTrendChart 
              reports={filteredReports}
              forecastReports={monthlyForecast}
              title={`Historisk Trend - ${getPeriodLabel()}`}
            />
            
            <ForecastSection data={forecast} year={selectedYear} />
            
            <FinancialAnalysisSection data={financialAnalysis} />
            
            <ShippingBenchmarkCard companyId={company.id} />
          </>
        )}
      </div>
    </Layout>
  );
};

export default FinancialDashboard;
