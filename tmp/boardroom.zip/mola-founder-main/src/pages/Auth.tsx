import { useState } from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { loginSchema, signupSchema } from '@/lib/authSchemas';
import { PasswordStrengthMeter } from '@/components/PasswordStrengthMeter';
import { PasswordPolicyTooltip } from '@/components/PasswordPolicyTooltip';
import { isCommonPassword } from '@/lib/passwordValidation';
import { z } from 'zod';
import molaLogo from '@/assets/mola-logo.png';

const Auth = () => {
  const { user, loading, signIn, signUp } = useAuth();
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [signupData, setSignupData] = useState({ email: '', password: '', confirmPassword: '' });
  const [loginErrors, setLoginErrors] = useState<any>({});
  const [signupErrors, setSignupErrors] = useState<any>({});
  const [isPasswordValid, setIsPasswordValid] = useState(false);
  const [isPasswordLeaked, setIsPasswordLeaked] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          <div className="text-foreground text-sm">Indlæser...</div>
        </div>
      </div>
    );
  }

  if (user) {
    return <Navigate to="/" replace />;
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Guard mod dobbelt-klik
    if (isSubmitting) return;
    
    setLoginErrors({});
    setIsSubmitting(true);

    // Timeout efter 15 sekunder - nulstil knappen hvis login hænger
    const timeoutId = setTimeout(() => {
      setIsSubmitting(false);
      setLoginErrors({ general: 'Login tog for lang tid. Prøv igen.' });
    }, 15000);

    try {
      loginSchema.parse(loginData);
      const { error } = await signIn(loginData.email, loginData.password);
      
      clearTimeout(timeoutId);
      
      // Kun nulstil isSubmitting ved fejl - ved succes håndterer onAuthStateChange redirect
      if (error) {
        setIsSubmitting(false);
      }
    } catch (error) {
      clearTimeout(timeoutId);
      setIsSubmitting(false);
      
      if (error instanceof z.ZodError) {
        const formattedErrors: any = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0]] = err.message;
          }
        });
        setLoginErrors(formattedErrors);
      }
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupErrors({});

    // Check if password is common
    if (isCommonPassword(signupData.password)) {
      setSignupErrors({ password: 'Dette password er for almindeligt. Vælg et stærkere password.' });
      return;
    }

    // Check if password is leaked
    if (isPasswordLeaked) {
      setSignupErrors({ password: 'Dette password er fundet i et data-læk. Vælg et andet password.' });
      return;
    }

    // Check if password validation passed
    if (!isPasswordValid) {
      setSignupErrors({ password: 'Password opfylder ikke alle sikkerhedskrav' });
      return;
    }

    setIsSubmitting(true);

    try {
      signupSchema.parse(signupData);
      // signUp requires fullName and companyName - using email as placeholder for now
      await signUp(signupData.email, signupData.password, '', '');
    } catch (error) {
      if (error instanceof z.ZodError) {
        const formattedErrors: any = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0]] = err.message;
          }
        });
        setSignupErrors(formattedErrors);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordValidationChange = (isValid: boolean, isLeaked: boolean) => {
    setIsPasswordValid(isValid);
    setIsPasswordLeaked(isLeaked);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border bg-card">
        <CardHeader className="space-y-4">
          <div className="flex justify-center">
            <img 
              src={molaLogo} 
              alt="MOLA" 
              className="h-16 w-auto"
            />
          </div>
          <CardDescription className="text-center text-muted-foreground">
            Log ind eller opret en konto
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Log ind</TabsTrigger>
              <TabsTrigger value="signup">Opret konto</TabsTrigger>
            </TabsList>

            {/* Login Tab */}
            <TabsContent value="login">
              <form onSubmit={handleLogin} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    type="email"
                    placeholder="din@email.dk"
                    value={loginData.email}
                    onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                    className="h-12 text-base"
                  />
                  {loginErrors.email && <p className="text-sm text-destructive">{loginErrors.email}</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password">Password</Label>
                  <Input
                    id="login-password"
                    type="password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    className="h-12 text-base"
                  />
                {loginErrors.password && <p className="text-sm text-destructive">{loginErrors.password}</p>}
                </div>
                {loginErrors.general && (
                  <p className="text-sm text-destructive text-center">{loginErrors.general}</p>
                )}
                <Button type="submit" className="w-full h-12 text-base" disabled={isSubmitting}>
                  {isSubmitting ? 'Logger ind...' : 'Log ind'}
                </Button>
                <div className="text-center">
                  <Link to="/forgot-password" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    Glemt password?
                  </Link>
                </div>
              </form>
            </TabsContent>

            {/* Signup Tab */}
            <TabsContent value="signup">
              <form onSubmit={handleSignup} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    type="email"
                    placeholder="din@email.dk"
                    value={signupData.email}
                    onChange={(e) => setSignupData({ ...signupData, email: e.target.value })}
                    className="h-12 text-base"
                  />
                  {signupErrors.email && <p className="text-sm text-destructive">{signupErrors.email}</p>}
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <PasswordPolicyTooltip />
                  </div>
                  <Input
                    id="signup-password"
                    type="password"
                    value={signupData.password}
                    onChange={(e) => setSignupData({ ...signupData, password: e.target.value })}
                    className="h-12 text-base"
                  />
                  {signupErrors.password && <p className="text-sm text-destructive">{signupErrors.password}</p>}
                  
                  {/* Password Strength Meter */}
                  <PasswordStrengthMeter 
                    password={signupData.password}
                    onValidationChange={handlePasswordValidationChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="signup-confirm-password">Bekræft Password</Label>
                  <Input
                    id="signup-confirm-password"
                    type="password"
                    value={signupData.confirmPassword}
                    onChange={(e) => setSignupData({ ...signupData, confirmPassword: e.target.value })}
                    className="h-12 text-base"
                  />
                  {signupErrors.confirmPassword && <p className="text-sm text-destructive">{signupErrors.confirmPassword}</p>}
                </div>
                <Button 
                  type="submit" 
                  className="w-full h-12 text-base" 
                  disabled={isSubmitting || !isPasswordValid || isPasswordLeaked}
                >
                  {isSubmitting ? 'Opretter konto...' : 'Opret konto'}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
