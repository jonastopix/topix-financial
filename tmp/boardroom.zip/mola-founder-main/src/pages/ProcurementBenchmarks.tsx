import Layout from "@/components/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCompanyData } from "@/hooks/useCompanyData";
import { useRole } from "@/contexts/RoleContext";
import { useCompanyPrices, usePortfolioBenchmarks, calculateSavings, getSavingsBadge } from "@/hooks/useProcurementData";
import { ArrowDown, ArrowUp, Minus } from "lucide-react";

export default function ProcurementBenchmarks() {
  const { data: company } = useCompanyData();
  const { selectedCompanyId } = useRole();
  const companyId = selectedCompanyId || company?.id;
  
  const { data: prices, isLoading } = useCompanyPrices(companyId);

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <h1 className="text-3xl font-bold">Benchmarks</h1>
          <p className="text-muted-foreground">Indlæser...</p>
        </div>
      </Layout>
    );
  }

  const groupedPrices = prices?.reduce((acc, price) => {
    const key = `${price.category}-${price.subcategory}`;
    if (!acc[key]) {
      acc[key] = [];
    }
    acc[key].push(price);
    return acc;
  }, {} as Record<string, typeof prices>);

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Benchmarks</h1>
          <p className="text-muted-foreground">
            Sammenlign dine priser med porteføljegennemsnittet
          </p>
        </div>

        {!prices || prices.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">
                Du har endnu ikke indlæst nogen priser.
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Brug "Indlæs egne priser" knappen på Deals & Indkøb siden for at komme i gang.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {Object.entries(groupedPrices || {}).map(([key, priceList]) => {
              const price = priceList[0];
              return (
                <BenchmarkCard
                  key={key}
                  price={price}
                />
              );
            })}
          </div>
        )}
      </div>
    </Layout>
  );
}

function BenchmarkCard({ price }: { price: any }) {
  const { data: benchmarks } = usePortfolioBenchmarks(price.category, price.subcategory);
  
  const savings = calculateSavings(
    price.value_numeric,
    benchmarks?.median || null,
    price.sample_volume_monthly
  );
  
  const badge = getSavingsBadge(price.value_numeric, benchmarks || null);

  const categoryLabels: Record<string, string> = {
    shipping: "Fragt",
    payment: "Betaling",
    saas: "SaaS",
    energy: "Energi",
    tele: "Tele",
  };

  const subcategoryLabels: Record<string, string> = {
    home_delivery: "Hjemmelevering",
    pickup_point: "Pakkeshop",
    card_fee: "Kortgebyr",
    mobilepay: "MobilePay",
    klarna: "Klarna",
    workfeed: "Workfeed",
    slack: "Slack",
    clickup: "ClickUp",
    electricity: "El",
    sim: "Mobil SIM",
    internet: "Internet",
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">
              {subcategoryLabels[price.subcategory] || price.subcategory}
            </CardTitle>
            <CardDescription>
              {categoryLabels[price.category] || price.category}
            </CardDescription>
          </div>
          {badge && (
            <Badge variant={badge.color as any}>
              {badge.label}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Din pris</p>
            <p className="text-2xl font-bold text-blue-600">
              {price.value_numeric.toFixed(2)} {price.unit}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Porteføljesnit</p>
            <p className="text-2xl font-bold text-green-600">
              {benchmarks?.median ? `${benchmarks.median.toFixed(2)} ${price.unit}` : "N/A"}
            </p>
          </div>
        </div>

        {savings && benchmarks && (
          <div className="pt-4 border-t">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Estimeret besparelse/år</span>
              <div className="flex items-center gap-2">
                {savings.annualSavings < 0 ? (
                  <ArrowDown className="w-4 h-4 text-red-500" />
                ) : savings.annualSavings > 0 ? (
                  <ArrowUp className="w-4 h-4 text-green-500" />
                ) : (
                  <Minus className="w-4 h-4 text-muted-foreground" />
                )}
                <span className={`font-semibold ${
                  savings.annualSavings < 0 ? "text-red-500" : 
                  savings.annualSavings > 0 ? "text-green-500" : 
                  "text-muted-foreground"
                }`}>
                  {Math.abs(savings.annualSavings).toLocaleString('da-DK')} kr
                </span>
              </div>
            </div>
            {benchmarks.sampleCount && (
              <p className="text-xs text-muted-foreground mt-2">
                Baseret på {benchmarks.sampleCount} selskaber
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}