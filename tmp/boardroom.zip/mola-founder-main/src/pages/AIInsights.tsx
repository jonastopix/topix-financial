import Layout from '@/components/Layout';
import AIInsightsPlaceholder from '@/components/AIInsightsPlaceholder';

const AIInsights = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-8">
        <div>
          <h1 className="text-4xl font-bold mb-2">AI Insights</h1>
          <p className="text-muted-foreground">AI-drevne analyser af din virksomheds præstation</p>
        </div>

        <AIInsightsPlaceholder />
      </div>
    </Layout>
  );
};

export default AIInsights;
