import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, Percent, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useCompanyFinancials } from '@/hooks/useCompanyFinancials';

export default function InvestorDashboard() {
  const { user } = useAuth();

  // Fetch companies where user is an investor
  const { data: companies, isLoading } = useQuery({
    queryKey: ['investor-companies', user?.id],
    queryFn: async () => {
      if (!user) return [];

      const { data, error } = await supabase
        .from('company_cap_table')
        .select(`
          id,
          ownership_pct,
          company_id,
          companies:company_id (
            id,
            name,
            logo_url,
            cvr,
            industry,
            status
          )
        `)
        .eq('user_id', user.id);

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="p-8">Indlæser dine investeringer...</div>
      </Layout>
    );
  }

  const totalCompanies = companies?.length || 0;
  const totalOwnership = companies?.reduce((sum, c) => sum + Number(c.ownership_pct), 0) || 0;

  return (
    <Layout>
      <div className="space-y-8 p-8">
        <div>
          <h1 className="text-3xl font-bold">Investor Dashboard</h1>
          <p className="text-muted-foreground mt-2">
            Oversigt over dine investeringer i MOLA portefølje
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Antal investeringer</p>
                  <p className="text-3xl font-bold">{totalCompanies}</p>
                </div>
                <Building2 className="h-10 w-10 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Samlet ejerandel</p>
                  <p className="text-3xl font-bold">{totalOwnership.toFixed(2)}%</p>
                </div>
                <Percent className="h-10 w-10 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Gns. ejerandel</p>
                  <p className="text-3xl font-bold">
                    {totalCompanies > 0 ? (totalOwnership / totalCompanies).toFixed(2) : 0}%
                  </p>
                </div>
                <TrendingUp className="h-10 w-10 text-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Companies */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Dine investeringer</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {companies && companies.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-muted-foreground">Ingen investeringer endnu</p>
                </CardContent>
              </Card>
            ) : (
              companies?.map((capEntry: any) => (
                <CompanyInvestmentCard
                  key={capEntry.id}
                  company={capEntry.companies}
                  ownership={capEntry.ownership_pct}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}

function CompanyInvestmentCard({ company, ownership }: { company: any; ownership: number }) {
  const { data: financials } = useCompanyFinancials(company.id);

  return (
    <Link to={`/investor/company/${company.id}`}>
      <Card className="hover:shadow-lg transition-shadow cursor-pointer">
        <CardHeader>
          <div className="flex items-center gap-4">
            {company.logo_url && (
              <img
                src={company.logo_url}
                alt={company.name}
                className="h-12 w-12 rounded-lg object-contain"
              />
            )}
            <div>
              <CardTitle className="text-lg">{company.name}</CardTitle>
              <CardDescription className="text-sm">CVR: {company.cvr}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Din ejerandel</span>
              <span className="font-bold text-primary">{ownership}%</span>
            </div>

            {financials?.ytd && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">YTD Omsætning</span>
                  <span className="font-medium">
                    {(financials.ytd.revenue / 1000).toFixed(0)}k DKK
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">YTD EBITDA</span>
                  <span className="font-medium">
                    {(financials.ytd.ebitda / 1000).toFixed(0)}k DKK
                  </span>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
