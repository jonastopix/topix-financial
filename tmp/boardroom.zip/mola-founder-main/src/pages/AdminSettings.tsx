import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CalendlySettings } from '@/components/CalendlySettings';
import { MeetingInvitationsWidget } from '@/components/MeetingInvitationsWidget';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Trash2, AlertTriangle, ShoppingCart, Shield, Users, Layout as LayoutIcon, Mail, CheckCircle2, Handshake, ClipboardCheck, Play } from 'lucide-react';
import { useSystemSettings } from '@/hooks/useSystemSettings';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useNavigate } from 'react-router-dom';
import { DataAccessRequestsTable } from '@/components/DataAccessRequestsTable';
import { OnboardingPreviewModal } from '@/components/OnboardingPreviewModal';

const AdminSettings = () => {
  const [isCleaningUp, setIsCleaningUp] = useState(false);
  const [showOnboardingPreview, setShowOnboardingPreview] = useState(false);
  const navigate = useNavigate();
  const { remindersEnabled, isLoading, toggleReminders } = useSystemSettings();

  const handleToggleReminders = async (enabled: boolean) => {
    await toggleReminders(enabled);
  };

  const handleCleanupDemoData = async () => {
    setIsCleaningUp(true);
    try {
      const { error } = await supabase.rpc('cleanup_demo_data');
      
      if (error) throw error;
      
      toast.success('Demo-data fjernet', {
        description: 'Alle demo-data er blevet slettet succesfuldt.',
      });
    } catch (error) {
      console.error('Error cleaning up demo data:', error);
      toast.error('Fejl ved sletning af demo-data', {
        description: 'Der opstod en fejl. Prøv igen.',
      });
    } finally {
      setIsCleaningUp(false);
    }
  };

  return (
    <Layout>
      <div className="space-y-8 max-w-full">
        <div>
          <h1 className="text-4xl font-bold mb-2">Admin Indstillinger</h1>
          <p className="text-muted-foreground">Administrer systemindstillinger</p>
        </div>

        {/* Calendly Integration */}
        <div className="grid gap-6 md:grid-cols-2">
          <CalendlySettings />
          <MeetingInvitationsWidget />
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Data Anmodninger
              </CardTitle>
              <CardDescription>
                Administrer bruger anmodninger om data export
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataAccessRequestsTable />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Support Kontakter
              </CardTitle>
              <CardDescription>
                Administrer support team kontakter med email og telefon
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/support-contacts-settings')}>
                Administrer Support Kontakter
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LayoutIcon className="h-5 w-5" />
                Footer Indstillinger
              </CardTitle>
              <CardDescription>
                Administrer footer indhold, links og sektioner
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/footer-settings')}>
                Administrer Footer
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Email Templates
              </CardTitle>
              <CardDescription>
                Administrer email templates med preview og variable system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/email-templates')}>
                Administrer Email Templates
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Handshake className="h-5 w-5" />
                Netværk Administration
              </CardTitle>
              <CardDescription>
                Administrer trusted partners og kategorier
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/admin/trusted-partners')}>
                Administrer Netværk
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClipboardCheck className="h-5 w-5" />
                Selskabs-Governance
              </CardTitle>
              <CardDescription>
                Administrer governance punkter der gælder for alle selskaber med årshjul og deadlines
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/admin/governance-templates')}>
                Administrer Governance Templates
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="h-5 w-5" />
                Test Onboarding
              </CardTitle>
              <CardDescription>
                Se founder onboarding-flowet
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setShowOnboardingPreview(true)}>
                <Play className="mr-2 h-4 w-4" />
                Start Onboarding
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                Månedsrapport Reminders
              </CardTitle>
              <CardDescription>
                Slå automatiske påmindelse emails til og fra
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="font-medium">Automatiske Reminders</div>
                    <div className="text-sm text-muted-foreground">
                      Sender emails d. 10. (påmindelse) og d. 21. (rykker)
                    </div>
                  </div>
                  <Switch 
                    checked={remindersEnabled} 
                    onCheckedChange={handleToggleReminders}
                    disabled={isLoading}
                  />
                </div>
                
                {remindersEnabled && (
                  <div className="flex items-start gap-3 p-4 border border-success/50 bg-success/5 rounded-lg">
                    <CheckCircle2 className="h-5 w-5 text-success flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-success">Reminder systemet er aktivt</p>
                      <p className="text-muted-foreground">
                        Emails sendes automatisk til aktive selskaber d. 10. og d. 21. hver måned
                      </p>
                    </div>
                  </div>
                )}
                
                {!remindersEnabled && (
                  <div className="flex items-start gap-3 p-4 border border-warning/50 bg-warning/5 rounded-lg">
                    <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-warning">Reminder systemet er deaktiveret</p>
                      <p className="text-muted-foreground">
                        Der sendes ingen automatiske emails før du aktiverer systemet
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Deals & Indkøb Administration - DEAKTIVERET MIDLERTIDIGT */}
          {false && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Deals & Indkøb Administration
                </CardTitle>
                <CardDescription>
                  Administrer partneraftaler, selskabspriser, adoptioner og benchmarks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={() => navigate('/procurement/admin')}>
                  Åbn Procurement Admin
                </Button>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trash2 className="h-5 w-5" />
                Demo-data Styring
              </CardTitle>
              <CardDescription>
                Fjern alle demo-data fra systemet (selskaber, rapporter, NPS, badges)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3 p-4 border border-warning/50 bg-warning/5 rounded-lg">
                <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
                <div className="text-sm space-y-1">
                  <p className="font-medium text-warning">Advarsel: Denne handling kan ikke fortrydes</p>
                  <p className="text-muted-foreground">
                    Dette vil slette alle demo-selskaber (Vinhuset, Bland Selv Frø, Filternew) 
                    samt tilhørende månedlige rapporter, NPS svar, shipping priser og badges.
                  </p>
                </div>
              </div>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="destructive" 
                    disabled={isCleaningUp}
                    className="w-full sm:w-auto"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    {isCleaningUp ? 'Fjerner demo-data...' : 'Fjern demo-data'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Dette vil permanent slette alle demo-data fra systemet. 
                      Denne handling kan ikke fortrydes.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Annuller</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleCleanupDemoData}
                      className="bg-destructive hover:bg-destructive/90"
                    >
                      Ja, slet demo-data
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </div>

      <OnboardingPreviewModal 
        isOpen={showOnboardingPreview} 
        onClose={() => setShowOnboardingPreview(false)} 
      />
    </Layout>
  );
};

export default AdminSettings;
