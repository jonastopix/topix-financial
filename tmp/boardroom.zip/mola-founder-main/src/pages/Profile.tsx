import { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useProfileManagement } from '@/hooks/useProfileManagement';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Skeleton } from '@/components/ui/skeleton';
import { Camera, Trash2, User, Mail, Building2, Lock, Save, Linkedin, Handshake, Plug } from 'lucide-react';
import { MondayIntegrationCard } from '@/components/MondayIntegrationCard';
import { toast } from 'sonner';
import { z } from 'zod';

const profileSchema = z.object({
  full_name: z.string().trim().min(2, 'Navn skal være mindst 2 tegn').max(100, 'Navn må maks være 100 tegn'),
  company_name: z.string().trim().max(100, 'Firmanavn må maks være 100 tegn').optional(),
  title: z.string().trim().max(100, 'Titel må maks være 100 tegn').optional().or(z.literal('')),
  bio: z.string().trim().max(300, 'Bio må maks være 300 tegn').optional().or(z.literal('')),
  linkedin_url: z.string().trim().url('Ugyldig LinkedIn URL').optional().or(z.literal('')),
  can_help_with: z.string().trim().max(500, 'Maks 500 tegn').optional().or(z.literal('')),
});

const passwordSchema = z.object({
  newPassword: z.string().min(8, 'Password skal være mindst 8 tegn'),
  confirmPassword: z.string(),
}).refine((data) => data.newPassword === data.confirmPassword, {
  message: "Passwords matcher ikke",
  path: ["confirmPassword"],
});

const Profile = () => {
  const { user, updatePassword } = useAuth();
  const { profile, isLoading, isUploadingAvatar, updateProfile, uploadAvatar, deleteAvatar } = useProfileManagement();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [title, setTitle] = useState('');
  const [bio, setBio] = useState('');
  const [skills, setSkills] = useState<string[]>([]);
  const [skillInput, setSkillInput] = useState('');
  const [linkedinUrl, setLinkedinUrl] = useState('');
  const [canHelpWith, setCanHelpWith] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Update form when profile loads
  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setCompanyName(profile.company_name || '');
      setTitle(profile.title || '');
      setBio(profile.bio || '');
      setSkills(profile.skills || []);
      setLinkedinUrl(profile.linkedin_url || '');
      setCanHelpWith((profile as any).can_help_with || '');
    }
  }, [profile]);

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleAvatarChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await uploadAvatar(file);
    }
  };

  const handleDeleteAvatar = async () => {
    if (confirm('Er du sikker på at du vil slette dit profilbillede?')) {
      await deleteAvatar();
    }
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      const validated = profileSchema.parse({ 
        full_name: fullName, 
        company_name: companyName,
        title: title || '',
        bio: bio || '',
        linkedin_url: linkedinUrl || '',
        can_help_with: canHelpWith || ''
      });
      updateProfile({
        ...validated,
        skills
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: { [key: string]: string } = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            newErrors[err.path[0].toString()] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  const handleAddSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()]);
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter(skill => skill !== skillToRemove));
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddSkill();
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    try {
      const validated = passwordSchema.parse({ newPassword, confirmPassword });
      const { error } = await updatePassword(validated.newPassword);
      
      if (error) {
        toast.error('Fejl ved opdatering af password: ' + error.message);
      } else {
        toast.success('Password opdateret');
        setNewPassword('');
        setConfirmPassword('');
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const newErrors: { [key: string]: string } = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            newErrors[err.path[0].toString()] = err.message;
          }
        });
        setErrors(newErrors);
      }
    }
  };

  const getInitials = () => {
    if (profile?.full_name) {
      return profile.full_name
        .split(' ')
        .map(n => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2);
    }
    return user?.email?.[0].toUpperCase() || 'U';
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="space-y-6">
            <Skeleton className="h-8 w-48" />
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-24 w-24 rounded-full mx-auto" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="space-y-6">
          {/* Page Header */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Min Profil</h1>
            <p className="text-muted-foreground mt-2">Administrer dine profilindstillinger</p>
          </div>

          {/* Profile Picture */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Profilbillede
              </CardTitle>
              <CardDescription>Upload et billede til din profil</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center gap-4">
                <Avatar className="h-32 w-32 border-4 border-border">
                  <AvatarImage src={profile?.avatar_url || undefined} alt={profile?.full_name || 'User'} />
                  <AvatarFallback className="text-3xl">{getInitials()}</AvatarFallback>
                </Avatar>
                <div className="flex gap-2">
                  <Button
                    onClick={handleAvatarClick}
                    disabled={isUploadingAvatar}
                    className="gap-2"
                  >
                    <Camera className="h-4 w-4" />
                    {isUploadingAvatar ? 'Uploader...' : 'Upload billede'}
                  </Button>
                  {profile?.avatar_url && (
                    <Button
                      variant="outline"
                      onClick={handleDeleteAvatar}
                      disabled={isUploadingAvatar}
                      className="gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Slet
                    </Button>
                  )}
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleAvatarChange}
                  className="hidden"
                />
                <p className="text-xs text-muted-foreground">
                  Tilladt: JPG, PNG, WEBP. Maks 5MB
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Profile Information */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Profilinformation
              </CardTitle>
              <CardDescription>Opdater dine personlige oplysninger</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileUpdate} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={user?.email || ''}
                    disabled
                    className="bg-muted"
                  />
                  <p className="text-xs text-muted-foreground">Email kan ikke ændres</p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="full_name" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Fulde navn *
                  </Label>
                  <Input
                    id="full_name"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Dit fulde navn"
                    className={errors.full_name ? 'border-destructive' : ''}
                  />
                  {errors.full_name && (
                    <p className="text-sm text-destructive">{errors.full_name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="company_name" className="flex items-center gap-2">
                    <Building2 className="h-4 w-4" />
                    Firmanavn
                  </Label>
                  <Input
                    id="company_name"
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Dit firmanavn (valgfrit)"
                    className={errors.company_name ? 'border-destructive' : ''}
                  />
                  {errors.company_name && (
                    <p className="text-sm text-destructive">{errors.company_name}</p>
                  )}
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="title">
                    Titel
                  </Label>
                  <Input
                    id="title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="f.eks. CEO, Founder & CTO, Co-Founder"
                    maxLength={100}
                    className={errors.title ? 'border-destructive' : ''}
                  />
                  {errors.title ? (
                    <p className="text-sm text-destructive">{errors.title}</p>
                  ) : (
                    <p className="text-xs text-muted-foreground">{title.length}/100 tegn</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">
                    Bio
                  </Label>
                  <Textarea
                    id="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Fortæl kort om dig og din virksomhed..."
                    maxLength={300}
                    rows={4}
                    className={errors.bio ? 'border-destructive' : ''}
                  />
                  {errors.bio ? (
                    <p className="text-sm text-destructive">{errors.bio}</p>
                  ) : (
                    <p className="text-xs text-muted-foreground">{bio.length}/300 tegn</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="skills">
                    Kompetencer
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="skills"
                      value={skillInput}
                      onChange={(e) => setSkillInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="f.eks. React, B2B Sales, Fundraising"
                    />
                    <Button type="button" onClick={handleAddSkill} variant="outline">
                      Tilføj
                    </Button>
                  </div>
                  {skills.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {skills.map((skill) => (
                        <Badge 
                          key={skill} 
                          variant="secondary" 
                          className="cursor-pointer hover:bg-destructive hover:text-destructive-foreground transition-colors"
                          onClick={() => handleRemoveSkill(skill)}
                        >
                          {skill} ×
                        </Badge>
                      ))}
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Klik på et tag for at fjerne det
                  </p>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="can_help_with" className="flex items-center gap-2">
                    <Handshake className="h-4 w-4" />
                    Jeg kan hjælpe med
                  </Label>
                  <Textarea
                    id="can_help_with"
                    value={canHelpWith}
                    onChange={(e) => setCanHelpWith(e.target.value)}
                    placeholder="Beskriv hvad du kan tilbyde andre founders, f.eks. fundraising sparring, intro til kunder, erfaring med specifikke teknologier..."
                    maxLength={500}
                    rows={4}
                    className={errors.can_help_with ? 'border-destructive' : ''}
                  />
                  {errors.can_help_with ? (
                    <p className="text-sm text-destructive">{errors.can_help_with}</p>
                  ) : (
                    <p className="text-xs text-muted-foreground">{canHelpWith.length}/500 tegn</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Dette vises til andre founders på "Meet the Founders" siden
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="linkedin_url" className="flex items-center gap-2">
                    <Linkedin className="h-4 w-4" />
                    LinkedIn Profil
                  </Label>
                  <Input
                    id="linkedin_url"
                    type="url"
                    value={linkedinUrl}
                    onChange={(e) => setLinkedinUrl(e.target.value)}
                    placeholder="https://linkedin.com/in/dit-navn"
                    className={errors.linkedin_url ? 'border-destructive' : ''}
                  />
                  {errors.linkedin_url && (
                    <p className="text-sm text-destructive">{errors.linkedin_url}</p>
                  )}
                </div>

                <Button type="submit" className="w-full gap-2">
                  <Save className="h-4 w-4" />
                  Gem ændringer
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Integrationer */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plug className="h-5 w-5" />
                Integrationer
              </CardTitle>
              <CardDescription>Forbind eksterne værktøjer med din konto</CardDescription>
            </CardHeader>
            <CardContent>
              <MondayIntegrationCard />
            </CardContent>
          </Card>

          {/* Change Password */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Skift password
              </CardTitle>
              <CardDescription>Opdater dit password</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="newPassword">Nyt password *</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Mindst 8 tegn"
                    className={errors.newPassword ? 'border-destructive' : ''}
                  />
                  {errors.newPassword && (
                    <p className="text-sm text-destructive">{errors.newPassword}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Bekræft password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Gentag dit nye password"
                    className={errors.confirmPassword ? 'border-destructive' : ''}
                  />
                  {errors.confirmPassword && (
                    <p className="text-sm text-destructive">{errors.confirmPassword}</p>
                  )}
                </div>

                <Button type="submit" className="w-full gap-2">
                  <Lock className="h-4 w-4" />
                  Opdater password
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Profile;
