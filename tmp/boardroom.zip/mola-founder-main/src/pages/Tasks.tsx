import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTaskManagement, Task } from '@/hooks/useTaskManagement';
import { useAuth } from '@/contexts/AuthContext';
import Layout from '@/components/Layout';
import TasksKanban from '@/components/TasksKanban';
import TaskCard from '@/components/TaskCard';
import TaskDetailsDialog from '@/components/TaskDetailsDialog';
import TasksTable from '@/components/TasksTable';
import TasksToolbar from '@/components/TasksToolbar';
import TaskMobileRow from '@/components/TaskMobileRow';
import TaskProductivityWidget from '@/components/TaskProductivityWidget';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { ListTodo, LayoutGrid, Table2 } from 'lucide-react';

const Tasks = () => {
  const { tasks, isLoading, updateTask } = useTaskManagement();
  const { user } = useAuth();
  const [view, setView] = useState<'table' | 'kanban' | 'list'>('table');
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showTaskDetails, setShowTaskDetails] = useState(false);

  // Toolbar state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('open');
  const [sortBy, setSortBy] = useState('due_date');

  // Handle deep-linking via ?taskId=xxx
  useEffect(() => {
    const taskIdFromUrl = searchParams.get('taskId');
    if (taskIdFromUrl && tasks && tasks.length > 0) {
      const task = tasks.find(t => t.id === taskIdFromUrl);
      if (task) {
        setSelectedTask(task);
        setShowTaskDetails(true);
        searchParams.delete('taskId');
        setSearchParams(searchParams, { replace: true });
      }
    }
  }, [searchParams, tasks, setSearchParams]);

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    if (!tasks) return [];

    let result = [...tasks];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(task => 
        task.title.toLowerCase().includes(query) ||
        task.description?.toLowerCase().includes(query) ||
        task.company?.name?.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (statusFilter === 'open') {
      result = result.filter(task => task.status !== 'done');
    } else if (statusFilter === 'delegated') {
      // Delegated: tasks I created and assigned to someone else
      result = result.filter(task => 
        task.created_by === user?.id && 
        task.assigned_to && 
        task.assigned_to !== user?.id
      );
    } else if (statusFilter !== 'all') {
      result = result.filter(task => task.status === statusFilter);
    }

    // Sort
    result.sort((a, b) => {
      switch (sortBy) {
        case 'due_date':
          if (!a.due_date && !b.due_date) return 0;
          if (!a.due_date) return 1;
          if (!b.due_date) return -1;
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        case 'priority':
          const priorityOrder: Record<string, number> = { urgent: 0, high: 1, medium: 2, low: 3 };
          return (priorityOrder[a.priority] || 4) - (priorityOrder[b.priority] || 4);
        case 'created_at':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case 'title':
          return a.title.localeCompare(b.title, 'da');
        default:
          return 0;
      }
    });

    return result;
  }, [tasks, searchQuery, statusFilter, sortBy]);

  const handleCloseTaskDetails = () => {
    setShowTaskDetails(false);
    setSelectedTask(null);
  };

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setShowTaskDetails(true);
  };

  const handleToggleStatus = (task: Task) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    updateTask.mutate({ id: task.id, status: newStatus });
  };

  return (
    <Layout>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold">Opgaver</h1>
            <p className="text-muted-foreground text-sm mt-1">
              Administrer dine opgaver og deadlines
            </p>
          </div>
        </div>

        {/* Productivity Widget */}
        <TaskProductivityWidget />

        {/* Toolbar */}
        <TasksToolbar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          statusFilter={statusFilter}
          onStatusFilterChange={setStatusFilter}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />

        <Tabs value={view} onValueChange={(v) => setView(v as typeof view)}>
          <TabsList className="h-9">
            <TabsTrigger value="table" className="gap-1.5 text-xs sm:text-sm">
              <Table2 className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Tabel</span>
            </TabsTrigger>
            <TabsTrigger value="kanban" className="gap-1.5 text-xs sm:text-sm">
              <LayoutGrid className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Kanban</span>
            </TabsTrigger>
            <TabsTrigger value="list" className="gap-1.5 text-xs sm:text-sm">
              <ListTodo className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Kort</span>
            </TabsTrigger>
          </TabsList>

          {/* Table View */}
          <TabsContent value="table" className="mt-4">
            {isLoading ? (
              <div className="space-y-2">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (
              <>
                {/* Desktop Table */}
                <div className="hidden md:block">
                  <TasksTable tasks={filteredTasks} />
                </div>
                {/* Mobile List */}
                <div className="md:hidden space-y-2">
                  {filteredTasks.length === 0 ? (
                    <div className="text-center py-12 border rounded-lg bg-card">
                      <p className="text-muted-foreground">Ingen opgaver</p>
                    </div>
                  ) : (
                    filteredTasks.map((task) => (
                      <TaskMobileRow
                        key={task.id}
                        task={task}
                        onToggleStatus={handleToggleStatus}
                        onClick={handleTaskClick}
                      />
                    ))
                  )}
                </div>
              </>
            )}
          </TabsContent>

          {/* Kanban View */}
          <TabsContent value="kanban" className="mt-4">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="space-y-3">
                    <Skeleton className="h-8 w-32" />
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-24 w-full" />
                  </div>
                ))}
              </div>
            ) : (
              <TasksKanban tasks={filteredTasks} />
            )}
          </TabsContent>

          {/* Card/List View */}
          <TabsContent value="list" className="mt-4">
            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTasks.map((task) => (
                  <div key={task.id} onClick={() => handleTaskClick(task)} className="cursor-pointer">
                    <TaskCard task={task} />
                  </div>
                ))}
                {filteredTasks.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Ingen opgaver</p>
                  </div>
                )}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Task Details Dialog */}
      {selectedTask && (
        <TaskDetailsDialog
          task={selectedTask}
          open={showTaskDetails}
          onOpenChange={handleCloseTaskDetails}
        />
      )}
    </Layout>
  );
};

export default Tasks;
