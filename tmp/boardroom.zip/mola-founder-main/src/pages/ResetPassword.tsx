import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { resetPasswordSchema } from '@/lib/authSchemas';
import { PasswordStrengthMeter } from '@/components/PasswordStrengthMeter';
import { PasswordPolicyTooltip } from '@/components/PasswordPolicyTooltip';
import { isCommonPassword } from '@/lib/passwordValidation';
import { z } from 'zod';
import molaLogo from '@/assets/mola-logo.png';

const ResetPassword = () => {
  const { updatePassword } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<any>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isPasswordValid, setIsPasswordValid] = useState(false);
  const [isPasswordLeaked, setIsPasswordLeaked] = useState(false);
  const [hasValidToken, setHasValidToken] = useState(false);

  useEffect(() => {
    // Check if we have a valid recovery token in the URL hash
    const hashParams = new URLSearchParams(location.hash.substring(1));
    const hasToken = hashParams.has('access_token') || hashParams.has('type');
    
    if (!hasToken) {
      // No recovery token - redirect to forgot password
      navigate('/forgot-password', { replace: true });
    } else {
      setHasValidToken(true);
    }
  }, [location, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Check if password is common
    if (isCommonPassword(password)) {
      setErrors({ password: 'Dette password er for almindeligt. Vælg et stærkere password.' });
      return;
    }

    // Check if password is leaked
    if (isPasswordLeaked) {
      setErrors({ password: 'Dette password er fundet i et data-læk. Vælg et andet password.' });
      return;
    }

    // Check if password validation passed
    if (!isPasswordValid) {
      setErrors({ password: 'Password opfylder ikke alle sikkerhedskrav' });
      return;
    }

    setIsSubmitting(true);

    try {
      resetPasswordSchema.parse({ password, confirmPassword });
      const { error } = await updatePassword(password);
      
      if (!error) {
        setTimeout(() => {
          navigate('/', { replace: true });
        }, 1500);
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        const formattedErrors: any = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            formattedErrors[err.path[0]] = err.message;
          }
        });
        setErrors(formattedErrors);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePasswordValidationChange = (isValid: boolean, isLeaked: boolean) => {
    setIsPasswordValid(isValid);
    setIsPasswordLeaked(isLeaked);
  };

  if (!hasValidToken) {
    return null;
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border bg-card">
        <CardHeader className="space-y-4">
          <div className="flex justify-center">
            <img 
              src={molaLogo} 
              alt="MOLA" 
              className="h-16 w-auto"
            />
          </div>
          <CardTitle className="text-center">Nulstil password</CardTitle>
          <CardDescription className="text-center text-muted-foreground">
            Indtast dit nye password nedenfor
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Label htmlFor="password">Nyt password</Label>
                <PasswordPolicyTooltip />
              </div>
              <Input
                id="password"
                type="password"
                placeholder="Mindst 8 tegn"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 text-base"
              />
              {errors.password && <p className="text-sm text-destructive">{errors.password}</p>}
              
              {/* Password Strength Meter */}
              <PasswordStrengthMeter 
                password={password}
                onValidationChange={handlePasswordValidationChange}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Bekræft password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="Gentag password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="h-12 text-base"
              />
              {errors.confirmPassword && <p className="text-sm text-destructive">{errors.confirmPassword}</p>}
            </div>
            <Button 
              type="submit" 
              className="w-full h-12 text-base" 
              disabled={isSubmitting || !isPasswordValid || isPasswordLeaked}
            >
              {isSubmitting ? 'Opdaterer...' : 'Opdater password'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResetPassword;
