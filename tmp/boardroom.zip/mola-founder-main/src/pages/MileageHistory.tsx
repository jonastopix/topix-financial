import { useState } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Car, ArrowLeft, Eye } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useNavigate } from 'react-router-dom';
import { useMileageSubmissions, MileageSubmission } from '@/hooks/useMileage';
import Layout from '@/components/Layout';

const formatDKK = (value: number) => value.toLocaleString('da-DK', { style: 'currency', currency: 'DKK' });

const MONTHS = [
  'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni',
  'Juli', 'August', 'September', 'Oktober', 'November', 'December'
];

export default function MileageHistory() {
  const navigate = useNavigate();
  const { data: submissions = [], isLoading } = useMileageSubmissions();
  const [viewSubmission, setViewSubmission] = useState<MileageSubmission | null>(null);
  
  return (
    <Layout>
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/admin/mileage')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Car className="h-6 w-6" />
              Indsendte kørselsrapporter
            </h1>
            <p className="text-muted-foreground">
              Historik over alle indsendte kørselsrapporter
            </p>
          </div>
        </div>
        
        {/* Submissions Table */}
        <Card>
          <CardHeader>
            <CardTitle>Rapporter</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-center py-8 text-muted-foreground">Indlæser...</p>
            ) : submissions.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">
                Ingen rapporter indsendt endnu
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Periode</TableHead>
                    <TableHead>Virksomhed</TableHead>
                    <TableHead className="text-right">Total km</TableHead>
                    <TableHead className="text-right">Beløb</TableHead>
                    <TableHead>Sendt til</TableHead>
                    <TableHead>Sendt</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {submissions.map((submission) => (
                    <TableRow key={submission.id}>
                      <TableCell>
                        {MONTHS[submission.period_month - 1]} {submission.period_year}
                      </TableCell>
                      <TableCell>{submission.paying_company?.name}</TableCell>
                      <TableCell className="text-right">
                        {Number(submission.total_km).toFixed(1)}
                      </TableCell>
                      <TableCell className="text-right">
                        {formatDKK(Number(submission.total_amount_dkk))}
                      </TableCell>
                      <TableCell>
                        {submission.sent_to_emails.join(', ')}
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        {format(new Date(submission.sent_at), 'dd/MM/yyyy HH:mm')}
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setViewSubmission(submission)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Se detaljer
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
        
        {/* View Submission Dialog */}
        <Dialog open={!!viewSubmission} onOpenChange={() => setViewSubmission(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                Kørselsrapport - {viewSubmission?.paying_company?.name}
              </DialogTitle>
              <DialogDescription>
                {viewSubmission && (
                  <>
                    {MONTHS[viewSubmission.period_month - 1]} {viewSubmission.period_year} •
                    Sendt {format(new Date(viewSubmission.sent_at), "d. MMMM yyyy 'kl.' HH:mm", { locale: da })}
                  </>
                )}
              </DialogDescription>
            </DialogHeader>
            
            {viewSubmission && (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Total km</CardDescription>
                      <CardTitle>{Number(viewSubmission.total_km).toFixed(1)}</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Beløb</CardDescription>
                      <CardTitle>{formatDKK(Number(viewSubmission.total_amount_dkk))}</CardTitle>
                    </CardHeader>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardDescription>Medarbejder</CardDescription>
                      <CardTitle className="text-lg">{viewSubmission.employee_name}</CardTitle>
                    </CardHeader>
                  </Card>
                </div>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dato</TableHead>
                      <TableHead>Fra</TableHead>
                      <TableHead>Til</TableHead>
                      <TableHead>Formål</TableHead>
                      <TableHead className="text-right">Km</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(viewSubmission.entries_snapshot as any[]).map((entry: any, idx: number) => (
                      <TableRow key={idx}>
                        <TableCell>{format(new Date(entry.trip_date), 'dd/MM/yyyy')}</TableCell>
                        <TableCell className="max-w-[150px] truncate" title={entry.from_address}>
                          {entry.from_address}
                        </TableCell>
                        <TableCell className="max-w-[150px] truncate" title={entry.to_address}>
                          {entry.to_address}
                        </TableCell>
                        <TableCell>{entry.purpose}</TableCell>
                        <TableCell className="text-right">{Number(entry.distance_km).toFixed(1)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
