import { useParams, useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { ArrowLeft, FileText, CheckSquare, Calendar, Download, Archive, Eye, Clock, CalendarIcon } from 'lucide-react';
import {
  useDDCase,
  useDDCategories,
  useDDCategoryProgress,
  useDDDocuments,
  useUpdateDDCase,
  DDStatus,
} from '@/hooks/useDueDiligence';
import { DDStatusBadge } from '@/components/DDStatusBadge';
import { DDDocumentChecklist } from '@/components/DDDocumentChecklist';
import { ExportDDArchiveDialog } from '@/components/ExportDDArchiveDialog';
import { useState, useEffect } from 'react';

export default function DueDiligenceCase() {
  const { caseId } = useParams<{ caseId: string }>();
  const navigate = useNavigate();
  const [notes, setNotes] = useState('');
  const [showExportDialog, setShowExportDialog] = useState(false);
  const [deadline, setDeadline] = useState('');

  const { data: ddCase, isLoading: caseLoading } = useDDCase(caseId);
  const { data: categories = [] } = useDDCategories();
  const { data: categoryProgress = [] } = useDDCategoryProgress(caseId);
  const { data: documents = [] } = useDDDocuments(caseId);
  
  const updateCaseMutation = useUpdateDDCase();

  useEffect(() => {
    if (ddCase?.notes) {
      setNotes(ddCase.notes);
    }
    if (ddCase?.deadline) {
      setDeadline(ddCase.deadline);
    }
  }, [ddCase?.notes, ddCase?.deadline]);

  const isDeadlineNear = (deadlineStr: string) => {
    const deadlineDate = new Date(deadlineStr);
    const today = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntil <= 7 && daysUntil >= 0;
  };

  const handleDeadlineSelect = (date: Date | undefined) => {
    if (!caseId) return;
    const newDeadline = date ? date.toISOString().split('T')[0] : null;
    setDeadline(newDeadline || '');
    updateCaseMutation.mutate({ 
      id: caseId, 
      updates: { deadline: newDeadline } 
    });
  };

  const handleStatusChange = (status: DDStatus) => {
    if (!caseId) return;
    updateCaseMutation.mutate({ 
      id: caseId, 
      updates: { 
        status,
        completed_at: status === 'approved' || status === 'rejected' 
          ? new Date().toISOString() 
          : null 
      } 
    });
  };

  const handleNotesUpdate = () => {
    if (!caseId) return;
    updateCaseMutation.mutate({ 
      id: caseId, 
      updates: { notes } 
    });
  };

  if (caseLoading) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <p>Loading...</p>
        </div>
      </Layout>
    );
  }

  if (!ddCase) {
    return (
      <Layout>
        <div className="container mx-auto py-8">
          <Card>
            <CardHeader>
              <CardTitle>DD case ikke fundet</CardTitle>
              <CardDescription>
                Den ønskede due diligence case kunne ikke findes.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => navigate('/portfolio/due-diligence')}>
                Tilbage til oversigt
              </Button>
            </CardContent>
          </Card>
        </div>
      </Layout>
    );
  }

  const totalFileSize = documents.reduce((sum, doc) => sum + Number(doc.file_size || 0), 0);
  const isExportable = ddCase.status === 'approved' || ddCase.status === 'rejected';

  return (
    <Layout>
      <div className="container mx-auto py-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-bold">
                {ddCase.companies?.name || 'Due Diligence Case'}
              </h1>
              <DDStatusBadge status={ddCase.status} />
              {ddCase.exported_at && (
                <Badge variant="outline" className="gap-1">
                  <Archive className="h-3 w-3" />
                  Arkiveret
                </Badge>
              )}
            </div>
            <p className="text-muted-foreground">
              Administrer due diligence proces og dokumenter
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => navigate(`/my-due-diligence/${caseId}`)}
            >
              <Eye className="h-4 w-4 mr-2" />
              Se som founder
            </Button>
            {isExportable && (
              <Button 
                variant="default" 
                onClick={() => setShowExportDialog(true)}
                disabled={documents.length === 0}
              >
                <Download className="h-4 w-4 mr-2" />
                {ddCase.exported_at ? 'Re-eksporter Arkiv' : 'Eksporter Arkiv'}
              </Button>
            )}
            <Select value={ddCase.status} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="not_started">Ikke startet</SelectItem>
                <SelectItem value="in_progress">I gang</SelectItem>
                <SelectItem value="pending_review">Afventer review</SelectItem>
                <SelectItem value="approved">Godkendt</SelectItem>
                <SelectItem value="rejected">Afvist</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => navigate('/portfolio/due-diligence')}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Tilbage til pipeline
            </Button>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid gap-4 md:grid-cols-5">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Status</CardTitle>
              <DDStatusBadge status={ddCase.status} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold capitalize">
                {ddCase.status.replace('_', ' ')}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Fremskridt</CardTitle>
              <CheckSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {Math.round((categoryProgress.filter(p => p.status === 'completed').length / Math.max(categories.filter(c => c.parent_category_code).length, 1)) * 100)}%
              </div>
              <p className="text-xs text-muted-foreground">
                {categoryProgress.filter(p => p.status === 'completed').length} af {categories.filter(c => c.parent_category_code).length} kategorier
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Dokumenter</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{documents.length}</div>
              <p className="text-xs text-muted-foreground">
                Uploadede filer
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Startet</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold">
                {ddCase.started_at 
                  ? new Date(ddCase.started_at).toLocaleDateString('da-DK')
                  : 'Ikke startet'}
              </div>
              {ddCase.completed_at && (
                <p className="text-xs text-muted-foreground">
                  Færdig: {new Date(ddCase.completed_at).toLocaleDateString('da-DK')}
                </p>
              )}
            </CardContent>
          </Card>

          <Card className={ddCase.deadline && isDeadlineNear(ddCase.deadline) ? 'border-destructive' : ''}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Deadline</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold mb-2">
                {deadline 
                  ? format(new Date(deadline), 'd. MMMM yyyy', { locale: da })
                  : 'Ingen deadline'}
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full justify-start">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {deadline ? 'Ændr deadline' : 'Sæt deadline'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={deadline ? new Date(deadline) : undefined}
                    onSelect={handleDeadlineSelect}
                    disabled={(date) => date < new Date()}
                    className="pointer-events-auto"
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              {ddCase.deadline && isDeadlineNear(ddCase.deadline) && (
                <Badge variant="destructive" className="mt-2">
                  Deadline nærmer sig!
                </Badge>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="checklist" className="space-y-4">
          <TabsList>
            <TabsTrigger value="checklist">
              <CheckSquare className="h-4 w-4 mr-2" />
              Dokumenter
            </TabsTrigger>
            <TabsTrigger value="notes">
              <FileText className="h-4 w-4 mr-2" />
              Noter
            </TabsTrigger>
          </TabsList>

          <TabsContent value="checklist" className="space-y-4">
            <DDDocumentChecklist
              caseId={ddCase.id}
              categories={categories}
              categoryProgress={categoryProgress}
              documents={documents}
            />
          </TabsContent>

          <TabsContent value="notes" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Interne noter</CardTitle>
                <CardDescription>
                  Noter til dette DD case (ikke synlige for founder)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Skriv noter her..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={10}
                />
                <Button onClick={handleNotesUpdate}>
                  Gem noter
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Export Dialog */}
        <ExportDDArchiveDialog
          open={showExportDialog}
          onOpenChange={setShowExportDialog}
          caseId={ddCase.id}
          documentCount={documents.length}
          totalSize={totalFileSize}
          companyName={ddCase.companies?.name || 'Company'}
        />
      </div>
    </Layout>
  );
}
