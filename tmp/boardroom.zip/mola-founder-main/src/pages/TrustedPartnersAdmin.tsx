import { useState } from 'react';
import Layout from '@/components/Layout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Handshake, Plus, Pencil, Trash2, Building2, Star,
  Scale, Calculator, Users, Megaphone, Code, Banknote, Shield, Lightbulb, MoreHorizontal,
  GripVertical, FolderOpen
} from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import {
  useTrustedPartnerCategoriesAdmin,
  useTrustedPartnersAdmin,
  useCreateTrustedPartnerCategory,
  useUpdateTrustedPartnerCategory,
  useDeleteTrustedPartnerCategory,
  useCreateTrustedPartner,
  useUpdateTrustedPartner,
  useDeleteTrustedPartner,
  TrustedPartnerCategory,
  TrustedPartner,
} from '@/hooks/useTrustedPartners';

const ICON_OPTIONS = [
  { name: 'Scale', label: 'Vægt' },
  { name: 'Calculator', label: 'Lommeregner' },
  { name: 'Users', label: 'Brugere' },
  { name: 'Megaphone', label: 'Megafon' },
  { name: 'Code', label: 'Kode' },
  { name: 'Banknote', label: 'Penge' },
  { name: 'Shield', label: 'Skjold' },
  { name: 'Lightbulb', label: 'Pære' },
  { name: 'Building2', label: 'Bygning' },
  { name: 'Briefcase', label: 'Mappe' },
  { name: 'GraduationCap', label: 'Uddannelse' },
  { name: 'Truck', label: 'Lastbil' },
  { name: 'HeartPulse', label: 'Sundhed' },
  { name: 'Wrench', label: 'Værktøj' },
  { name: 'MoreHorizontal', label: 'Andet' },
];

const TrustedPartnersAdmin = () => {
  const [activeTab, setActiveTab] = useState('partners');
  
  // Categories state
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<TrustedPartnerCategory | null>(null);
  const [categoryForm, setCategoryForm] = useState({
    name: '',
    slug: '',
    icon_name: 'Briefcase',
    description: '',
  });

  // Partners state
  const [partnerDialogOpen, setPartnerDialogOpen] = useState(false);
  const [editingPartner, setEditingPartner] = useState<TrustedPartner | null>(null);
  const [partnerForm, setPartnerForm] = useState({
    category_id: '',
    company_name: '',
    contact_name: '',
    contact_title: '',
    email: '',
    phone: '',
    website: '',
    linkedin_url: '',
    description: '',
    is_mola_recommended: false,
  });

  // Queries
  const { data: categories, isLoading: categoriesLoading } = useTrustedPartnerCategoriesAdmin();
  const { data: partners, isLoading: partnersLoading } = useTrustedPartnersAdmin();

  // Mutations
  const createCategory = useCreateTrustedPartnerCategory();
  const updateCategory = useUpdateTrustedPartnerCategory();
  const deleteCategory = useDeleteTrustedPartnerCategory();
  const createPartner = useCreateTrustedPartner();
  const updatePartner = useUpdateTrustedPartner();
  const deletePartner = useDeleteTrustedPartner();

  const getIcon = (iconName: string) => {
    const IconComponent = (LucideIcons as any)[iconName];
    return IconComponent ? <IconComponent className="h-4 w-4" /> : <Building2 className="h-4 w-4" />;
  };

  // Category handlers
  const handleOpenCategoryDialog = (category?: TrustedPartnerCategory) => {
    if (category) {
      setEditingCategory(category);
      setCategoryForm({
        name: category.name,
        slug: category.slug,
        icon_name: category.icon_name,
        description: category.description || '',
      });
    } else {
      setEditingCategory(null);
      setCategoryForm({ name: '', slug: '', icon_name: 'Briefcase', description: '' });
    }
    setCategoryDialogOpen(true);
  };

  const handleSaveCategory = async () => {
    if (editingCategory) {
      await updateCategory.mutateAsync({ id: editingCategory.id, ...categoryForm });
    } else {
      await createCategory.mutateAsync(categoryForm);
    }
    setCategoryDialogOpen(false);
  };

  // Partner handlers
  const handleOpenPartnerDialog = (partner?: TrustedPartner) => {
    if (partner) {
      setEditingPartner(partner);
      setPartnerForm({
        category_id: partner.category_id,
        company_name: partner.company_name,
        contact_name: partner.contact_name || '',
        contact_title: partner.contact_title || '',
        email: partner.email || '',
        phone: partner.phone || '',
        website: partner.website || '',
        linkedin_url: partner.linkedin_url || '',
        description: partner.description || '',
        is_mola_recommended: partner.is_mola_recommended,
      });
    } else {
      setEditingPartner(null);
      setPartnerForm({
        category_id: categories?.[0]?.id || '',
        company_name: '',
        contact_name: '',
        contact_title: '',
        email: '',
        phone: '',
        website: '',
        linkedin_url: '',
        description: '',
        is_mola_recommended: false,
      });
    }
    setPartnerDialogOpen(true);
  };

  const handleSavePartner = async () => {
    if (editingPartner) {
      await updatePartner.mutateAsync({ id: editingPartner.id, ...partnerForm });
    } else {
      await createPartner.mutateAsync(partnerForm);
    }
    setPartnerDialogOpen(false);
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Handshake className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h1 className="text-3xl font-bold">Netværk Administration</h1>
              <p className="text-muted-foreground">Administrer kategorier og partnere</p>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="partners" className="gap-2">
              <Building2 className="h-4 w-4" />
              Partnere
            </TabsTrigger>
            <TabsTrigger value="categories" className="gap-2">
              <FolderOpen className="h-4 w-4" />
              Kategorier
            </TabsTrigger>
          </TabsList>

          {/* Partners Tab */}
          <TabsContent value="partners" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Partnere</CardTitle>
                  <CardDescription>Administrer trusted partners i netværket</CardDescription>
                </div>
                <Button onClick={() => handleOpenPartnerDialog()} disabled={!categories?.length}>
                  <Plus className="h-4 w-4 mr-2" />
                  Tilføj Partner
                </Button>
              </CardHeader>
              <CardContent>
                {partnersLoading ? (
                  <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : partners?.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Building2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>Ingen partnere endnu</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Firma</TableHead>
                        <TableHead>Kategori</TableHead>
                        <TableHead>Kontaktperson</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Handlinger</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {partners?.map((partner) => (
                        <TableRow key={partner.id} className={!partner.is_active ? 'opacity-50' : ''}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{partner.company_name}</span>
                              {partner.is_mola_recommended && (
                                <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            {partner.category && (
                              <Badge variant="outline" className="gap-1">
                                {getIcon(partner.category.icon_name)}
                                {partner.category.name}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>{partner.contact_name || '-'}</TableCell>
                          <TableCell>
                            <Badge variant={partner.is_active ? 'default' : 'secondary'}>
                              {partner.is_active ? 'Aktiv' : 'Inaktiv'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleOpenPartnerDialog(partner)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => deletePartner.mutate(partner.id)}
                                disabled={!partner.is_active}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Categories Tab */}
          <TabsContent value="categories" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Kategorier</CardTitle>
                  <CardDescription>Administrer partner kategorier</CardDescription>
                </div>
                <Button onClick={() => handleOpenCategoryDialog()}>
                  <Plus className="h-4 w-4 mr-2" />
                  Tilføj Kategori
                </Button>
              </CardHeader>
              <CardContent>
                {categoriesLoading ? (
                  <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-12 w-full" />
                    ))}
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12"></TableHead>
                        <TableHead>Ikon</TableHead>
                        <TableHead>Navn</TableHead>
                        <TableHead>Slug</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Handlinger</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {categories?.map((category) => (
                        <TableRow key={category.id} className={!category.is_active ? 'opacity-50' : ''}>
                          <TableCell>
                            <GripVertical className="h-4 w-4 text-muted-foreground" />
                          </TableCell>
                          <TableCell>
                            <div className="p-2 rounded bg-muted w-fit">
                              {getIcon(category.icon_name)}
                            </div>
                          </TableCell>
                          <TableCell className="font-medium">{category.name}</TableCell>
                          <TableCell className="text-muted-foreground">{category.slug}</TableCell>
                          <TableCell>
                            <Badge variant={category.is_active ? 'default' : 'secondary'}>
                              {category.is_active ? 'Aktiv' : 'Inaktiv'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleOpenCategoryDialog(category)}
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => deleteCategory.mutate(category.id)}
                                disabled={!category.is_active}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Category Dialog */}
        <Dialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingCategory ? 'Rediger Kategori' : 'Ny Kategori'}</DialogTitle>
              <DialogDescription>
                {editingCategory ? 'Opdater kategori detaljer' : 'Tilføj en ny partner kategori'}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Navn</Label>
                <Input
                  value={categoryForm.name}
                  onChange={(e) => setCategoryForm({ ...categoryForm, name: e.target.value })}
                  placeholder="f.eks. Advokater"
                />
              </div>
              <div className="space-y-2">
                <Label>Slug</Label>
                <Input
                  value={categoryForm.slug}
                  onChange={(e) => setCategoryForm({ ...categoryForm, slug: e.target.value })}
                  placeholder="f.eks. legal"
                />
              </div>
              <div className="space-y-2">
                <Label>Ikon</Label>
                <Select
                  value={categoryForm.icon_name}
                  onValueChange={(value) => setCategoryForm({ ...categoryForm, icon_name: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ICON_OPTIONS.map((icon) => (
                      <SelectItem key={icon.name} value={icon.name}>
                        <div className="flex items-center gap-2">
                          {getIcon(icon.name)}
                          {icon.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Beskrivelse</Label>
                <Textarea
                  value={categoryForm.description}
                  onChange={(e) => setCategoryForm({ ...categoryForm, description: e.target.value })}
                  placeholder="Kort beskrivelse af kategorien"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCategoryDialogOpen(false)}>
                Annuller
              </Button>
              <Button onClick={handleSaveCategory} disabled={!categoryForm.name || !categoryForm.slug}>
                {editingCategory ? 'Opdater' : 'Opret'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Partner Dialog */}
        <Dialog open={partnerDialogOpen} onOpenChange={setPartnerDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingPartner ? 'Rediger Partner' : 'Ny Partner'}</DialogTitle>
              <DialogDescription>
                {editingPartner ? 'Opdater partner detaljer' : 'Tilføj en ny trusted partner'}
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Kategori *</Label>
                <Select
                  value={partnerForm.category_id}
                  onValueChange={(value) => setPartnerForm({ ...partnerForm, category_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg kategori" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.filter(c => c.is_active).map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        <div className="flex items-center gap-2">
                          {getIcon(category.icon_name)}
                          {category.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Firmanavn *</Label>
                <Input
                  value={partnerForm.company_name}
                  onChange={(e) => setPartnerForm({ ...partnerForm, company_name: e.target.value })}
                  placeholder="f.eks. Kromann Reumert"
                />
              </div>
              <div className="space-y-2">
                <Label>Kontaktperson</Label>
                <Input
                  value={partnerForm.contact_name}
                  onChange={(e) => setPartnerForm({ ...partnerForm, contact_name: e.target.value })}
                  placeholder="f.eks. Thomas Jensen"
                />
              </div>
              <div className="space-y-2">
                <Label>Titel</Label>
                <Input
                  value={partnerForm.contact_title}
                  onChange={(e) => setPartnerForm({ ...partnerForm, contact_title: e.target.value })}
                  placeholder="f.eks. Partner"
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  value={partnerForm.email}
                  onChange={(e) => setPartnerForm({ ...partnerForm, email: e.target.value })}
                  placeholder="email@firma.dk"
                />
              </div>
              <div className="space-y-2">
                <Label>Telefon</Label>
                <Input
                  value={partnerForm.phone}
                  onChange={(e) => setPartnerForm({ ...partnerForm, phone: e.target.value })}
                  placeholder="+45 12 34 56 78"
                />
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input
                  value={partnerForm.website}
                  onChange={(e) => setPartnerForm({ ...partnerForm, website: e.target.value })}
                  placeholder="https://www.firma.dk"
                />
              </div>
              <div className="space-y-2">
                <Label>LinkedIn</Label>
                <Input
                  value={partnerForm.linkedin_url}
                  onChange={(e) => setPartnerForm({ ...partnerForm, linkedin_url: e.target.value })}
                  placeholder="https://linkedin.com/in/..."
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Beskrivelse</Label>
                <Textarea
                  value={partnerForm.description}
                  onChange={(e) => setPartnerForm({ ...partnerForm, description: e.target.value })}
                  placeholder="Hvad kan de hjælpe med? (max 500 tegn)"
                  maxLength={500}
                  rows={3}
                />
              </div>
              <div className="md:col-span-2 flex items-center gap-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
                <Switch
                  checked={partnerForm.is_mola_recommended}
                  onCheckedChange={(checked) => setPartnerForm({ ...partnerForm, is_mola_recommended: checked })}
                />
                <div>
                  <Label className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-amber-500" />
                    MOLA Anbefalet
                  </Label>
                  <p className="text-xs text-muted-foreground">Marker som særligt anbefalet partner</p>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setPartnerDialogOpen(false)}>
                Annuller
              </Button>
              <Button 
                onClick={handleSavePartner} 
                disabled={!partnerForm.company_name || !partnerForm.category_id}
              >
                {editingPartner ? 'Opdater' : 'Opret'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default TrustedPartnersAdmin;
