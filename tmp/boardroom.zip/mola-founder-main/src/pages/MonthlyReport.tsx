import { useMemo, useState } from 'react';
import Layout from '@/components/Layout';
import CompanySelector from '@/components/CompanySelector';
import { useRole } from '@/contexts/RoleContext';
import { useCompanyData } from '@/hooks/useCompanyData';
import BoardroomMonthlyReportForm from '@/components/BoardroomMonthlyReportForm';
import { BoardroomAIFeedbackCard } from '@/components/BoardroomAIFeedbackCard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function MonthlyReport() {
  const { isAdmin, selectedCompanyId } = useRole();
  const { data: myCompany } = useCompanyData();

  const effectiveCompanyId = useMemo(() => {
    if (isAdmin) return selectedCompanyId;
    return myCompany?.id ?? null;
  }, [isAdmin, selectedCompanyId, myCompany?.id]);

  const [reportId, setReportId] = useState<string | undefined>(undefined);

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Rapportering</h1>
            <p className="text-muted-foreground">Indtast månedstal – få AI feedback – og få det til at rykke.</p>
          </div>
          {isAdmin && <CompanySelector />}
        </div>

        {!effectiveCompanyId && isAdmin && (
          <Card>
            <CardContent className="p-6 text-sm text-muted-foreground">
              Vælg et selskab i toppen for at rapportere.
            </CardContent>
          </Card>
        )}

        {effectiveCompanyId && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <BoardroomMonthlyReportForm companyId={effectiveCompanyId} onSaved={setReportId} />
            <BoardroomAIFeedbackCard reportId={reportId} />
          </div>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Definitioner</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <div><span className="font-medium text-foreground">DB / bruttoavance</span>: Omsætning minus vareforbrug/direkte omkostninger.</div>
            <div><span className="font-medium text-foreground">Kapacitetsomkostninger</span>: Faste omkostninger (lokaler, software, administration, etc.).</div>
            <div><span className="font-medium text-foreground">Resultat før skat</span>: Efter alle omkostninger – før skat (og typisk før ekstraordinære poster, hvis I adskiller dem).</div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
