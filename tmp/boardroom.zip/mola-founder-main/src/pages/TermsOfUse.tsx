import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { FileText, Scale, AlertTriangle, Users, Shield, Building2 } from "lucide-react";

const TermsOfUse = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
            <Scale className="h-10 w-10 text-primary" />
            Brugsvilkår
          </h1>
          <p className="text-lg text-muted-foreground">
            Betingelser for brug af MOLA investeringsplatform
          </p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Generelt
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Disse brugsvilkår regulerer din brug af MOLA investeringsplatform, der drives af:
              </p>
              <div className="space-y-3 pl-4">
                <div>
                  <h4 className="font-semibold">MOLA Invest ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 31944937</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
                <div>
                  <h4 className="font-semibold">Viking Capital ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 43500848</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
                <div>
                  <h4 className="font-semibold">Mola LH Invest ApS</h4>
                  <p className="text-sm text-muted-foreground">CVR: 45180212</p>
                  <p className="text-sm text-muted-foreground">Brunbjergvej 4, st, 8240 Risskov</p>
                </div>
              </div>
              <p className="text-muted-foreground mt-4">
                Ved at tilgå og bruge platformen accepterer du disse vilkår. Hvis du ikke accepterer vilkårene, må du ikke bruge platformen.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                Adgang og brugerkonti
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Brugertyper</h4>
                <p className="text-muted-foreground mb-2">
                  Platformen betjener forskellige brugertyper med forskellige adgangsrettigheder:
                </p>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground pl-4">
                  <li><strong>Investorer:</strong> Adgang til porteføljedata for deres investeringer</li>
                  <li><strong>Porteføljevirksomheder (stiftere):</strong> Mulighed for at indberette data og kommunikere</li>
                  <li><strong>Fund partnere:</strong> Adgang til at administrere porteføljer</li>
                  <li><strong>MOLA administratorer:</strong> Fuld administrativ adgang</li>
                  <li><strong>Eksterne rådgivere:</strong> Begrænset adgang til specifikke projekter</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Ansvar for brugerkonto</h4>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Du er ansvarlig for at beskytte dine loginoplysninger</li>
                  <li>Du må ikke dele din adgang med andre</li>
                  <li>Du skal straks informere os om uautoriseret brug af din konto</li>
                  <li>Du er ansvarlig for alle aktiviteter under din konto</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Fortrolighed og datasikkerhed
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Fortrolighedsforpligtelse</h4>
                <p className="text-muted-foreground mb-2">
                  Al information på platformen er fortrolig og må ikke deles med tredjeparter uden skriftlig tilladelse:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Finansielle data og rapporter</li>
                  <li>Forretningsplaner og strategier</li>
                  <li>Investeringsvilkår og -forhold</li>
                  <li>Kontaktoplysninger og persondata</li>
                  <li>Due diligence dokumenter</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Databeskyttelse</h4>
                <p className="text-muted-foreground">
                  Din brug af platformen er underlagt vores{" "}
                  <a href="/databeskyttelse" className="text-primary hover:underline">
                    databeskyttelsespolitik
                  </a>
                  , som beskriver, hvordan vi håndterer personoplysninger i overensstemmelse med GDPR.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                Brug af platformen
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Tilladt brug</h4>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Rapportering af finansielle data og KPI'er</li>
                  <li>Upload og deling af relevante dokumenter</li>
                  <li>Kommunikation vedrørende investeringsforhold</li>
                  <li>Adgang til porteføljeanalyse og rapporter</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Forbudt brug</h4>
                <p className="text-muted-foreground mb-2">
                  Følgende aktiviteter er forbudt:
                </p>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Misbrug, manipulation eller forfalskning af data</li>
                  <li>Uautoriseret adgang til andre brugeres data</li>
                  <li>Upload af virus, malware eller skadelig kode</li>
                  <li>Automatiseret dataudtræk eller scraping</li>
                  <li>Kommerciel brug uden forudgående aftale</li>
                  <li>Krænkelse af tredjeparters rettigheder</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Data og indhold
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Dit indhold</h4>
                <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                  <li>Du bevarer ejerskabet til det indhold, du uploader</li>
                  <li>Du giver os ret til at opbevare og behandle data i henhold til aftalen</li>
                  <li>Du garanterer, at du har ret til at dele det uploadede indhold</li>
                  <li>Du er ansvarlig for nøjagtigheden af indberettede data</li>
                </ul>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Platformens indhold</h4>
                <p className="text-muted-foreground">
                  Alt indhold, design og funktionalitet på platformen ejes af MOLA Invest ApS, Viking Capital ApS og MOLA LH Invest ApS og er beskyttet af dansk og international lovgivning om ophavsret og intellektuelle ejendomsrettigheder.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-primary" />
                Ansvarsfraskrivelse
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Service "som den er"</h4>
                <p className="text-muted-foreground">
                  Platformen leveres "som den er" uden garantier af nogen art. Vi bestræber os på at opretholde høj tilgængelighed, men kan ikke garantere uafbrudt service.
                </p>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Investeringsrådgivning</h4>
                <p className="text-muted-foreground">
                  Information på platformen udgør ikke investeringsrådgivning. Alle investeringsbeslutninger træffes på eget ansvar efter konsultation med professionelle rådgivere.
                </p>
              </div>
              <Separator />
              <div>
                <h4 className="font-semibold mb-2">Ansvarsbegrænsning</h4>
                <p className="text-muted-foreground">
                  Vi er ikke ansvarlige for indirekte tab, driftstab eller tab af data, medmindre det skyldes grov uagtsomhed eller forsæt.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Scale className="h-5 w-5 text-primary" />
                Opsigelse og suspension
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Vi forbeholder os retten til at suspendere eller opsige din adgang ved:
              </p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Brud på disse vilkår</li>
                <li>Misbrug af platformen</li>
                <li>Afslutning af investeringsforhold</li>
                <li>Manglende overholdelse af rapporteringskrav</li>
              </ul>
              <p className="text-muted-foreground mt-4">
                Ved opsigelse bevarer vi data i overensstemmelse med lovkrav og vores databeskyttelsespolitik.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Lovvalg og tvister
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Disse vilkår er underlagt dansk ret. Eventuelle tvister skal søges løst i mindelighed. Hvis dette ikke er muligt, skal tvister afgøres ved danske domstole.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-primary" />
                Ændringer af vilkår
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Vi kan opdatere disse vilkår fra tid til anden. Væsentlige ændringer vil blive kommunikeret via email eller gennem platformen med mindst 30 dages varsel. Fortsat brug af platformen efter ændringer udgør accept af de opdaterede vilkår.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Kontakt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-muted-foreground">
                Spørgsmål til disse vilkår kan rettes til:
              </p>
              <div className="space-y-2">
                <p className="font-semibold">Email:</p>
                <a href="mailto:kontakt@molainvest.dk" className="text-primary hover:underline">
                  kontakt@molainvest.dk
                </a>
              </div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">
                <strong>Senest opdateret:</strong> {new Date().toLocaleDateString('da-DK')}
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Version 1.0
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default TermsOfUse;
