import { useParams, Navigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMonthlyReports } from '@/hooks/useCompanyData';
import { useNPSResponses } from '@/hooks/useCompanyData';
import { useBadges } from '@/hooks/useCompanyData';
import { useValuationSettings } from '@/hooks/useValuationSettings';
import { useRole } from '@/contexts/RoleContext';
import { useRecentlyVisitedCompanies } from '@/hooks/useRecentlyVisitedCompanies';
import Layout from '@/components/Layout';
import { ValuationSettingsCard } from '@/components/ValuationSettingsCard';
import { ValuationSettingsForm } from '@/components/ValuationSettingsForm';
import { DDPartnerTeamCard } from '@/components/DDPartnerTeamCard';
import { ResponsiblePartnerCard } from '@/components/ResponsiblePartnerCard';
import CompanyHealthIndex from '@/components/CompanyHealthIndex';
import { CompanyHealthBreakdown } from '@/components/CompanyHealthBreakdown';
import { CompanyQuickActionsPanel } from '@/components/CompanyQuickActionsPanel';
import ScorecardMetric from '@/components/ScorecardMetric';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { calculateYTD, calculateYOY, getLatestMonth, calculateScorecard, calculateHealthIndex, generateScoreTrend } from '@/lib/metricsCalculations';
import { TrendingUp, TrendingDown, DollarSign, Users, Activity, Target, Wallet, BarChart, Zap, Heart } from 'lucide-react';
import CompanyDocumentsView from '@/components/CompanyDocumentsView';
import CompanyContactsView from '@/components/CompanyContactsView';
import CompanyTimelineView from '@/components/CompanyTimelineView';
import CompanyTasksView from '@/components/CompanyTasksView';
import { CompanyFundingRounds } from '@/components/CompanyFundingRounds';
import { FundingRoundsTimeline } from '@/components/FundingRoundsTimeline';
import { CompanyReturnsView } from '@/components/CompanyReturnsView';
import { MissingReportsAlert } from '@/components/MissingReportsAlert';
import { CompanyMeetingsView } from '@/components/CompanyMeetingsView';
import { CompanyCapTable } from '@/components/CompanyCapTable';
import { cn } from '@/lib/utils';

import { MeetingFrequencySettings } from '@/components/MeetingFrequencySettings';
import { MeetingInvitationSettings } from '@/components/MeetingInvitationSettings';
import { BoardMembersCard } from '@/components/BoardMembersCard';
import { BoardGovernanceChecklist } from '@/components/BoardGovernanceChecklist';
import { BoardOverviewCard } from '@/components/BoardOverviewCard';
import { CompanyPRView } from '@/components/CompanyPRView';
import { CompanyGovernanceChecklist } from '@/components/CompanyGovernanceChecklist';
import { TrustpilotScoreCard } from '@/components/TrustpilotScoreCard';

const Company = () => {
  const { companyId } = useParams<{ companyId: string }>();
  const { isAdmin } = useRole();
  const { trackVisit } = useRecentlyVisitedCompanies();

  // Track company visit for "recently visited" feature
  useEffect(() => {
    if (companyId) {
      trackVisit(companyId);
    }
  }, [companyId, trackVisit]);
  
  // Fetch specific company by ID from URL
  const { data: company, isLoading: companyLoading } = useQuery({
    queryKey: ['company', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', companyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  const { data: monthlyReports = [], isLoading: reportsLoading } = useMonthlyReports(companyId);
  const { data: npsResponses = [] } = useNPSResponses(companyId);
  const { data: badges = [] } = useBadges(companyId);
  const { data: valuationSettings } = useValuationSettings(companyId);

  if (!companyId) {
    return <Navigate to="/" replace />;
  }

  if (companyLoading || reportsLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <p className="text-muted-foreground">Indlæser selskabsdata...</p>
        </div>
      </Layout>
    );
  }

  if (!company) {
    return (
      <Layout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <p className="text-muted-foreground">Selskab ikke fundet</p>
        </div>
      </Layout>
    );
  }

  const currentYear = new Date().getFullYear();
  const ytdData = calculateYTD(monthlyReports, currentYear);
  const yoyData = calculateYOY(monthlyReports, currentYear);
  const latestMetrics = getLatestMonth(monthlyReports);
  const scorecard = calculateScorecard(monthlyReports, npsResponses, currentYear);
  const healthIndex = calculateHealthIndex(
    scorecard.financial,
    scorecard.growth,
    scorecard.transparency,
    scorecard.relationship
  );
  const scorecardTrends = {
    financial: generateScoreTrend(monthlyReports, 'financial'),
    growth: generateScoreTrend(monthlyReports, 'growth'),
    transparency: generateScoreTrend(monthlyReports, 'transparency'),
    relationship: npsResponses.slice(-6).map(nps => nps.score * 10),
  };

  const formatCurrency = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return 'N/A';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string | null | undefined) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('da-DK', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Company Header */}
        <div className="flex items-start gap-6 mb-8">
          {company.logo_url && (
            <img 
              src={company.logo_url} 
              alt={company.name} 
              className="h-24 w-24 rounded-xl object-cover border-2 border-border" 
            />
          )}
          <div className="flex-1">
            <h1 className="text-4xl font-bold mb-2">{company.name}</h1>
            <p className="text-muted-foreground text-lg mb-4">CVR: {company.cvr || 'N/A'}</p>
            
            {/* Quick stats bar */}
            <div className="flex gap-6 text-sm">
              <div>
                <span className="text-muted-foreground">Investeret: </span>
                <span className="font-semibold">
                  {formatCurrency(company.total_invested_amount_dkk ?? company.invested_amount_dkk)}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Ejerandel: </span>
                <span className="font-semibold">
                  {(company.total_equity_share_pct ?? company.equity_share_pct)?.toFixed(2)}%
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">Health Index: </span>
                <span className={`font-semibold ${getHealthColor(healthIndex)}`}>
                  {healthIndex.toFixed(1)}/100
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Valuation Settings (Admin Only) */}
        {isAdmin && (
          valuationSettings ? (
            <ValuationSettingsCard settings={valuationSettings} companyId={company.id} />
          ) : (
            <ValuationSettingsForm companyId={company.id} />
          )
        )}

        {/* DD Partner Team (Only for companies in due diligence) */}
        {isAdmin && company.status && (company.status === 'due_diligence' || company.status.startsWith('dd_')) && (
          <DDPartnerTeamCard companyId={company.id} />
        )}

        {/* Responsible Partner (For active companies and others not in DD) */}
        {isAdmin && company.status && company.status !== 'due_diligence' && !company.status.startsWith('dd_') && (
          <ResponsiblePartnerCard companyId={company.id} companyName={company.name} />
        )}

        {/* Tabs Structure */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="w-full h-auto flex overflow-x-auto gap-1 p-1 bg-muted rounded-lg">
            <TabsTrigger value="overview" className="flex-shrink-0 whitespace-nowrap">Oversigt</TabsTrigger>
            <TabsTrigger value="funding" className="flex-shrink-0 whitespace-nowrap">Funding</TabsTrigger>
            {isAdmin && <TabsTrigger value="returns" className="flex-shrink-0 whitespace-nowrap">Returns & Exit</TabsTrigger>}
            <TabsTrigger value="captable" className="flex-shrink-0 whitespace-nowrap">Cap Table</TabsTrigger>
            <TabsTrigger value="governance" className="flex-shrink-0 whitespace-nowrap">Governance</TabsTrigger>
            <TabsTrigger value="tasks" className="flex-shrink-0 whitespace-nowrap">Opgaver</TabsTrigger>
            <TabsTrigger value="meetings" className="flex-shrink-0 whitespace-nowrap">Møder</TabsTrigger>
            {company.has_board && (
              <TabsTrigger value="board" className="flex-shrink-0 whitespace-nowrap">
                <Users className="h-4 w-4 mr-2" />
                Bestyrelse
              </TabsTrigger>
            )}
            {isAdmin && <TabsTrigger value="settings" className="flex-shrink-0 whitespace-nowrap">Indstillinger</TabsTrigger>}
            <TabsTrigger value="documents" className="flex-shrink-0 whitespace-nowrap">Dokumenter</TabsTrigger>
            <TabsTrigger value="contacts" className="flex-shrink-0 whitespace-nowrap">Kontakter</TabsTrigger>
            <TabsTrigger value="timeline" className="flex-shrink-0 whitespace-nowrap">Timeline</TabsTrigger>
            {isAdmin && <TabsTrigger value="pr" className="flex-shrink-0 whitespace-nowrap">PR</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Missing Reports Alert */}
            <MissingReportsAlert 
              companyName={company.name}
              lastReportMonth={latestMetrics?.month}
              lastReportYear={latestMetrics?.year}
            />

            {/* Quick Actions Panel */}
            {isAdmin && (
              <CompanyQuickActionsPanel
                companyId={companyId!}
                companyName={company.name}
                companyEmail={company.email}
                companyPhone={company.phone}
                googleDriveUrl={company.google_drive_url}
                company={company}
              />
            )}

            {/* Trustpilot Score Card */}
            <TrustpilotScoreCard companyId={company.id} showManageButton={isAdmin} />

            {/* Latest Month Metrics */}
            {latestMetrics && (
              <div>
                <h2 className="text-2xl font-bold mb-4">
                  Seneste måned ({latestMetrics.month}/{latestMetrics.year})
                </h2>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Omsætning</p>
                    <p className="text-2xl font-bold">{formatCurrency(latestMetrics.revenue)}</p>
                    {latestMetrics.revenueChange !== 0 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {latestMetrics.revenueChange > 0 ? '+' : ''}
                        {latestMetrics.revenueChange.toFixed(1)}% vs forrige måned
                      </p>
                    )}
                  </div>
                  <DollarSign className="h-8 w-8 text-primary" />
                </div>
              </Card>
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">EBITDA</p>
                    <p className="text-2xl font-bold">{formatCurrency(latestMetrics.ebitda)}</p>
                    {latestMetrics.ebitdaChange !== 0 && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {latestMetrics.ebitdaChange > 0 ? '+' : ''}
                        {latestMetrics.ebitdaChange.toFixed(1)}% vs forrige måned
                      </p>
                    )}
                  </div>
                  <Activity className="h-8 w-8 text-primary" />
                </div>
              </Card>
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Nye kunder</p>
                    <p className="text-2xl font-bold">{latestMetrics.newCustomers}</p>
                  </div>
                  <Users className="h-8 w-8 text-primary" />
                </div>
              </Card>
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Likviditet</p>
                    <p className="text-2xl font-bold">{formatCurrency(latestMetrics.cash)}</p>
                  </div>
                  <Wallet className="h-8 w-8 text-primary" />
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* YTD Metrics */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Year-to-Date (YTD {currentYear})</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">YTD Omsætning</p>
              <p className="text-2xl font-bold">{formatCurrency(ytdData.revenue)}</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">YTD EBITDA</p>
              <p className="text-2xl font-bold">{formatCurrency(ytdData.ebitda)}</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">EBITDA Margin</p>
              <p className="text-2xl font-bold">{ytdData.margin.toFixed(1)}%</p>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Nuværende likviditet</p>
              <p className="text-2xl font-bold">{formatCurrency(ytdData.cash)}</p>
            </Card>
          </div>
        </div>

        {/* YOY Metrics */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Year-over-Year (YOY)</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">YOY Omsætning</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold">{yoyData.revenueGrowth.toFixed(1)}%</p>
                {yoyData.revenueGrowth >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">YOY EBITDA</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold">{yoyData.ebitdaGrowth.toFixed(1)}%</p>
                {yoyData.ebitdaGrowth >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Margin ændring</p>
              <div className="flex items-center gap-2">
                <p className="text-2xl font-bold">
                  {yoyData.marginChange > 0 ? '+' : ''}
                  {yoyData.marginChange.toFixed(1)} p.p.
                </p>
                {yoyData.marginChange >= 0 ? (
                  <TrendingUp className="h-5 w-5 text-green-500" />
                ) : (
                  <TrendingDown className="h-5 w-5 text-red-500" />
                )}
              </div>
            </Card>
            <Card className="p-4">
              <p className="text-sm text-muted-foreground">Sammenlignings periode</p>
              <p className="text-sm font-medium">{currentYear} vs {currentYear - 1}</p>
            </Card>
          </div>
        </div>

        {/* MOLA Scorecard */}
        <div>
          <h2 className="text-2xl font-bold mb-4">MOLA Scorecard</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <ScorecardMetric
              title="Financial"
              score={scorecard.financial}
              icon={DollarSign}
              color="text-blue-500"
              trend={scorecardTrends.financial}
            />
            <ScorecardMetric
              title="Growth"
              score={scorecard.growth}
              icon={BarChart}
              color="text-green-500"
              trend={scorecardTrends.growth}
            />
            <ScorecardMetric
              title="Transparency"
              score={scorecard.transparency}
              icon={Zap}
              color="text-purple-500"
              trend={scorecardTrends.transparency}
            />
            <ScorecardMetric
              title="Relationship"
              score={scorecard.relationship}
              icon={Heart}
              color="text-pink-500"
              trend={scorecardTrends.relationship}
            />
          </div>
        </div>

            {/* Health Index with Breakdown */}
            <CompanyHealthBreakdown
              healthIndex={healthIndex}
              financialScore={scorecard.financial}
              growthScore={scorecard.growth}
              transparencyScore={scorecard.transparency}
              relationshipScore={scorecard.relationship}
            />
          </TabsContent>

          <TabsContent value="funding" className="space-y-6">
            <FundingRoundsTimeline companyId={companyId!} />
            <CompanyFundingRounds companyId={companyId!} />
          </TabsContent>

          {isAdmin && (
            <TabsContent value="returns" className="space-y-6">
              <CompanyReturnsView 
                companyId={companyId!} 
                fundId={company.fund_id || ''} 
                investedAmount={company.invested_amount_dkk || 0}
              />
            </TabsContent>
          )}

          <TabsContent value="captable" className="space-y-6">
            <CompanyCapTable companyId={companyId!} />
          </TabsContent>

          <TabsContent value="governance" className="space-y-6">
            <CompanyGovernanceChecklist
              companyId={companyId!}
              year={currentYear}
              fiscalYearEndMonth={company.fiscal_year_end_month || 12}
              fiscalYearEndDay={company.fiscal_year_end_day || 31}
              canManage={isAdmin}
            />
          </TabsContent>

          <TabsContent value="tasks" className="space-y-6">
            <CompanyTasksView companyId={companyId!} />
          </TabsContent>

          <TabsContent value="meetings" className="space-y-6">
            <CompanyMeetingsView companyId={companyId!} />
          </TabsContent>

          {company.has_board && (
            <TabsContent value="board" className="space-y-6">
              <BoardOverviewCard 
                companyId={companyId!} 
                fiscalYearEndMonth={company.fiscal_year_end_month || 12}
                fiscalYearEndDay={company.fiscal_year_end_day || 31}
              />
              <BoardMembersCard companyId={companyId!} canManage={isAdmin} />
              <BoardGovernanceChecklist
                companyId={companyId!}
                year={new Date().getFullYear()}
                fiscalYearEndMonth={company.fiscal_year_end_month || 12}
                fiscalYearEndDay={company.fiscal_year_end_day || 31}
                canManage={isAdmin}
              />
            </TabsContent>
          )}

          {isAdmin && (
            <TabsContent value="settings" className="space-y-6">
              <h2 className="text-2xl font-bold">Møde Indstillinger</h2>
              <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
                <MeetingFrequencySettings
                  companyId={companyId!}
                  currentFrequency={company.meeting_frequency}
                  currentDuration={company.meeting_duration_minutes}
                  lastInvitationSent={company.last_meeting_invitation_sent_at}
                />
                <MeetingInvitationSettings
                  companyId={companyId!}
                  autoInviteResponsiblePartner={company.auto_invite_responsible_partner}
                  autoInviteCoinvestors={company.auto_invite_coinvestors}
                  autoInviteDdPartners={company.auto_invite_dd_partners}
                  responsiblePartnerId={company.responsible_partner_id}
                />
              </div>
            </TabsContent>
          )}

          <TabsContent value="documents" className="space-y-6">
            <CompanyDocumentsView companyId={companyId!} />
          </TabsContent>

          <TabsContent value="contacts" className="space-y-6">
            <CompanyContactsView companyId={companyId!} />
          </TabsContent>

          <TabsContent value="timeline" className="space-y-6">
            <CompanyTimelineView companyId={companyId!} />
          </TabsContent>

          {isAdmin && (
            <TabsContent value="pr" className="space-y-6">
              <CompanyPRView companyId={companyId!} />
            </TabsContent>
          )}
        </Tabs>
      </div>
    </Layout>
  );
};

export default Company;
