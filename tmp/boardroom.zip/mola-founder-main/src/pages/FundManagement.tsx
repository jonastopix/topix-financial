import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useFunds } from '@/hooks/useReturnsData';
import { useFundOwnership, useFundManagementMutations } from '@/hooks/useFundManagement';
import { FundOwnershipTable } from '@/components/FundOwnershipTable';
import { AddFundOwnershipDialog } from '@/components/AddFundOwnershipDialog';
import { FundsList } from '@/components/FundsList';
import { CreateFundDialog } from '@/components/CreateFundDialog';
import { EditFundDialog } from '@/components/EditFundDialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Building2 } from 'lucide-react';

export default function FundManagement() {
  const { data: funds, isLoading: fundsLoading } = useFunds();
  const [selectedFundId, setSelectedFundId] = useState<string>('');
  const [editingFund, setEditingFund] = useState<any>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  
  const { data: ownerships, isLoading: ownershipsLoading } = useFundOwnership(selectedFundId);
  
  const { createFund, updateFund, deleteFund, addOwnership, deleteOwnership } = useFundManagementMutations();

  const handleEditFund = (fund: any) => {
    setEditingFund(fund);
    setEditDialogOpen(true);
  };

  if (fundsLoading) {
    return (
      <Layout>
        <div className="space-y-6 max-w-full">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-96 w-full" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-full">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Building2 className="h-8 w-8" />
            Fund Management
          </h1>
          <p className="text-muted-foreground mt-2">
            Administrer fonde og ejerskabsstrukturer
          </p>
        </div>

        <Tabs defaultValue="funds" className="space-y-4">
          <TabsList>
            <TabsTrigger value="funds">Fonde</TabsTrigger>
            <TabsTrigger value="ownership">Ejerskabsstruktur</TabsTrigger>
          </TabsList>

          <TabsContent value="funds" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Fonde</CardTitle>
                    <CardDescription>
                      Opret og administrer dine investeringsfonde
                    </CardDescription>
                  </div>
                  <CreateFundDialog onCreate={(fund) => createFund.mutate(fund)} />
                </div>
              </CardHeader>
              <CardContent>
                <FundsList
                  funds={funds || []}
                  onEdit={handleEditFund}
                  onDelete={(id) => deleteFund.mutate(id)}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ownership" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fund Ejerskabsstruktur</CardTitle>
                <CardDescription>
                  Definer hvem der ejer andele i hver fond
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="w-64">
                    <Select value={selectedFundId} onValueChange={setSelectedFundId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg en fond" />
                      </SelectTrigger>
                      <SelectContent>
                        {funds?.map((fund) => (
                          <SelectItem key={fund.id} value={fund.id}>
                            {fund.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {selectedFundId && (
                    <AddFundOwnershipDialog
                      fundId={selectedFundId}
                      onAdd={(ownership) => addOwnership.mutate(ownership)}
                    />
                  )}
                </div>

                {selectedFundId ? (
                  ownershipsLoading ? (
                    <Skeleton className="h-64 w-full" />
                  ) : (
                    <FundOwnershipTable
                      ownerships={ownerships || []}
                      onDelete={(id) => deleteOwnership.mutate(id)}
                    />
                  )
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    Vælg en fond for at se og administrere ejerskab
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <EditFundDialog
          fund={editingFund}
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          onUpdate={(fund) => updateFund.mutate(fund)}
        />
      </div>
    </Layout>
  );
}
