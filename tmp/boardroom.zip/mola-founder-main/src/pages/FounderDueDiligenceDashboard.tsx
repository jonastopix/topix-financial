import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { CheckCircle2, Circle, AlertCircle, Target, HelpCircle, BookOpen, MessageCircle } from 'lucide-react';
import { useActiveAnnouncements } from '@/hooks/useActiveAnnouncements';
import { AnnouncementsFeed } from '@/components/AnnouncementsFeed';
import { formatNumber } from '@/lib/formatters';
import MyTasksWidget from '@/components/MyTasksWidget';

interface DDCase {
  id: string;
  status: string;
  companies?: { name: string };
}

interface DDTemplate {
  id: string;
  item_name: string;
  category: string;
  required: boolean;
}

interface DDProgress {
  template_id: string;
  completed: boolean;
}

interface FounderDueDiligenceDashboardProps {
  ddCase: DDCase;
  templates: DDTemplate[];
  progress: DDProgress[];
  companyId?: string;
}

export function FounderDueDiligenceDashboard({ 
  ddCase, 
  templates, 
  progress,
  companyId 
}: FounderDueDiligenceDashboardProps) {
  const navigate = useNavigate();
  const { data: announcements = [] } = useActiveAnnouncements(companyId);

  const completedCount = progress.filter(p => p.completed).length;
  const totalCount = templates.length;
  const progressPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  // Get next 5 incomplete tasks
  const incompleteTasks = templates
    .filter(t => !progress.find(p => p.template_id === t.id && p.completed))
    .slice(0, 5);

  const statusLabels: Record<string, string> = {
    not_started: 'Ikke startet',
    in_progress: 'I gang',
    pending_review: 'Afventer gennemgang',
    approved: 'Godkendt',
    rejected: 'Afvist',
  };

  const statusColors: Record<string, string> = {
    not_started: 'outline',
    in_progress: 'warning',
    pending_review: 'default',
    approved: 'success',
    rejected: 'destructive',
  };

  return (
    <div className="space-y-8 animate-fade-up">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl glass-card p-8 md:p-12">
        <div className="absolute inset-0 gradient-primary opacity-5" />
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold gradient-text mb-2">Due Diligence</h1>
              <p className="text-muted-foreground text-lg">
                {ddCase.companies?.name || 'Dit selskab'} - Følg din fremdrift
              </p>
            </div>
            <Badge 
              variant={statusColors[ddCase.status] as any || 'outline'} 
              className="w-fit text-base px-4 py-2"
            >
              {statusLabels[ddCase.status] || ddCase.status}
            </Badge>
          </div>
        </div>
      </div>

      {/* Main Progress Card - Circular Design */}
      <Card className="p-8 md:p-12 glass-card hover-lift">
        <div className="flex flex-col items-center text-center">
          {/* Large Circular Progress */}
          <div className="relative w-48 h-48 md:w-64 md:h-64 mb-8">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="50%"
                cy="50%"
                r="45%"
                stroke="currentColor"
                strokeWidth="12"
                fill="none"
                className="text-muted"
              />
              <circle
                cx="50%"
                cy="50%"
                r="45%"
                stroke="url(#gradient)"
                strokeWidth="12"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 45}`}
                strokeDashoffset={`${2 * Math.PI * 45 * (1 - progressPercentage / 100)}`}
                className="transition-all duration-1000"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="hsl(var(--primary))" />
                  <stop offset="100%" stopColor="hsl(var(--accent))" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-5xl md:text-6xl font-bold gradient-text">
                {formatNumber(progressPercentage, 0)}%
              </p>
              <p className="text-sm text-muted-foreground mt-2">Afsluttet</p>
            </div>
          </div>

          <div className="mb-6">
            <p className="text-2xl font-semibold mb-2">
              {completedCount} af {totalCount} punkter
            </p>
            <p className="text-muted-foreground">
              {totalCount - completedCount === 0 
                ? '🎉 Fantastisk! Alle opgaver er afsluttet!' 
                : `${totalCount - completedCount} opgaver tilbage`}
            </p>
          </div>

          <Button 
            onClick={() => navigate('/my-due-diligence')} 
            size="lg"
            className="gap-2 gradient-primary text-lg px-8"
          >
            <Target className="h-5 w-5" />
            Gå til tjekliste
          </Button>
        </div>
      </Card>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Upcoming Tasks - Kanban Style */}
        <Card className="p-6 glass-card hover-lift animate-slide-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 rounded-lg bg-primary/10">
              <AlertCircle className="h-5 w-5 text-primary" />
            </div>
            <h3 className="text-xl font-semibold">Næste opgaver</h3>
          </div>
          {incompleteTasks.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle2 className="h-16 w-16 text-success mx-auto mb-4" />
              <p className="text-lg font-semibold mb-2">Alle opgaver afsluttet!</p>
              <p className="text-sm text-muted-foreground">
                Fantastisk arbejde! 🎉
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {incompleteTasks.map((task, index) => (
                <div 
                  key={task.id} 
                  className="p-4 rounded-lg border border-border/50 bg-card/50 hover:bg-card/80 transition-all hover-lift"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">
                      <Circle className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium mb-1">{task.item_name}</p>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="text-xs">
                          {task.category}
                        </Badge>
                        {task.required && (
                          <Badge variant="destructive" className="text-xs">
                            Påkrævet
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {incompleteTasks.length > 0 && (
            <Button 
              variant="outline" 
              className="w-full mt-6"
              onClick={() => navigate('/my-due-diligence')}
            >
              Se alle opgaver
            </Button>
          )}
        </Card>

        {/* Help & Contact Card */}
        <Card className="p-6 glass-card hover-lift animate-slide-in delay-100">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 rounded-lg bg-accent/10">
              <HelpCircle className="h-5 w-5 text-accent" />
            </div>
            <h3 className="text-xl font-semibold">Brug for hjælp?</h3>
          </div>
          <p className="text-muted-foreground mb-6">
            Har du spørgsmål til due diligence processen? Vi er her for at hjælpe dig!
          </p>
          <div className="space-y-3">
            <Button 
              className="w-full justify-start gap-3 h-auto py-4"
              onClick={() => navigate('/contact')}
              variant="gradient"
            >
              <MessageCircle className="h-5 w-5" />
              <div className="text-left">
                <p className="font-semibold">Kontakt MOLA teamet</p>
                <p className="text-xs opacity-80">Direkte support fra dit team</p>
              </div>
            </Button>
            <Button 
              variant="outline"
              className="w-full justify-start gap-3 h-auto py-4"
              onClick={() => navigate('/support')}
            >
              <HelpCircle className="h-5 w-5" />
              <div className="text-left">
                <p className="font-semibold">Support & FAQ</p>
                <p className="text-xs text-muted-foreground">Find svar på almindelige spørgsmål</p>
              </div>
            </Button>
            {/* Resource Hub - midlertidigt skjult
            <Button 
              variant="outline"
              className="w-full justify-start gap-3 h-auto py-4"
              onClick={() => navigate('/resources')}
            >
              <BookOpen className="h-5 w-5" />
              <div className="text-left">
                <p className="font-semibold">Ressourcer & guides</p>
                <p className="text-xs text-muted-foreground">Dokumentation og vejledninger</p>
              </div>
            </Button>
            */}
          </div>
        </Card>
      </div>

      {/* My Tasks Widget */}
      <div className="animate-fade-up delay-150">
        <MyTasksWidget />
      </div>

      {/* Announcements */}
      <div className="animate-fade-up delay-200">
        <AnnouncementsFeed announcements={announcements} />
      </div>
    </div>
  );
}
