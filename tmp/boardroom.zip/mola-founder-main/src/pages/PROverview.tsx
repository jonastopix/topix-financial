import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { usePortfolioPR, CompanyPRSummary } from '@/hooks/usePortfolioPR';
import { usePortfolioPendingPR } from '@/hooks/usePortfolioPendingPR';
import PendingPRSection from '@/components/PendingPRSection';
import { useNavigate } from 'react-router-dom';
import {
  Newspaper,
  TrendingUp,
  TrendingDown,
  Minus,
  ExternalLink,
  Building2,
  BarChart3,
  Award,
  Search,
  ArrowRight,
  Clock,
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from 'recharts';

const getSentimentBadge = (sentiment: string | null) => {
  switch (sentiment) {
    case 'positive':
      return (
        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
          <TrendingUp className="h-3 w-3 mr-1" />
          Positiv
        </Badge>
      );
    case 'negative':
      return (
        <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
          <TrendingDown className="h-3 w-3 mr-1" />
          Negativ
        </Badge>
      );
    case 'neutral':
      return (
        <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200">
          <Minus className="h-3 w-3 mr-1" />
          Neutral
        </Badge>
      );
    default:
      return null;
  }
};

const formatDate = (dateString: string | null) => {
  if (!dateString) return '-';
  try {
    return new Date(dateString).toLocaleDateString('da-DK', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return '-';
  }
};

const SENTIMENT_COLORS = {
  positive: '#22c55e',
  neutral: '#6b7280',
  negative: '#ef4444',
};

export default function PROverview() {
  const { prStats, isLoading, error, showOnlySaved, setShowOnlySaved } = usePortfolioPR();
  const { totalPending } = usePortfolioPendingPR();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Layout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-48" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-28" />
            ))}
          </div>
          <Skeleton className="h-96" />
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="text-center py-12">
          <p className="text-destructive">Kunne ikke hente PR-data</p>
        </div>
      </Layout>
    );
  }

  const hasArticles = prStats?.totalArticles && prStats.totalArticles > 0;
  const companiesWithPR = prStats?.articlesByCompany.filter(c => c.totalArticles > 0) || [];

  const sentimentPieData = [
    { name: 'Positiv', value: prStats?.sentimentBreakdown.positive || 0, color: SENTIMENT_COLORS.positive },
    { name: 'Neutral', value: prStats?.sentimentBreakdown.neutral || 0, color: SENTIMENT_COLORS.neutral },
    { name: 'Negativ', value: prStats?.sentimentBreakdown.negative || 0, color: SENTIMENT_COLORS.negative },
  ].filter(d => d.value > 0);

  const leaderboardData = companiesWithPR.slice(0, 10).map(company => ({
    name: company.name.length > 15 
      ? company.name.substring(0, 15) + '...' 
      : company.name,
    fullName: company.name,
    Positiv: company.positiveCount,
    Neutral: company.neutralCount,
    Negativ: company.negativeCount,
    total: company.totalArticles,
    companyId: company.id,
  }));

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">PR Overblik</h1>
            <p className="text-muted-foreground">
              Aggregeret presseomtale for hele porteføljen
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Switch
              id="show-saved"
              checked={showOnlySaved}
              onCheckedChange={setShowOnlySaved}
            />
            <Label htmlFor="show-saved" className="text-sm">
              Kun gemte artikler
            </Label>
          </div>
        </div>

        {/* Pending Articles Section - Admin Review */}
        <PendingPRSection />

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {showOnlySaved ? 'Gemte Artikler' : 'Alle Artikler'}
              </CardTitle>
              <Newspaper className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{prStats?.totalArticles || 0}</div>
              <p className="text-xs text-muted-foreground">
                På tværs af porteføljen
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Positiv Omtale</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {prStats?.sentimentBreakdown.positive || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                {prStats?.totalArticles ? 
                  `${Math.round((prStats.sentimentBreakdown.positive / prStats.totalArticles) * 100)}% af total` 
                  : '0%'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Negativ Omtale</CardTitle>
              <TrendingDown className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">
                {prStats?.sentimentBreakdown.negative || 0}
              </div>
              <p className="text-xs text-muted-foreground">
                {prStats?.totalArticles ? 
                  `${Math.round((prStats.sentimentBreakdown.negative / prStats.totalArticles) * 100)}% af total` 
                  : '0%'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Selskaber med PR</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {companiesWithPR.length}
              </div>
              <p className="text-xs text-muted-foreground">
                Har {showOnlySaved ? 'gemte' : 'søgte'} artikler
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Empty State with Quick Navigation */}
        {!hasArticles && (
          <Card className="border-dashed">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 h-16 w-16 rounded-full bg-muted flex items-center justify-center">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <CardTitle>Kom i gang med PR-overvågning</CardTitle>
              <CardDescription className="max-w-md mx-auto">
                For at se PR-statistik her, skal du først søge efter artikler på de enkelte selskabers PR-fane
                {showOnlySaved && ' og gemme dem'}.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-center text-sm text-muted-foreground">
                  Vælg et selskab for at starte:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {prStats?.allCompanies.slice(0, 8).map(company => (
                    <Button
                      key={company.id}
                      variant="outline"
                      className="justify-between h-auto py-3"
                      onClick={() => navigate(`/company/${company.id}?tab=pr`)}
                    >
                      <span className="truncate">{company.name}</span>
                      <ArrowRight className="h-4 w-4 ml-2 shrink-0" />
                    </Button>
                  ))}
                </div>
                {prStats?.allCompanies && prStats.allCompanies.length > 8 && (
                  <p className="text-center text-sm text-muted-foreground">
                    + {prStats.allCompanies.length - 8} flere selskaber
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Charts Row - Only show if we have data */}
        {hasArticles && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Sentiment Pie Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Sentiment Fordeling
                </CardTitle>
                <CardDescription>
                  Fordeling af positiv, neutral og negativ omtale
                </CardDescription>
              </CardHeader>
              <CardContent>
                {sentimentPieData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={sentimentPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {sentimentPieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    Ingen sentiment-data
                  </div>
                )}
              </CardContent>
            </Card>

            {/* PR Leaderboard Bar Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  PR Leaderboard
                </CardTitle>
                <CardDescription>
                  Selskaber rangeret efter presseomtale
                </CardDescription>
              </CardHeader>
              <CardContent>
                {leaderboardData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={leaderboardData} layout="vertical">
                      <XAxis type="number" />
                      <YAxis 
                        dataKey="name" 
                        type="category" 
                        width={120}
                        tick={{ fontSize: 12 }}
                      />
                      <Tooltip 
                        formatter={(value, name) => [value, name]}
                        labelFormatter={(label) => {
                          const item = leaderboardData.find(d => d.name === label);
                          return item?.fullName || label;
                        }}
                      />
                      <Legend />
                      <Bar dataKey="Positiv" stackId="a" fill={SENTIMENT_COLORS.positive} />
                      <Bar dataKey="Neutral" stackId="a" fill={SENTIMENT_COLORS.neutral} />
                      <Bar dataKey="Negativ" stackId="a" fill={SENTIMENT_COLORS.negative} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex items-center justify-center h-[250px] text-muted-foreground">
                    Ingen data endnu
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Company Leaderboard Table - Only show if we have data */}
        {hasArticles && (
          <Card>
            <CardHeader>
              <CardTitle>PR Leaderboard - Detaljer</CardTitle>
              <CardDescription>
                Hvilke selskaber får mest presseomtale
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">#</TableHead>
                    <TableHead>Selskab</TableHead>
                    <TableHead className="text-center">Total</TableHead>
                    <TableHead className="text-center">Positiv</TableHead>
                    <TableHead className="text-center">Neutral</TableHead>
                    <TableHead className="text-center">Negativ</TableHead>
                    <TableHead className="text-right">Handling</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {companiesWithPR.map((company, index) => (
                    <TableRow key={company.id}>
                      <TableCell className="font-medium">
                        {index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : index + 1}
                      </TableCell>
                      <TableCell className="font-medium">{company.name}</TableCell>
                      <TableCell className="text-center">{company.totalArticles}</TableCell>
                      <TableCell className="text-center text-green-600">{company.positiveCount}</TableCell>
                      <TableCell className="text-center text-gray-500">{company.neutralCount}</TableCell>
                      <TableCell className="text-center text-red-600">{company.negativeCount}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => navigate(`/company/${company.id}?tab=pr`)}
                        >
                          Se detaljer
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Recent Articles - Only show if we have data */}
        {hasArticles && prStats?.recentArticles && prStats.recentArticles.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Seneste {showOnlySaved ? 'Gemte ' : ''}Artikler</CardTitle>
              <CardDescription>
                De nyeste {showOnlySaved ? 'gemte ' : ''}PR-artikler på tværs af porteføljen
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Selskab</TableHead>
                    <TableHead>Titel</TableHead>
                    <TableHead>Kilde</TableHead>
                    <TableHead>Sentiment</TableHead>
                    <TableHead>Dato</TableHead>
                    <TableHead className="text-right">Link</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prStats.recentArticles.map((article) => (
                    <TableRow key={article.id}>
                      <TableCell>
                        <Button
                          variant="link"
                          className="p-0 h-auto"
                          onClick={() => navigate(`/company/${article.company_id}?tab=pr`)}
                        >
                          {article.company_name}
                        </Button>
                      </TableCell>
                      <TableCell className="max-w-xs truncate" title={article.title}>
                        {article.title}
                      </TableCell>
                      <TableCell>{article.source || '-'}</TableCell>
                      <TableCell>{getSentimentBadge(article.sentiment)}</TableCell>
                      <TableCell>{formatDate(article.published_at)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => window.open(article.url, '_blank')}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* All Companies Quick Access - Always show at bottom */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Alle Porteføljeselskaber
            </CardTitle>
            <CardDescription>
              Klik på et selskab for at gå til dets PR-fane og søge efter artikler
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
              {prStats?.allCompanies.map(company => {
                const companyStats = prStats.articlesByCompany.find(c => c.id === company.id);
                const articleCount = companyStats?.totalArticles || 0;
                
                return (
                  <Button
                    key={company.id}
                    variant="outline"
                    className="justify-between h-auto py-3 px-4"
                    onClick={() => navigate(`/company/${company.id}?tab=pr`)}
                  >
                    <span className="truncate flex-1 text-left">{company.name}</span>
                    {articleCount > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {articleCount}
                      </Badge>
                    )}
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
