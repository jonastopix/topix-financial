import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import TokenizedMonthlyReportForm from '@/components/TokenizedMonthlyReportForm';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const TokenizedMonthlyReport = () => {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tokenData, setTokenData] = useState<any>(null);
  const [companyData, setCompanyData] = useState<any>(null);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const validateToken = async () => {
      if (!token) {
        setError('Ugyldigt link - intet token fundet');
        setLoading(false);
        return;
      }

      try {
        // Fetch and validate token
        const { data: tokenRecord, error: tokenError } = await supabase
          .from('monthly_report_tokens')
          .select('*')
          .eq('token', token)
          .single();

        if (tokenError || !tokenRecord) {
          setError('Ugyldigt eller udløbet link. Kontakt venligst MOLA for et nyt link.');
          setLoading(false);
          return;
        }

        // Check if already used (tokens expire after single use only)
        if (tokenRecord.status === 'used') {
          setError('Dette link er allerede blevet brugt til at indsende en rapport.');
          setLoading(false);
          return;
        }

        // Fetch company data
        const { data: company, error: companyError } = await supabase
          .from('companies')
          .select('id, name, logo_url')
          .eq('id', tokenRecord.company_id)
          .single();

        if (companyError || !company) {
          setError('Kunne ikke hente virksomhedsdata.');
          setLoading(false);
          return;
        }

        setTokenData(tokenRecord);
        setCompanyData(company);
        setLoading(false);
      } catch (err: any) {
        console.error('Error validating token:', err);
        setError('Der opstod en fejl ved validering af linket.');
        setLoading(false);
      }
    };

    validateToken();
  }, [token]);

  const handleSubmitSuccess = () => {
    setSubmitted(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Validerer link...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20 p-4">
        <Alert variant="destructive" className="max-w-md">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Fejl</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted/20 p-4">
        <Alert className="max-w-md border-primary bg-primary/5">
          <CheckCircle className="h-4 w-4 text-primary" />
          <AlertTitle>Tak for din rapport!</AlertTitle>
          <AlertDescription>
            Din månedsrapport er modtaget og vil blive behandlet hurtigst muligt. Du kan nu lukke dette vindue.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <TokenizedMonthlyReportForm 
        token={token!}
        tokenData={tokenData}
        companyData={companyData}
        onSubmitSuccess={handleSubmitSuccess}
      />
    </div>
  );
};

export default TokenizedMonthlyReport;
