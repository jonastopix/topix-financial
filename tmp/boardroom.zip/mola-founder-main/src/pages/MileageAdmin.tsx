import { useState } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { 
  Car, 
  Plus, 
  Settings, 
  Trash2, 
  Send, 
  Building2,
  Landmark,
  CalendarDays,
  Pencil,
  CheckCircle2,
  History
} from 'lucide-react';
import Layout from '@/components/Layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  useMileageSettings, 
  useMileageEntries, 
  useMileageMutations,
  useUnsubmittedEntriesByPayingEntity,
  MileageEntry,
  PayingEntityType
} from '@/hooks/useMileage';
import { supabase } from '@/integrations/supabase/client';
import { MileageSettingsDialog } from '@/components/MileageSettingsDialog';
import { SendMileageReportDialog } from '@/components/SendMileageReportDialog';
import { MileageQuickSheet } from '@/components/MileageQuickSheet';
import { EditMileageEntryDialog } from '@/components/EditMileageEntryDialog';
import { ExportMileageReportDialog } from '@/components/ExportMileageReportDialog';

const formatDKK = (value: number) => value.toLocaleString('da-DK', { style: 'currency', currency: 'DKK' });

const MONTHS = [
  'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni',
  'Juli', 'August', 'September', 'Oktober', 'November', 'December'
];

export default function MileageAdmin() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;
  
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState<string>('all');
  const [showSettings, setShowSettings] = useState(false);
  const [showRegisterSheet, setShowRegisterSheet] = useState(false);
  const [sendReportEntity, setSendReportEntity] = useState<{ id: string; type: PayingEntityType } | null>(null);
  const [editingEntry, setEditingEntry] = useState<MileageEntry | null>(null);
  
  const { data: settings } = useMileageSettings();
  const { data: entries = [], isLoading } = useMileageEntries({
    year: selectedYear,
    month: selectedMonth,
    payingCompanyId: selectedCompanyFilter !== 'all' ? selectedCompanyFilter : undefined,
  });
  const unsubmittedByEntity = useUnsubmittedEntriesByPayingEntity();
  const { deleteEntry } = useMileageMutations();
  
  // Get unique companies from entries
  const { data: companies = [] } = useQuery({
    queryKey: ['companies-for-mileage-filter'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
  });
  
  const years = Array.from({ length: 5 }, (_, i) => currentYear - i);
  
  const totalKm = entries.reduce((sum, e) => sum + Number(e.distance_km), 0);
  const totalAmount = entries.reduce((sum, e) => sum + Number(e.amount_dkk), 0);
  const submittedEntries = entries.filter(e => e.is_submitted);
  const unsubmittedEntries = entries.filter(e => !e.is_submitted);

  // Helper to get date range text for entries
  const getDateRange = (groupEntries: MileageEntry[]) => {
    if (groupEntries.length === 0) return '';
    const dates = groupEntries.map(e => new Date(e.trip_date)).sort((a, b) => a.getTime() - b.getTime());
    const first = dates[0];
    const last = dates[dates.length - 1];
    if (first.getTime() === last.getTime()) {
      return format(first, 'd. MMM', { locale: da });
    }
    return `${format(first, 'd. MMM', { locale: da })} - ${format(last, 'd. MMM', { locale: da })}`;
  };
  
  return (
    <Layout>
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Car className="h-6 w-6" />
              Kørselsregnskab
            </h1>
            <p className="text-muted-foreground">
              {settings?.employee_name || 'Ikke konfigureret'} • SKAT-sats 2026: 3,94 kr/km
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button onClick={() => setShowRegisterSheet(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Registrer kørsel
            </Button>
            <ExportMileageReportDialog 
              entries={entries}
              year={selectedYear}
              month={selectedMonth}
              settings={settings ? {
                employee_name: settings.employee_name || undefined,
                rate_per_km: settings.high_rate_per_km,
                home_address: settings.private_address || undefined,
                office_address: settings.office_address || undefined,
              } : undefined}
            />
            <Button variant="outline" onClick={() => navigate('/admin/mileage/history')}>
              <History className="h-4 w-4 mr-2" />
              Historik
            </Button>
            <Button variant="outline" onClick={() => setShowSettings(true)}>
              <Settings className="h-4 w-4 mr-2" />
              Indstillinger
            </Button>
          </div>
        </div>
        
        {/* Summary Cards - Unsubmitted by Company - IMPROVED UX */}
        {unsubmittedByEntity.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {unsubmittedByEntity.map((group, idx) => {
              // Use different border colors for visual distinction
              const borderColors = [
                'border-l-primary',
                'border-l-blue-500',
                'border-l-green-500',
                'border-l-orange-500',
                'border-l-purple-500',
              ];
              const borderColor = borderColors[idx % borderColors.length];
              const EntityIcon = group.entityType === 'fund' ? Landmark : Building2;
              
              return (
                <Card key={`${group.entityType}-${group.entityId}`} className={`border-l-4 ${borderColor}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-2">
                      <EntityIcon className="h-5 w-5 text-muted-foreground" />
                      <CardTitle className="text-lg">{group.entityName}</CardTitle>
                    </div>
                    <CardDescription className="flex items-center gap-2">
                      <CalendarDays className="h-3 w-3" />
                      {group.entries.length} kørsler • {getDateRange(group.entries)}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {/* Mini preview of recent trips */}
                    <div className="space-y-1 mb-4 text-sm">
                      {group.entries.slice(0, 2).map(entry => (
                        <div key={entry.id} className="flex justify-between text-muted-foreground">
                          <span className="truncate max-w-[180px]">
                            {format(new Date(entry.trip_date), 'dd/MM')}: {entry.purpose}
                          </span>
                          <span className="font-medium">{Number(entry.distance_km).toFixed(0)} km</span>
                        </div>
                      ))}
                      {group.entries.length > 2 && (
                        <p className="text-xs text-muted-foreground italic">
                          + {group.entries.length - 2} flere kørsler...
                        </p>
                      )}
                    </div>
                    
                    <div className="flex justify-between items-center pt-2 border-t">
                      <div>
                        <p className="text-2xl font-bold">{group.totalKm.toFixed(1)} km</p>
                        <p className="text-muted-foreground text-sm">{formatDKK(group.totalAmount)}</p>
                      </div>
                      <Button 
                        size="sm"
                        onClick={() => setSendReportEntity({ id: group.entityId, type: group.entityType })}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Send rapport
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : entries.length > 0 ? (
          // Show positive message when all entries are submitted
          <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
            <CardContent className="flex items-center gap-3 py-4">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <p className="text-green-800 dark:text-green-200">Alle kørsler er indsendt!</p>
            </CardContent>
          </Card>
        ) : null}
        
        {/* Filters */}
        <Card>
          <CardHeader>
            <CardTitle>Filtre</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="w-32">
                <Select value={String(selectedYear)} onValueChange={(v) => setSelectedYear(Number(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {years.map((year) => (
                      <SelectItem key={year} value={String(year)}>
                        {year}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-40">
                <Select value={String(selectedMonth)} onValueChange={(v) => setSelectedMonth(Number(v))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {MONTHS.map((month, idx) => (
                      <SelectItem key={idx + 1} value={String(idx + 1)}>
                        {month}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="w-48">
                <Select value={selectedCompanyFilter} onValueChange={setSelectedCompanyFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Alle virksomheder" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Alle virksomheder</SelectItem>
                    {companies.map((company) => (
                      <SelectItem key={company.id} value={company.id}>
                        {company.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total km</CardDescription>
              <CardTitle className="text-2xl">{totalKm.toFixed(1)}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Total beløb</CardDescription>
              <CardTitle className="text-2xl">{formatDKK(totalAmount)}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Indsendt</CardDescription>
              <CardTitle className="text-2xl">{submittedEntries.length}</CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Afventer</CardDescription>
              <CardTitle className="text-2xl">{unsubmittedEntries.length}</CardTitle>
            </CardHeader>
          </Card>
        </div>
        
        {/* Entries Table */}
        <Card>
          <CardHeader>
            <CardTitle>
              Kørsler - {MONTHS[selectedMonth - 1]} {selectedYear}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p className="text-center py-8 text-muted-foreground">Indlæser...</p>
            ) : entries.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">
                Ingen kørsler registreret i denne periode
              </p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dato</TableHead>
                      <TableHead>Fra</TableHead>
                      <TableHead>Til</TableHead>
                      <TableHead>Formål</TableHead>
                      <TableHead className="text-right">Km</TableHead>
                      <TableHead className="text-right">Beløb</TableHead>
                      <TableHead>Betales af</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-[100px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {entries.map((entry) => (
                      <TableRow key={entry.id}>
                        <TableCell className="whitespace-nowrap">
                          {format(new Date(entry.trip_date), 'dd/MM/yyyy')}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate" title={entry.from_address}>
                          {entry.from_address}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate" title={entry.to_address}>
                          {entry.to_address}
                        </TableCell>
                        <TableCell>{entry.purpose}</TableCell>
                        <TableCell className="text-right">{Number(entry.distance_km).toFixed(1)}</TableCell>
                        <TableCell className="text-right">{formatDKK(Number(entry.amount_dkk))}</TableCell>
                        <TableCell>{entry.paying_company?.name || entry.paying_fund?.name || '-'}</TableCell>
                        <TableCell>
                          {entry.is_submitted ? (
                            <Badge variant="secondary">Indsendt</Badge>
                          ) : (
                            <Badge>Afventer</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {!entry.is_submitted && (
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => setEditingEntry(entry)}
                                title="Redigér kørsel"
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="icon" title="Slet kørsel">
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Slet kørsel?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Er du sikker på at du vil slette denne kørsel? Handlingen kan ikke fortrydes.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Annuller</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => deleteEntry.mutate(entry.id)}
                                    >
                                      Slet
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
        
        <MileageSettingsDialog open={showSettings} onOpenChange={setShowSettings} />
        <MileageQuickSheet open={showRegisterSheet} onOpenChange={setShowRegisterSheet} />
        <EditMileageEntryDialog 
          entry={editingEntry} 
          open={!!editingEntry} 
          onOpenChange={(open) => !open && setEditingEntry(null)} 
        />
        
        {sendReportEntity && (
          <SendMileageReportDialog
            open={!!sendReportEntity}
            onOpenChange={() => setSendReportEntity(null)}
            entityId={sendReportEntity.id}
            entityType={sendReportEntity.type}
          />
        )}
      </div>
    </Layout>
  );
}
