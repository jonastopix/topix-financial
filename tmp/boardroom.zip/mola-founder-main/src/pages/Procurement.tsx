import { useState } from "react";
import Layout from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { ProcurementWizard } from "@/components/ProcurementWizard";
import { FounderMarketplace } from "@/components/FounderMarketplace";
import { useCompanyData } from "@/hooks/useCompanyData";
import { useRole } from "@/contexts/RoleContext";
import { Package, CreditCard, Laptop, Shield, Zap, Box, BarChart3, ChevronRight, Store } from "lucide-react";

export default function Procurement() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [wizardOpen, setWizardOpen] = useState(false);
  const { data: company } = useCompanyData();
  const { selectedCompanyId } = useRole();
  
  const companyId = selectedCompanyId || company?.id;

  const categories = [
    {
      id: "shipping",
      label: "Fragt & levering",
      icon: Package,
      description: "GLS, PostNord, og andre fragtpartnere",
      color: "text-blue-500",
      bgColor: "bg-blue-50 dark:bg-blue-950/20",
    },
    {
      id: "payment",
      label: "Betaling & gebyrer",
      icon: CreditCard,
      description: "Quickpay, Stripe, MobilePay",
      color: "text-green-500",
      bgColor: "bg-green-50 dark:bg-green-950/20",
    },
    {
      id: "saas",
      label: "SaaS & tools",
      icon: Laptop,
      description: "Workfeed, Slack, ClickUp",
      color: "text-purple-500",
      bgColor: "bg-purple-50 dark:bg-purple-950/20",
    },
    {
      id: "tele",
      label: "Tele & data",
      icon: Zap,
      description: "Mobil, internet, hosting",
      color: "text-yellow-500",
      bgColor: "bg-yellow-50 dark:bg-yellow-950/20",
    },
    {
      id: "insurance",
      label: "Forsikring & energi",
      icon: Shield,
      description: "Erhvervsforsikring, el, varme",
      color: "text-red-500",
      bgColor: "bg-red-50 dark:bg-red-950/20",
    },
    {
      id: "packaging",
      label: "Emballage & logistik",
      icon: Box,
      description: "Kasser, tape, labels",
      color: "text-orange-500",
      bgColor: "bg-orange-50 dark:bg-orange-950/20",
    },
  ];

  // Overview view - Tabs with Marketplace + Categories
  if (!selectedCategory) {
    return (
      <Layout>
        <div className="space-y-8">
          {/* Hero Section */}
          <div className="relative overflow-hidden rounded-2xl glass-card p-8 md:p-12 animate-fade-up">
            <div className="absolute inset-0 gradient-hero opacity-10" />
            <div className="relative z-10">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                <div>
                  <h1 className="text-4xl font-bold mb-2 gradient-text">Deals & Indkøb</h1>
                  <p className="text-muted-foreground text-lg">
                    Sammenlign priser, find besparelser og del deals
                  </p>
                </div>
                <Button 
                  onClick={() => setWizardOpen(true)} 
                  size="lg" 
                  className="bg-gradient-to-r from-accent to-accent-glow hover:opacity-90 transition-opacity w-full sm:w-auto shadow-lg hover:shadow-glow-accent"
                >
                  Indlæs egne priser
                </Button>
              </div>
            </div>
          </div>

          <Tabs defaultValue="marketplace" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto">
              <TabsTrigger value="marketplace" className="gap-2">
                <Store className="w-4 h-4" />
                Founder Deals
              </TabsTrigger>
              <TabsTrigger value="categories" className="gap-2">
                <Package className="w-4 h-4" />
                Kategorier
              </TabsTrigger>
            </TabsList>

            <TabsContent value="marketplace" className="space-y-6">
              <FounderMarketplace companyId={companyId} showCreateButton={true} />
            </TabsContent>

            <TabsContent value="categories" className="space-y-6">

          {/* Category Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((cat, index) => (
              <Card
                key={cat.id}
                className="group cursor-pointer transition-all duration-300 hover-lift glass-card animate-scale-in hover:border-primary/50"
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => setSelectedCategory(cat.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "p-4 rounded-xl transition-all duration-300",
                      "group-hover:scale-110 group-hover:shadow-lg",
                      cat.color,
                      "bg-gradient-to-br from-card/80 to-card/40"
                    )}>
                      <cat.icon className="w-7 h-7" />
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                        {cat.label}
                      </h3>
                      <p className="text-sm text-muted-foreground">{cat.description}</p>
                    </div>
                    
                    <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* Benchmarks as special card */}
            <Card
              className="group cursor-pointer transition-all duration-300 hover-lift glass-card animate-scale-in hover:border-primary/50 relative overflow-hidden"
              style={{ animationDelay: `${categories.length * 100}ms` }}
              onClick={() => setSelectedCategory('benchmarks')}
            >
              <div className="absolute inset-0 gradient-primary opacity-5" />
              <CardContent className="p-6 relative z-10">
                <div className="flex items-start gap-4">
                  <div className="p-4 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10 text-primary transition-all duration-300 group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-primary/20">
                    <BarChart3 className="w-7 h-7" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">
                      Benchmarks
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Sammenlign med porteføljen
                    </p>
                  </div>
                  
                  <ChevronRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                </div>
              </CardContent>
            </Card>
          </div>
            </TabsContent>
          </Tabs>
        </div>

        {companyId && (
          <ProcurementWizard
            open={wizardOpen}
            onOpenChange={setWizardOpen}
            companyId={companyId}
          />
        )}
      </Layout>
    );
  }

  // Category detail view - with sidebar
  const selectedCat = categories.find(c => c.id === selectedCategory) || {
    id: 'benchmarks',
    label: 'Benchmarks',
    icon: BarChart3,
    description: 'Sammenlign med porteføljen',
    color: 'text-primary',
    bgColor: 'bg-primary/5'
  };

  return (
    <Layout>
      <div className="flex gap-6">
        {/* Sidebar Navigation */}
        <aside className="hidden lg:block w-64 flex-shrink-0 animate-slide-in">
          <Card className="p-4 sticky top-4 glass-card">
            <Button
              variant="ghost"
              className="w-full justify-start mb-4 hover:bg-primary/10 transition-colors"
              onClick={() => setSelectedCategory(null)}
            >
              <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
              Tilbage til overblik
            </Button>
            
            <div className="space-y-1">
              {[...categories, { id: 'benchmarks', label: 'Benchmarks', icon: BarChart3, color: 'text-primary' }].map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={cn(
                    "w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 text-left group",
                    selectedCategory === cat.id
                      ? "bg-primary/10 text-primary font-medium shadow-sm"
                      : "hover:bg-muted text-muted-foreground hover:translate-x-1"
                  )}
                >
                  <cat.icon className="w-4 h-4 flex-shrink-0 transition-transform group-hover:scale-110" />
                  <span className="text-sm truncate">{cat.label}</span>
                </button>
              ))}
            </div>
          </Card>
        </aside>

        {/* Main Content */}
        <div className="flex-1 space-y-6 animate-slide-in" style={{ animationDelay: '100ms' }}>
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
            <div>
              <Button
                variant="ghost"
                className="mb-2 lg:hidden hover:bg-primary/10"
                onClick={() => setSelectedCategory(null)}
              >
                <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                Tilbage til overblik
              </Button>
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-gradient-to-br from-primary/20 to-primary/10">
                  <selectedCat.icon className={cn("w-8 h-8", selectedCat.color)} />
                </div>
                <div>
                  <h1 className="text-3xl font-bold">{selectedCat.label}</h1>
                  <p className="text-muted-foreground">{selectedCat.description}</p>
                </div>
              </div>
            </div>
            <Button 
              onClick={() => setWizardOpen(true)} 
              size="lg" 
              className="bg-gradient-to-r from-accent to-accent-glow hover:opacity-90 transition-opacity w-full sm:w-auto shadow-lg hover:shadow-glow-accent"
            >
              Indlæs egne priser
            </Button>
          </div>

          <Card className="glass-card p-8 animate-scale-in" style={{ animationDelay: '200ms' }}>
            <div className="text-center text-muted-foreground py-12">
              <div className="mb-4 flex justify-center">
                <div className="p-4 rounded-full bg-muted/50">
                  <selectedCat.icon className={cn("w-12 h-12", selectedCat.color)} />
                </div>
              </div>
              <p className="text-lg font-medium mb-2">Indhold for {selectedCat.label} kommer snart...</p>
              <p className="text-sm">
                Brug "Indlæs egne priser" knappen for at begynde
              </p>
            </div>
          </Card>
        </div>
      </div>

      {companyId && (
        <ProcurementWizard
          open={wizardOpen}
          onOpenChange={setWizardOpen}
          companyId={companyId}
        />
      )}
    </Layout>
  );
}