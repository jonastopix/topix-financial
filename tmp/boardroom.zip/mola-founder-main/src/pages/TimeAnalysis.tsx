import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import Layout from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, TrendingUp, Target, AlertCircle } from 'lucide-react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, Legend } from 'recharts';
import { calculateScorecard, calculateHealthIndex } from '@/lib/metricsCalculations';
import { startOfMonth, startOfQuarter, startOfYear, isAfter } from 'date-fns';

type TimePeriod = 'month' | 'quarter' | 'year' | 'all';

export default function TimeAnalysis() {
  const [selectedPeriod, setSelectedPeriod] = useState<TimePeriod>('year');

  const { data: companies = [] } = useQuery({
    queryKey: ['all-companies-for-time-analysis'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('is_active', true);
      if (error) throw error;
      return data || [];
    },
  });
  const currentYear = new Date().getFullYear();

  const { data: allMeetings = [] } = useQuery({
    queryKey: ['all-meetings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_meetings')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  // Fetch monthly reports for all companies
  const { data: allReports = [] } = useQuery({
    queryKey: ['all-monthly-reports'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('monthly_reports')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  // Fetch NPS responses for all companies
  const { data: allNPS = [] } = useQuery({
    queryKey: ['all-nps-responses'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('nps_responses')
        .select('*');
      if (error) throw error;
      return data;
    },
  });

  // Filter meetings based on selected period
  const filteredMeetings = useMemo(() => {
    const now = new Date();
    return allMeetings.filter(m => {
      if (selectedPeriod === 'all') return true;
      const meetingDate = new Date(m.meeting_date);
      let periodStart: Date;
      switch (selectedPeriod) {
        case 'month':
          periodStart = startOfMonth(now);
          break;
        case 'quarter':
          periodStart = startOfQuarter(now);
          break;
        case 'year':
          periodStart = startOfYear(now);
          break;
        default:
          return true;
      }
      return isAfter(meetingDate, periodStart) || meetingDate.getTime() === periodStart.getTime();
    });
  }, [allMeetings, selectedPeriod]);

  const periodLabel = useMemo(() => {
    switch (selectedPeriod) {
      case 'month': return 'denne måned';
      case 'quarter': return 'dette kvartal';
      case 'year': return 'dette år';
      case 'all': return 'al tid';
    }
  }, [selectedPeriod]);

  // Calculate metrics per company with real Health Index (using filtered meetings)
  const companyMetrics = useMemo(() => {
    return companies.map(company => {
      const companyMeetings = filteredMeetings.filter(m => m.company_id === company.id);
      const totalMinutes = companyMeetings.reduce((sum, m) => sum + Number(m.duration_minutes), 0);
      const totalHours = totalMinutes / 60;
      
      // Get company-specific reports and NPS
      const companyReports = allReports.filter(r => r.company_id === company.id);
      const companyNPS = allNPS.filter(n => n.company_id === company.id);
      
      // Calculate real Health Index using existing functions
      const scorecard = calculateScorecard(companyReports, companyNPS, currentYear);
      const healthIndex = calculateHealthIndex(
        scorecard.financial,
        scorecard.growth,
        scorecard.transparency,
        scorecard.relationship
      );
      
      return {
        id: company.id,
        name: company.name,
        totalHours,
        meetingCount: companyMeetings.length,
        investedAmount: Number(company.total_invested_amount_dkk || 0),
        healthIndex: Math.round(healthIndex),
        scorecard,
        timePerInvestment: company.total_invested_amount_dkk 
          ? totalHours / (Number(company.total_invested_amount_dkk) / 1000000)
          : 0,
      };
    }).filter(m => m.totalHours > 0);
  }, [companies, filteredMeetings, allReports, allNPS, currentYear]);

  // Sort by different metrics
  const mostEfficient = [...companyMetrics].sort((a, b) => 
    (b.healthIndex / (b.totalHours || 1)) - (a.healthIndex / (a.totalHours || 1))
  ).slice(0, 5);

  const needsAttention = [...companyMetrics]
    .filter(m => m.healthIndex < 60 && m.totalHours < 10)
    .slice(0, 5);

  const timeIntensive = [...companyMetrics]
    .sort((a, b) => b.totalHours - a.totalHours)
    .slice(0, 5);

  const totalHoursAllCompanies = companyMetrics.reduce((sum, m) => sum + m.totalHours, 0);
  const avgHoursPerCompany = companyMetrics.length > 0 ? totalHoursAllCompanies / companyMetrics.length : 0;

  // Prepare scatter plot data
  const scatterData = companyMetrics.map(m => ({
    name: m.name,
    hours: Math.round(m.totalHours * 10) / 10,
    health: m.healthIndex,
    meetings: m.meetingCount,
  }));

  // Color function based on health index
  const getColor = (health: number) => {
    if (health >= 75) return 'hsl(var(--chart-1))'; // Green
    if (health >= 60) return 'hsl(var(--chart-3))'; // Yellow
    return 'hsl(var(--chart-5))'; // Red
  };

  // Custom tooltip for scatter plot
  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-semibold">{data.name}</p>
          <p className="text-sm text-muted-foreground">Timer: {data.hours}t</p>
          <p className="text-sm text-muted-foreground">Health Index: {data.health}</p>
          <p className="text-sm text-muted-foreground">Møder: {data.meetings}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Tidsanalyse & Performance</h1>
          <p className="text-muted-foreground mt-2">
            Analyse af sammenhæng mellem investeret tid og virksomheders performance
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Total tid investeret</p>
                  <p className="text-2xl font-bold">{Math.round(totalHoursAllCompanies)}t</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Gns. pr. virksomhed</p>
                  <p className="text-2xl font-bold">{Math.round(avgHoursPerCompany)}t</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Virksomheder sporet</p>
                  <p className="text-2xl font-bold">{companyMetrics.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Kræver opmærksomhed</p>
                  <p className="text-2xl font-bold">{needsAttention.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Scatter Plot Visualization */}
        {scatterData.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <CardTitle>Tidsforbrug vs. Health Index</CardTitle>
                  <CardDescription>
                    Viser data for {periodLabel}. Grøn = Sund (≥75), Gul = Stabil (60-74), Rød = Risiko (&lt;60)
                  </CardDescription>
                </div>
                <Select value={selectedPeriod} onValueChange={(v) => setSelectedPeriod(v as TimePeriod)}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Vælg periode" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="month">Denne måned</SelectItem>
                    <SelectItem value="quarter">Dette kvartal</SelectItem>
                    <SelectItem value="year">Dette år</SelectItem>
                    <SelectItem value="all">Al tid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    type="number" 
                    dataKey="hours" 
                    name="Timer" 
                    label={{ value: 'Timer brugt', position: 'bottom', offset: 0 }}
                    className="text-muted-foreground"
                  />
                  <YAxis 
                    type="number" 
                    dataKey="health" 
                    name="Health Index" 
                    domain={[0, 100]}
                    label={{ value: 'Health Index', angle: -90, position: 'insideLeft' }}
                    className="text-muted-foreground"
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend 
                    verticalAlign="top"
                    align="right"
                    wrapperStyle={{ paddingBottom: 20 }}
                    payload={[
                      { value: 'Sund (≥75)', type: 'circle', color: 'hsl(var(--chart-1))' },
                      { value: 'Stabil (60-74)', type: 'circle', color: 'hsl(var(--chart-3))' },
                      { value: 'Risiko (<60)', type: 'circle', color: 'hsl(var(--chart-5))' },
                    ]}
                  />
                  <Scatter name="Virksomheder" data={scatterData}>
                    {scatterData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={getColor(entry.health)} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
              <div className="mt-4 text-sm text-muted-foreground">
                <p>
                  <strong>Ideal position:</strong> Øverste venstre hjørne (høj health, lav tid) = Mest effektive investeringer
                </p>
                <p>
                  <strong>Kræver opmærksomhed:</strong> Nederste venstre hjørne (lav health, lav tid) = Behov for mere engagement
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Most Efficient */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Mest effektive</CardTitle>
              <CardDescription>Høj performance, lav tidsinvestering</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mostEfficient.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Ingen data endnu</p>
                ) : (
                  mostEfficient.map(company => (
                    <div key={company.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium text-sm">{company.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {Math.round(company.totalHours)}t · Health: {company.healthIndex}
                        </p>
                      </div>
                      <span className="text-xs bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100 px-2 py-1 rounded">
                        Effektiv
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Needs Attention */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Kræver opmærksomhed</CardTitle>
              <CardDescription>Lav performance, lav tidsinvestering</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {needsAttention.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Ingen virksomheder</p>
                ) : (
                  needsAttention.map(company => (
                    <div key={company.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium text-sm">{company.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {Math.round(company.totalHours)}t · Health: {company.healthIndex}
                        </p>
                      </div>
                      <span className="text-xs bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100 px-2 py-1 rounded">
                        Obs
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Time Intensive */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Tidskrævende</CardTitle>
              <CardDescription>Flest timer investeret</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {timeIntensive.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Ingen data endnu</p>
                ) : (
                  timeIntensive.map(company => (
                    <div key={company.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium text-sm">{company.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {Math.round(company.totalHours)}t · {company.meetingCount} møder
                        </p>
                      </div>
                      <span className="text-xs bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-100 px-2 py-1 rounded">
                        {Math.round(company.totalHours)}t
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* All Companies Table */}
        <Card>
          <CardHeader>
            <CardTitle>Alle virksomheder</CardTitle>
          </CardHeader>
          <CardContent>
            {companyMetrics.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">
                Ingen møder registreret endnu. Start med at registrere møder for at se analyser.
              </p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-4">Virksomhed</th>
                      <th className="text-right py-2 px-4">Møder</th>
                      <th className="text-right py-2 px-4">Total tid</th>
                      <th className="text-right py-2 px-4">Timer/mDKK inv.</th>
                      <th className="text-right py-2 px-4">Health</th>
                    </tr>
                  </thead>
                  <tbody>
                    {companyMetrics.map(company => (
                      <tr key={company.id} className="border-b hover:bg-muted/50">
                        <td className="py-2 px-4 font-medium">{company.name}</td>
                        <td className="text-right py-2 px-4">{company.meetingCount}</td>
                        <td className="text-right py-2 px-4">{Math.round(company.totalHours)}t</td>
                        <td className="text-right py-2 px-4">
                          {company.timePerInvestment > 0 ? Math.round(company.timePerInvestment) : '-'}
                        </td>
                        <td className="text-right py-2 px-4">
                          <span className={`px-2 py-1 rounded text-xs ${
                            company.healthIndex >= 75 ? 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-100' :
                            company.healthIndex >= 60 ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-100' :
                            'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-100'
                          }`}>
                            {company.healthIndex}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
