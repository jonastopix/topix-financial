import { useState } from 'react';
import { Link } from 'react-router-dom';
import Layout from '@/components/Layout';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Users, UserPlus, CheckCircle2, AlertCircle } from 'lucide-react';
import { useFoundersDirectory } from '@/hooks/useFoundersDirectory';
import { FounderCard } from '@/components/FounderCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const MeetTheFounders = () => {
  const [search, setSearch] = useState('');
  const [industry, setIndustry] = useState<string>('');
  const [sortBy, setSortBy] = useState<'name' | 'recent'>('name');
  const { user } = useAuth();

  const { data: founders, isLoading } = useFoundersDirectory({
    search,
    industry: industry || undefined,
    sortBy,
  });

  // Fetch current user's profile to check completeness
  const { data: myProfile } = useQuery({
    queryKey: ['my-profile-status', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('profiles')
        .select('bio, skills, can_help_with, linkedin_url, title')
        .eq('id', user.id)
        .single();
      return data;
    },
    enabled: !!user?.id,
  });

  const industries = [
    'ecommerce',
    'saas',
    'marketplace',
    'fintech',
    'healthtech',
    'edtech',
    'other',
  ];

  const getIndustryLabel = (value: string) => {
    const labels: Record<string, string> = {
      ecommerce: 'E-commerce',
      saas: 'SaaS',
      marketplace: 'Marketplace',
      fintech: 'FinTech',
      healthtech: 'HealthTech',
      edtech: 'EdTech',
      other: 'Andet',
    };
    return labels[value] || value;
  };

  // Check which profile fields are missing
  const missingFields: string[] = [];
  if (myProfile) {
    if (!myProfile.bio) missingFields.push('Bio');
    if (!myProfile.skills || myProfile.skills.length === 0) missingFields.push('Kompetencer');
    if (!myProfile.can_help_with) missingFields.push('Jeg kan hjælpe med');
  }
  const isProfileComplete = myProfile && missingFields.length === 0;

  return (
    <Layout>
      <div className="container mx-auto py-8 px-4 space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Meet the Founders</h1>
          <p className="text-muted-foreground">
            Netværk med andre founders i MOLA-porteføljen
          </p>
        </div>

        {/* Profile Guide Card */}
        {myProfile && (
          <Card className={isProfileComplete ? 'border-green-500/30 bg-green-500/5' : 'border-primary/30 bg-primary/5'}>
            <CardContent className="flex items-start gap-4 py-4">
              {isProfileComplete ? (
                <CheckCircle2 className="h-6 w-6 text-green-500 mt-0.5 shrink-0" />
              ) : (
                <UserPlus className="h-6 w-6 text-primary mt-0.5 shrink-0" />
              )}
              <div className="flex-1 space-y-2">
                {isProfileComplete ? (
                  <>
                    <h3 className="font-semibold text-green-700 dark:text-green-400">Din profil er synlig</h3>
                    <p className="text-sm text-muted-foreground">
                      Andre founders kan nu finde dig og se hvad du kan hjælpe med.
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="font-semibold">Bliv synlig for andre founders</h3>
                    <p className="text-sm text-muted-foreground">
                      For at blive vist på denne side, skal du udfylde din profil med bio, kompetencer og hvad du kan hjælpe andre founders med.
                    </p>
                    {missingFields.length > 0 && (
                      <div className="flex items-center gap-2 text-sm">
                        <AlertCircle className="h-4 w-4 text-amber-500" />
                        <span className="text-muted-foreground">
                          Du mangler: <span className="font-medium text-foreground">{missingFields.join(', ')}</span>
                        </span>
                      </div>
                    )}
                  </>
                )}
              </div>
              <Button asChild variant={isProfileComplete ? 'outline' : 'default'} size="sm">
                <Link to="/profile">
                  {isProfileComplete ? 'Rediger profil' : 'Opdater din profil'}
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Søg efter navn, firma eller kompetencer..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={industry} onValueChange={setIndustry}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Alle brancher" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle brancher</SelectItem>
              {industries.map((ind) => (
                <SelectItem key={ind} value={ind}>
                  {getIndustryLabel(ind)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={(val) => setSortBy(val as 'name' | 'recent')}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Alfabetisk</SelectItem>
              <SelectItem value="recent">Nyeste først</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Results count */}
        {!isLoading && founders && (
          <p className="text-sm text-muted-foreground">
            {founders.length} founder{founders.length !== 1 ? 's' : ''} fundet
          </p>
        )}

        {/* Founders Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-64 w-full" />
              </div>
            ))}
          </div>
        ) : founders && founders.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {founders.map((founder) => (
              <FounderCard key={founder.id} founder={founder} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 space-y-4">
            <Users className="h-16 w-16 text-muted-foreground/50" />
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">Ingen founders fundet</h3>
              <p className="text-muted-foreground">
                Prøv at justere dine filtre eller søgning
              </p>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default MeetTheFounders;
