import { useState } from 'react';
import Layout from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Pencil, Trash2, RotateCcw, ClipboardCheck, AlertTriangle } from 'lucide-react';
import { useGovernanceTemplatesAdmin, GovernanceTemplate } from '@/hooks/useGovernanceTemplatesAdmin';

const CATEGORY_OPTIONS = [
  { value: 'finansiel_kontrol', label: 'Finansiel Kontrol' },
  { value: 'forsikringer', label: 'Forsikringer' },
  { value: 'personale', label: 'Personale' },
  { value: 'compliance', label: 'Compliance' },
];

const MONTHS_OPTIONS = Array.from({ length: 12 }, (_, i) => ({
  value: i.toString(),
  label: i === 0 ? 'Ved regnskabsårets afslutning' : `${i} måned${i > 1 ? 'er' : ''} efter`,
}));

interface TemplateFormData {
  category: string;
  item_name: string;
  description: string;
  frequency: string;
  months_after_fiscal_year_end: number;
  required: boolean;
  is_active: boolean;
  sort_order: number;
}

const defaultFormData: TemplateFormData = {
  category: 'finansiel_kontrol',
  item_name: '',
  description: '',
  frequency: 'annual',
  months_after_fiscal_year_end: 0,
  required: true,
  is_active: true,
  sort_order: 100,
};

const GovernanceTemplatesAdmin = () => {
  const { templates, categories, isLoading, createTemplate, updateTemplate, deleteTemplate, reactivateTemplate } = useGovernanceTemplatesAdmin();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<GovernanceTemplate | null>(null);
  const [formData, setFormData] = useState<TemplateFormData>(defaultFormData);
  const [showInactive, setShowInactive] = useState(false);

  const handleOpenDialog = (template?: GovernanceTemplate) => {
    if (template) {
      setEditingTemplate(template);
      setFormData({
        category: template.category,
        item_name: template.item_name,
        description: template.description || '',
        frequency: template.frequency,
        months_after_fiscal_year_end: template.months_after_fiscal_year_end || 0,
        required: template.required ?? true,
        is_active: template.is_active ?? true,
        sort_order: template.sort_order,
      });
    } else {
      setEditingTemplate(null);
      setFormData(defaultFormData);
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (editingTemplate) {
      await updateTemplate.mutateAsync({
        id: editingTemplate.id,
        ...formData,
      });
    } else {
      await createTemplate.mutateAsync(formData);
    }
    setIsDialogOpen(false);
    setEditingTemplate(null);
    setFormData(defaultFormData);
  };

  const handleDelete = async (id: string) => {
    if (confirm('Er du sikker på at du vil deaktivere dette governance punkt?')) {
      await deleteTemplate.mutateAsync(id);
    }
  };

  const handleReactivate = async (id: string) => {
    await reactivateTemplate.mutateAsync(id);
  };

  const filteredTemplates = templates?.filter(t => showInactive || t.is_active) || [];
  const groupedTemplates = filteredTemplates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {} as Record<string, GovernanceTemplate[]>);

  const getCategoryLabel = (value: string) => 
    CATEGORY_OPTIONS.find(o => o.value === value)?.label || value;

  const getMonthsLabel = (months: number) =>
    MONTHS_OPTIONS.find(o => o.value === months.toString())?.label || `${months} måneder`;

  return (
    <Layout>
      <div className="space-y-8 max-w-full">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold mb-2 flex items-center gap-3">
              <ClipboardCheck className="h-10 w-10" />
              Governance Templates
            </h1>
            <p className="text-muted-foreground">
              Administrer governance punkter der gælder for alle selskaber
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="mr-2 h-4 w-4" />
                Tilføj punkt
              </Button>
            </DialogTrigger>
            
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>
                  {editingTemplate ? 'Rediger governance punkt' : 'Tilføj governance punkt'}
                </DialogTitle>
                <DialogDescription>
                  Punktet vil blive tilføjet til alle selskaber
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Kategori</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORY_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="item_name">Navn</Label>
                  <Input
                    id="item_name"
                    value={formData.item_name}
                    onChange={(e) => setFormData({ ...formData, item_name: e.target.value })}
                    placeholder="F.eks. Dobbelt godkendelse i bank"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Beskrivelse (valgfri)</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Kort beskrivelse af punktet..."
                    rows={2}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="months">Deadline (måneder efter regnskabsår)</Label>
                  <Select
                    value={formData.months_after_fiscal_year_end.toString()}
                    onValueChange={(value) => setFormData({ ...formData, months_after_fiscal_year_end: parseInt(value) })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MONTHS_OPTIONS.map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="sort_order">Rækkefølge</Label>
                  <Input
                    id="sort_order"
                    type="number"
                    value={formData.sort_order}
                    onChange={(e) => setFormData({ ...formData, sort_order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="required">Påkrævet</Label>
                  <Switch
                    id="required"
                    checked={formData.required}
                    onCheckedChange={(checked) => setFormData({ ...formData, required: checked })}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Annuller
                </Button>
                <Button onClick={handleSave} disabled={!formData.item_name}>
                  {editingTemplate ? 'Gem ændringer' : 'Tilføj punkt'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Governance Punkter</CardTitle>
                <CardDescription>
                  Disse punkter tilføjes automatisk til alle selskabers governance checklist
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="show-inactive" className="text-sm">Vis inaktive</Label>
                <Switch
                  id="show-inactive"
                  checked={showInactive}
                  onCheckedChange={setShowInactive}
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">Indlæser...</div>
            ) : Object.keys(groupedTemplates).length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Ingen governance punkter fundet
              </div>
            ) : (
              <div className="space-y-6">
                {Object.entries(groupedTemplates).map(([category, items]) => (
                  <div key={category}>
                    <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
                      {getCategoryLabel(category)}
                      <Badge variant="secondary">{items.length}</Badge>
                    </h3>
                    
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Punkt</TableHead>
                          <TableHead>Deadline</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="w-[100px]">Handlinger</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {items.map((template) => (
                          <TableRow 
                            key={template.id}
                            className={!template.is_active ? 'opacity-50' : ''}
                          >
                            <TableCell>
                              <div>
                                <div className="font-medium">{template.item_name}</div>
                                {template.description && (
                                  <div className="text-sm text-muted-foreground">
                                    {template.description}
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {getMonthsLabel(template.months_after_fiscal_year_end || 0)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                {template.required && (
                                  <Badge variant="secondary">Påkrævet</Badge>
                                )}
                                {!template.is_active && (
                                  <Badge variant="destructive">Inaktiv</Badge>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleOpenDialog(template)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                {template.is_active ? (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDelete(template.id)}
                                  >
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                ) : (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleReactivate(template.id)}
                                  >
                                    <RotateCcw className="h-4 w-4 text-success" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-warning/50 bg-warning/5">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-warning">
              <AlertTriangle className="h-5 w-5" />
              Vigtig information
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-2">
            <p>
              <strong>Nye punkter</strong> tilføjes automatisk til alle selskabers governance checklist.
            </p>
            <p>
              <strong>Deadlines</strong> beregnes baseret på hvert selskabs individuelle regnskabsår.
            </p>
            <p>
              <strong>Deaktiverede punkter</strong> fjernes ikke fra eksisterende progress, men vises ikke for nye år.
            </p>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default GovernanceTemplatesAdmin;
