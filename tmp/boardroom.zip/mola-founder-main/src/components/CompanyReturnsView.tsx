import { useState } from 'react';
import { useCompanyReturnsData } from '@/hooks/useReturnsData';
import { useFundingRounds } from '@/hooks/useFundingRounds';
import { ReturnsKPICard } from './ReturnsKPICard';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import {
  TrendingUp,
  Wallet,
  PiggyBank,
  Target,
  BarChart3,
  Plus,
  AlertCircle,
  Edit3,
  Pencil,
} from 'lucide-react';
import {
  calculatePaidIn,
  calculateDistributions,
  calculateUnrealizedValue,
  calculateDPI,
  calculateTVPI,
  calculateMOIC,
  calculateROI,
  formatDKK,
  formatMultiple,
  formatPercentage,
  type Exit,
} from '@/lib/returnsCalculations';
import { format } from 'date-fns';
import { useRole } from '@/contexts/RoleContext';
import { AddDividendDialog } from './AddDividendDialog';
import { RecordExitDialog } from './RecordExitDialog';
import { EditExitDialog } from './EditExitDialog';

interface CompanyReturnsViewProps {
  companyId: string;
  fundId: string;
  investedAmount?: number;
}

export function CompanyReturnsView({
  companyId,
  fundId,
  investedAmount = 0,
}: CompanyReturnsViewProps) {
  const { isAdmin } = useRole();
  const { dividends, exits, valuations, isLoading } = useCompanyReturnsData(companyId);
  const { data: fundingRounds, isLoading: isLoadingRounds } = useFundingRounds(companyId);
  const [dividendDialogOpen, setDividendDialogOpen] = useState(false);
  const [exitDialogOpen, setExitDialogOpen] = useState(false);
  const [editingExit, setEditingExit] = useState<Exit | null>(null);

  if (isLoading || isLoadingRounds) {
    return <div className="text-center py-8">Loading returns data...</div>;
  }

  // Use funding rounds if available, otherwise use invested amount from company
  const totalInvested = fundingRounds && fundingRounds.length > 0 
    ? fundingRounds.reduce((sum, r) => sum + r.invested_amount_dkk, 0)
    : investedAmount;
  const totalEquity = fundingRounds?.reduce((sum, r) => sum + r.equity_acquired_pct, 0) || 0;

  // Calculate metrics
  const paidIn = calculatePaidIn(totalInvested);
  const distributions = calculateDistributions(dividends, exits);
  const latestValuation = valuations[0] || null;
  const unrealizedValue = calculateUnrealizedValue(
    latestValuation,
    totalEquity,
    exits
  );

  const dpi = calculateDPI(distributions, paidIn);
  const tvpi = calculateTVPI(distributions, unrealizedValue, paidIn);
  const moic = calculateMOIC(distributions, unrealizedValue, paidIn);
  const roi = calculateROI(distributions, unrealizedValue, paidIn);

  // Check if company has exited
  const hasExited = exits.length > 0;

  // Founders see limited info
  if (!isAdmin) {
    return (
      <div className="space-y-6">
        {hasExited && (
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                Exited
              </Badge>
              <p className="text-muted-foreground">
                This company has been exited on {format(new Date(exits[0].closing_date), 'dd MMM yyyy')}
              </p>
            </div>
            {exits[0].note && (
              <p className="mt-4 text-sm">{exits[0].note}</p>
            )}
          </Card>
        )}
        <Card className="p-6 text-center">
          <p className="text-muted-foreground">
            Return metrics are only visible to MOLA admins
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Warning if no valuation */}
      {!latestValuation && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            No valuation recorded for this company. Unrealized value will be 0 and TVPI will only reflect distributions.
          </AlertDescription>
        </Alert>
      )}

      {/* Valuation info card */}
      {latestValuation && (
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Latest Valuation</p>
              <p className="text-2xl font-bold">{formatDKK(latestValuation.post_money_valuation_dkk)}</p>
              <p className="text-xs text-muted-foreground mt-1">
                As of {format(new Date(latestValuation.as_of_date), 'dd MMM yyyy')}
              </p>
            </div>
            <div>
              {latestValuation.source.includes('Funding Round') ? (
                <Badge variant="secondary" className="flex items-center gap-1">
                  <Target className="h-3 w-3" />
                  Funding Round
                </Badge>
              ) : latestValuation.source.includes('Market-based') || latestValuation.source.includes('Auto-calculated') ? (
                <Badge variant="outline" className="flex items-center gap-1">
                  <BarChart3 className="h-3 w-3" />
                  Market-based
                </Badge>
              ) : (
                <Badge variant="default" className="flex items-center gap-1">
                  <Edit3 className="h-3 w-3" />
                  Manual
                </Badge>
              )}
            </div>
          </div>
        </Card>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-4">
        <ReturnsKPICard
          title="Paid-In Capital"
          value={formatDKK(paidIn)}
          icon={TrendingUp}
        />
        <ReturnsKPICard
          title="Distributions"
          value={formatDKK(distributions)}
          subtitle={`DPI: ${formatMultiple(dpi)}`}
          icon={Wallet}
          trend={distributions > 0 ? 'up' : 'neutral'}
        />
        <ReturnsKPICard
          title="Unrealized Value"
          value={formatDKK(unrealizedValue)}
          subtitle={latestValuation ? format(new Date(latestValuation.as_of_date), 'dd MMM yyyy') : 'No valuation'}
          icon={PiggyBank}
        />
        <ReturnsKPICard
          title="DPI"
          value={formatMultiple(dpi)}
          subtitle="Distributions / Paid-In"
          icon={Target}
        />
        <ReturnsKPICard
          title="TVPI"
          value={formatMultiple(tvpi)}
          subtitle={`MOIC: ${formatMultiple(moic)}`}
          icon={BarChart3}
          trend={tvpi > 1 ? 'up' : tvpi < 1 ? 'down' : 'neutral'}
        />
        <ReturnsKPICard
          title="ROI"
          value={formatPercentage(roi)}
          subtitle="Return on Investment"
          icon={TrendingUp}
          trend={roi > 0 ? 'up' : roi < 0 ? 'down' : 'neutral'}
        />
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4">
        <Button onClick={() => setDividendDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Dividend
        </Button>
        <Button variant="outline" onClick={() => setExitDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Record Exit
        </Button>
      </div>

      <AddDividendDialog
        open={dividendDialogOpen}
        onOpenChange={setDividendDialogOpen}
        companyId={companyId}
        fundId={fundId}
      />

      <RecordExitDialog
        open={exitDialogOpen}
        onOpenChange={setExitDialogOpen}
        companyId={companyId}
        fundId={fundId}
        currentOwnershipPct={totalEquity}
      />

      {/* Exits Table */}
      {exits.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Exits</h3>
          <div className="space-y-4">
            {exits.map((exit) => {
              // Calculate MOLA's share based on ownership percentage
              const molaShare = exit.gross_sale_amount_dkk * (exit.mola_ownership_pct_at_exit / 100);
              const netProceeds = molaShare - exit.transaction_costs_dkk;
              const isProfit = netProceeds >= paidIn;
              const gain = netProceeds - paidIn;
              const roiPercent = paidIn > 0 ? ((netProceeds - paidIn) / paidIn) * 100 : 0;
              
              return (
                <div key={exit.id} className="border-b pb-4 last:border-b-0">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <div className="font-medium">Exit on {format(new Date(exit.closing_date), 'dd MMM yyyy')}</div>
                      {exit.note && <div className="text-sm text-muted-foreground mt-1">{exit.note}</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setEditingExit(exit)}
                        className="h-8 w-8"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Badge variant={isProfit ? "default" : "destructive"}>
                        {isProfit ? "Profit" : "Loss"}
                      </Badge>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-7 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Total Sale</div>
                      <div className="font-medium">{formatDKK(exit.gross_sale_amount_dkk)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">MOLA Ownership</div>
                      <div className="font-medium">{exit.mola_ownership_pct_at_exit}%</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">MOLA's Share</div>
                      <div className="font-medium">{formatDKK(molaShare)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Transaction Costs</div>
                      <div className="font-medium">{formatDKK(exit.transaction_costs_dkk)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Net Proceeds</div>
                      <div className="font-medium">{formatDKK(netProceeds)}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Gain/Loss</div>
                      <div className={`font-bold ${isProfit ? 'text-primary' : 'text-destructive'}`}>
                        {isProfit ? '+' : '-'}{new Intl.NumberFormat('da-DK', { 
                          style: 'currency', 
                          currency: 'DKK',
                          minimumFractionDigits: 0,
                          maximumFractionDigits: 0
                        }).format(Math.floor(Math.abs(gain)))}
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">ROI</div>
                      <div className={`font-bold ${isProfit ? 'text-primary' : 'text-destructive'}`}>
                        {roiPercent >= 0 ? '+' : ''}{roiPercent.toFixed(2)}%
                      </div>
                    </div>
                  </div>
                  {exit.retained_shares_pct > 0 && (
                    <div className="mt-2 text-sm text-muted-foreground">
                      Retained shares: {exit.retained_shares_pct}%
                    </div>
                  )}
                  {exit.earnout_possible && exit.earnout_amount_potential_dkk && (
                    <div className="mt-2 text-sm text-muted-foreground">
                      Potential earnout: {formatDKK(exit.earnout_amount_potential_dkk)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Dividends Table */}
      {dividends.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Dividends</h3>
          <div className="space-y-4">
            {dividends.map((dividend) => (
              <div key={dividend.id} className="border-b pb-4 last:border-b-0">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium">
                      Paid on {format(new Date(dividend.paid_date), 'dd MMM yyyy')}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Declared: {format(new Date(dividend.declared_date), 'dd MMM yyyy')}
                    </div>
                    {dividend.note && (
                      <div className="text-sm text-muted-foreground mt-1">{dividend.note}</div>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-primary">{formatDKK(dividend.amount_dkk)}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Edit Exit Dialog */}
      {editingExit && (
        <EditExitDialog
          open={!!editingExit}
          onOpenChange={(open) => !open && setEditingExit(null)}
          exit={editingExit}
        />
      )}
    </div>
  );
}
