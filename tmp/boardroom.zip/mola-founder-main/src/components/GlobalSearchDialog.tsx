import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from '@/components/ui/command';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Building2, Clock, Search } from 'lucide-react';
import { useRecentlyVisitedCompanies } from '@/hooks/useRecentlyVisitedCompanies';

interface GlobalSearchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const statusColors: Record<string, string> = {
  active: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
  exited: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
  pipeline: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
  inactive: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
};

const statusLabels: Record<string, string> = {
  active: 'Aktiv',
  exited: 'Exited',
  pipeline: 'Pipeline',
  inactive: 'Inaktiv',
};

export function GlobalSearchDialog({ open, onOpenChange }: GlobalSearchDialogProps) {
  const [search, setSearch] = useState('');
  const navigate = useNavigate();
  const { companies: recentCompanies } = useRecentlyVisitedCompanies();

  // Fetch all active companies
  const { data: allCompanies = [] } = useQuery({
    queryKey: ['all-companies-search'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, industry, status, logo_url')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  // Filter companies based on search
  const filteredCompanies = useMemo(() => {
    if (!search.trim()) {
      return allCompanies.slice(0, 10);
    }
    const searchLower = search.toLowerCase();
    return allCompanies.filter(
      (c) =>
        c.name?.toLowerCase().includes(searchLower) ||
        c.industry?.toLowerCase().includes(searchLower)
    );
  }, [allCompanies, search]);

  const handleSelect = (companyId: string) => {
    navigate(`/company/${companyId}`);
    onOpenChange(false);
    setSearch('');
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput
        placeholder="Søg efter selskab (navn, branche)..."
        value={search}
        onValueChange={setSearch}
      />
      <CommandList>
        <CommandEmpty>
          <div className="flex flex-col items-center gap-2 py-6">
            <Search className="h-10 w-10 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">Ingen selskaber fundet</p>
          </div>
        </CommandEmpty>

        {/* Recently visited - only show when not searching */}
        {!search.trim() && recentCompanies && recentCompanies.length > 0 && (
          <>
            <CommandGroup heading="Senest besøgte">
              {recentCompanies.slice(0, 5).map((company) => (
                <CommandItem
                  key={`recent-${company.id}`}
                  value={`recent-${company.name}`}
                  onSelect={() => handleSelect(company.id)}
                  className="flex items-center gap-3 cursor-pointer"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={company.logo_url || undefined} alt={company.name} />
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      {getInitials(company.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{company.name}</p>
                    {company.industry && (
                      <p className="text-xs text-muted-foreground truncate">{company.industry}</p>
                    )}
                  </div>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CommandItem>
              ))}
            </CommandGroup>
            <CommandSeparator />
          </>
        )}

        {/* All/filtered companies */}
        <CommandGroup heading={search.trim() ? 'Resultater' : 'Alle selskaber'}>
          {filteredCompanies.map((company) => (
            <CommandItem
              key={company.id}
              value={`${company.name}-${company.industry || ''}`}
              onSelect={() => handleSelect(company.id)}
              className="flex items-center gap-3 cursor-pointer"
            >
              <Avatar className="h-8 w-8">
                <AvatarImage src={company.logo_url || undefined} alt={company.name} />
                <AvatarFallback className="bg-primary/10 text-primary text-xs">
                  {getInitials(company.name)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-medium truncate">{company.name}</p>
                {company.industry && (
                  <p className="text-xs text-muted-foreground truncate">{company.industry}</p>
                )}
              </div>
              {company.status && (
                <Badge
                  variant="secondary"
                  className={`text-xs ${statusColors[company.status] || ''}`}
                >
                  {statusLabels[company.status] || company.status}
                </Badge>
              )}
            </CommandItem>
          ))}
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
