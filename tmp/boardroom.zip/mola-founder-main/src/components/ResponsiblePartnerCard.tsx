import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { UserPlus, X, User, Building2 } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';

interface ResponsiblePartnerCardProps {
  companyId: string;
  companyName: string;
}

export function ResponsiblePartnerCard({ companyId, companyName }: ResponsiblePartnerCardProps) {
  const [isAssigning, setIsAssigning] = useState(false);
  const [selectedPartnerId, setSelectedPartnerId] = useState<string>('');
  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);
  const queryClient = useQueryClient();

  // Fetch current responsible partner and company fund
  const { data: company, isLoading: companyLoading } = useQuery({
    queryKey: ['company-responsible-partner', companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('responsible_partner_id, fund_id')
        .eq('id', companyId)
        .single();

      if (error) throw error;

      // Fetch fund name if company has a fund_id
      let fundName = null;
      if (data.fund_id) {
        const { data: fund } = await supabase
          .from('funds')
          .select('name')
          .eq('id', data.fund_id)
          .single();
        
        fundName = fund?.name;
      }

      return {
        ...data,
        fundName,
      };
    },
  });

  // Fetch partner details if assigned
  const { data: partner } = useQuery({
    queryKey: ['partner-details', company?.responsible_partner_id],
    queryFn: async () => {
      if (!company?.responsible_partner_id) return null;

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('id, full_name, company_name')
        .eq('id', company.responsible_partner_id)
        .single();

      if (profileError) throw profileError;
      
      return profile;
    },
    enabled: !!company?.responsible_partner_id,
  });

  // Fetch available fund partners
  const { data: fundPartners = [] } = useQuery({
    queryKey: ['fund-partners'],
    queryFn: async () => {
      // Get all users with fund_partner or mola_admin role
      const { data: userRoles, error: rolesError } = await supabase
        .from('user_roles')
        .select('user_id, role')
        .in('role', ['fund_partner', 'mola_admin', 'owner']);

      if (rolesError) throw rolesError;

      const userIds = [...new Set(userRoles.map(r => r.user_id))];

      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, company_name')
        .in('id', userIds)
        .eq('is_active', true);

      if (profilesError) throw profilesError;

      return profiles || [];
    },
  });

  // Mutation to assign partner
  const assignMutation = useMutation({
    mutationFn: async (partnerId: string) => {
      const { error } = await supabase
        .from('companies')
        .update({ responsible_partner_id: partnerId })
        .eq('id', companyId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-responsible-partner', companyId] });
      queryClient.invalidateQueries({ queryKey: ['company', companyId] });
      toast.success('Ansvarlig partner tildelt');
      setIsAssigning(false);
      setSelectedPartnerId('');
    },
    onError: (error: any) => {
      toast.error('Kunne ikke tildele partner: ' + error.message);
    },
  });

  // Mutation to remove partner
  const removeMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('companies')
        .update({ responsible_partner_id: null })
        .eq('id', companyId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-responsible-partner', companyId] });
      queryClient.invalidateQueries({ queryKey: ['company', companyId] });
      toast.success('Ansvarlig partner fjernet');
      setRemoveDialogOpen(false);
    },
    onError: (error: any) => {
      toast.error('Kunne ikke fjerne partner: ' + error.message);
    },
  });

  const handleAssign = () => {
    if (!selectedPartnerId) {
      toast.error('Vælg venligst en partner');
      return;
    }
    assignMutation.mutate(selectedPartnerId);
  };

  if (companyLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Ansvarlig Partner
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Indlæser...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Ansvarlig Partner
              </CardTitle>
              <CardDescription>
                {company?.fundName 
                  ? `Den ansvarlige partner fra ${company.fundName} for ${companyName}`
                  : `Den ansvarlige partner for ${companyName}`
                }
              </CardDescription>
            </div>
            {!isAssigning && !partner && (
              <Button onClick={() => setIsAssigning(true)} size="sm" variant="gradient">
                <UserPlus className="h-4 w-4 mr-2" />
                Tildel Partner
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {isAssigning ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Vælg Partner</label>
                <Select value={selectedPartnerId} onValueChange={setSelectedPartnerId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg en partner..." />
                  </SelectTrigger>
                  <SelectContent>
                    {fundPartners.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.full_name} {p.company_name && `(${p.company_name})`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleAssign}
                  disabled={!selectedPartnerId || assignMutation.isPending}
                  variant="gradient"
                >
                  Tildel
                </Button>
                <Button
                  onClick={() => {
                    setIsAssigning(false);
                    setSelectedPartnerId('');
                  }}
                  variant="outline"
                >
                  Annuller
                </Button>
              </div>
            </div>
          ) : partner ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between p-4 border rounded-lg bg-accent/5">
                <div className="flex items-start gap-3 flex-1">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <User className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold">{partner.full_name}</p>
                      <Badge variant="secondary">Ansvarlig</Badge>
                    </div>
                    {company?.fundName && (
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Building2 className="h-3 w-3" />
                        {company.fundName}
                      </div>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setRemoveDialogOpen(true)}
                    className="text-destructive hover:text-destructive"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <Button
                onClick={() => setIsAssigning(true)}
                variant="outline"
                size="sm"
              >
                Skift Partner
              </Button>
            </div>
          ) : (
            <div className="text-center py-8">
              <User className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground mb-4">
                Ingen ansvarlig partner tildelt endnu
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={removeDialogOpen} onOpenChange={setRemoveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fjern ansvarlig partner</AlertDialogTitle>
            <AlertDialogDescription>
              Er du sikker på, at du vil fjerne {partner?.full_name} som ansvarlig partner for {companyName}?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => removeMutation.mutate()}
              disabled={removeMutation.isPending}
              className="bg-destructive hover:bg-destructive/90"
            >
              Fjern Partner
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
