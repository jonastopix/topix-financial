import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  FileText, 
  Download, 
  Calendar,
  Filter,
  CheckSquare
} from 'lucide-react';
import { calculateScorecard, calculateHealthIndex, calculateYTD, calculateYOY } from '@/lib/metricsCalculations';
import { toast } from 'sonner';

export function CustomReportsGenerator() {
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [reportType, setReportType] = useState<'summary' | 'detailed' | 'comparison'>('summary');
  const [timeFrame, setTimeFrame] = useState<'ytd' | 'q1' | 'q2' | 'q3' | 'q4' | 'full-year'>('ytd');
  const [includeMetrics, setIncludeMetrics] = useState({
    financial: true,
    health: true,
    scorecard: true,
    trends: false,
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const { data: companies } = useQuery({
    queryKey: ['companies-for-reports'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, industry')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  const toggleCompany = (companyId: string) => {
    setSelectedCompanies(prev =>
      prev.includes(companyId)
        ? prev.filter(id => id !== companyId)
        : [...prev, companyId]
    );
  };

  const selectAllCompanies = () => {
    if (selectedCompanies.length === companies?.length) {
      setSelectedCompanies([]);
    } else {
      setSelectedCompanies(companies?.map(c => c.id) || []);
    }
  };

  const generateReport = async () => {
    if (selectedCompanies.length === 0) {
      toast.error('Vælg mindst ét selskab');
      return;
    }

    setIsGenerating(true);

    try {
      const currentYear = new Date().getFullYear();

      // Fetch data for selected companies
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', selectedCompanies);

      if (reportsError) throw reportsError;

      const { data: npsData, error: npsError } = await supabase
        .from('nps_responses')
        .select('*')
        .in('company_id', selectedCompanies);

      if (npsError) throw npsError;

      // Build report data
      const reportData = selectedCompanies.map(companyId => {
        const company = companies?.find(c => c.id === companyId);
        const companyReports = reports?.filter(r => r.company_id === companyId) || [];
        const companyNPS = npsData?.filter(n => n.company_id === companyId) || [];

        const scorecard = calculateScorecard(companyReports, companyNPS, currentYear);
        const healthIndex = calculateHealthIndex(
          scorecard.financial,
          scorecard.growth,
          scorecard.transparency,
          scorecard.relationship
        );
        const ytd = calculateYTD(companyReports, currentYear);
        const yoy = calculateYOY(companyReports, currentYear);

        return {
          company: company?.name || 'Unknown',
          industry: company?.industry || 'N/A',
          ...(includeMetrics.financial && {
            ytdRevenue: ytd.revenue,
            ytdEbitda: ytd.ebitda,
            ytdMargin: ytd.margin,
          }),
          ...(includeMetrics.health && {
            healthIndex,
          }),
          ...(includeMetrics.scorecard && {
            financial: scorecard.financial,
            growth: scorecard.growth,
            transparency: scorecard.transparency,
            relationship: scorecard.relationship,
          }),
          ...(includeMetrics.trends && {
            yoyRevenueGrowth: yoy.revenueGrowth,
            yoyEbitdaGrowth: yoy.ebitdaGrowth,
          }),
        };
      });

      // Create CSV
      const headers = Object.keys(reportData[0]);
      const csvContent = [
        headers.join(','),
        ...reportData.map(row => 
          headers.map(header => {
            const value = (row as any)[header];
            return typeof value === 'number' ? value.toFixed(2) : value;
          }).join(',')
        )
      ].join('\n');

      // Download CSV
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `portfolio_report_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast.success('Rapport genereret og downloadet');
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Kunne ikke generere rapport');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <FileText className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-bold">Custom Reports Generator</h2>
      </div>

      <div className="space-y-6">
        {/* Report Type */}
        <div className="space-y-2">
          <Label>Rapporttype</Label>
          <Select value={reportType} onValueChange={(value: any) => setReportType(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="summary">Oversigt</SelectItem>
              <SelectItem value="detailed">Detaljeret</SelectItem>
              <SelectItem value="comparison">Sammenligning</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Time Frame */}
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Tidsperiode
          </Label>
          <Select value={timeFrame} onValueChange={(value: any) => setTimeFrame(value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ytd">Year-to-Date</SelectItem>
              <SelectItem value="q1">Q1</SelectItem>
              <SelectItem value="q2">Q2</SelectItem>
              <SelectItem value="q3">Q3</SelectItem>
              <SelectItem value="q4">Q4</SelectItem>
              <SelectItem value="full-year">Hele året</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Metrics Selection */}
        <div className="space-y-3">
          <Label className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Inkluder metrics
          </Label>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Checkbox
                checked={includeMetrics.financial}
                onCheckedChange={(checked) =>
                  setIncludeMetrics(prev => ({ ...prev, financial: checked as boolean }))
                }
              />
              <span className="text-sm">Finansielle KPI'er</span>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                checked={includeMetrics.health}
                onCheckedChange={(checked) =>
                  setIncludeMetrics(prev => ({ ...prev, health: checked as boolean }))
                }
              />
              <span className="text-sm">Health Index</span>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                checked={includeMetrics.scorecard}
                onCheckedChange={(checked) =>
                  setIncludeMetrics(prev => ({ ...prev, scorecard: checked as boolean }))
                }
              />
              <span className="text-sm">MOLA Scorecard</span>
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                checked={includeMetrics.trends}
                onCheckedChange={(checked) =>
                  setIncludeMetrics(prev => ({ ...prev, trends: checked as boolean }))
                }
              />
              <span className="text-sm">YOY Trends</span>
            </div>
          </div>
        </div>

        {/* Company Selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2">
              <CheckSquare className="h-4 w-4" />
              Vælg selskaber ({selectedCompanies.length} valgt)
            </Label>
            <Button
              variant="outline"
              size="sm"
              onClick={selectAllCompanies}
            >
              {selectedCompanies.length === companies?.length ? 'Fravælg alle' : 'Vælg alle'}
            </Button>
          </div>
          <div className="border rounded-lg p-4 max-h-[200px] overflow-y-auto space-y-2">
            {companies?.map(company => (
              <div key={company.id} className="flex items-center gap-2">
                <Checkbox
                  checked={selectedCompanies.includes(company.id)}
                  onCheckedChange={() => toggleCompany(company.id)}
                />
                <span className="text-sm">{company.name}</span>
                {company.industry && (
                  <span className="text-xs text-muted-foreground">({company.industry})</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Generate Button */}
        <Button
          onClick={generateReport}
          disabled={isGenerating || selectedCompanies.length === 0}
          className="w-full gap-2"
        >
          <Download className="h-4 w-4" />
          {isGenerating ? 'Genererer...' : 'Generer og download rapport (CSV)'}
        </Button>
      </div>
    </Card>
  );
}
