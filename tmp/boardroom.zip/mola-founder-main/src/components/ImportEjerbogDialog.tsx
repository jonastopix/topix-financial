import { useState, useRef } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { FileUp, Loader2, X, AlertTriangle, CheckCircle2, Upload } from 'lucide-react';
import { useEjerbogImport, type ParsedEntry } from '@/hooks/useEjerbogImport';
import { cn } from '@/lib/utils';

interface ImportEjerbogDialogProps {
  companyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ImportEjerbogDialog({ companyId, open, onOpenChange }: ImportEjerbogDialogProps) {
  const [clearExisting, setClearExisting] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const {
    uploadAndParse,
    importEntries,
    removeEntry,
    updateEntry,
    reset,
    isUploading,
    isParsing,
    isImporting,
    isProcessing,
    parsedData,
    error,
    existingEntriesCount,
  } = useEjerbogImport(companyId);

  const validateAndUpload = async (file: File) => {
    if (file.type !== 'application/pdf') {
      alert('Vælg venligst en PDF-fil');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      alert('Filen er for stor. Maksimum er 10 MB');
      return;
    }

    await uploadAndParse(file);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    await validateAndUpload(file);
    
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    await validateAndUpload(file);
  };

  const handleImport = async () => {
    if (!parsedData) return;
    await importEntries(parsedData.entries, clearExisting, parsedData.ejerbog_date);
    onOpenChange(false);
  };

  const handleClose = () => {
    reset();
    onOpenChange(false);
  };

  const totalOwnership = parsedData?.entries.reduce((sum, e) => sum + e.ownership_pct, 0) || 0;
  const isValidTotal = Math.abs(totalOwnership - 100) < 0.5;

  const getOwnerTypeBadge = (type: string) => {
    return type === 'company' ? (
      <Badge variant="secondary">Selskab</Badge>
    ) : (
      <Badge variant="default">Person</Badge>
    );
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileUp className="h-5 w-5" />
            Importér ejerbog
          </DialogTitle>
          <DialogDescription>
            Upload en ejerbog-PDF for at automatisk udfylde cap table
          </DialogDescription>
        </DialogHeader>

        {/* File Upload Area */}
        {!parsedData && !isProcessing && (
          <div 
            className={cn(
              "border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors",
              isDragging 
                ? "border-primary bg-primary/5" 
                : "border-muted-foreground/25 hover:border-primary/50"
            )}
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <Upload className={cn("h-12 w-12 mx-auto mb-4", isDragging ? "text-primary" : "text-muted-foreground")} />
            <p className="text-lg font-medium mb-1">Træk ejerbog-PDF hertil</p>
            <p className="text-sm text-muted-foreground mb-4">eller klik for at vælge fil</p>
            <Button variant="outline" type="button">
              Vælg fil
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,application/pdf"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>
        )}

        {/* Processing State */}
        {isProcessing && (
          <div className="py-12 text-center">
            <Loader2 className="h-12 w-12 mx-auto text-primary animate-spin mb-4" />
            <p className="text-lg font-medium">
              {isUploading && 'Uploader fil...'}
              {isParsing && 'Analyserer ejerbog med AI...'}
              {isImporting && 'Importerer ejere...'}
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Dette kan tage op til 30 sekunder
            </p>
          </div>
        )}

        {/* Error State */}
        {error && !isProcessing && (
          <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
            <div>
              <p className="font-medium text-destructive">Fejl ved import</p>
              <p className="text-sm text-muted-foreground">{error}</p>
              <Button variant="outline" size="sm" className="mt-3" onClick={reset}>
                Prøv igen
              </Button>
            </div>
          </div>
        )}

        {/* Parsed Data Preview */}
        {parsedData && !isProcessing && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div className="flex flex-col gap-1">
                <div>
                  <span className="text-sm text-muted-foreground">Selskabskapital: </span>
                  <span className="font-medium">
                    {parsedData.total_capital?.toLocaleString('da-DK') || 'Ukendt'} DKK
                  </span>
                </div>
                {parsedData.ejerbog_date && (
                  <div>
                    <span className="text-sm text-muted-foreground">Ejerbog dateret: </span>
                    <span className="font-medium">
                      {new Date(parsedData.ejerbog_date).toLocaleDateString('da-DK')}
                    </span>
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2">
                {isValidTotal ? (
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-warning" />
                )}
                <span className={`text-sm font-medium ${isValidTotal ? 'text-green-600' : 'text-warning'}`}>
                  Total: {totalOwnership.toFixed(2)}%
                </span>
              </div>
            </div>

            {/* Entries Table */}
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Navn</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="text-right">Andel</TableHead>
                    <TableHead className="text-right">Aktier (nom.)</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {parsedData.entries.map((entry, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Input
                          value={entry.owner_name}
                          onChange={(e) => updateEntry(index, { owner_name: e.target.value })}
                          className="h-8"
                        />
                      </TableCell>
                      <TableCell>{getOwnerTypeBadge(entry.owner_type)}</TableCell>
                      <TableCell className="text-right font-medium">
                        {entry.ownership_pct.toFixed(2)}%
                      </TableCell>
                      <TableCell className="text-right">
                        {entry.shares?.toLocaleString('da-DK') || '-'}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeEntry(index)}
                          className="h-8 w-8 p-0"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* Clear Existing Option */}
            {existingEntriesCount > 0 && (
              <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                <Checkbox
                  id="clear-existing"
                  checked={clearExisting}
                  onCheckedChange={(checked) => setClearExisting(checked === true)}
                />
                <label htmlFor="clear-existing" className="text-sm cursor-pointer">
                  Slet eksisterende {existingEntriesCount} ejere før import
                </label>
              </div>
            )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isProcessing}>
            Annuller
          </Button>
          {parsedData && (
            <Button onClick={handleImport} disabled={isProcessing || parsedData.entries.length === 0}>
              {isImporting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Importerer...
                </>
              ) : (
                `Importér ${parsedData.entries.length} ejere`
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
