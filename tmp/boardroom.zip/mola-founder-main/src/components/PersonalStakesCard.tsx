import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Plus, Trash2 } from 'lucide-react';
import { PersonalStake } from '@/hooks/useFundManagement';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface PersonalStakesCardProps {
  stakes: PersonalStake[];
  userId: string;
  onAdd: (stake: { user_id: string; entity_name: string; entity_type: 'company' | 'fund'; ownership_pct: number }) => void;
  onDelete: (stakeId: string) => void;
}

export function PersonalStakesCard({ stakes, userId, onAdd, onDelete }: PersonalStakesCardProps) {
  const [open, setOpen] = useState(false);
  const [entityName, setEntityName] = useState('');
  const [entityType, setEntityType] = useState<'company' | 'fund'>('company');
  const [ownershipPct, setOwnershipPct] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      user_id: userId,
      entity_name: entityName,
      entity_type: entityType,
      ownership_pct: parseFloat(ownershipPct),
    });
    setEntityName('');
    setOwnershipPct('');
    setOpen(false);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Mine Personlige Ejerandele</CardTitle>
            <CardDescription>
              Dine direkte ejerandele i selskaber og fonde
            </CardDescription>
          </div>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Tilføj Ejerandel
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Tilføj Personlig Ejerandel</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="entityName">Enhed Navn</Label>
                  <Input
                    id="entityName"
                    value={entityName}
                    onChange={(e) => setEntityName(e.target.value)}
                    placeholder="fx Mola Invest ApS"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="entityType">Type</Label>
                  <Select value={entityType} onValueChange={(value: any) => setEntityType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="company">Selskab</SelectItem>
                      <SelectItem value="fund">Fond</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ownershipPct">Min Ejerandel (%)</Label>
                  <Input
                    id="ownershipPct"
                    type="number"
                    min="0"
                    max="100"
                    step="0.01"
                    value={ownershipPct}
                    onChange={(e) => setOwnershipPct(e.target.value)}
                    placeholder="100"
                    required
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                    Annuller
                  </Button>
                  <Button type="submit">Tilføj</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Enhed</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="text-right">Min Ejerandel</TableHead>
              <TableHead className="text-right">Handlinger</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {stakes.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-muted-foreground">
                  Ingen personlige ejerandele tilføjet endnu
                </TableCell>
              </TableRow>
            ) : (
              stakes.map((stake) => (
                <TableRow key={stake.id}>
                  <TableCell className="font-medium">{stake.entity_name}</TableCell>
                  <TableCell>
                    <Badge variant={stake.entity_type === 'company' ? 'secondary' : 'outline'}>
                      {stake.entity_type === 'company' ? 'Selskab' : 'Fond'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">{stake.ownership_pct}%</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(stake.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
