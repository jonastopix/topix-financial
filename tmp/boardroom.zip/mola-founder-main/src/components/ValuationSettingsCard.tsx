import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from './ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Settings, RefreshCw, TrendingUp, Trash2 } from 'lucide-react';
import { ValuationSettings } from '@/hooks/useValuationSettings';
import { useValuationCalculator } from '@/hooks/useValuationCalculator';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from './ui/collapsible';

interface ValuationSettingsCardProps {
  settings: ValuationSettings;
  companyId: string;
}

export function ValuationSettingsCard({ settings, companyId }: ValuationSettingsCardProps) {
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [revenueMultiple, setRevenueMultiple] = useState(settings.revenue_multiple.toString());
  const [ebitdaMultiple, setEbitdaMultiple] = useState(settings.ebitda_multiple.toString());
  const [activeMarkets, setActiveMarkets] = useState(settings.active_markets.toString());
  const [revenueWeight, setRevenueWeight] = useState([settings.valuation_weight_revenue_pct]);
  const [isUpdating, setIsUpdating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const { canCalculate, calculateValuation } = useValuationCalculator(companyId);
  const queryClient = useQueryClient();

  const handleRecalculate = async () => {
    if (!canCalculate) return;
    await calculateValuation();
    await queryClient.invalidateQueries({ queryKey: ['company-returns-data', companyId] });
  };

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);

    try {
      const revMult = parseFloat(revenueMultiple);
      const ebitMult = parseFloat(ebitdaMultiple);
      const markets = parseInt(activeMarkets);
      const revWeight = revenueWeight[0];

      // Validate
      if (revMult < 0.1 || revMult > 100) {
        toast.error('Revenue multiple skal være mellem 0.1 og 100');
        return;
      }
      if (ebitMult < 0.1 || ebitMult > 100) {
        toast.error('EBITDA multiple skal være mellem 0.1 og 100');
        return;
      }
      if (markets < 1 || markets > 200) {
        toast.error('Antal markeder skal være mellem 1 og 200');
        return;
      }

      const { error } = await supabase
        .from('company_valuation_settings')
        .update({
          revenue_multiple: revMult,
          ebitda_multiple: ebitMult,
          active_markets: markets,
          valuation_weight_revenue_pct: revWeight,
          updated_at: new Date().toISOString(),
        })
        .eq('id', settings.id);

      if (error) {
        console.error('Error updating settings:', error);
        toast.error('Fejl ved opdatering af indstillinger');
        throw error;
      }

      await queryClient.invalidateQueries({ queryKey: ['valuation-settings', companyId] });
      toast.success('Indstillinger opdateret!');
      setIsEditOpen(false);
    } catch (error) {
      console.error('Error in handleUpdate:', error);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    
    try {
      const { error } = await supabase
        .from('company_valuation_settings')
        .delete()
        .eq('id', settings.id);

      if (error) {
        console.error('Error deleting settings:', error);
        toast.error('Fejl ved sletning af indstillinger');
        throw error;
      }

      await queryClient.invalidateQueries({ queryKey: ['valuation-settings', companyId] });
      toast.success('Valuation indstillinger slettet');
      setIsDeleteOpen(false);
    } catch (error) {
      console.error('Error in handleDelete:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <TrendingUp className="h-5 w-5 text-primary" />
              <div className="flex-1">
                <CollapsibleTrigger className="text-left hover:underline">
                  <h3 className="text-sm font-semibold">Valuation Indstillinger</h3>
                </CollapsibleTrigger>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs">
                    Revenue: {settings.revenue_multiple}x
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    EBITDA: {settings.ebitda_multiple}x
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {settings.active_markets} markets
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" onClick={() => setIsEditOpen(true)}>
                <Settings className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRecalculate}
                disabled={!canCalculate}
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setIsDeleteOpen(true)}
                className="text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <CollapsibleContent className="mt-4 pt-4 border-t">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Vægtning:</span>
                <p className="font-medium">
                  {settings.valuation_weight_revenue_pct}% Revenue / {100 - settings.valuation_weight_revenue_pct}% EBITDA
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Sidst opdateret:</span>
                <p className="font-medium">
                  {new Date(settings.updated_at).toLocaleDateString('da-DK')}
                </p>
              </div>
            </div>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rediger Valuation Parametre</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleUpdate} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-revenue-multiple">Revenue Multiple</Label>
              <Input
                id="edit-revenue-multiple"
                type="number"
                step="0.1"
                min="0.1"
                max="100"
                value={revenueMultiple}
                onChange={(e) => setRevenueMultiple(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-ebitda-multiple">EBITDA Multiple</Label>
              <Input
                id="edit-ebitda-multiple"
                type="number"
                step="0.1"
                min="0.1"
                max="100"
                value={ebitdaMultiple}
                onChange={(e) => setEbitdaMultiple(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-active-markets">Antal Aktive Markeder</Label>
              <Input
                id="edit-active-markets"
                type="number"
                min="1"
                max="200"
                value={activeMarkets}
                onChange={(e) => setActiveMarkets(e.target.value)}
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Vægtning</Label>
                <div className="text-sm font-medium">
                  Revenue {revenueWeight[0]}% • EBITDA {100 - revenueWeight[0]}%
                </div>
              </div>
              <Slider
                value={revenueWeight}
                onValueChange={setRevenueWeight}
                max={100}
                step={5}
              />
            </div>

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsEditOpen(false)}
                className="flex-1"
              >
                Annuller
              </Button>
              <Button type="submit" disabled={isUpdating} className="flex-1">
                {isUpdating ? 'Gemmer...' : 'Gem Ændringer'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Slet valuation indstillinger?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil slette de nuværende valuation parametre. Eksisterende valuations vil blive bevaret, 
              men automatisk beregning ved månedlige rapporter vil blive deaktiveret.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete} 
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? 'Sletter...' : 'Slet indstillinger'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
