import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Award, Lock, ChevronRight, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useBadges, BadgeWithDefinition } from '@/hooks/useBadges';

function BadgeCard({ badge, showProgress = true }: { badge: BadgeWithDefinition; showProgress?: boolean }) {
  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className={`p-4 rounded-lg border ${
        badge.isEarned 
          ? 'bg-primary/5 border-primary/20' 
          : 'bg-muted/50 border-border opacity-60'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className={`text-3xl ${!badge.isEarned && 'grayscale'}`}>
          {badge.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h4 className={`font-medium truncate ${badge.isEarned ? '' : 'text-muted-foreground'}`}>
              {badge.label}
            </h4>
            {badge.isEarned && (
              <Sparkles className="h-3 w-3 text-yellow-500 flex-shrink-0" />
            )}
          </div>
          <p className="text-xs text-muted-foreground line-clamp-2">
            {badge.description}
          </p>
          
          {showProgress && !badge.isEarned && badge.target > 1 && (
            <div className="mt-2 space-y-1">
              <Progress value={badge.progressPercent} className="h-1" />
              <p className="text-xs text-muted-foreground">
                {badge.progress} / {badge.target}
              </p>
            </div>
          )}
          
          {badge.isEarned && badge.earned_at && (
            <p className="text-xs text-primary mt-1">
              Optjent {new Date(badge.earned_at).toLocaleDateString('da-DK')}
            </p>
          )}
        </div>
        {!badge.isEarned && (
          <Lock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
        )}
      </div>
    </motion.div>
  );
}

export function BadgesShowcase() {
  const { badges, earnedBadges, earnedCount, totalCount, isLoading } = useBadges();
  const [dialogOpen, setDialogOpen] = useState(false);

  // Group badges by type
  const achievementBadges = badges.filter(b => b.badge_type === 'achievement');
  const streakBadges = badges.filter(b => b.badge_type === 'streak');
  const xpBadges = badges.filter(b => b.badge_type === 'xp');
  const secretBadges = badges.filter(b => b.badge_type === 'secret');

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Badges</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-20 bg-muted animate-pulse rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Award className="h-4 w-4" />
            Badges
          </CardTitle>
          <Badge variant="secondary" className="text-xs">
            {earnedCount}/{totalCount}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {/* Preview of earned badges */}
        <div className="flex flex-wrap gap-2 mb-3">
          {earnedBadges.slice(0, 5).map((badge) => (
            <motion.div
              key={badge.code}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              whileHover={{ scale: 1.2 }}
              className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-xl cursor-pointer"
              title={badge.label}
            >
              {badge.icon}
            </motion.div>
          ))}
          {earnedBadges.length === 0 && (
            <p className="text-sm text-muted-foreground">
              Ingen badges optjent endnu
            </p>
          )}
        </div>

        {/* Progress bar */}
        <div className="space-y-1 mb-3">
          <Progress value={(earnedCount / totalCount) * 100} className="h-1.5" />
          <p className="text-xs text-muted-foreground">
            {Math.round((earnedCount / totalCount) * 100)}% af alle badges optjent
          </p>
        </div>

        {/* View all button */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="w-full">
              Se alle badges
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[80vh]">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Alle Badges ({earnedCount}/{totalCount})
              </DialogTitle>
            </DialogHeader>
            <Tabs defaultValue="all">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="all">Alle</TabsTrigger>
                <TabsTrigger value="achievements">Achievements</TabsTrigger>
                <TabsTrigger value="streaks">Streaks</TabsTrigger>
                <TabsTrigger value="secret">Hemmelige</TabsTrigger>
              </TabsList>
              <ScrollArea className="h-[50vh] mt-4">
                <TabsContent value="all" className="space-y-3 mt-0">
                  <AnimatePresence>
                    {badges.map((badge, index) => (
                      <motion.div
                        key={badge.code}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <BadgeCard badge={badge} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </TabsContent>
                <TabsContent value="achievements" className="space-y-3 mt-0">
                  {achievementBadges.map((badge) => (
                    <BadgeCard key={badge.code} badge={badge} />
                  ))}
                </TabsContent>
                <TabsContent value="streaks" className="space-y-3 mt-0">
                  {streakBadges.map((badge) => (
                    <BadgeCard key={badge.code} badge={badge} />
                  ))}
                </TabsContent>
                <TabsContent value="secret" className="space-y-3 mt-0">
                  {secretBadges.map((badge) => (
                    <BadgeCard key={badge.code} badge={badge} />
                  ))}
                  {xpBadges.map((badge) => (
                    <BadgeCard key={badge.code} badge={badge} />
                  ))}
                </TabsContent>
              </ScrollArea>
            </Tabs>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
