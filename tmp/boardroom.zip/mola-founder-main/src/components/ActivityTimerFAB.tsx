import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Timer, Play, Square, X, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useActivityTimer } from '@/hooks/useActivityTimer';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

interface ActivityTimerFABProps {
  onTimerStop?: (result: {
    durationMinutes: number;
    companyId: string | null;
    companyName: string | null;
    activityType: string | null;
  }) => void;
}

export function ActivityTimerFAB({ onTimerStop }: ActivityTimerFABProps) {
  const [isOpen, setIsOpen] = useState(false);
  const {
    isRunning,
    companyName,
    activityType,
    elapsedTime,
    elapsedMinutes,
    stopTimer,
    cancelTimer,
  } = useActivityTimer();

  const handleStop = () => {
    const result = stopTimer();
    onTimerStop?.(result);
    setIsOpen(false);
  };

  const handleCancel = () => {
    cancelTimer();
    setIsOpen(false);
  };

  if (!isRunning) return null;

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          className="fixed bottom-20 left-4 z-50 md:bottom-6"
        >
          <Button
            size="lg"
            className={cn(
              'rounded-full shadow-lg h-14 px-4 gap-2',
              'bg-red-500 hover:bg-red-600 text-white',
              'animate-pulse'
            )}
          >
            <Timer className="h-5 w-5" />
            <span className="font-mono font-bold">{elapsedTime}</span>
          </Button>
        </motion.div>
      </SheetTrigger>

      <SheetContent side="bottom" className="rounded-t-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-red-500" />
            Aktiv Timer
          </SheetTitle>
        </SheetHeader>

        <div className="py-6 space-y-6">
          {/* Timer display */}
          <div className="text-center">
            <motion.div
              key={elapsedTime}
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              className="text-5xl font-mono font-bold text-foreground"
            >
              {elapsedTime}
            </motion.div>
            <p className="text-muted-foreground mt-2">
              {elapsedMinutes} {elapsedMinutes === 1 ? 'minut' : 'minutter'}
            </p>
          </div>

          {/* Activity info */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Selskab</span>
              <span className="font-medium">{companyName || 'Ikke valgt'}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Type</span>
              <span className="font-medium capitalize">{activityType || 'Møde'}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={handleCancel}
            >
              <X className="h-4 w-4 mr-2" />
              Annuller
            </Button>
            <Button
              className="flex-1 bg-red-500 hover:bg-red-600"
              onClick={handleStop}
            >
              <Square className="h-4 w-4 mr-2" />
              Stop & Gem
            </Button>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            Timeren fortsætter selvom du forlader siden
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// Mini component for starting timer from activity sheet
export function TimerStartButton({
  companyId,
  companyName,
  activityType,
  disabled,
}: {
  companyId: string;
  companyName: string;
  activityType: string;
  disabled?: boolean;
}) {
  const { isRunning, startTimer } = useActivityTimer();

  const handleStart = () => {
    startTimer(companyId, companyName, activityType);
  };

  if (isRunning) {
    return (
      <Button variant="outline" size="sm" disabled className="gap-2">
        <Timer className="h-4 w-4 animate-pulse text-red-500" />
        Timer kører...
      </Button>
    );
  }

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={handleStart}
      disabled={disabled}
      className="gap-2"
    >
      <Play className="h-4 w-4" />
      Start timer
    </Button>
  );
}
