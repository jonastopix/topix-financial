import { Progress } from '@/components/ui/progress';

interface ProgressBarProps {
  value: number;
  total: number;
}

const ProgressBar = ({ value, total }: ProgressBarProps) => {
  const percentage = total > 0 ? Math.round((value / total) * 100) : 0;

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-foreground font-medium">Samlet fremdrift</span>
        <span className="text-muted-foreground">
          {value} / {total} dokumenter uploadet ({percentage}%)
        </span>
      </div>
      <Progress value={percentage} className="h-2" />
    </div>
  );
};

export default ProgressBar;
