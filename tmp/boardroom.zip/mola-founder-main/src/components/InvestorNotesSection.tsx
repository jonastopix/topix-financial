import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useInvestorNotes, useInvestorNotesMutations } from '@/hooks/useInvestorNotes';
import { useAuth } from '@/contexts/AuthContext';
import { Pencil, Trash2, Plus, Save, X } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface InvestorNotesSectionProps {
  companyId: string;
}

export function InvestorNotesSection({ companyId }: InvestorNotesSectionProps) {
  const { user } = useAuth();
  const { data: notes, isLoading } = useInvestorNotes(companyId);
  const { addNote, updateNote, deleteNote } = useInvestorNotesMutations();

  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  const handleAdd = () => {
    if (!user || !noteText.trim()) return;

    addNote.mutate(
      {
        company_id: companyId,
        investor_id: user.id,
        note_text: noteText,
        is_private: true,
      },
      {
        onSuccess: () => {
          setNoteText('');
          setIsAdding(false);
        },
      }
    );
  };

  const handleUpdate = (id: string) => {
    if (!noteText.trim()) return;

    updateNote.mutate(
      {
        id,
        note_text: noteText,
      },
      {
        onSuccess: () => {
          setNoteText('');
          setEditingId(null);
        },
      }
    );
  };

  const handleDelete = (id: string) => {
    if (confirm('Er du sikker på at du vil slette denne note?')) {
      deleteNote.mutate({ id, companyId });
    }
  };

  const startEdit = (note: any) => {
    setEditingId(note.id);
    setNoteText(note.note_text);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setNoteText('');
    setIsAdding(false);
  };

  if (isLoading) {
    return <div>Indlæser noter...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Mine private noter</CardTitle>
              <CardDescription>
                Disse noter er kun synlige for dig og MOLA administratorer
              </CardDescription>
            </div>
            {!isAdding && !editingId && (
              <Button onClick={() => setIsAdding(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Ny note
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Add form */}
            {isAdding && (
              <Card className="border-2 border-primary/20">
                <CardContent className="pt-6 space-y-4">
                  <Textarea
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    placeholder="Skriv din note her..."
                    rows={4}
                  />
                  <div className="flex gap-2">
                    <Button onClick={handleAdd} disabled={addNote.isPending}>
                      <Save className="h-4 w-4 mr-2" />
                      Gem note
                    </Button>
                    <Button variant="outline" onClick={cancelEdit}>
                      <X className="h-4 w-4 mr-2" />
                      Annuller
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Notes list */}
            {notes && notes.length === 0 && !isAdding ? (
              <div className="text-center py-8 text-muted-foreground">
                <p>Ingen noter endnu. Tilføj din første note.</p>
              </div>
            ) : (
              notes?.map((note) => (
                <Card key={note.id}>
                  <CardContent className="pt-6">
                    {editingId === note.id ? (
                      <div className="space-y-4">
                        <Textarea
                          value={noteText}
                          onChange={(e) => setNoteText(e.target.value)}
                          rows={4}
                        />
                        <div className="flex gap-2">
                          <Button onClick={() => handleUpdate(note.id)} disabled={updateNote.isPending}>
                            <Save className="h-4 w-4 mr-2" />
                            Gem ændringer
                          </Button>
                          <Button variant="outline" onClick={cancelEdit}>
                            <X className="h-4 w-4 mr-2" />
                            Annuller
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-start justify-between gap-4">
                          <p className="text-sm whitespace-pre-wrap flex-1">{note.note_text}</p>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => startEdit(note)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(note.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          {format(new Date(note.created_at), 'PPP HH:mm', { locale: da })}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
