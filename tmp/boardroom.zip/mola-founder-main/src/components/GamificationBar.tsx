import { Award, TrendingUp, Shield } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Card } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const GamificationBar = () => {
  const badges = [
    {
      icon: Award,
      name: 'Consistency Award',
      description: '3 rapporteringer i træk',
      earned: true
    },
    {
      icon: TrendingUp,
      name: 'Growth Award',
      description: '+25% YOY omsætning',
      earned: true
    },
    {
      icon: Shield,
      name: 'Transparency Award',
      description: 'Alle dokumenter uploadet & AI-rapport delt',
      earned: false
    }
  ];

  return (
    <Card className="p-6 mb-8">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Din Progress</h3>
          <span className="text-sm text-muted-foreground">3/12 måneder (25%)</span>
        </div>
        <Progress value={25} className="h-3" />
        
        <div className="pt-4 border-t border-border">
          <h4 className="text-sm font-medium mb-3">Dine Badges</h4>
          <div className="flex gap-4">
            <TooltipProvider>
              {badges.map((badge, idx) => (
                <Tooltip key={idx}>
                  <TooltipTrigger asChild>
                    <div 
                      className={`flex flex-col items-center gap-2 p-3 rounded-lg transition-all duration-300 ${
                        badge.earned 
                          ? 'bg-accent/10 hover:bg-accent/20 cursor-pointer' 
                          : 'opacity-30 grayscale'
                      }`}
                    >
                      <badge.icon className={badge.earned ? 'h-8 w-8 text-accent' : 'h-8 w-8'} />
                      <span className="text-xs text-center max-w-[80px]">{badge.name}</span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{badge.description}</p>
                  </TooltipContent>
                </Tooltip>
              ))}
            </TooltipProvider>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default GamificationBar;
