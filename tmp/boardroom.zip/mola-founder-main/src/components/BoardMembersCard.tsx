import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Plus, Mail, Phone, Calendar, AlertTriangle } from 'lucide-react';
import { useBoardMembers } from '@/hooks/useBoardMembers';
import { useState } from 'react';
import { AddBoardMemberDialog } from './AddBoardMemberDialog';
import { format, differenceInMonths } from 'date-fns';
import { da } from 'date-fns/locale';

interface BoardMembersCardProps {
  companyId: string;
  canManage?: boolean;
}

export function BoardMembersCard({ companyId, canManage = false }: BoardMembersCardProps) {
  const { activeMembers, isLoading } = useBoardMembers(companyId);
  const [showAddDialog, setShowAddDialog] = useState(false);

  const getTermWarning = (termEndDate?: string) => {
    if (!termEndDate) return null;
    
    const monthsUntilEnd = differenceInMonths(new Date(termEndDate), new Date());
    if (monthsUntilEnd <= 3 && monthsUntilEnd >= 0) {
      return `Valgperiode udløber om ${monthsUntilEnd} måned${monthsUntilEnd !== 1 ? 'er' : ''}`;
    }
    return null;
  };

  const getRoleName = (role: string) => {
    switch (role) {
      case 'chairman': return 'Formand';
      case 'member': return 'Medlem';
      case 'alternate': return 'Suppleant';
      default: return role;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground">Indlæser...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              <CardTitle>Bestyrelsesmedlemmer</CardTitle>
              <Badge variant="secondary">{activeMembers.length}</Badge>
            </div>
            {canManage && (
              <Button onClick={() => setShowAddDialog(true)} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Tilføj medlem
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {activeMembers.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Ingen bestyrelsesmedlemmer tilføjet endnu
            </p>
          ) : (
            <div className="space-y-4">
              {activeMembers.map((member) => {
                const warning = getTermWarning(member.term_end_date);
                
                return (
                  <div
                    key={member.id}
                    className="flex items-start justify-between p-4 rounded-lg border bg-card"
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold">{member.name}</h4>
                        <Badge variant={member.role === 'chairman' ? 'default' : 'secondary'}>
                          {getRoleName(member.role)}
                        </Badge>
                        {warning && (
                          <Badge variant="destructive" className="flex items-center gap-1">
                            <AlertTriangle className="h-3 w-3" />
                            {warning}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex flex-col gap-1 text-sm text-muted-foreground">
                        {member.email && (
                          <div className="flex items-center gap-2">
                            <Mail className="h-3 w-3" />
                            <a href={`mailto:${member.email}`} className="hover:underline">
                              {member.email}
                            </a>
                          </div>
                        )}
                        {member.phone && (
                          <div className="flex items-center gap-2">
                            <Phone className="h-3 w-3" />
                            <a href={`tel:${member.phone}`} className="hover:underline">
                              {member.phone}
                            </a>
                          </div>
                        )}
                        <div className="flex items-center gap-2">
                          <Calendar className="h-3 w-3" />
                          <span>
                            Tiltrådt: {format(new Date(member.appointed_date), 'PPP', { locale: da })}
                          </span>
                        </div>
                        {member.term_end_date && (
                          <div className="flex items-center gap-2">
                            <Calendar className="h-3 w-3" />
                            <span>
                              Valgperiode udløber: {format(new Date(member.term_end_date), 'PPP', { locale: da })}
                            </span>
                          </div>
                        )}
                      </div>

                      {member.notes && (
                        <p className="text-sm text-muted-foreground italic">
                          {member.notes}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <AddBoardMemberDialog
        companyId={companyId}
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
      />
    </>
  );
}
