import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useSaveCompanyPrices } from "@/hooks/useProcurementData";
import { Package, CreditCard, Laptop, Zap, CheckCircle2 } from "lucide-react";

interface ProcurementWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
}

interface PriceData {
  category: string;
  subcategory: string;
  value_numeric: number;
  unit: string;
  sample_volume_monthly: number | null;
}

export const ProcurementWizard = ({ open, onOpenChange, companyId }: ProcurementWizardProps) => {
  const [step, setStep] = useState(1);
  const [prices, setPrices] = useState<PriceData[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const navigate = useNavigate();
  const { toast } = useToast();
  const savePrices = useSaveCompanyPrices();

  const [shippingHome, setShippingHome] = useState("");
  const [shippingPickup, setShippingPickup] = useState("");
  const [shippingVolume, setShippingVolume] = useState("");
  
  const [paymentCard, setPaymentCard] = useState("");
  const [paymentMobilepay, setPaymentMobilepay] = useState("");
  const [paymentKlarna, setPaymentKlarna] = useState("");
  const [paymentVolume, setPaymentVolume] = useState("");
  
  const [saasWorkfeed, setSaasWorkfeed] = useState("");
  const [saasSlack, setSaasSlack] = useState("");
  const [saasClickup, setSaasClickup] = useState("");
  const [saasUsers, setSaasUsers] = useState("");
  
  const [energyElectricity, setEnergyElectricity] = useState("");
  const [energyVolume, setEnergyVolume] = useState("");
  const [teleSim, setTeleSim] = useState("");
  const [teleInternet, setTeleInternet] = useState("");

  const validateNumber = (value: string, fieldName: string, required = false) => {
    if (!value && !required) return true;
    if (!value && required) {
      setErrors(prev => ({ ...prev, [fieldName]: "Dette felt er påkrævet" }));
      return false;
    }
    const num = parseFloat(value);
    if (isNaN(num) || num <= 0) {
      setErrors(prev => ({ ...prev, [fieldName]: "Skal være et tal større end 0" }));
      return false;
    }
    setErrors(prev => {
      const newErrors = { ...prev };
      delete newErrors[fieldName];
      return newErrors;
    });
    return true;
  };

  const validateStep = (currentStep: number) => {
    let valid = true;
    const newErrors: Record<string, string> = {};

    if (currentStep === 2) {
      if (!shippingHome && !shippingPickup) {
        newErrors.shipping = "Indtast mindst én fragtoption";
        valid = false;
      }
      if (shippingHome && !validateNumber(shippingHome, 'shippingHome', true)) valid = false;
      if (shippingPickup && !validateNumber(shippingPickup, 'shippingPickup', true)) valid = false;
      if (!validateNumber(shippingVolume, 'shippingVolume', true)) valid = false;
    } else if (currentStep === 3) {
      if (!paymentCard && !paymentMobilepay && !paymentKlarna) {
        newErrors.payment = "Indtast mindst én betalingsoption";
        valid = false;
      }
      if (paymentCard && !validateNumber(paymentCard, 'paymentCard', true)) valid = false;
      if (paymentMobilepay && !validateNumber(paymentMobilepay, 'paymentMobilepay', true)) valid = false;
      if (paymentKlarna && !validateNumber(paymentKlarna, 'paymentKlarna', true)) valid = false;
      if (!validateNumber(paymentVolume, 'paymentVolume', true)) valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
  };

  const handleSubmit = async () => {
    const allPrices: PriceData[] = [];

    // Shipping
    if (shippingHome) {
      allPrices.push({
        category: 'shipping',
        subcategory: 'home_delivery',
        value_numeric: parseFloat(shippingHome),
        unit: 'kr/pakke',
        sample_volume_monthly: parseFloat(shippingVolume) || null,
      });
    }
    if (shippingPickup) {
      allPrices.push({
        category: 'shipping',
        subcategory: 'pickup_point',
        value_numeric: parseFloat(shippingPickup),
        unit: 'kr/pakke',
        sample_volume_monthly: parseFloat(shippingVolume) || null,
      });
    }

    // Payment
    if (paymentCard) {
      allPrices.push({
        category: 'payment',
        subcategory: 'card_fee',
        value_numeric: parseFloat(paymentCard),
        unit: '% af transaction',
        sample_volume_monthly: parseFloat(paymentVolume) || null,
      });
    }
    if (paymentMobilepay) {
      allPrices.push({
        category: 'payment',
        subcategory: 'mobilepay',
        value_numeric: parseFloat(paymentMobilepay),
        unit: '% af transaction',
        sample_volume_monthly: parseFloat(paymentVolume) || null,
      });
    }
    if (paymentKlarna) {
      allPrices.push({
        category: 'payment',
        subcategory: 'klarna',
        value_numeric: parseFloat(paymentKlarna),
        unit: '% af transaction',
        sample_volume_monthly: parseFloat(paymentVolume) || null,
      });
    }

    // SaaS
    if (saasWorkfeed) {
      allPrices.push({
        category: 'saas',
        subcategory: 'workfeed',
        value_numeric: parseFloat(saasWorkfeed),
        unit: 'kr/bruger/md',
        sample_volume_monthly: parseFloat(saasUsers) || null,
      });
    }
    if (saasSlack) {
      allPrices.push({
        category: 'saas',
        subcategory: 'slack',
        value_numeric: parseFloat(saasSlack),
        unit: 'kr/bruger/md',
        sample_volume_monthly: parseFloat(saasUsers) || null,
      });
    }
    if (saasClickup) {
      allPrices.push({
        category: 'saas',
        subcategory: 'clickup',
        value_numeric: parseFloat(saasClickup),
        unit: 'kr/bruger/md',
        sample_volume_monthly: parseFloat(saasUsers) || null,
      });
    }

    // Energy & Tele
    if (energyElectricity) {
      allPrices.push({
        category: 'energy',
        subcategory: 'electricity',
        value_numeric: parseFloat(energyElectricity),
        unit: 'kr/kWh',
        sample_volume_monthly: parseFloat(energyVolume) || null,
      });
    }
    if (teleSim) {
      allPrices.push({
        category: 'tele',
        subcategory: 'sim',
        value_numeric: parseFloat(teleSim),
        unit: 'kr/SIM/md',
        sample_volume_monthly: null,
      });
    }
    if (teleInternet) {
      allPrices.push({
        category: 'tele',
        subcategory: 'internet',
        value_numeric: parseFloat(teleInternet),
        unit: 'kr/md',
        sample_volume_monthly: null,
      });
    }

    const pricesWithCompany = allPrices.map(p => ({ ...p, company_id: companyId }));
    
    await savePrices.mutateAsync(pricesWithCompany as any);
    onOpenChange(false);
    navigate('/procurement/benchmarks');
    toast({
      title: "Priser gemt!",
      description: "Dine priser er nu sammenlignet med porteføljen.",
    });
  };

  const steps = [
    { number: 1, title: "Velkommen", icon: CheckCircle2 },
    { number: 2, title: "Fragt", icon: Package },
    { number: 3, title: "Betaling", icon: CreditCard },
    { number: 4, title: "SaaS", icon: Laptop },
    { number: 5, title: "Energi & Tele", icon: Zap },
    { number: 6, title: "Bekræft", icon: CheckCircle2 },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Indlæs egne priser</DialogTitle>
        </DialogHeader>

        {/* Progress bar */}
        <div className="flex items-center justify-between mb-6">
          {steps.map((s, idx) => (
            <div key={s.number} className="flex items-center">
              <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                step >= s.number ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
              }`}>
                {step > s.number ? <CheckCircle2 className="w-4 h-4" /> : s.number}
              </div>
              {idx < steps.length - 1 && (
                <div className={`w-12 h-0.5 ${step > s.number ? 'bg-primary' : 'bg-muted'}`} />
              )}
            </div>
          ))}
        </div>

        {/* Step 1: Intro */}
        {step === 1 && (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Velkommen til prisindlæsnings-guiden! Vi hjælper dig med at sammenligne dine priser med porteføljen.
            </p>
            <p className="text-sm text-muted-foreground">
              Du vil blive guidet gennem 5 kategorier. Indtast dine nuværende priser, så vi kan beregne 
              potentielle besparelser.
            </p>
          </div>
        )}

        {/* Step 2: Shipping */}
        {step === 2 && (
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Package className="w-5 h-5" />
              Fragt & levering
            </h3>
            
            <div>
              <Label htmlFor="shippingHome">Hjemmelevering (kr/pakke)</Label>
              <Input
                id="shippingHome"
                type="number"
                step="0.01"
                value={shippingHome}
                onChange={(e) => setShippingHome(e.target.value)}
                onBlur={() => validateNumber(shippingHome, 'shippingHome')}
              />
              {errors.shippingHome && <p className="text-sm text-destructive mt-1">{errors.shippingHome}</p>}
            </div>

            <div>
              <Label htmlFor="shippingPickup">Pakkeshop (kr/pakke)</Label>
              <Input
                id="shippingPickup"
                type="number"
                step="0.01"
                value={shippingPickup}
                onChange={(e) => setShippingPickup(e.target.value)}
                onBlur={() => validateNumber(shippingPickup, 'shippingPickup')}
              />
              {errors.shippingPickup && <p className="text-sm text-destructive mt-1">{errors.shippingPickup}</p>}
            </div>

            <div>
              <Label htmlFor="shippingVolume">Månedligt volumen (antal pakker) *</Label>
              <Input
                id="shippingVolume"
                type="number"
                value={shippingVolume}
                onChange={(e) => setShippingVolume(e.target.value)}
                onBlur={() => validateNumber(shippingVolume, 'shippingVolume', true)}
                required
              />
              {errors.shippingVolume && <p className="text-sm text-destructive mt-1">{errors.shippingVolume}</p>}
            </div>

            {errors.shipping && <p className="text-sm text-destructive">{errors.shipping}</p>}
          </div>
        )}

        {/* Step 3: Payment */}
        {step === 3 && (
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Betaling & gebyrer
            </h3>
            
            <div>
              <Label htmlFor="paymentCard">Kortgebyr (% af transaction)</Label>
              <Input
                id="paymentCard"
                type="number"
                step="0.01"
                value={paymentCard}
                onChange={(e) => setPaymentCard(e.target.value)}
                onBlur={() => validateNumber(paymentCard, 'paymentCard')}
              />
              {errors.paymentCard && <p className="text-sm text-destructive mt-1">{errors.paymentCard}</p>}
            </div>

            <div>
              <Label htmlFor="paymentMobilepay">MobilePay (% af transaction)</Label>
              <Input
                id="paymentMobilepay"
                type="number"
                step="0.01"
                value={paymentMobilepay}
                onChange={(e) => setPaymentMobilepay(e.target.value)}
                onBlur={() => validateNumber(paymentMobilepay, 'paymentMobilepay')}
              />
              {errors.paymentMobilepay && <p className="text-sm text-destructive mt-1">{errors.paymentMobilepay}</p>}
            </div>

            <div>
              <Label htmlFor="paymentKlarna">Klarna (% af transaction)</Label>
              <Input
                id="paymentKlarna"
                type="number"
                step="0.01"
                value={paymentKlarna}
                onChange={(e) => setPaymentKlarna(e.target.value)}
                onBlur={() => validateNumber(paymentKlarna, 'paymentKlarna')}
              />
              {errors.paymentKlarna && <p className="text-sm text-destructive mt-1">{errors.paymentKlarna}</p>}
            </div>

            <div>
              <Label htmlFor="paymentVolume">Månedlige transaktioner *</Label>
              <Input
                id="paymentVolume"
                type="number"
                value={paymentVolume}
                onChange={(e) => setPaymentVolume(e.target.value)}
                onBlur={() => validateNumber(paymentVolume, 'paymentVolume', true)}
                required
              />
              {errors.paymentVolume && <p className="text-sm text-destructive mt-1">{errors.paymentVolume}</p>}
            </div>

            {errors.payment && <p className="text-sm text-destructive">{errors.payment}</p>}
          </div>
        )}

        {/* Step 4: SaaS */}
        {step === 4 && (
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Laptop className="w-5 h-5" />
              SaaS & tools
            </h3>
            
            <div>
              <Label htmlFor="saasWorkfeed">Workfeed (kr/bruger/md)</Label>
              <Input
                id="saasWorkfeed"
                type="number"
                step="0.01"
                value={saasWorkfeed}
                onChange={(e) => setSaasWorkfeed(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="saasSlack">Slack (kr/bruger/md)</Label>
              <Input
                id="saasSlack"
                type="number"
                step="0.01"
                value={saasSlack}
                onChange={(e) => setSaasSlack(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="saasClickup">ClickUp (kr/bruger/md)</Label>
              <Input
                id="saasClickup"
                type="number"
                step="0.01"
                value={saasClickup}
                onChange={(e) => setSaasClickup(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="saasUsers">Antal brugere</Label>
              <Input
                id="saasUsers"
                type="number"
                value={saasUsers}
                onChange={(e) => setSaasUsers(e.target.value)}
              />
            </div>
          </div>
        )}

        {/* Step 5: Energy & Tele */}
        {step === 5 && (
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Energi & Tele
            </h3>
            
            <div>
              <Label htmlFor="energyElectricity">El (kr/kWh)</Label>
              <Input
                id="energyElectricity"
                type="number"
                step="0.01"
                value={energyElectricity}
                onChange={(e) => setEnergyElectricity(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="energyVolume">Månedligt forbrug (kWh)</Label>
              <Input
                id="energyVolume"
                type="number"
                value={energyVolume}
                onChange={(e) => setEnergyVolume(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="teleSim">Mobil SIM (kr/SIM/md)</Label>
              <Input
                id="teleSim"
                type="number"
                step="0.01"
                value={teleSim}
                onChange={(e) => setTeleSim(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="teleInternet">Internet (kr/md)</Label>
              <Input
                id="teleInternet"
                type="number"
                step="0.01"
                value={teleInternet}
                onChange={(e) => setTeleInternet(e.target.value)}
              />
            </div>
          </div>
        )}

        {/* Step 6: Confirm */}
        {step === 6 && (
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              Bekræft og gem
            </h3>
            <p className="text-muted-foreground">
              Du er ved at gemme dine priser. Vi vil beregne hvor du står i forhold til porteføljen 
              og vise potentielle besparelser.
            </p>
            <p className="text-sm text-muted-foreground">
              Tryk "Gem" for at fortsætte til benchmarks.
            </p>
          </div>
        )}

        {/* Navigation buttons */}
        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={step === 1}
          >
            Tilbage
          </Button>
          
          {step < 6 ? (
            <Button onClick={handleNext}>
              Næste
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={savePrices.isPending}>
              {savePrices.isPending ? "Gemmer..." : "Gem"}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};