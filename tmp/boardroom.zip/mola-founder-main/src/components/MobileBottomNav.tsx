import { useNavigate, useLocation } from 'react-router-dom';
import { Home, CheckSquare, Plus, Search, Menu, LogOut, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { useSidebar } from '@/components/ui/sidebar';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { UnifiedQuickFAB } from './UnifiedQuickFAB';

const MobileBottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { signOut, user } = useAuth();
  const { isAdmin, activeRole } = useRole();
  const { toggleSidebar } = useSidebar();
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Simplified navigation items - focused on quick actions
  const navItems = [
    { icon: Home, label: 'Hjem', path: '/', action: null },
    { icon: CheckSquare, label: 'Opgaver', path: '/tasks', action: null },
    { icon: Plus, label: 'Registrer', path: null, action: 'fab' }, // Opens UnifiedQuickFAB
    { icon: Search, label: 'Søg', path: null, action: 'search' },
  ];

  const isActive = (path: string | null) => {
    if (!path) return false;
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const handleNavClick = (path: string | null, action: string | null) => {
    if (action === 'search') {
      // Trigger global search (Cmd+K)
      const event = new KeyboardEvent('keydown', {
        key: 'k',
        metaKey: true,
        bubbles: true,
      });
      document.dispatchEvent(event);
    } else if (action === 'fab') {
      // This is handled by UnifiedQuickFAB itself which is always visible
      return;
    } else if (path) {
      navigate(path);
    }
  };

  if (!user) return null;

  return (
    <>
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 glass-nav border-t border-border/50 pb-safe">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.map(({ icon: Icon, label, path, action }) => {
            // Special handling for the "Registrer" button - render UnifiedQuickFAB trigger
            if (action === 'fab') {
              return <UnifiedQuickFAB key="fab" inline />;
            }

            return (
              <button
                key={path || action || label}
                onClick={() => handleNavClick(path, action)}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 p-2 min-w-[64px] min-h-[48px] rounded-lg transition-colors tap-safe",
                  isActive(path)
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{label}</span>
              </button>
            );
          })}

          {/* More menu with drawer */}
          <Drawer open={drawerOpen} onOpenChange={setDrawerOpen}>
            <DrawerTrigger asChild>
              <button
                className={cn(
                  "flex flex-col items-center justify-center gap-1 p-2 min-w-[64px] min-h-[48px] rounded-lg transition-colors tap-safe",
                  "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                )}
              >
                <Menu className="h-5 w-5" />
                <span className="text-xs font-medium">Menu</span>
              </button>
            </DrawerTrigger>
            <DrawerContent>
              <DrawerHeader>
                <DrawerTitle>Menu</DrawerTitle>
              </DrawerHeader>
              <div className="p-4 space-y-2 pb-safe">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-12 text-base"
                  onClick={() => {
                    setDrawerOpen(false);
                    navigate('/profile');
                  }}
                >
                  <User className="h-5 w-5 mr-3" />
                  Profil
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-12 text-base"
                  onClick={() => {
                    setDrawerOpen(false);
                    toggleSidebar();
                  }}
                >
                  <Menu className="h-5 w-5 mr-3" />
                  Vis navigation
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-12 text-base text-destructive hover:text-destructive hover:bg-destructive/10"
                  onClick={() => {
                    setDrawerOpen(false);
                    signOut();
                  }}
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Log ud
                </Button>
              </div>
            </DrawerContent>
          </Drawer>
        </div>
      </nav>
    </>
  );
};

export default MobileBottomNav;
