import { motion } from 'framer-motion';
import { Flame, Star, Trophy, TrendingUp, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useGamification, LEVELS } from '@/hooks/useGamification';
import { useBadges } from '@/hooks/useBadges';
import { LevelUpCelebration } from './LevelUpCelebration';

export function GamificationWidget() {
  const { 
    stats, 
    isLoading, 
    xpEarnedToday, 
    levelUpCelebration, 
    clearLevelUpCelebration 
  } = useGamification();
  const { recentBadges, earnedCount, totalCount } = useBadges();

  if (isLoading || !stats) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Din Fremdrift</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-32 bg-muted animate-pulse rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  const nextLevel = LEVELS.find(l => l.level === stats.level + 1);

  return (
    <>
      <LevelUpCelebration level={levelUpCelebration} onClose={clearLevelUpCelebration} />
      
      <Card className="overflow-hidden">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Trophy className="h-4 w-4 text-yellow-500" />
              Din Fremdrift
            </CardTitle>
            <Badge variant="outline" className="text-xs">
              {earnedCount}/{totalCount} badges
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Level & XP Section */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  className={`text-2xl font-bold ${stats.levelColor}`}
                >
                  Lv.{stats.level}
                </motion.div>
                <span className="text-sm font-medium">{stats.levelTitle}</span>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-sm font-medium">
                  <Zap className="h-4 w-4 text-yellow-500" />
                  {stats.xp} XP
                </div>
                {xpEarnedToday > 0 && (
                  <span className="text-xs text-green-500">+{xpEarnedToday} i dag</span>
                )}
              </div>
            </div>
            
            {nextLevel && (
              <div className="space-y-1">
                <Progress value={stats.xpProgress} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{stats.xpToNextLevel} XP til Level {nextLevel.level}</span>
                  <span>{nextLevel.title}</span>
                </div>
              </div>
            )}
          </div>

          {/* Streak Section */}
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div className="flex items-center gap-2">
              <motion.div
                animate={stats.activityStreak > 0 ? { 
                  scale: [1, 1.2, 1],
                } : {}}
                transition={{ repeat: Infinity, duration: 2 }}
              >
                <Flame className={`h-5 w-5 ${stats.activityStreak > 0 ? 'text-orange-500' : 'text-muted-foreground'}`} />
              </motion.div>
              <div>
                <div className="font-medium">
                  {stats.activityStreak} dages streak
                </div>
                <div className="text-xs text-muted-foreground">
                  {stats.streakFreezeCount > 0 
                    ? `${stats.streakFreezeCount} freeze${stats.streakFreezeCount > 1 ? 's' : ''} tilgængelig`
                    : 'Ingen streak freeze'
                  }
                </div>
              </div>
            </div>
            {stats.activityStreak >= 7 && (
              <Badge variant="secondary" className="text-xs">
                <TrendingUp className="h-3 w-3 mr-1" />
                Hot!
              </Badge>
            )}
          </div>

          {/* Recent Badges */}
          {recentBadges.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Nyeste Badges
              </h4>
              <TooltipProvider>
                <div className="flex gap-2">
                  {recentBadges.slice(0, 3).map((badge) => (
                    <Tooltip key={badge.code}>
                      <TooltipTrigger>
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          whileHover={{ scale: 1.1 }}
                          className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-xl cursor-pointer"
                        >
                          {badge.icon}
                        </motion.div>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="font-medium">{badge.label}</p>
                        <p className="text-xs text-muted-foreground">{badge.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  ))}
                </div>
              </TooltipProvider>
            </div>
          )}

          {/* Level stars */}
          <div className="flex justify-center gap-1 pt-2">
            {Array.from({ length: 7 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < stats.level 
                    ? 'fill-yellow-400 text-yellow-400' 
                    : 'text-muted-foreground/30'
                }`}
              />
            ))}
          </div>
        </CardContent>
      </Card>
    </>
  );
}
