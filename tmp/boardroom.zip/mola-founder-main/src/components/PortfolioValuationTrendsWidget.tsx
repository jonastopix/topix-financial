import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatCurrency, formatPercentage, formatCompact } from '@/lib/formatters';
import { format, parseISO } from 'date-fns';
import { TrendingUp, TrendingDown, Award, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import { useIsMobile } from '@/hooks/use-mobile';

interface CompanyValuationGrowth {
  id: string;
  name: string;
  firstValuation: number;
  latestValuation: number;
  growth: number;
  growthPercentage: number;
  valuationCount: number;
}

export function PortfolioValuationTrendsWidget() {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const { data, isLoading } = useQuery({
    queryKey: ['portfolio-valuation-trends'],
    queryFn: async () => {
      // Fetch all active companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, total_equity_share_pct, equity_share_pct')
        .eq('is_active', true)
        .order('name');
      
      if (companiesError) throw companiesError;

      // Fetch all valuations
      const { data: valuations, error: valuationsError } = await supabase
        .from('valuations')
        .select('*')
        .order('as_of_date', { ascending: true });
      
      if (valuationsError) throw valuationsError;

      // Fetch funding rounds for equity calculation
      const { data: fundingRounds, error: fundingRoundsError } = await supabase
        .from('funding_rounds')
        .select('company_id, equity_acquired_pct');
      
      if (fundingRoundsError) throw fundingRoundsError;

      // Calculate company-level growth
      const companyGrowth: CompanyValuationGrowth[] = companies
        .map(company => {
          const companyValuations = valuations.filter(v => v.company_id === company.id);
          
          if (companyValuations.length === 0) {
            return null;
          }

          const sortedValuations = companyValuations.sort((a, b) => 
            new Date(a.as_of_date).getTime() - new Date(b.as_of_date).getTime()
          );

          const firstValuation = sortedValuations[0].post_money_valuation_dkk;
          const latestValuation = sortedValuations[sortedValuations.length - 1].post_money_valuation_dkk;
          const growth = latestValuation - firstValuation;
          const growthPercentage = (growth / firstValuation) * 100;

          return {
            id: company.id,
            name: company.name,
            firstValuation,
            latestValuation,
            growth,
            growthPercentage,
            valuationCount: companyValuations.length,
          };
        })
        .filter((c): c is CompanyValuationGrowth => c !== null)
        .sort((a, b) => b.growthPercentage - a.growthPercentage);

      // Create portfolio timeline data (aggregate by month)
      const timelineMap = new Map<string, { date: string; totalValue: number; molaValue: number; count: number }>();

      valuations.forEach(valuation => {
        const company = companies.find(c => c.id === valuation.company_id);
        if (!company) return;

        // Calculate equity
        const companyFundingRounds = fundingRounds?.filter(f => f.company_id === company.id) || [];
        let equityPct = 0;
        if (companyFundingRounds.length > 0) {
          equityPct = companyFundingRounds.reduce((sum, r) => sum + (r.equity_acquired_pct || 0), 0);
        } else {
          equityPct = company.total_equity_share_pct || company.equity_share_pct || 0;
        }

        const monthKey = format(parseISO(valuation.as_of_date), 'yyyy-MM');
        const molaValue = valuation.post_money_valuation_dkk * (equityPct / 100);

        if (!timelineMap.has(monthKey)) {
          timelineMap.set(monthKey, {
            date: monthKey,
            totalValue: 0,
            molaValue: 0,
            count: 0,
          });
        }

        const existing = timelineMap.get(monthKey)!;
        existing.totalValue += valuation.post_money_valuation_dkk;
        existing.molaValue += molaValue;
        existing.count += 1;
      });

      const portfolioTimeline = Array.from(timelineMap.values())
        .sort((a, b) => a.date.localeCompare(b.date))
        .map(item => ({
          date: format(parseISO(item.date + '-01'), 'MMM yy'),
          fullDate: item.date,
          totalValue: item.totalValue,
          molaValue: item.molaValue,
          avgValue: item.totalValue / item.count,
        }));

      // Calculate portfolio stats
      const totalCurrentValuation = companyGrowth.reduce((sum, c) => sum + c.latestValuation, 0);
      const totalInitialValuation = companyGrowth.reduce((sum, c) => sum + c.firstValuation, 0);
      const portfolioGrowth = totalCurrentValuation - totalInitialValuation;
      const portfolioGrowthPercentage = (portfolioGrowth / totalInitialValuation) * 100;

      return {
        companyGrowth,
        portfolioTimeline,
        portfolioStats: {
          totalCurrentValuation,
          totalInitialValuation,
          portfolioGrowth,
          portfolioGrowthPercentage,
          companiesWithValuations: companyGrowth.length,
        },
      };
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-96 mt-2" />
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-[200px] w-full" />
          <Skeleton className="h-32 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!data || data.companyGrowth.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Portfolio Valuation Trends
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No valuation data available yet
          </p>
        </CardContent>
      </Card>
    );
  }

  const { companyGrowth, portfolioTimeline, portfolioStats } = data;
  const topPerformers = companyGrowth.slice(0, 5);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-semibold mb-2">{payload[0].payload.date}</p>
          <p className="text-sm text-primary">
            MOLA Value: {formatCurrency(payload[0].value, 0)}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Portfolio Valuation Trends
            </CardTitle>
            <CardDescription>
              Aggregated valuation growth and top performing companies
            </CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate('/portfolio/valuations')}>
            View All
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Portfolio Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          <div className="p-3 sm:p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Current Valuation</p>
            <p className="text-lg sm:text-2xl font-bold truncate">
              {isMobile 
                ? formatCompact(portfolioStats.totalCurrentValuation) + ' kr.'
                : formatCurrency(portfolioStats.totalCurrentValuation, 0)
              }
            </p>
          </div>
          <div className="p-3 sm:p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Total Growth</p>
            <p className="text-lg sm:text-2xl font-bold truncate">
              {isMobile 
                ? formatCompact(portfolioStats.portfolioGrowth) + ' kr.'
                : formatCurrency(portfolioStats.portfolioGrowth, 0)
              }
            </p>
            <p className={`text-xs mt-1 ${portfolioStats.portfolioGrowthPercentage >= 0 ? 'text-primary' : 'text-destructive'}`}>
              {portfolioStats.portfolioGrowthPercentage >= 0 ? '+' : ''}{portfolioStats.portfolioGrowthPercentage.toFixed(1)}%
            </p>
          </div>
          <div className="p-3 sm:p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Companies</p>
            <p className="text-lg sm:text-2xl font-bold">{portfolioStats.companiesWithValuations}</p>
            <p className="text-xs text-muted-foreground mt-1">with valuations</p>
          </div>
          <div className="p-3 sm:p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Avg Growth</p>
            <p className="text-lg sm:text-2xl font-bold">
              {formatPercentage(portfolioStats.portfolioGrowthPercentage / portfolioStats.companiesWithValuations)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">per company</p>
          </div>
        </div>

        {/* Portfolio Timeline Chart */}
        <div>
          <h3 className="font-semibold text-sm mb-4">MOLA Portfolio Value Over Time</h3>
          <div className="h-[200px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={portfolioTimeline} margin={{ top: 5, right: isMobile ? 10 : 30, left: isMobile ? 0 : 20, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorMola" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                />
                <YAxis 
                  className="text-xs"
                  tick={{ fill: 'hsl(var(--muted-foreground))' }}
                  tickFormatter={(value) => `${(value / 1000000).toFixed(0)}M`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area 
                  type="monotone" 
                  dataKey="molaValue" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                  fill="url(#colorMola)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Performers */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Award className="h-5 w-5 text-primary" />
            <h3 className="font-semibold">Top Performers</h3>
          </div>
          <div className="space-y-2">
            {topPerformers.map((company, index) => (
              <div 
                key={company.id} 
                className="flex items-center gap-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                onClick={() => navigate(`/company/${company.id}`)}
              >
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                  {index + 1}
                </div>
                <div className="flex-grow min-w-0">
                  <p className="font-medium truncate">{company.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {company.valuationCount} valuation{company.valuationCount !== 1 ? 's' : ''}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-bold text-sm sm:text-lg">
                    {isMobile 
                      ? formatCompact(company.latestValuation) + ' kr.'
                      : formatCurrency(company.latestValuation, 0)
                    }
                  </p>
                  <div className="flex items-center gap-1 justify-end">
                    {company.growthPercentage >= 0 ? (
                      <TrendingUp className="h-3 w-3 text-primary" />
                    ) : (
                      <TrendingDown className="h-3 w-3 text-destructive" />
                    )}
                    <span className={`text-xs font-semibold ${company.growthPercentage >= 0 ? 'text-primary' : 'text-destructive'}`}>
                      {company.growthPercentage >= 0 ? '+' : ''}{company.growthPercentage.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* View All Button */}
        <Button 
          variant="outline" 
          className="w-full"
          onClick={() => navigate('/portfolio/valuations')}
        >
          View All Valuations
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
}
