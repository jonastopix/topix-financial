import { useState, useMemo, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Calculator, 
  DollarSign, 
  Percent, 
  Users,
  TrendingUp,
  Info,
  Target,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  BarChart3,
  Clock,
  Zap,
  Link2
} from 'lucide-react';
import { useROASCalculations, ROASCalculation } from '@/hooks/useROASCalculations';
import { cn } from '@/lib/utils';

interface CLVAnalyzerProps {
  companyId: string | undefined;
}

interface CLVInputs {
  aov: string;
  ordersPerYear: string;
  marginMode: 'percent' | 'kr';
  marginPercent: string;
  marginKr: string;
  customerLifetimeYears: string;
  cac: string;
  targetCLVCACRatio: string;
  useROASData: boolean;
}

const initialInputs: CLVInputs = {
  aov: '',
  ordersPerYear: '',
  marginMode: 'percent',
  marginPercent: '',
  marginKr: '',
  customerLifetimeYears: '3',
  cac: '',
  targetCLVCACRatio: '3',
  useROASData: false,
};

const formatNumber = (num: number): string => {
  if (!isFinite(num) || isNaN(num)) return '—';
  return num.toLocaleString('da-DK', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
};

const formatDecimal = (num: number, decimals: number = 2): string => {
  if (!isFinite(num) || isNaN(num)) return '—';
  return num.toLocaleString('da-DK', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
};

export function CLVAnalyzer({ companyId }: CLVAnalyzerProps) {
  const [inputs, setInputs] = useState<CLVInputs>(initialInputs);
  const { calculations } = useROASCalculations(companyId);

  // Get latest ROAS calculation
  const latestROASCalc: ROASCalculation | undefined = calculations?.[0];

  const parseNumber = (value: string): number => {
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) ? 0 : parsed;
  };

  // Auto-fill from ROAS calculator when toggle is enabled
  useEffect(() => {
    if (inputs.useROASData && latestROASCalc) {
      const contributionMarginKr = latestROASCalc.contribution_margin;
      const aov = latestROASCalc.average_order_value;
      
      if (contributionMarginKr > 0 && aov > 0) {
        const marginPct = (contributionMarginKr / aov) * 100;
        setInputs(prev => ({
          ...prev,
          aov: aov.toString(),
          marginMode: 'kr',
          marginKr: contributionMarginKr.toFixed(2),
          marginPercent: marginPct.toFixed(1),
        }));
      }
    }
  }, [inputs.useROASData, latestROASCalc]);

  const results = useMemo(() => {
    const aov = parseNumber(inputs.aov);
    const ordersPerYear = parseNumber(inputs.ordersPerYear);
    const lifetimeYears = parseNumber(inputs.customerLifetimeYears);
    const cac = parseNumber(inputs.cac);
    const targetRatio = parseNumber(inputs.targetCLVCACRatio);

    // Calculate contribution margin per order
    let contributionMarginPerOrder: number;
    let marginPercent: number;

    if (inputs.marginMode === 'kr') {
      contributionMarginPerOrder = parseNumber(inputs.marginKr);
      marginPercent = aov > 0 ? (contributionMarginPerOrder / aov) * 100 : 0;
    } else {
      marginPercent = parseNumber(inputs.marginPercent);
      contributionMarginPerOrder = aov * (marginPercent / 100);
    }

    // First order economics
    const breakevenROAS = marginPercent > 0 ? 1 / (marginPercent / 100) : 0;
    const breakevenCACFirstOrder = contributionMarginPerOrder;

    // Lifetime economics
    const annualRevenuePerCustomer = aov * ordersPerYear;
    const annualContributionProfit = contributionMarginPerOrder * ordersPerYear;
    const clv = annualContributionProfit * lifetimeYears;
    const clvCacRatio = cac > 0 ? clv / cac : 0;
    const recommendedMaxCAC = targetRatio > 0 ? clv / targetRatio : 0;

    // Check if we have enough data
    const hasBasicData = aov > 0 && ordersPerYear > 0 && lifetimeYears > 0;
    const hasMarginData = contributionMarginPerOrder > 0;
    const hasAllData = hasBasicData && hasMarginData && cac > 0;

    return {
      contributionMarginPerOrder,
      marginPercent,
      breakevenROAS,
      breakevenCACFirstOrder,
      annualRevenuePerCustomer,
      annualContributionProfit,
      clv,
      clvCacRatio,
      recommendedMaxCAC,
      hasBasicData,
      hasMarginData,
      hasAllData,
    };
  }, [inputs]);

  const handleInputChange = (field: keyof CLVInputs, value: string | boolean) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  // Determine status badge
  const getStatusBadge = () => {
    if (!results.hasAllData) return null;
    
    const ratio = results.clvCacRatio;
    if (ratio < 2) {
      return { variant: 'destructive' as const, label: 'Kritisk', icon: AlertTriangle };
    } else if (ratio <= 3) {
      return { variant: 'secondary' as const, label: 'Acceptabel', icon: AlertCircle, className: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/30' };
    } else {
      return { variant: 'secondary' as const, label: 'Stærk', icon: CheckCircle2, className: 'bg-green-500/10 text-green-600 border-green-500/30' };
    }
  };

  // Get recommendation text
  const getRecommendation = () => {
    if (!results.hasAllData) return null;

    const cac = parseNumber(inputs.cac);
    const breakevenCAC = results.breakevenCACFirstOrder;
    const maxCAC = results.recommendedMaxCAC;

    if (cac > maxCAC) {
      return {
        type: 'danger',
        text: 'CAC er for høj – skru ned eller forbedr margin/retention.',
        icon: AlertTriangle,
      };
    } else if (cac > breakevenCAC) {
      return {
        type: 'warning',
        text: 'OK – du betaler for vækst, CLV bærer modellen.',
        icon: AlertCircle,
      };
    } else {
      return {
        type: 'success',
        text: 'Stærkt – du tjener allerede på første ordre.',
        icon: CheckCircle2,
      };
    }
  };

  const statusBadge = getStatusBadge();
  const recommendation = getRecommendation();

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Input Section */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            Indtast dine data
          </CardTitle>
          <CardDescription>
            Beregn Customer Lifetime Value og vurder din marketing-effektivitet
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Section 0: ROAS Data Toggle */}
          {latestROASCalc && (
            <div className="space-y-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
              <div className="flex items-center justify-between">
                <Label htmlFor="use-roas" className="flex items-center gap-2 cursor-pointer">
                  <Link2 className="h-4 w-4 text-primary" />
                  Brug data fra ROAS-beregner
                </Label>
                <Switch
                  id="use-roas"
                  checked={inputs.useROASData}
                  onCheckedChange={(checked) => handleInputChange('useROASData', checked)}
                />
              </div>
              {inputs.useROASData && (
                <p className="text-xs text-muted-foreground">
                  AOV: {formatNumber(latestROASCalc.average_order_value)} kr. | 
                  Contribution margin: {formatNumber(latestROASCalc.contribution_margin)} kr.
                </p>
              )}
            </div>
          )}

          {/* Section 1: Ordre & køb */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
              <DollarSign className="h-4 w-4" />
              Ordre & køb
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="aov">
                AOV ekskl. moms (DKK)
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground ml-1 inline cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Gennemsnitlig ordreværdi (Average Order Value) før moms.</p>
                  </TooltipContent>
                </Tooltip>
              </Label>
              <div className="relative">
                <Input
                  id="aov"
                  type="text"
                  inputMode="decimal"
                  placeholder="500"
                  value={inputs.aov}
                  onChange={(e) => handleInputChange('aov', e.target.value)}
                  className="pr-10"
                  disabled={inputs.useROASData}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">kr.</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="ordersPerYear">
                Køb pr. kunde pr. år
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground ml-1 inline cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Hvor mange gange køber en gennemsnitlig kunde om året?</p>
                  </TooltipContent>
                </Tooltip>
              </Label>
              <Input
                id="ordersPerYear"
                type="text"
                inputMode="decimal"
                placeholder="2.5"
                value={inputs.ordersPerYear}
                onChange={(e) => handleInputChange('ordersPerYear', e.target.value)}
              />
            </div>
          </div>

          {/* Section 2: Contribution margin */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
              <Percent className="h-4 w-4" />
              Contribution margin (før ads)
            </h3>
            
            <Tabs 
              value={inputs.marginMode} 
              onValueChange={(v) => handleInputChange('marginMode', v)}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="percent" disabled={inputs.useROASData}>Procent (%)</TabsTrigger>
                <TabsTrigger value="kr" disabled={inputs.useROASData}>Kr. pr. ordre</TabsTrigger>
              </TabsList>
            </Tabs>
            
            {inputs.marginMode === 'percent' ? (
              <div className="space-y-2">
                <Label htmlFor="marginPercent">Contribution margin (%)</Label>
                <div className="relative">
                  <Input
                    id="marginPercent"
                    type="text"
                    inputMode="decimal"
                    placeholder="40"
                    value={inputs.marginPercent}
                    onChange={(e) => handleInputChange('marginPercent', e.target.value)}
                    className="pr-10"
                    disabled={inputs.useROASData}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">%</span>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="marginKr">Contribution margin (kr. pr. ordre)</Label>
                <div className="relative">
                  <Input
                    id="marginKr"
                    type="text"
                    inputMode="decimal"
                    placeholder="200"
                    value={inputs.marginKr}
                    onChange={(e) => handleInputChange('marginKr', e.target.value)}
                    className="pr-10"
                    disabled={inputs.useROASData}
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">kr.</span>
                </div>
              </div>
            )}
          </div>

          {/* Section 3: Kundelivstid */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
              <Clock className="h-4 w-4" />
              Kundelevetid
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="lifetime">
                Kundelivstid (år)
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground ml-1 inline cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Hvor mange år forbliver en kunde typisk aktiv? Standard er 2-5 år for de fleste e-commerce virksomheder.</p>
                  </TooltipContent>
                </Tooltip>
              </Label>
              <div className="relative">
                <Input
                  id="lifetime"
                  type="text"
                  inputMode="decimal"
                  placeholder="3"
                  value={inputs.customerLifetimeYears}
                  onChange={(e) => handleInputChange('customerLifetimeYears', e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">år</span>
              </div>
            </div>
          </div>

          {/* Section 4: Marketing */}
          <div className="space-y-4">
            <h3 className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
              <Target className="h-4 w-4" />
              Marketing
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="cac">
                CAC (DKK)
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground ml-1 inline cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Customer Acquisition Cost – hvad koster det i gennemsnit at skaffe en ny kunde?</p>
                  </TooltipContent>
                </Tooltip>
              </Label>
              <div className="relative">
                <Input
                  id="cac"
                  type="text"
                  inputMode="decimal"
                  placeholder="150"
                  value={inputs.cac}
                  onChange={(e) => handleInputChange('cac', e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">kr.</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetRatio">
                Target CLV/CAC multiple
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3.5 w-3.5 text-muted-foreground ml-1 inline cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="max-w-xs">
                    <p>Ønsket forhold mellem CLV og CAC. 3:1 er en god tommelfingerregel for sund vækst.</p>
                  </TooltipContent>
                </Tooltip>
              </Label>
              <div className="relative">
                <Input
                  id="targetRatio"
                  type="text"
                  inputMode="decimal"
                  placeholder="3"
                  value={inputs.targetCLVCACRatio}
                  onChange={(e) => handleInputChange('targetCLVCACRatio', e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">x</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Output Section */}
      <div className="space-y-6">
        {/* First Order Economics */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Zap className="h-5 w-5 text-primary" />
              First Order Economics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Break-even ROAS</p>
                <p className="text-2xl font-bold tabular-nums">
                  {results.hasMarginData ? formatDecimal(results.breakevenROAS) : '—'}
                </p>
              </div>
              <div className="p-4 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Break-even CAC (first order)</p>
                <p className="text-2xl font-bold tabular-nums">
                  {results.hasMarginData ? `${formatNumber(results.breakevenCACFirstOrder)} kr.` : '—'}
                </p>
              </div>
            </div>
            {results.hasMarginData && (
              <p className="text-xs text-muted-foreground">
                Du må max betale {formatNumber(results.breakevenCACFirstOrder)} kr. for at gå i 0 på første ordre.
              </p>
            )}
          </CardContent>
        </Card>

        {/* Lifetime Economics */}
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center justify-between text-lg">
              <span className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                Lifetime Economics
              </span>
              {statusBadge && (
                <Badge variant={statusBadge.variant} className={cn("gap-1", statusBadge.className)}>
                  <statusBadge.icon className="h-3 w-3" />
                  {statusBadge.label}
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* CLV Hero Number */}
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground mb-1">Customer Lifetime Value (CLV)</p>
              <p className={cn(
                "text-5xl font-bold tabular-nums",
                results.hasBasicData && results.hasMarginData ? "text-primary" : "text-muted-foreground"
              )}>
                {results.hasBasicData && results.hasMarginData 
                  ? `${formatNumber(results.clv)} kr.`
                  : 'Udfyld felter'}
              </p>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Årlig omsætning/kunde</p>
                <p className="text-lg font-semibold tabular-nums">
                  {results.hasBasicData ? `${formatNumber(results.annualRevenuePerCustomer)} kr.` : '—'}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Årlig profit/kunde</p>
                <p className="text-lg font-semibold tabular-nums">
                  {results.hasBasicData && results.hasMarginData 
                    ? `${formatNumber(results.annualContributionProfit)} kr.`
                    : '—'}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">CLV/CAC ratio</p>
                <p className={cn(
                  "text-lg font-semibold tabular-nums",
                  results.hasAllData && results.clvCacRatio >= 3 ? "text-green-600" :
                  results.hasAllData && results.clvCacRatio >= 2 ? "text-yellow-600" :
                  results.hasAllData ? "text-destructive" : ""
                )}>
                  {results.hasAllData ? `${formatDecimal(results.clvCacRatio)}x` : '—'}
                </p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs text-muted-foreground mb-1">Anbefalet max CAC</p>
                <p className="text-lg font-semibold tabular-nums">
                  {results.hasBasicData && results.hasMarginData 
                    ? `${formatNumber(results.recommendedMaxCAC)} kr.`
                    : '—'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Decision Box */}
        {results.hasAllData && recommendation && (
          <Alert className={cn(
            recommendation.type === 'danger' && "border-destructive/50 bg-destructive/10",
            recommendation.type === 'warning' && "border-yellow-500/50 bg-yellow-500/10",
            recommendation.type === 'success' && "border-green-500/50 bg-green-500/10"
          )}>
            <recommendation.icon className={cn(
              "h-4 w-4",
              recommendation.type === 'danger' && "text-destructive",
              recommendation.type === 'warning' && "text-yellow-600",
              recommendation.type === 'success' && "text-green-600"
            )} />
            <AlertTitle>Anbefaling</AlertTitle>
            <AlertDescription className="space-y-2">
              <div className="flex flex-col gap-1 text-sm">
                <span>First order break-even CAC: <strong>{formatNumber(results.breakevenCACFirstOrder)} kr.</strong></span>
                <span>Max CAC (lifetime): <strong>{formatNumber(results.recommendedMaxCAC)} kr.</strong></span>
              </div>
              <p className="font-medium mt-2">{recommendation.text}</p>
            </AlertDescription>
          </Alert>
        )}

        {/* Info when data is missing */}
        {!results.hasBasicData && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Kom i gang</AlertTitle>
            <AlertDescription>
              Udfyld AOV, køb pr. år og kundelivstid for at se dine CLV-beregninger.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}
