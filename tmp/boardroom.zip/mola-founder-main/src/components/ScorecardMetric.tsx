import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { LucideIcon } from 'lucide-react';
import { formatNumber } from '@/lib/formatters';

interface ScorecardMetricProps {
  title: string;
  score: number;
  icon: LucideIcon;
  color: string;
  trend?: number[];
  previousScore?: number;
}

const ScorecardMetric = ({ title, score, icon: Icon, color, trend, previousScore }: ScorecardMetricProps) => {
  const scoreChange = previousScore !== undefined ? score - previousScore : 0;
  const isPositive = scoreChange >= 0;

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const scoreColor = getScoreColor(score);

  return (
    <Card className="p-6 hover:shadow-lg transition-shadow duration-300">
      <div className="flex items-center justify-between mb-4">
        <Icon className={`h-8 w-8 ${scoreColor}`} />
        <div className="flex items-center gap-2">
          <span className={`text-2xl lg:text-3xl font-bold ${scoreColor} truncate`}>
            {Math.round(score)}
          </span>
          {scoreChange !== 0 && (
            <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
              {isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
              <span className="text-sm font-medium">{formatNumber(Math.abs(scoreChange), 0)}</span>
            </div>
          )}
        </div>
      </div>
      
      <h3 className="text-sm font-medium text-muted-foreground mb-3">{title}</h3>
      <Progress value={score} className="h-2 mb-3" />

      {trend && trend.length > 1 && (
        <div className="flex items-end gap-1 h-12">
          {trend.map((value, idx) => (
            <div
              key={idx}
              className={`flex-1 ${scoreColor} rounded-t transition-all duration-300`}
              style={{
                height: `${(value / 100) * 100}%`,
                opacity: 0.3 + (idx / trend.length) * 0.7,
              }}
            />
          ))}
        </div>
      )}
    </Card>
  );
};

export default ScorecardMetric;