import { useState } from 'react';
import { Mail, Linkedin, Building2, UserCircle, Handshake } from 'lucide-react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { FounderProfileDialog } from './FounderProfileDialog';

interface FounderCardProps {
  founder: {
    id: string;
    full_name: string | null;
    title?: string;
    bio?: string;
    skills?: string[];
    linkedin_url?: string;
    avatar_url?: string;
    email?: string;
    can_help_with?: string;
    company: {
      id: string;
      name: string;
      logo_url?: string;
      industry?: string;
      description?: string;
      business_model?: string;
      target_market?: string;
    } | null;
    badges?: Array<{ code: string; label: string }>;
  };
}

export const FounderCard = ({ founder }: FounderCardProps) => {
  const [showProfile, setShowProfile] = useState(false);

  const getInitials = (name: string | null | undefined) => {
    if (!name) return '??';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const truncateBio = (bio: string | undefined, maxLength: number = 150) => {
    if (!bio) return '';
    if (bio.length <= maxLength) return bio;
    return bio.slice(0, maxLength) + '...';
  };

  const truncateCanHelpWith = (text: string | undefined, maxLength: number = 80) => {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength) + '...';
  };

  const handleEmailClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (founder.email) {
      window.location.href = `mailto:${founder.email}?subject=MOLA Founder Network - Hej ${founder.full_name}`;
    }
  };

  const handleLinkedInClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (founder.linkedin_url) {
      window.open(founder.linkedin_url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <>
      <Card className="hover:shadow-lg transition-all duration-300 group cursor-pointer" onClick={() => setShowProfile(true)}>
        <CardHeader className="pb-3">
          <div className="flex items-start gap-3">
            <Avatar className="h-16 w-16">
              <AvatarImage src={founder.avatar_url} alt={founder.full_name || 'Founder'} />
              <AvatarFallback className="bg-primary/10 text-primary text-lg">
                {getInitials(founder.full_name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg truncate group-hover:text-primary transition-colors">
                {founder.full_name || 'Ukendt bruger'}
              </h3>
              {founder.title && (
                <p className="text-sm text-muted-foreground truncate">
                  {founder.title}
                </p>
              )}
              {founder.company && (
                <div className="flex items-center gap-2 mt-1">
                  {founder.company.logo_url ? (
                    <img
                      src={founder.company.logo_url}
                      alt={founder.company.name}
                      className="h-5 w-5 rounded object-cover"
                    />
                  ) : (
                    <Building2 className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className="text-sm text-muted-foreground truncate">
                    {founder.company.name}
                  </span>
                </div>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Bio */}
          {founder.bio && (
            <p className="text-sm text-muted-foreground line-clamp-3">
              {truncateBio(founder.bio)}
            </p>
          )}

          {/* Can Help With - Highlighted */}
          {founder.can_help_with && (
            <div className="bg-primary/5 rounded-md p-2 border border-primary/20">
              <p className="text-xs font-medium text-primary flex items-center gap-1 mb-1">
                <Handshake className="h-3 w-3" />
                Kan hjælpe med
              </p>
              <p className="text-xs text-muted-foreground">
                {truncateCanHelpWith(founder.can_help_with)}
              </p>
            </div>
          )}

          {/* Skills */}
          {founder.skills && founder.skills.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground">Kompetencer</p>
              <div className="flex flex-wrap gap-2">
                {founder.skills.slice(0, 3).map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs">
                    {skill}
                  </Badge>
                ))}
                {founder.skills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{founder.skills.length - 3} mere
                  </Badge>
                )}
              </div>
            </div>
          )}

          {/* Achievements/Badges */}
          {founder.badges && founder.badges.length > 0 && (
            <div className="space-y-2">
              <p className="text-xs font-medium text-muted-foreground">Præstationer</p>
              <div className="flex flex-wrap gap-2">
                {founder.badges.slice(0, 2).map((badge) => (
                  <Badge key={badge.code} variant="outline" className="text-xs border-yellow-500/50 text-yellow-700">
                    🏆 {badge.label}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Contact Buttons */}
          <div className="flex gap-2 pt-2">
            {founder.email && (
              <Button
                variant="outline"
                size="sm"
                className="flex-1"
                onClick={handleEmailClick}
              >
                <Mail className="h-4 w-4 mr-2" />
                Email
              </Button>
            )}
            {founder.linkedin_url && (
              <Button
                variant="ghost"
                size="sm"
                className="flex-1"
                onClick={handleLinkedInClick}
              >
                <Linkedin className="h-4 w-4 mr-2" />
                LinkedIn
              </Button>
            )}
          </div>

          {/* View Profile Button */}
          <Button
            variant="outline"
            className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              setShowProfile(true);
            }}
          >
            <UserCircle className="h-4 w-4 mr-2" />
            Se profil
          </Button>
        </CardContent>
      </Card>

      <FounderProfileDialog
        founder={founder}
        open={showProfile}
        onOpenChange={setShowProfile}
      />
    </>
  );
};