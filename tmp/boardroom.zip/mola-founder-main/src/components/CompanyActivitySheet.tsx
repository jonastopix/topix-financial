import { useState, useMemo } from 'react';
import { format, subDays } from 'date-fns';
import { da } from 'date-fns/locale';
import { Calendar, Clock, FileText, Monitor, Phone, MapPin, Briefcase, MessageCircle, Play, History, Repeat, Timer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DrawerHeader, DrawerTitle, DrawerDescription, DrawerFooter, DrawerClose } from '@/components/ui/drawer';
import { useCompanyMeetings } from '@/hooks/useCompanyMeetings';
import { useCompanyContacts } from '@/hooks/useCompanyContacts';
import { useActivityTimer } from '@/hooks/useActivityTimer';
import { useGamification } from '@/hooks/useGamification';
import { useBadges } from '@/hooks/useBadges';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface CompanyActivitySheetProps {
  companyId: string;
  companyName: string;
  onSuccess: () => void;
}

const ACTIVITY_TYPES = [
  { value: 'admin', label: 'Admin', icon: Briefcase, defaultDuration: '30' },
  { value: 'online', label: 'Online', icon: Monitor, defaultDuration: '30' },
  { value: 'physical', label: 'Fysisk', icon: MapPin, defaultDuration: '60' },
  { value: 'phone', label: 'Telefon', icon: Phone, defaultDuration: '15' },
  { value: 'checkin', label: 'Check-in', icon: MessageCircle, defaultDuration: '10' },
] as const;

const DURATION_OPTIONS = [
  { value: '5', label: '5 min' },
  { value: '10', label: '10 min' },
  { value: '15', label: '15 min' },
  { value: '30', label: '30 min' },
  { value: '45', label: '45 min' },
  { value: '60', label: '1 time' },
  { value: '90', label: '1.5 time' },
  { value: '120', label: '2 timer' },
];

const QUICK_DATES = [
  { value: 'today', label: 'I dag', getDate: () => new Date() },
  { value: 'yesterday', label: 'I går', getDate: () => subDays(new Date(), 1) },
];

export function CompanyActivitySheet({ companyId, companyName, onSuccess }: CompanyActivitySheetProps) {
  const { toast } = useToast();
  const { meetings, createMeeting } = useCompanyMeetings(companyId);
  const { contacts } = useCompanyContacts(companyId);
  const { isRunning, elapsedTime, elapsedMinutes, startTimer, stopTimer, companyId: timerCompanyId } = useActivityTimer();
  const { awardXp, updateStreak } = useGamification();
  const { incrementProgress, checkSecretBadges } = useBadges();
  
  const [activityType, setActivityType] = useState<string>('online');
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [quickDateValue, setQuickDateValue] = useState<string>('today');
  const [duration, setDuration] = useState<string>('30');
  const [title, setTitle] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);

  // Get recent meetings for this company (last 5)
  const recentMeetings = useMemo(() => {
    if (!meetings) return [];
    return meetings
      .sort((a, b) => new Date(b.meeting_date).getTime() - new Date(a.meeting_date).getTime())
      .slice(0, 5);
  }, [meetings]);

  // Get unique recent titles for suggestions
  const titleSuggestions = useMemo(() => {
    if (!meetings) return [];
    const titles = meetings
      .map(m => m.title)
      .filter((t, i, arr) => arr.indexOf(t) === i)
      .slice(0, 5);
    return titles;
  }, [meetings]);

  const handleQuickDateSelect = (value: string) => {
    const quickDate = QUICK_DATES.find(d => d.value === value);
    if (quickDate) {
      setSelectedDate(quickDate.getDate());
      setQuickDateValue(value);
    }
  };

  const handleCalendarSelect = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      setQuickDateValue('custom');
      setShowCalendar(false);
    }
  };

  const handleActivityTypeChange = (type: string) => {
    setActivityType(type);
    const activityConfig = ACTIVITY_TYPES.find(t => t.value === type);
    if (activityConfig) {
      setDuration(activityConfig.defaultDuration);
    }
  };

  const handleCopyMeeting = (meeting: any) => {
    setTitle(meeting.title);
    setActivityType(meeting.meeting_type);
    setNotes(meeting.notes || '');
    setDuration(String(meeting.duration_minutes));
    // Keep today's date
    setSelectedDate(new Date());
    setQuickDateValue('today');
  };

  const handleTitleSuggestionClick = (suggestedTitle: string) => {
    setTitle(suggestedTitle);
  };

  const handleFollowUpClick = () => {
    if (recentMeetings.length > 0) {
      setTitle(`Opfølgning: ${recentMeetings[0].title}`);
    }
  };

  const toggleParticipant = (contactId: string) => {
    setSelectedParticipants(prev => 
      prev.includes(contactId) 
        ? prev.filter(id => id !== contactId)
        : [...prev, contactId]
    );
  };

  const handleStartTimer = () => {
    startTimer(companyId, companyName, activityType);
    toast({
      title: 'Timer startet',
      description: `Timer kører for ${companyName}`,
    });
  };

  const handleStopTimer = () => {
    const result = stopTimer();
    if (result.durationMinutes > 0) {
      setDuration(String(Math.max(5, Math.round(result.durationMinutes / 5) * 5)));
    }
    toast({
      title: 'Timer stoppet',
      description: `Varighed: ${result.durationMinutes} minutter`,
    });
  };

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast({
        title: 'Manglende titel',
        description: 'Angiv venligst en titel for aktiviteten',
        variant: 'destructive',
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Get participant data as objects
      const participantData = selectedParticipants
        .map(id => {
          const contact = contacts?.find(c => c.id === id);
          return contact ? { id: contact.id, name: contact.name } : null;
        })
        .filter((p): p is { id: string; name: string } => p !== null);

      await createMeeting.mutateAsync({
        company_id: companyId,
        title: title.trim(),
        meeting_date: format(selectedDate, 'yyyy-MM-dd'),
        duration_minutes: parseInt(duration),
        meeting_type: activityType,
        notes: notes.trim() || null,
        participants: participantData,
      });
      
      // Award XP and update streak
      try {
        await awardXp({
          eventType: 'activity_logged',
          description: `Logget ${activityType}: ${title}`,
        });
        await updateStreak();
        await incrementProgress('first_activity');
        await checkSecretBadges();
      } catch (e) {
        console.error('Gamification error:', e);
      }
      
      toast({
        title: 'Aktivitet registreret',
        description: `${title} er gemt for ${companyName}`,
      });
      
      // Reset form
      setTitle('');
      setNotes('');
      setActivityType('online');
      setDuration('30');
      setSelectedDate(new Date());
      setQuickDateValue('today');
      setSelectedParticipants([]);
      
      onSuccess();
    } catch (error) {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke gemme aktiviteten. Prøv igen.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const isTimerForThisCompany = isRunning && timerCompanyId === companyId;

  return (
    <div className="flex flex-col max-h-[80vh]">
      <DrawerHeader className="px-4 flex-shrink-0">
        <DrawerTitle>Registrer aktivitet</DrawerTitle>
        <DrawerDescription>{companyName}</DrawerDescription>
      </DrawerHeader>

      <div className="flex-1 overflow-y-auto px-4">
        <div className="space-y-4 pb-4">
          {/* Recent Activities */}
          {recentMeetings.length > 0 && (
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5 text-muted-foreground">
                <History className="h-3.5 w-3.5" />
                Seneste aktiviteter
              </Label>
              <div className="space-y-1.5 max-h-32 overflow-y-auto">
                {recentMeetings.slice(0, 3).map(meeting => {
                  const TypeIcon = ACTIVITY_TYPES.find(t => t.value === meeting.meeting_type)?.icon || Monitor;
                  return (
                    <div 
                      key={meeting.id}
                      className="flex items-center justify-between p-2 rounded-lg bg-muted/50 text-sm"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <TypeIcon className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                        <span className="truncate">{meeting.title}</span>
                        <span className="text-xs text-muted-foreground flex-shrink-0">
                          {format(new Date(meeting.meeting_date), 'd. MMM', { locale: da })}
                        </span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs"
                        onClick={() => handleCopyMeeting(meeting)}
                      >
                        <Repeat className="h-3 w-3 mr-1" />
                        Kopiér
                      </Button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Activity Type */}
          <div className="space-y-2">
            <Label>Type</Label>
            <div className="grid grid-cols-5 gap-1.5">
              {ACTIVITY_TYPES.map(type => {
                const Icon = type.icon;
                return (
                  <Button
                    key={type.value}
                    type="button"
                    variant={activityType === type.value ? 'default' : 'outline'}
                    className={cn(
                      'flex flex-col h-auto py-2 px-1 gap-0.5',
                      activityType === type.value && 'ring-2 ring-primary ring-offset-2'
                    )}
                    onClick={() => handleActivityTypeChange(type.value)}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="text-[10px]">{type.label}</span>
                  </Button>
                );
              })}
            </div>
          </div>

          {/* Timer Section */}
          <div className="flex items-center gap-2">
            {isTimerForThisCompany ? (
              <Button
                type="button"
                variant="destructive"
                size="sm"
                onClick={handleStopTimer}
                className="gap-2 flex-1"
              >
                <Timer className="h-4 w-4 animate-pulse" />
                Stop timer ({elapsedTime})
              </Button>
            ) : !isRunning ? (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleStartTimer}
                className="gap-2"
              >
                <Play className="h-4 w-4" />
                Start timer
              </Button>
            ) : (
              <Badge variant="secondary" className="text-xs">
                Timer kører for andet selskab
              </Badge>
            )}
          </div>

          {/* Date Selection */}
          <div className="space-y-2">
            <Label>Dato</Label>
            <div className="flex gap-2">
              {QUICK_DATES.map(qd => (
                <Button
                  key={qd.value}
                  type="button"
                  variant={quickDateValue === qd.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleQuickDateSelect(qd.value)}
                >
                  {qd.label}
                </Button>
              ))}
              <Popover open={showCalendar} onOpenChange={setShowCalendar}>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant={quickDateValue === 'custom' ? 'default' : 'outline'}
                    size="sm"
                    className="flex-1"
                  >
                    <Calendar className="h-4 w-4 mr-1" />
                    {quickDateValue === 'custom' 
                      ? format(selectedDate, 'd. MMM', { locale: da })
                      : 'Anden dato'
                    }
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={selectedDate}
                    onSelect={handleCalendarSelect}
                    initialFocus
                    locale={da}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Duration */}
          <div className="space-y-2">
            <Label>Varighed</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger>
                <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {DURATION_OPTIONS.map(opt => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Title with suggestions */}
          <div className="space-y-2">
            <Label>Titel / Emne</Label>
            <Input
              placeholder="F.eks. Statusmøde, Regnskabsgennemgang..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            {/* Title suggestions */}
            {(titleSuggestions.length > 0 || recentMeetings.length > 0) && !title && (
              <div className="flex flex-wrap gap-1.5">
                {recentMeetings.length > 0 && (
                  <Badge 
                    variant="outline" 
                    className="cursor-pointer hover:bg-accent text-xs"
                    onClick={handleFollowUpClick}
                  >
                    Opfølgning
                  </Badge>
                )}
                {titleSuggestions.slice(0, 3).map((suggestion, i) => (
                  <Badge 
                    key={i}
                    variant="outline" 
                    className="cursor-pointer hover:bg-accent text-xs"
                    onClick={() => handleTitleSuggestionClick(suggestion)}
                  >
                    {suggestion.length > 20 ? suggestion.slice(0, 20) + '...' : suggestion}
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Participants from contacts */}
          {contacts && contacts.length > 0 && (
            <div className="space-y-2">
              <Label>Deltagere (valgfrit)</Label>
              <div className="flex flex-wrap gap-1.5">
                {contacts.slice(0, 6).map(contact => (
                  <Badge 
                    key={contact.id}
                    variant={selectedParticipants.includes(contact.id) ? 'default' : 'outline'}
                    className="cursor-pointer text-xs"
                    onClick={() => toggleParticipant(contact.id)}
                  >
                    {contact.name}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1">
              <FileText className="h-4 w-4" />
              Noter (valgfrit)
            </Label>
            <Textarea
              placeholder="Korte noter om mødet..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>
      </div>

      <DrawerFooter className="flex-shrink-0 border-t bg-background px-4 pb-8">
        <Button 
          onClick={handleSubmit} 
          disabled={isSubmitting || !title.trim()}
          className="w-full"
        >
          {isSubmitting ? 'Gemmer...' : 'Gem aktivitet'}
        </Button>
        <DrawerClose asChild>
          <Button variant="outline" className="w-full">Annuller</Button>
        </DrawerClose>
      </DrawerFooter>
    </div>
  );
}
