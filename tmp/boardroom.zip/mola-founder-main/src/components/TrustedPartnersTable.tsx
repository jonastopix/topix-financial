import { useState } from 'react';
import { Building2, User, Mail, Phone, Smartphone, Globe, Linkedin, Star, Pencil, CheckCheck } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { TrustedPartner } from '@/hooks/useTrustedPartners';
import { PartnerRatingStars } from '@/components/PartnerRatingStars';
import { PartnerRatingStats } from '@/hooks/usePartnerRatings';

interface TrustedPartnersTableProps {
  partners: TrustedPartner[];
  ratingStats: PartnerRatingStats[] | undefined;
  onEdit?: (partner: TrustedPartner) => void;
  hasAdminAccess?: boolean;
}

export const TrustedPartnersTable = ({
  partners,
  ratingStats,
  onEdit,
  hasAdminAccess = false,
}: TrustedPartnersTableProps) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const getRatingStatsForPartner = (partnerId: string) => {
    return ratingStats?.find(s => s.partner_id === partnerId);
  };

  const handleCopy = async (value: string, field: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  if (partners.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="p-4 rounded-full bg-muted mb-4">
          <Building2 className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium mb-1">Ingen partnere fundet</h3>
        <p className="text-muted-foreground max-w-sm">
          Prøv at justere din søgning eller vælg en anden kategori
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[250px]">Firma</TableHead>
            <TableHead className="w-[120px]">Kategori</TableHead>
            <TableHead className="w-[180px]">Kontakt</TableHead>
            <TableHead className="w-[140px]">Rating</TableHead>
            <TableHead className="w-[200px]">Telefon</TableHead>
            <TableHead className="w-[100px] text-right">Handlinger</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {partners.map((partner) => {
            const stats = getRatingStatsForPartner(partner.id);
            const mobilePhone = (partner as any).mobile_phone;
            
            return (
              <TableRow key={partner.id} className="group h-14">
                {/* Firma */}
                <TableCell>
                  <div className="flex items-center gap-3">
                    {partner.logo_url ? (
                      <img
                        src={partner.logo_url}
                        alt={partner.company_name}
                        className="w-8 h-8 rounded object-contain bg-muted p-0.5"
                      />
                    ) : (
                      <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center">
                        <Building2 className="h-4 w-4 text-primary" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-foreground truncate">
                          {partner.company_name}
                        </span>
                        {partner.is_mola_recommended && (
                          <Badge variant="secondary" className="bg-amber-500/10 text-amber-600 border-amber-500/30 h-5 px-1.5 text-[10px]">
                            <Star className="h-2.5 w-2.5 fill-current mr-0.5" />
                            MOLA
                          </Badge>
                        )}
                      </div>
                      {partner.email && (
                        <div className="text-xs text-muted-foreground truncate max-w-[180px]">
                          {partner.email}
                        </div>
                      )}
                    </div>
                  </div>
                </TableCell>

                {/* Kategori */}
                <TableCell>
                  <span className="text-sm text-muted-foreground">
                    {partner.category?.name || '-'}
                  </span>
                </TableCell>

                {/* Kontakt */}
                <TableCell>
                  {partner.contact_name ? (
                    <div className="flex items-center gap-2">
                      <User className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                      <div className="min-w-0">
                        <div className="text-sm truncate">{partner.contact_name}</div>
                        {partner.contact_title && (
                          <div className="text-xs text-muted-foreground truncate">
                            {partner.contact_title}
                          </div>
                        )}
                      </div>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground">-</span>
                  )}
                </TableCell>

                {/* Rating */}
                <TableCell>
                  <PartnerRatingStars
                    partnerId={partner.id}
                    averageRating={stats?.average_rating ?? 0}
                    ratingCount={stats?.rating_count ?? 0}
                    userRating={stats?.user_rating ?? null}
                    size="sm"
                    showCount
                  />
                </TableCell>

                {/* Telefon */}
                <TableCell>
                  <div className="flex flex-col gap-0.5">
                    {partner.phone && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            onClick={() => handleCopy(partner.phone!, `phone-${partner.id}`)}
                            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {copiedField === `phone-${partner.id}` ? (
                              <CheckCheck className="h-3 w-3 text-green-500" />
                            ) : (
                              <Phone className="h-3 w-3" />
                            )}
                            <span>{partner.phone}</span>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>Klik for at kopiere</TooltipContent>
                      </Tooltip>
                    )}
                    {mobilePhone && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <button
                            onClick={() => handleCopy(mobilePhone, `mobile-${partner.id}`)}
                            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
                          >
                            {copiedField === `mobile-${partner.id}` ? (
                              <CheckCheck className="h-3 w-3 text-green-500" />
                            ) : (
                              <Smartphone className="h-3 w-3" />
                            )}
                            <span>{mobilePhone}</span>
                          </button>
                        </TooltipTrigger>
                        <TooltipContent>Klik for at kopiere mobil</TooltipContent>
                      </Tooltip>
                    )}
                    {!partner.phone && !mobilePhone && (
                      <span className="text-xs text-muted-foreground">-</span>
                    )}
                  </div>
                </TableCell>

                {/* Handlinger */}
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    {hasAdminAccess && onEdit && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => onEdit(partner)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Rediger partner</TooltipContent>
                      </Tooltip>
                    )}
                    {partner.website && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            asChild
                          >
                            <a href={partner.website} target="_blank" rel="noopener noreferrer">
                              <Globe className="h-4 w-4" />
                            </a>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Åbn website</TooltipContent>
                      </Tooltip>
                    )}
                    {partner.linkedin_url && (
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            asChild
                          >
                            <a href={partner.linkedin_url} target="_blank" rel="noopener noreferrer">
                              <Linkedin className="h-4 w-4" />
                            </a>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>Åbn LinkedIn</TooltipContent>
                      </Tooltip>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
};
