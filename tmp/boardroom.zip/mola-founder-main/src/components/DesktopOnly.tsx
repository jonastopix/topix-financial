import { useIsMobile } from '@/hooks/use-mobile';
import { ReactNode } from 'react';

interface DesktopOnlyProps {
  children: ReactNode;
}

/**
 * Utility component that only renders children on desktop (non-mobile) devices.
 * Use this to hide complex widgets/sections that are not suitable for mobile.
 */
export const DesktopOnly = ({ children }: DesktopOnlyProps) => {
  const isMobile = useIsMobile();
  
  if (isMobile) return null;
  
  return <>{children}</>;
};
