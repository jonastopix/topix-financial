import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { type CashFlow } from '@/lib/returnsCalculations';

interface CashFlowEventsTableProps {
  cashFlows: CashFlow[];
}

export function CashFlowEventsTable({ cashFlows }: CashFlowEventsTableProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getTypeLabel = (type: CashFlow['type']) => {
    switch (type) {
      case 'investment':
        return 'Investering';
      case 'dividend':
        return 'Udbytte';
      case 'exit':
        return 'Exit';
      default:
        return type;
    }
  };

  const getTypeVariant = (type: CashFlow['type']) => {
    switch (type) {
      case 'investment':
        return 'secondary' as const;
      case 'dividend':
        return 'outline' as const;
      case 'exit':
        return 'default' as const;
      default:
        return 'secondary' as const;
    }
  };

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Dato</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Beskrivelse</TableHead>
          <TableHead className="text-right">Beløb</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {cashFlows.map((cf, index) => (
          <TableRow key={index}>
            <TableCell className="font-medium">
              {format(new Date(cf.date), 'dd MMM yyyy', { locale: da })}
            </TableCell>
            <TableCell>
              <Badge variant={getTypeVariant(cf.type)}>
                {getTypeLabel(cf.type)}
              </Badge>
            </TableCell>
            <TableCell>{cf.description}</TableCell>
            <TableCell className="text-right font-medium">
              <span className={cf.amount < 0 ? 'text-destructive' : 'text-green-600'}>
                {formatCurrency(cf.amount)}
              </span>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
