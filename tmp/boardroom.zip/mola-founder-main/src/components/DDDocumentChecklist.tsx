import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Accordion } from '@/components/ui/accordion';
import { DDCategoryAccordion } from './DDCategoryAccordion';
import { DDDocumentCategory, DDCategoryProgress, DDDocument } from '@/hooks/useDueDiligence';
import { FileText, CheckCircle2, Clock } from 'lucide-react';

interface DDDocumentChecklistProps {
  caseId: string;
  categories: DDDocumentCategory[];
  categoryProgress: DDCategoryProgress[];
  documents: DDDocument[];
}

export function DDDocumentChecklist({
  caseId,
  categories,
  categoryProgress,
  documents,
}: DDDocumentChecklistProps) {
  // Group categories by parent (main categories have no parent)
  const mainCategories = useMemo(() => {
    return categories.filter(c => !c.parent_category_code);
  }, [categories]);

  const getSubcategories = (parentCode: string) => {
    return categories.filter(c => c.parent_category_code === parentCode);
  };

  // Calculate overall progress
  const overallProgress = useMemo(() => {
    const totalCategories = categories.filter(c => c.parent_category_code !== null).length;
    const completedCategories = categoryProgress.filter(
      p => p.status === 'completed' && p.dd_document_categories?.parent_category_code !== null
    ).length;
    
    return totalCategories > 0 ? Math.round((completedCategories / totalCategories) * 100) : 0;
  }, [categories, categoryProgress]);

  // Count stats
  const stats = useMemo(() => {
    const total = categories.filter(c => c.parent_category_code !== null).length;
    const completed = categoryProgress.filter(
      p => p.status === 'completed' && p.dd_document_categories?.parent_category_code !== null
    ).length;
    const inProgress = categoryProgress.filter(
      p => p.status === 'in_progress' && p.dd_document_categories?.parent_category_code !== null
    ).length;
    
    return { total, completed, inProgress };
  }, [categories, categoryProgress]);

  return (
    <div className="space-y-6">
      {/* Progress Overview */}
      <Card>
        <CardHeader>
          <CardTitle>Due Diligence Fremskridt</CardTitle>
          <CardDescription>
            Upload dokumenter for hver kategori nedenfor
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Samlet fremskridt</span>
              <span className="font-medium">{overallProgress}%</span>
            </div>
            <Progress value={overallProgress} className="h-3" />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-card">
              <FileText className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Kategorier i alt</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-card">
              <Clock className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">{stats.inProgress}</p>
                <p className="text-xs text-muted-foreground">I gang</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 rounded-lg border bg-card">
              <CheckCircle2 className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{stats.completed}</p>
                <p className="text-xs text-muted-foreground">Færdige</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Category Checklist */}
      <Card>
        <CardHeader>
          <CardTitle>Dokumentkategorier</CardTitle>
          <CardDescription>
            Klik på hver kategori for at uploade dokumenter
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="space-y-4">
            {mainCategories.map(mainCategory => {
              const subcategories = getSubcategories(mainCategory.category_code);
              
              return (
                <DDCategoryAccordion
                  key={mainCategory.id}
                  caseId={caseId}
                  mainCategory={mainCategory}
                  subcategories={subcategories}
                  categoryProgress={categoryProgress}
                  documents={documents}
                />
              );
            })}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}
