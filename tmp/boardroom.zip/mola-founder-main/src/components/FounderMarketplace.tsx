import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useFounderDeals } from "@/hooks/useFounderDeals";
import { FounderDealCard } from "./FounderDealCard";
import { FounderDealDetailDialog } from "./FounderDealDetailDialog";
import { CreateFounderDealDialog } from "./CreateFounderDealDialog";
import { Search, Plus, Package, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { FounderDeal } from "@/hooks/useFounderDeals";

interface FounderMarketplaceProps {
  companyId?: string;
  showCreateButton?: boolean;
}

const CATEGORY_FILTERS = [
  { value: "all", label: "Alle kategorier" },
  { value: "saas", label: "SaaS & Tools" },
  { value: "marketing", label: "Marketing" },
  { value: "shipping", label: "Fragt & Levering" },
  { value: "payment", label: "Betaling" },
  { value: "tech", label: "Tech & Development" },
  { value: "design", label: "Design & Creative" },
  { value: "other", label: "Andet" },
];

export function FounderMarketplace({ companyId, showCreateButton = false }: FounderMarketplaceProps) {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDeal, setSelectedDeal] = useState<FounderDeal | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);

  const { data: deals = [], isLoading } = useFounderDeals(
    selectedCategory === "all" ? undefined : selectedCategory
  );

  const filteredDeals = deals.filter(deal => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      deal.title.toLowerCase().includes(query) ||
      deal.description?.toLowerCase().includes(query) ||
      deal.companies?.name.toLowerCase().includes(query)
    );
  });

  const handleViewDetails = (deal: FounderDeal) => {
    setSelectedDeal(deal);
    setDetailDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header with filters */}
      <div className="glass-card p-6 rounded-2xl space-y-4 animate-fade-up">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold gradient-text mb-1">MOLA Marketplace</h2>
            <p className="text-muted-foreground">
              Eksklusive deals fra founders til founders
            </p>
          </div>
          {showCreateButton && companyId && (
            <Button 
              onClick={() => setCreateDialogOpen(true)}
              className="bg-gradient-to-r from-accent to-accent-glow hover:opacity-90 shadow-lg hover:shadow-glow-accent"
            >
              <Plus className="w-4 h-4 mr-2" />
              Opret Deal
            </Button>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Søg i deals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CATEGORY_FILTERS.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Deals grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-48 rounded-lg" />
          ))}
        </div>
      ) : filteredDeals.length === 0 ? (
        <div className="glass-card p-12 rounded-2xl text-center animate-scale-in">
          <div className="flex justify-center mb-4">
            <div className="p-4 rounded-full bg-muted/50">
              <Package className="w-12 h-12 text-muted-foreground" />
            </div>
          </div>
          <h3 className="text-lg font-semibold mb-2">Ingen deals fundet</h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || selectedCategory !== "all"
              ? "Prøv at ændre dine søgefiltre"
              : "Vær den første til at dele et deal med fællesskabet"}
          </p>
          {showCreateButton && companyId && (
            <Button 
              onClick={() => setCreateDialogOpen(true)}
              variant="outline"
              className="mt-2"
            >
              <Plus className="w-4 h-4 mr-2" />
              Opret Deal
            </Button>
          )}
        </div>
      ) : (
        <>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Sparkles className="w-4 h-4" />
            <span>{filteredDeals.length} deals tilgængelige</span>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredDeals.map((deal, index) => (
              <div 
                key={deal.id} 
                className="animate-scale-in"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                <FounderDealCard
                  deal={deal}
                  onViewDetails={() => handleViewDetails(deal)}
                />
              </div>
            ))}
          </div>
        </>
      )}

      {/* Dialogs */}
      <FounderDealDetailDialog
        deal={selectedDeal}
        open={detailDialogOpen}
        onOpenChange={setDetailDialogOpen}
        companyId={companyId}
      />

      {companyId && (
        <CreateFounderDealDialog
          open={createDialogOpen}
          onOpenChange={setCreateDialogOpen}
          companyId={companyId}
        />
      )}
    </div>
  );
}
