import { Badge } from '@/components/ui/badge';
import { CompanyStatus } from '@/hooks/useCompanyManagement';

interface CompanyStatusBadgeProps {
  status: CompanyStatus;
}

export function CompanyStatusBadge({ status }: CompanyStatusBadgeProps) {
  const statusConfig = {
    new_investment: {
      label: '🟡 Ny investering',
      className: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20',
    },
    due_diligence: {
      label: '🔵 Due Diligence',
      className: 'bg-blue-500/10 text-blue-700 dark:text-blue-400 border-blue-500/20',
    },
    active: {
      label: '🟢 Aktiv',
      className: 'bg-green-500/10 text-green-700 dark:text-green-400 border-green-500/20',
    },
    exited: {
      label: '🎯 Solgt',
      className: 'bg-purple-500/10 text-purple-700 dark:text-purple-400 border-purple-500/20',
    },
    bankruptcy: {
      label: '🔴 Konkurs',
      className: 'bg-red-500/10 text-red-700 dark:text-red-400 border-red-500/20',
    },
    rejected: {
      label: '⚫ Afvist',
      className: 'bg-gray-500/10 text-gray-700 dark:text-gray-400 border-gray-500/20',
    },
    archived: {
      label: '📦 Arkiveret',
      className: 'bg-slate-500/10 text-slate-700 dark:text-slate-400 border-slate-500/20',
    },
  };

  const config = statusConfig[status];

  return (
    <Badge variant="outline" className={config.className}>
      {config.label}
    </Badge>
  );
}
