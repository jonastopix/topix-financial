import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { FileBarChart, Loader2, Mail, Printer, Send } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { useCompanyMeetings } from '@/hooks/useCompanyMeetings';
import { useCapTable } from '@/hooks/useCompanyCapTable';
import { useCompanyFinancials } from '@/hooks/useCompanyFinancials';
import { useAuth } from '@/contexts/AuthContext';

interface Company {
  id: string;
  name: string;
  cvr?: string | null;
  industry?: string | null;
  address?: string | null;
  city?: string | null;
  zipcode?: string | null;
  email?: string | null;
  phone?: string | null;
  founded_date?: string | null;
  invested_at?: string | null;
  status?: string;
  fund_id?: string | null;
  responsible_partner_id?: string | null;
  total_invested_amount_dkk?: number | null;
  total_equity_share_pct?: number | null;
}

interface ExportCompanyReportDialogProps {
  companyId: string;
  companyName: string;
  company: Company;
}

export function ExportCompanyReportDialog({ 
  companyId, 
  companyName,
  company 
}: ExportCompanyReportDialogProps) {
  const [open, setOpen] = useState(false);
  const [recipientEmails, setRecipientEmails] = useState('');
  const [personalMessage, setPersonalMessage] = useState('');
  const [isSendingEmail, setIsSendingEmail] = useState(false);
  const { user } = useAuth();

  // Fetch meetings data
  const { meetings, stats: meetingStats, isLoading: meetingsLoading } = useCompanyMeetings(companyId);

  // Fetch cap table
  const { data: capTable, isLoading: capTableLoading } = useCapTable(companyId);

  // Fetch financials
  const { data: financials, isLoading: financialsLoading } = useCompanyFinancials(companyId);

  // Fetch fund info
  const { data: fund } = useQuery({
    queryKey: ['fund-for-report', company?.fund_id],
    queryFn: async () => {
      if (!company?.fund_id) return null;
      const { data, error } = await supabase
        .from('funds')
        .select('name, cvr')
        .eq('id', company.fund_id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!company?.fund_id,
  });

  // Fetch responsible partner
  const { data: partner } = useQuery({
    queryKey: ['partner-for-report', company?.responsible_partner_id],
    queryFn: async () => {
      if (!company?.responsible_partner_id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', company.responsible_partner_id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!company?.responsible_partner_id,
  });

  // Fetch sender profile
  const { data: senderProfile } = useQuery({
    queryKey: ['sender-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .single();
      return data;
    },
    enabled: !!user?.id,
  });

  const isLoading = meetingsLoading || capTableLoading || financialsLoading;

  const formatDKK = (amount: number | null | undefined) => {
    if (amount === null || amount === undefined) return '-';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatMinutesToHours = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours === 0) return `${mins} min`;
    if (mins === 0) return `${hours} timer`;
    return `${hours} timer ${mins} min`;
  };

  const getStatusLabel = (status?: string) => {
    const statusMap: Record<string, string> = {
      'active': 'Aktiv',
      'due_diligence': 'Due Diligence',
      'new_investment': 'Ny investering',
      'exited': 'Exited',
      'write_off': 'Write-off',
    };
    return statusMap[status || ''] || status || '-';
  };

  const generateReportHTML = (forEmail: boolean = false) => {
    const today = format(new Date(), 'd. MMMM yyyy', { locale: da });
    const recentMeetings = meetings?.slice(0, 10) || [];
    
    // Calculate YTD values
    const ytdRevenue = financials?.ytd?.revenue || 0;
    const ytdEbitda = financials?.ytd?.ebitda || 0;
    const ytdMargin = ytdRevenue > 0 ? ((ytdEbitda / ytdRevenue) * 100).toFixed(1) : '-';
    
    // Calculate total cap table ownership
    const totalOwnership = capTable?.reduce((sum, entry) => sum + (entry.ownership_pct || 0), 0) || 0;

    const meetingTypeCounts = meetingStats?.meetingsByType || {};

    return `
<!DOCTYPE html>
<html lang="da">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Engagement Rapport - ${companyName}</title>
  <style>
    @media print {
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .page-break { page-break-before: always; }
    }
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background: #fff; color: #1a1a2e; line-height: 1.5; }
    .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; padding: 30px; border-radius: 8px; margin-bottom: 30px; }
    .header h1 { margin: 0 0 5px 0; font-size: 28px; }
    .header .subtitle { color: #a0aec0; font-size: 14px; }
    .header .date { color: #a0aec0; font-size: 12px; margin-top: 10px; }
    .section { margin-bottom: 30px; }
    .section h2 { font-size: 18px; color: #1a1a2e; border-bottom: 2px solid #e2e8f0; padding-bottom: 10px; margin-bottom: 15px; }
    .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; }
    .metric-card { background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0; }
    .metric-card .label { font-size: 12px; color: #64748b; margin-bottom: 5px; }
    .metric-card .value { font-size: 20px; font-weight: 600; color: #1a1a2e; }
    .info-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .info-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f1f5f9; }
    .info-row .label { color: #64748b; font-size: 14px; }
    .info-row .value { color: #1a1a2e; font-weight: 500; font-size: 14px; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th { background: #f8fafc; padding: 10px; text-align: left; font-size: 12px; color: #64748b; border-bottom: 2px solid #e2e8f0; }
    td { padding: 10px; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
    .highlight { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 20px; border-radius: 8px; text-align: center; margin-bottom: 30px; }
    .highlight .big-number { font-size: 36px; font-weight: 700; }
    .highlight .label { font-size: 14px; opacity: 0.9; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center; color: #94a3b8; font-size: 12px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>${companyName}</h1>
    <div class="subtitle">Engagement Rapport</div>
    <div class="date">Genereret ${today}</div>
  </div>

  <div class="highlight">
    <div class="big-number">${meetingStats?.totalMeetings || 0}</div>
    <div class="label">Møder afholdt med MOLA</div>
    <div style="margin-top: 10px; font-size: 14px;">${formatMinutesToHours(meetingStats?.totalMinutes || 0)} samlet tidsforbrug</div>
  </div>

  <div class="section">
    <h2>📋 Virksomhedsoplysninger</h2>
    <div class="info-grid">
      <div class="info-row">
        <span class="label">Virksomhedsnavn</span>
        <span class="value">${companyName}</span>
      </div>
      <div class="info-row">
        <span class="label">CVR</span>
        <span class="value">${company.cvr || '-'}</span>
      </div>
      <div class="info-row">
        <span class="label">Branche</span>
        <span class="value">${company.industry || '-'}</span>
      </div>
      <div class="info-row">
        <span class="label">Adresse</span>
        <span class="value">${company.address ? `${company.address}, ${company.zipcode || ''} ${company.city || ''}` : '-'}</span>
      </div>
      <div class="info-row">
        <span class="label">Status</span>
        <span class="value">${getStatusLabel(company.status)}</span>
      </div>
      <div class="info-row">
        <span class="label">Stiftet</span>
        <span class="value">${company.founded_date ? format(new Date(company.founded_date), 'd. MMM yyyy', { locale: da }) : '-'}</span>
      </div>
      <div class="info-row">
        <span class="label">Investeret dato</span>
        <span class="value">${company.invested_at ? format(new Date(company.invested_at), 'd. MMM yyyy', { locale: da }) : '-'}</span>
      </div>
      <div class="info-row">
        <span class="label">Email</span>
        <span class="value">${company.email || '-'}</span>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>💰 Investering</h2>
    <div class="grid">
      <div class="metric-card">
        <div class="label">Total investeret</div>
        <div class="value">${formatDKK(company.total_invested_amount_dkk)}</div>
      </div>
      <div class="metric-card">
        <div class="label">Ejerandel</div>
        <div class="value">${company.total_equity_share_pct ? `${company.total_equity_share_pct.toFixed(1)}%` : '-'}</div>
      </div>
      <div class="metric-card">
        <div class="label">Fond</div>
        <div class="value">${fund?.name || '-'}</div>
      </div>
      <div class="metric-card">
        <div class="label">Ansvarlig partner</div>
        <div class="value">${partner?.full_name || '-'}</div>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>📈 Omsætningsudvikling (YTD ${new Date().getFullYear()})</h2>
    <div class="grid">
      <div class="metric-card">
        <div class="label">YTD Omsætning</div>
        <div class="value">${formatDKK(ytdRevenue)}</div>
      </div>
      <div class="metric-card">
        <div class="label">YTD EBITDA</div>
        <div class="value">${formatDKK(ytdEbitda)}</div>
      </div>
      <div class="metric-card">
        <div class="label">EBITDA Margin</div>
        <div class="value">${ytdMargin}%</div>
      </div>
      <div class="metric-card">
        <div class="label">Antal rapporter</div>
        <div class="value">${financials?.reports?.length || 0}</div>
      </div>
    </div>
  </div>

  <div class="section">
    <h2>🤝 Møder med MOLA</h2>
    <div class="grid">
      <div class="metric-card">
        <div class="label">Antal møder</div>
        <div class="value">${meetingStats?.totalMeetings || 0}</div>
      </div>
      <div class="metric-card">
        <div class="label">Total tid</div>
        <div class="value">${formatMinutesToHours(meetingStats?.totalMinutes || 0)}</div>
      </div>
      <div class="metric-card">
        <div class="label">Gennemsnit pr. møde</div>
        <div class="value">${meetingStats?.averageDuration ? `${Math.round(meetingStats.averageDuration)} min` : '-'}</div>
      </div>
      <div class="metric-card">
        <div class="label">Mødetyper</div>
        <div class="value" style="font-size: 14px;">${Object.entries(meetingTypeCounts).map(([type, count]) => `${type}: ${count}`).join(', ') || '-'}</div>
      </div>
    </div>
    
    ${recentMeetings.length > 0 ? `
    <h3 style="font-size: 14px; color: #64748b; margin-top: 20px;">Seneste møder</h3>
    <table>
      <thead>
        <tr>
          <th>Dato</th>
          <th>Titel</th>
          <th>Type</th>
          <th>Varighed</th>
        </tr>
      </thead>
      <tbody>
        ${recentMeetings.map(m => {
          const meetingTypeLabels: Record<string, string> = {
            'admin': 'Admin',
            'online': 'Online møde',
            'physical': 'Fysisk møde',
            'phone': 'Telefon',
            'check_in': 'Check-in',
          };
          const typeLabel = meetingTypeLabels[m.meeting_type] || m.meeting_type || '-';
          return `
        <tr>
          <td>${format(new Date(m.meeting_date), 'd. MMM yyyy', { locale: da })}</td>
          <td>${m.title}</td>
          <td>${typeLabel}</td>
          <td>${m.duration_minutes} min</td>
        </tr>
        `;}).join('')}
      </tbody>
    </table>
    ` : '<p style="color: #64748b; font-style: italic;">Ingen møder registreret</p>'}
  </div>

  <div class="section">
    <h2>👥 Ejerkreds (Cap Table)</h2>
    <p style="color: #64748b; font-size: 14px; margin-bottom: 15px;">
      ${capTable?.length || 0} ejere • Total ejerandel: ${totalOwnership.toFixed(1)}%
    </p>
    ${capTable && capTable.length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>Ejer</th>
          <th>Type</th>
          <th style="text-align: right;">Ejerandel</th>
          <th style="text-align: right;">Antal aktier</th>
        </tr>
      </thead>
      <tbody>
        ${capTable.map(entry => `
        <tr>
          <td>${entry.owner_name}</td>
          <td>${entry.owner_type || '-'}</td>
          <td style="text-align: right;">${entry.ownership_pct.toFixed(2)}%</td>
          <td style="text-align: right;">${entry.shares?.toLocaleString('da-DK') || '-'}</td>
        </tr>
        `).join('')}
      </tbody>
    </table>
    ` : '<p style="color: #64748b; font-style: italic;">Ingen ejere registreret</p>'}
  </div>

  <div class="footer">
    <p><strong>MOLA Founder Portal</strong> • Fortroligt dokument</p>
    <p>Denne rapport dokumenterer MOLA's engagement og samarbejde med ${companyName}</p>
  </div>
</body>
</html>
    `;
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Kunne ikke åbne printvindue', {
        description: 'Tillad pop-ups i din browser'
      });
      return;
    }

    const html = generateReportHTML(false);
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 500);
  };

  const handleSendEmail = async () => {
    if (!recipientEmails.trim()) {
      toast.error('Indtast mindst én modtager-email');
      return;
    }

    const emails = recipientEmails.split(',').map(e => e.trim()).filter(Boolean);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const invalidEmails = emails.filter(e => !emailRegex.test(e));
    
    if (invalidEmails.length > 0) {
      toast.error('Ugyldige email-adresser', {
        description: invalidEmails.join(', ')
      });
      return;
    }

    setIsSendingEmail(true);

    try {
      const htmlContent = generateReportHTML(true);
      
      const { data, error } = await supabase.functions.invoke('send-company-report', {
        body: {
          recipients: emails,
          subject: `Engagement Rapport - ${companyName}`,
          htmlContent,
          personalMessage: personalMessage.trim(),
          senderName: senderProfile?.full_name || user?.email,
          companyName,
        }
      });

      if (error) throw error;

      toast.success('Rapport sendt!', {
        description: `Sendt til ${emails.length} modtager(e)`
      });
      
      setOpen(false);
      setRecipientEmails('');
      setPersonalMessage('');
    } catch (error: any) {
      console.error('Failed to send email:', error);
      toast.error('Kunne ikke sende rapport', {
        description: error.message || 'Prøv igen senere'
      });
    } finally {
      setIsSendingEmail(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline"
          className="justify-start gap-3 h-auto py-3"
        >
          <FileBarChart className="h-4 w-4" />
          <span>Engagement-rapport</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Engagement Rapport - {companyName}</DialogTitle>
          <DialogDescription>
            Generer en rapport over MOLA's engagement og virksomhedens udvikling
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-6">
            {/* Quick stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-muted/50 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold">{meetingStats?.totalMeetings || 0}</div>
                <div className="text-sm text-muted-foreground">Møder</div>
              </div>
              <div className="bg-muted/50 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold">{formatMinutesToHours(meetingStats?.totalMinutes || 0)}</div>
                <div className="text-sm text-muted-foreground">Total tid</div>
              </div>
              <div className="bg-muted/50 rounded-lg p-4 text-center">
                <div className="text-2xl font-bold">{capTable?.length || 0}</div>
                <div className="text-sm text-muted-foreground">Ejere</div>
              </div>
            </div>

            <Separator />

            {/* Print option */}
            <div>
              <Button onClick={handlePrint} variant="outline" className="w-full gap-2">
                <Printer className="h-4 w-4" />
                Print / Gem som PDF
              </Button>
            </div>

            <Separator />

            {/* Email section */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Send via email
              </h3>

              <div className="space-y-2">
                <Label htmlFor="recipients">Modtagere (komma-separeret)</Label>
                <Input
                  id="recipients"
                  type="text"
                  placeholder="email@example.com, email2@example.com"
                  value={recipientEmails}
                  onChange={(e) => setRecipientEmails(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Personlig besked (valgfri)</Label>
                <Textarea
                  id="message"
                  placeholder="Tilføj en personlig besked til rapporten..."
                  value={personalMessage}
                  onChange={(e) => setPersonalMessage(e.target.value)}
                  rows={3}
                />
              </div>

              <Button 
                onClick={handleSendEmail} 
                disabled={isSendingEmail || !recipientEmails.trim()}
                className="w-full gap-2"
              >
                {isSendingEmail ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Sender...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    Send rapport
                  </>
                )}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
