import { useNavigate } from 'react-router-dom';
import { useAllExits } from '@/hooks/useAllExits';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatPercentage } from '@/lib/formatters';

export const ExitPerformanceWidgets = () => {
  const navigate = useNavigate();
  const { data: exits, isLoading } = useAllExits();

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <div className="h-40 animate-pulse bg-muted rounded" />
        </Card>
        <Card className="p-6">
          <div className="h-40 animate-pulse bg-muted rounded" />
        </Card>
      </div>
    );
  }

  if (!exits || exits.length === 0) {
    return null;
  }

  // Calculate ROI and realized proceeds for each exit
  // Note: gross_sale_amount_dkk is MOLA's share directly, not total sale amount
  const exitsWithMetrics = exits.map(exit => {
    const realizedProceeds = exit.gross_sale_amount_dkk - exit.transaction_costs_dkk;
    const invested = exit.invested_amount_dkk || 0;
    const roi = invested > 0 ? ((realizedProceeds - invested) / invested) * 100 : 0;

    return {
      ...exit,
      realizedProceeds,
      roi,
    };
  });

  // Sort by ROI
  const sortedByROI = [...exitsWithMetrics].sort((a, b) => b.roi - a.roi);
  
  // Top 3 performing exits
  const topExits = sortedByROI.slice(0, 3);
  
  // Worst 3 performing exits
  const worstExits = sortedByROI.slice(-3).reverse();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatROI = (roi: number) => {
    const sign = roi >= 0 ? '+' : '';
    return sign + formatPercentage(roi, 1);
  };

  const handleViewAllExits = () => {
    navigate('/exits-history');
  };

  const handleCompanyClick = (companyId: string) => {
    navigate(`/company/${companyId}`);
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      {/* Top Performing Exits */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-lg bg-green-500/10 flex items-center justify-center">
              <TrendingUp className="h-5 w-5 text-green-600" />
            </div>
            <div>
              <h3 className="font-semibold">Top Performing Exits</h3>
              <p className="text-xs text-muted-foreground">Bedste exits efter ROI</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={handleViewAllExits}>
            Se alle
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="space-y-3">
          {topExits.map((exit, index) => (
            <div
              key={exit.id}
              onClick={() => handleCompanyClick(exit.company_id)}
              className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary text-sm font-bold flex-shrink-0">
                  {index + 1}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-medium truncate">{exit.company_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatCurrency(exit.realizedProceeds)}
                  </p>
                </div>
              </div>
              <Badge 
                variant={exit.roi >= 0 ? "default" : "destructive"}
                className={exit.roi >= 0 
                  ? "bg-green-500/10 text-green-700 hover:bg-green-500/20 flex-shrink-0" 
                  : "bg-red-500/10 text-red-700 hover:bg-red-500/20 flex-shrink-0"
                }
              >
                {formatROI(exit.roi)}
              </Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Worst Performing Exits */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 rounded-lg bg-red-500/10 flex items-center justify-center">
              <TrendingDown className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <h3 className="font-semibold">Worst Performing Exits</h3>
              <p className="text-xs text-muted-foreground">Dårligste exits efter ROI</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={handleViewAllExits}>
            Se alle
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>

        <div className="space-y-3">
          {worstExits.map((exit, index) => (
            <div
              key={exit.id}
              onClick={() => handleCompanyClick(exit.company_id)}
              className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
            >
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="flex items-center justify-center h-6 w-6 rounded bg-muted text-muted-foreground text-sm font-bold flex-shrink-0">
                  {index + 1}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-medium truncate">{exit.company_name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatCurrency(exit.realizedProceeds)}
                  </p>
                </div>
              </div>
              <Badge variant="destructive" className="bg-red-500/10 text-red-700 hover:bg-red-500/20 flex-shrink-0">
                {formatROI(exit.roi)}
              </Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
