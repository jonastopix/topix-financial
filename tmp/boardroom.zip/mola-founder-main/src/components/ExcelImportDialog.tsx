import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Upload, CheckCircle2, AlertCircle, XCircle, Loader2 } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

interface ExcelImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ParsedCompany {
  name: string;
  cvr?: string;
  investedAmount: number;
  equityPct: number;
  fundName: string;
  fundId?: string;
  investedAt?: string;
  ceoName?: string;
  email?: string;
  phone?: string;
  companyStatus: 'active' | 'due_diligence';
  status: 'ready' | 'exists' | 'error';
  errorMessage?: string;
}

interface ImportResult {
  companiesCreated: number;
  fundingRoundsCreated: number;
  contactsCreated: number;
  skipped: number;
  errors: string[];
  newCompanies: string[];
  skippedCompanies: string[];
}

const FUND_MAPPING: Record<string, string> = {
  'mola invest': '4256e67e-a93f-4147-b078-524ce24494b2',
  'viking capital': '078e596e-72de-42b7-95ac-396642f56719',
  'mola lh invest': '4c9f37ef-61ee-479f-bed0-54745bed798b',
};

export function ExcelImportDialog({ open, onOpenChange }: ExcelImportDialogProps) {
  const queryClient = useQueryClient();
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedCompany[]>([]);
  const [step, setStep] = useState<'upload' | 'preview' | 'importing' | 'complete'>('upload');
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [typeFilter, setTypeFilter] = useState<'all' | 'active' | 'due_diligence'>('all');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls') && !selectedFile.name.endsWith('.csv')) {
      toast.error('Venligst upload en Excel fil (.xlsx, .xls) eller CSV fil');
      return;
    }

    setFile(selectedFile);
    await parseExcelFile(selectedFile);
  };

  const parseSection = async (
    rows: any[][],
    sectionName: string,
    companyStatus: 'active' | 'due_diligence',
    existingCVRs: Set<string>
  ): Promise<ParsedCompany[]> => {
    // Find section
    let startIndex = -1;
    let headerIndex = -1;
    
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i] as any[];
      if (row[0] && typeof row[0] === 'string' && row[0].toLowerCase().includes(sectionName.toLowerCase())) {
        startIndex = i;
        headerIndex = i + 1;
        console.log(`Found "${sectionName}" at row:`, i, 'Header at row:', headerIndex);
        break;
      }
    }

    if (startIndex === -1) {
      console.log(`Section "${sectionName}" not found`);
      return [];
    }

    // Parse header to find column indices
    const headerRow = rows[headerIndex] as any[];
    const columnMap: Record<string, number> = {};
    
    headerRow.forEach((header: any, index: number) => {
      if (typeof header === 'string') {
        const normalized = header.toLowerCase().trim();
        if (normalized === 'name') columnMap.name = index;
        if (normalized === 'firmanavn') columnMap.name = index;
        if (normalized === 'cvr') columnMap.cvr = index;
        if (normalized.includes('beløb investeret')) columnMap.amount = index;
        if (normalized.includes('ejerskab')) columnMap.equity = index;
        if (normalized.includes('investeringsselskab')) columnMap.fund = index;
        if (normalized === 'ceo') columnMap.ceo = index;
        if (normalized === 'email') columnMap.email = index;
        if (normalized === 'mobil' || normalized === 'phone') columnMap.phone = index;
        if (normalized.includes('investerings dato')) columnMap.date = index;
      }
    });

    // Parse data rows
    const companies: ParsedCompany[] = [];
    const seenCVRs = new Set<string>(); // Track CVRs within this Excel file
    
    for (let i = headerIndex + 1; i < rows.length; i++) {
      const row = rows[i] as any[];
      
      // Stop at completely empty row
      if (!row || row.length === 0) break;
      
      // Stop if we reach a new section
      if (row[0] && typeof row[0] === 'string') {
        const firstCell = row[0].toString().toLowerCase();
        if (firstCell.includes('aktive investeringer') || 
            firstCell.includes('due diligence') || 
            firstCell.includes('exits')) {
          // Only stop if this is NOT our current section
          if (!firstCell.includes(sectionName.toLowerCase())) {
            console.log('Reached next section at row', i);
            break;
          }
        }
      }

      const rawName = row[columnMap.name]?.toString().trim();
      
      // Skip rows without company name, "Subitems" rows, header rows, or links
      if (!rawName || 
          rawName.toLowerCase() === 'subitems' || 
          rawName.toLowerCase() === 'name' ||
          rawName.toLowerCase().includes('link') ||
          rawName.includes('http') ||
          rawName.includes('www.')) {
        continue;
      }

      // Håndter specialtegn (f.eks. \&Peopl → &Peopl)
      const name = rawName.replace(/\\&/g, '&');
      const cvr = row[columnMap.cvr]?.toString().trim();
      const amount = parseFloat(row[columnMap.amount]?.toString().replace(/[^0-9.-]/g, '') || '0');
      const equity = parseFloat(row[columnMap.equity]?.toString().replace(/[^0-9.-]/g, '') || '0');
      const fundName = row[columnMap.fund]?.toString().trim();
      const ceoName = row[columnMap.ceo]?.toString().trim();
      const email = row[columnMap.email]?.toString().trim();
      const phone = row[columnMap.phone]?.toString().trim();
      const investedAt = row[columnMap.date] ? parseDateFromExcel(row[columnMap.date]) : undefined;

      if (!name) continue;

      const fundId = fundName ? FUND_MAPPING[fundName.toLowerCase()] : undefined;
      
      let status: 'ready' | 'exists' | 'error' = 'ready';
      let errorMessage: string | undefined;

      // Check if exists in database
      if (cvr && existingCVRs.has(cvr)) {
        status = 'exists';
        errorMessage = 'Findes allerede (CVR match)';
      }
      // Check for duplicate within Excel file
      else if (cvr && seenCVRs.has(cvr)) {
        status = 'exists';
        errorMessage = 'Duplikat i Excel fil (CVR allerede set)';
      }
      // Validate required fields
      else if (!name || !amount || !equity || !fundId) {
        status = 'error';
        if (!name) errorMessage = 'Mangler firmanavn';
        else if (!amount) errorMessage = 'Mangler beløb investeret';
        else if (!equity) errorMessage = 'Mangler ejerskab %';
        else if (!fundId) errorMessage = 'Ukendt investeringsselskab';
      }

      // Add CVR to seen set if company is ready to import
      if (cvr && status === 'ready') {
        seenCVRs.add(cvr);
      }

      console.log('📋 Parsed company:', name, '| companyStatus:', companyStatus, '| status:', status, '| errorMessage:', errorMessage);

      companies.push({
        name,
        cvr,
        investedAmount: amount,
        equityPct: equity,
        fundName: fundName || '',
        fundId,
        investedAt,
        ceoName,
        email,
        phone,
        companyStatus,
        status,
        errorMessage,
      });
    }

    return companies;
  };

  const parseExcelFile = async (file: File) => {
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json<any>(firstSheet, { header: 1 });

      // Check for existing companies by CVR
      const { data: existingCompanies } = await supabase
        .from('companies')
        .select('cvr')
        .not('cvr', 'is', null);

      const existingCVRs = new Set(existingCompanies?.map(c => c.cvr) || []);

      // Parse both sections
      const activeCompanies = await parseSection(rows, 'aktive investeringer', 'active', existingCVRs);
      const ddCompanies = await parseSection(rows, 'due diligence', 'due_diligence', existingCVRs);

      // Combine results
      const allCompanies = [...activeCompanies, ...ddCompanies];

      console.log('📊 Parsed companies summary:');
      console.log('- Active:', activeCompanies.length, activeCompanies.map(c => ({name: c.name, companyStatus: c.companyStatus, status: c.status})));
      console.log('- DD:', ddCompanies.length, ddCompanies.map(c => ({name: c.name, companyStatus: c.companyStatus, status: c.status})));

      if (allCompanies.length === 0) {
        toast.error('Kunne ikke finde nogen selskaber i Excel filen');
        return;
      }

      setParsedData(allCompanies);
      setStep('preview');
      toast.success(`Fandt ${allCompanies.length} selskaber (${activeCompanies.length} aktive, ${ddCompanies.length} due diligence)`);
    } catch (error) {
      console.error('Error parsing Excel:', error);
      toast.error('Fejl ved læsning af Excel fil');
    }
  };

  const parseDateFromExcel = (value: any): string | undefined => {
    if (!value) return undefined;
    
    // Excel serial date
    if (typeof value === 'number') {
      const date = new Date((value - 25569) * 86400 * 1000);
      return date.toISOString().split('T')[0];
    }
    
    // String date
    if (typeof value === 'string') {
      const date = new Date(value);
      if (!isNaN(date.getTime())) {
        return date.toISOString().split('T')[0];
      }
    }
    
    return undefined;
  };

  const handleImport = async () => {
    setStep('importing');
    const result: ImportResult = {
      companiesCreated: 0,
      fundingRoundsCreated: 0,
      contactsCreated: 0,
      skipped: 0,
      errors: [],
      newCompanies: [],
      skippedCompanies: [],
    };

    const companiesToImport = filteredData.filter(c => c.status === 'ready');

    for (const company of companiesToImport) {
      try {
        console.log('🚀 Importing company:', company.name, '| companyStatus:', company.companyStatus);
        
        // Create company
        const { data: newCompany, error: companyError } = await supabase
          .from('companies')
          .insert({
            name: company.name,
            cvr: company.cvr,
            fund_id: company.fundId,
            invested_at: company.investedAt,
            email: company.email,
            phone: company.phone,
            status: company.companyStatus,
            is_active: true,
          })
          .select()
          .single();

        if (companyError) {
          // Handle duplicate CVR error gracefully
          if (companyError.code === '23505' && companyError.message.includes('companies_cvr_unique')) {
            result.skipped++;
            result.skippedCompanies.push(`${company.name} - Duplikat CVR (allerede importeret i denne batch)`);
            continue;
          }
          throw companyError;
        }

        result.companiesCreated++;
        result.newCompanies.push(`${company.name} (CVR: ${company.cvr || 'N/A'})`);

        // Create funding round
        const { error: fundingError } = await supabase
          .from('funding_rounds')
          .insert({
            company_id: newCompany.id,
            fund_id: company.fundId,
            round_name: 'Initial Investment',
            round_type: 'initial',
            invested_amount_dkk: company.investedAmount,
            equity_acquired_pct: company.equityPct,
            invested_at: company.investedAt || new Date().toISOString().split('T')[0],
          });

        if (fundingError) throw fundingError;
        result.fundingRoundsCreated++;

        // Create contact if CEO info exists
        if (company.ceoName) {
          const { error: contactError } = await supabase
            .from('company_contacts')
            .insert({
              company_id: newCompany.id,
              name: company.ceoName,
              role: 'CEO',
              email: company.email,
              phone: company.phone,
              is_primary: true,
            });

          if (contactError) throw contactError;
          result.contactsCreated++;
        }

        // Auto-create DD case
        await supabase
          .from('due_diligence_cases')
          .insert({
            company_id: newCompany.id,
            status: 'not_started',
          });

      } catch (error: any) {
        result.errors.push(`${company.name}: ${error.message}`);
      }
    }

    // Count skipped
    const skippedCompanies = parsedData.filter(c => c.status !== 'ready');
    result.skipped = skippedCompanies.length;
    result.skippedCompanies = skippedCompanies.map(c => `${c.name} - ${c.errorMessage}`);

    setImportResult(result);
    setStep('complete');

    // Invalidate queries
    queryClient.invalidateQueries({ queryKey: ['companies-all'] });
    queryClient.invalidateQueries({ queryKey: ['funding-rounds'] });
    queryClient.invalidateQueries({ queryKey: ['company-contacts'] });
    queryClient.invalidateQueries({ queryKey: ['due-diligence-cases'] });

    if (result.companiesCreated > 0) {
      toast.success(`${result.companiesCreated} selskaber importeret!`);
    }
  };

  const handleClose = () => {
    setFile(null);
    setParsedData([]);
    setStep('upload');
    setImportResult(null);
    onOpenChange(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready':
        return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'exists':
        return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const filteredData = parsedData.filter(c => 
    typeFilter === 'all' || c.companyStatus === typeFilter
  );
  
  const readyCount = filteredData.filter(c => c.status === 'ready').length;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Import Selskaber fra Excel</DialogTitle>
          <DialogDescription>
            Upload en Excel fil med aktive investeringer og due diligence selskaber. Systemet checker automatisk for duplikater via CVR-nummer.
          </DialogDescription>
        </DialogHeader>

        {step === 'upload' && (
          <div className="space-y-4">
            <div className="border-2 border-dashed rounded-lg p-8 text-center">
              <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <Input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={handleFileChange}
                className="max-w-xs mx-auto"
              />
              <p className="text-sm text-muted-foreground mt-2">
                Upload Excel fil med "Aktive investeringer" og/eller "Due Diligence" sektioner
              </p>
            </div>

            <div className="bg-muted p-4 rounded-lg text-sm space-y-2">
              <p className="font-medium">Forventede kolonner:</p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Firmanavn</strong> (required)</li>
                <li><strong>Beløb investeret</strong> (required)</li>
                <li><strong>Ejerskab (%)</strong> (required)</li>
                <li><strong>Investeringsselskab</strong> (required)</li>
                <li>CVR (anbefalet - bruges til duplicate check)</li>
                <li>CEO, Email, Mobil (optional)</li>
              </ul>
            </div>
          </div>
        )}

        {step === 'preview' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex gap-2">
                <Badge variant="outline" className="gap-2">
                  <CheckCircle2 className="h-3 w-3" />
                  {readyCount} klar
                </Badge>
                <Badge variant="outline" className="gap-2">
                  <AlertCircle className="h-3 w-3" />
                  {filteredData.filter(c => c.status === 'exists').length} findes
                </Badge>
                <Badge variant="outline" className="gap-2">
                  <XCircle className="h-3 w-3" />
                  {filteredData.filter(c => c.status === 'error').length} fejl
                </Badge>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant={typeFilter === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTypeFilter('all')}
                >
                  Alle ({parsedData.length})
                </Button>
                <Button
                  variant={typeFilter === 'active' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTypeFilter('active')}
                >
                  Aktive ({parsedData.filter(c => c.companyStatus === 'active').length})
                </Button>
                <Button
                  variant={typeFilter === 'due_diligence' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setTypeFilter('due_diligence')}
                >
                  Due Diligence ({parsedData.filter(c => c.companyStatus === 'due_diligence').length})
                </Button>
              </div>
            </div>

            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[40px]"></TableHead>
                    <TableHead>Firma</TableHead>
                    <TableHead>CVR</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Beløb</TableHead>
                    <TableHead>Ejerskab</TableHead>
                    <TableHead>Fond</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredData.map((company, index) => (
                    <TableRow key={index}>
                      <TableCell>{getStatusIcon(company.status)}</TableCell>
                      <TableCell className="font-medium">{company.name}</TableCell>
                      <TableCell>{company.cvr || '-'}</TableCell>
                      <TableCell>
                        <Badge variant={company.companyStatus === 'active' ? 'default' : 'secondary'}>
                          {company.companyStatus === 'active' ? 'Aktiv' : 'DD'}
                        </Badge>
                      </TableCell>
                      <TableCell>{company.investedAmount.toLocaleString('da-DK')} kr</TableCell>
                      <TableCell>{company.equityPct}%</TableCell>
                      <TableCell className="text-sm">{company.fundName}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {company.status === 'ready' ? 'Klar til import' : company.errorMessage}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={handleClose}>
                Annuller
              </Button>
              <Button onClick={handleImport} disabled={readyCount === 0}>
                Import {readyCount} selskaber
              </Button>
            </div>
          </div>
        )}

        {step === 'importing' && (
          <div className="py-8 text-center">
            <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
            <p className="text-lg font-medium">Importerer selskaber...</p>
            <p className="text-sm text-muted-foreground">Dette kan tage et øjeblik</p>
          </div>
        )}

        {step === 'complete' && importResult && (
          <div className="space-y-4">
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <h3 className="font-medium text-green-900 dark:text-green-100">Import fuldført!</h3>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-sm text-muted-foreground">Nye selskaber</p>
                  <p className="text-2xl font-bold text-green-600">{importResult.companiesCreated}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Funding rounds</p>
                  <p className="text-2xl font-bold">{importResult.fundingRoundsCreated}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Kontakter</p>
                  <p className="text-2xl font-bold">{importResult.contactsCreated}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Skipped</p>
                  <p className="text-2xl font-bold text-yellow-600">{importResult.skipped}</p>
                </div>
              </div>
            </div>

            {importResult.newCompanies.length > 0 && (
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  Nye selskaber oprettet:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                  {importResult.newCompanies.map((company, index) => (
                    <li key={index}>{company}</li>
                  ))}
                </ul>
              </div>
            )}

            {importResult.skippedCompanies.length > 0 && (
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-yellow-600" />
                  Skipped:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                  {importResult.skippedCompanies.map((company, index) => (
                    <li key={index}>{company}</li>
                  ))}
                </ul>
              </div>
            )}

            {importResult.errors.length > 0 && (
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2 text-red-600">
                  <XCircle className="h-4 w-4" />
                  Fejl:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-sm text-red-600">
                  {importResult.errors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex justify-end">
              <Button onClick={handleClose}>Luk</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
