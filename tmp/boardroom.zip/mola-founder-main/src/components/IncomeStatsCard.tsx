import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useIncomeEntries } from "@/hooks/useIncomeEntries";
import { formatCurrency } from "@/lib/formatters";
import { TrendingUp, DollarSign, Clock } from "lucide-react";

export function IncomeStatsCard() {
  const { incomeEntries } = useIncomeEntries();

  const totalIncome = incomeEntries?.reduce((sum, entry) => sum + entry.amount_dkk, 0) || 0;
  const paidIncome = incomeEntries?.filter(e => e.status === "paid")
    .reduce((sum, entry) => sum + entry.amount_dkk, 0) || 0;
  const pendingIncome = incomeEntries?.filter(e => e.status === "sent" || e.status === "draft")
    .reduce((sum, entry) => sum + entry.amount_dkk, 0) || 0;

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Total Indkomst</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-xl lg:text-2xl font-bold truncate">{formatCurrency(totalIncome)}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Betalt</CardTitle>
          <TrendingUp className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-xl lg:text-2xl font-bold text-green-600 truncate">{formatCurrency(paidIncome)}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Afventer</CardTitle>
          <Clock className="h-4 w-4 text-orange-600" />
        </CardHeader>
        <CardContent>
          <div className="text-xl lg:text-2xl font-bold text-orange-600 truncate">{formatCurrency(pendingIncome)}</div>
        </CardContent>
      </Card>
    </>
  );
}
