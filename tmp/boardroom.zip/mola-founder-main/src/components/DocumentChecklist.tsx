import { Check, X, Upload } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { DocumentType } from '@/hooks/useCompanyDocuments';
import { useCompanyDocumentStatus, getDocumentPriorities } from '@/hooks/useCompanyDocumentStatus';
import { cn } from '@/lib/utils';

interface DocumentChecklistProps {
  companyId: string;
  hasBoard: boolean;
  onUploadClick: (documentType: DocumentType) => void;
}

const documentTypeLabels: Record<DocumentType, string> = {
  shareholder_agreement: 'Ejeraftale',
  articles_of_association: 'Vedtægter',
  annual_report: 'Årsrapport',
  board_minutes: 'Bestyrelsesprotokol',
  investment_memo: 'Investeringsmemo',
  term_sheet: 'Term Sheet',
  valuation_report: 'Værdiansættelse',
  other: 'Andet',
};

const DocumentChecklist = ({ companyId, hasBoard, onUploadClick }: DocumentChecklistProps) => {
  const { data: status } = useCompanyDocumentStatus(companyId, hasBoard);
  const priorities = getDocumentPriorities(hasBoard);

  if (!status) return null;

  const isUploaded = (type: DocumentType) => status.uploadedTypes.includes(type);

  const getStatusColor = () => {
    switch (status.status) {
      case 'critical':
        return 'text-destructive';
      case 'warning':
        return 'text-warning';
      case 'good':
        return 'text-success';
    }
  };

  const getStatusBadge = () => {
    switch (status.status) {
      case 'critical':
        return <Badge variant="destructive">Kritisk</Badge>;
      case 'warning':
        return <Badge className="bg-warning text-warning-foreground">Mangler vigtige</Badge>;
      case 'good':
        return <Badge className="bg-success text-success-foreground">God status</Badge>;
    }
  };

  return (
    <Card className="border-border/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Dokument Checklist</CardTitle>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Samlet fremskridt</span>
            <span className={cn("font-semibold", getStatusColor())}>
              {status.uploadedDocuments}/{status.totalDocuments} dokumenter
            </span>
          </div>
          <Progress value={status.completionRate} className="h-2" />
          <p className="text-xs text-muted-foreground text-right">
            {status.completionRate}% fuldført
          </p>
        </div>

        {status.missingCritical.length > 0 && (
          <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4 space-y-3">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-destructive animate-pulse" />
              <h4 className="font-semibold text-sm text-destructive">Kritiske dokumenter mangler</h4>
            </div>
            <div className="space-y-2">
              {priorities.critical.map((type) => (
                <DocumentChecklistItem
                  key={type}
                  type={type}
                  label={documentTypeLabels[type]}
                  isUploaded={isUploaded(type)}
                  isCritical={true}
                  onUploadClick={() => onUploadClick(type)}
                />
              ))}
            </div>
          </div>
        )}

        {status.missingCritical.length === 0 && (
          <div className="space-y-2">
            <h4 className="font-semibold text-sm flex items-center gap-2">
              <Check className="h-4 w-4 text-success" />
              Kritiske dokumenter
            </h4>
            <div className="space-y-2">
              {priorities.critical.map((type) => (
                <DocumentChecklistItem
                  key={type}
                  type={type}
                  label={documentTypeLabels[type]}
                  isUploaded={isUploaded(type)}
                  isCritical={true}
                  onUploadClick={() => onUploadClick(type)}
                />
              ))}
            </div>
          </div>
        )}

        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-muted-foreground">Vigtige dokumenter</h4>
          <div className="space-y-2">
            {priorities.important.map((type) => (
              <DocumentChecklistItem
                key={type}
                type={type}
                label={documentTypeLabels[type]}
                isUploaded={isUploaded(type)}
                isCritical={false}
                onUploadClick={() => onUploadClick(type)}
              />
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <h4 className="font-semibold text-sm text-muted-foreground">Valgfrie dokumenter</h4>
          <div className="space-y-2">
            {priorities.optional.map((type) => (
              <DocumentChecklistItem
                key={type}
                type={type}
                label={documentTypeLabels[type]}
                isUploaded={isUploaded(type)}
                isCritical={false}
                onUploadClick={() => onUploadClick(type)}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

interface DocumentChecklistItemProps {
  type: DocumentType;
  label: string;
  isUploaded: boolean;
  isCritical: boolean;
  onUploadClick: () => void;
}

const DocumentChecklistItem = ({ 
  label, 
  isUploaded, 
  isCritical, 
  onUploadClick 
}: DocumentChecklistItemProps) => {
  return (
    <div className={cn(
      "flex items-center justify-between p-3 rounded-md border",
      isUploaded 
        ? "bg-success/5 border-success/20" 
        : isCritical 
        ? "bg-background border-destructive/20" 
        : "bg-background border-border/50"
    )}>
      <div className="flex items-center gap-3">
        <div className={cn(
          "flex h-5 w-5 items-center justify-center rounded-full",
          isUploaded 
            ? "bg-success text-success-foreground" 
            : "border-2 border-muted-foreground/30"
        )}>
          {isUploaded ? (
            <Check className="h-3 w-3" />
          ) : (
            <X className="h-3 w-3 text-muted-foreground/30" />
          )}
        </div>
        <span className={cn(
          "text-sm",
          isUploaded ? "text-foreground font-medium" : "text-muted-foreground"
        )}>
          {label}
        </span>
        {isCritical && !isUploaded && (
          <Badge variant="outline" className="text-xs border-destructive/30 text-destructive">
            Kritisk
          </Badge>
        )}
      </div>
      {!isUploaded && (
        <Button
          size="sm"
          variant="outline"
          onClick={onUploadClick}
          className="h-7 gap-1"
        >
          <Upload className="h-3 w-3" />
          Upload
        </Button>
      )}
    </div>
  );
};

export default DocumentChecklist;
