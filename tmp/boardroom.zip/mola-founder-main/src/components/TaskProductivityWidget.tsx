import { Flame, Snowflake, Zap, Trophy } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useTaskProductivity, ProductivityLevel } from '@/hooks/useTaskProductivity';
import { cn } from '@/lib/utils';

const levelConfig: Record<ProductivityLevel, { 
  icon: typeof Flame; 
  label: string; 
  color: string; 
  bgColor: string;
  message: string;
}> = {
  cold: { 
    icon: Snowflake, 
    label: 'Kold start', 
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
    message: 'Tid til at komme i gang! 💪'
  },
  warming: { 
    icon: Zap, 
    label: 'Varmer op', 
    color: 'text-warning',
    bgColor: 'bg-warning/10',
    message: 'Godt i gang! Fortsæt sådan 👍'
  },
  hot: { 
    icon: Flame, 
    label: 'Hot!', 
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    message: 'Du er godt kørende! 🔥'
  },
  fire: { 
    icon: Flame, 
    label: 'On Fire!', 
    color: 'text-destructive',
    bgColor: 'bg-destructive/10',
    message: 'Fantastisk tempo! 🚀'
  },
  legendary: { 
    icon: Trophy, 
    label: 'Legendarisk!', 
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-500/10',
    message: 'Utroligt! Du er unstoppable! 🏆'
  },
};

export const TaskProductivityWidget = () => {
  const { stats, isLoading } = useTaskProductivity();

  if (isLoading) {
    return null;
  }

  const config = levelConfig[stats.productivityLevel];
  const Icon = config.icon;
  const progressPercent = Math.min((stats.completedToday / stats.dailyGoal) * 100, 100);

  return (
    <Card className={cn("p-4 mb-4", config.bgColor)}>
      <div className="flex items-center gap-4">
        {/* Icon */}
        <div className={cn(
          "flex items-center justify-center w-12 h-12 rounded-full",
          stats.productivityLevel === 'legendary' && "animate-pulse",
          stats.productivityLevel === 'fire' && "animate-pulse"
        )}>
          <Icon className={cn("h-8 w-8", config.color)} />
        </div>

        {/* Stats */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={cn("font-bold text-lg", config.color)}>{config.label}</span>
            {stats.currentStreak > 1 && (
              <span className="text-sm bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                🔥 {stats.currentStreak} dages streak
              </span>
            )}
          </div>
          
          {/* Progress bar */}
          <div className="flex items-center gap-2 mb-1">
            <Progress value={progressPercent} className="h-2 flex-1" />
            <span className="text-sm text-muted-foreground whitespace-nowrap">
              {stats.completedToday}/{stats.dailyGoal} i dag
            </span>
          </div>

          {/* Message and comparison */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>{config.message}</span>
            {stats.percentageVsAverage !== 0 && (
              <span className={cn(
                "font-medium",
                stats.isAboveAverage ? "text-success" : "text-muted-foreground"
              )}>
                {stats.isAboveAverage ? '+' : ''}{stats.percentageVsAverage}% vs. normalt
              </span>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
};

export default TaskProductivityWidget;
