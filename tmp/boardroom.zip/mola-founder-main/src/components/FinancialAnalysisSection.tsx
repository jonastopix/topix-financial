import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, DollarSign, Target, Zap } from 'lucide-react';
import { AnimatedNumber } from '@/components/AnimatedNumber';

interface FinancialAnalysisSectionProps {
  data: {
    investmentMultipleRevenue: number;
    avgMonthRevenue: number;
    marketingEfficiency: number;
    profitabilityPct: number;
  };
}

export function FinancialAnalysisSection({ data }: FinancialAnalysisSectionProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value) + ' kr';
  };

  const formatNumber = (value: number, decimals: number = 2) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  const formatPercent = (value: number, decimals: number = 1) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  // Clamp profitability to 0-30 for progress bar
  const profitabilityProgress = Math.min(100, Math.max(0, (data.profitabilityPct / 30) * 100));

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Finansiel Analyse</h2>

      <Card className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              <p className="text-sm font-medium text-muted-foreground">Investment Multiple</p>
            </div>
            <div>
              <p className="text-2xl lg:text-4xl font-bold text-primary truncate">
                {formatNumber(data.investmentMultipleRevenue, 2)}x
              </p>
              <p className="text-xs text-muted-foreground mt-1">på omsætning</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-success" />
              <p className="text-sm font-medium text-muted-foreground">Profitabilitet</p>
            </div>
            <div className="space-y-2">
              <p className="text-xl lg:text-2xl font-bold truncate">
                {formatPercent(data.profitabilityPct, 1)}%
              </p>
              <Progress value={profitabilityProgress} className="h-2" />
              <p className="text-xs text-muted-foreground">EBITDA Margin</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-warning" />
              <p className="text-sm font-medium text-muted-foreground">Gennemsnitlig månedlig omsætning</p>
            </div>
            <div>
              <p className="text-2xl lg:text-3xl font-bold truncate">
                {formatCurrency(data.avgMonthRevenue)}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-accent" />
              <p className="text-sm font-medium text-muted-foreground">Marketingeffektivitet</p>
            </div>
            <div>
              <p className="text-2xl lg:text-3xl font-bold text-accent truncate">
                {formatNumber(data.marketingEfficiency, 2)} kr
              </p>
              <p className="text-xs text-muted-foreground mt-1">per krone</p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
