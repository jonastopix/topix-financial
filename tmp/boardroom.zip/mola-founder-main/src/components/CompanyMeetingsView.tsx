import { useState } from 'react';
import { useCompanyMeetings } from '@/hooks/useCompanyMeetings';
import { useRole } from '@/contexts/RoleContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, Users, Plus, FileText, Video, Phone, MapPin, Settings } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface CompanyMeetingsViewProps {
  companyId: string;
}

export function CompanyMeetingsView({ companyId }: CompanyMeetingsViewProps) {
  const { meetings, isLoading, createMeeting, stats } = useCompanyMeetings(companyId);
  const { isAdmin, activeRole } = useRole();
  const canManageMeetings = isAdmin || activeRole === 'fund_partner';
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    meeting_date: format(new Date(), 'yyyy-MM-dd'),
    duration_minutes: 60,
    meeting_type: 'online',
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await createMeeting.mutateAsync({
      company_id: companyId,
      ...formData,
      participants: [],
      action_items: [],
    });
    setShowForm(false);
    setFormData({
      title: '',
      meeting_date: format(new Date(), 'yyyy-MM-dd'),
      duration_minutes: 60,
      meeting_type: 'online',
      notes: '',
    });
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}t ${mins}m` : `${mins}m`;
  };

  if (isLoading) {
    return <div>Indlæser møder...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Antal møder</p>
                <p className="text-2xl font-bold">{stats.totalMeetings}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Total tid</p>
                <p className="text-2xl font-bold">{formatDuration(stats.totalMinutes)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm text-muted-foreground">Gns. varighed</p>
                <p className="text-2xl font-bold">{formatDuration(Math.round(stats.averageDuration))}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            {canManageMeetings && (
              <Button onClick={() => setShowForm(!showForm)} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Ny møde
              </Button>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Registrer nyt møde</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Mødetitel</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="meeting_date">Dato</Label>
                  <Input
                    id="meeting_date"
                    type="date"
                    value={formData.meeting_date}
                    onChange={(e) => setFormData({ ...formData, meeting_date: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="duration">Varighed (minutter)</Label>
                  <Input
                    id="duration"
                    type="number"
                    min="1"
                    value={formData.duration_minutes}
                    onChange={(e) => setFormData({ ...formData, duration_minutes: parseInt(e.target.value) })}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="type">Mødetype</Label>
                <Select
                  value={formData.meeting_type}
                  onValueChange={(value) => setFormData({ ...formData, meeting_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="online">Online møde</SelectItem>
                    <SelectItem value="physical">Fysisk møde</SelectItem>
                    <SelectItem value="phone">Telefon</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="notes">Mødereferat</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={6}
                  placeholder="Beskriv hvad der blev diskuteret..."
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit" disabled={createMeeting.isPending}>
                  Gem møde
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>
                  Annuller
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Meeting history */}
      <Card>
        <CardHeader>
          <CardTitle>Mødehistorik</CardTitle>
        </CardHeader>
        <CardContent>
          {meetings.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Ingen møder registreret endnu.
            </p>
          ) : (
            <div className="space-y-4">
              {meetings.map((meeting) => (
                <div key={meeting.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-semibold">{meeting.title}</h4>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {format(new Date(meeting.meeting_date), 'PPP', { locale: da })}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatDuration(Number(meeting.duration_minutes))}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs px-2 py-1 bg-secondary rounded flex items-center gap-1">
                        {meeting.meeting_type === 'admin' && <><Settings className="h-3 w-3" />Admin</>}
                        {meeting.meeting_type === 'online' && <><Video className="h-3 w-3" />Online møde</>}
                        {meeting.meeting_type === 'physical' && <><MapPin className="h-3 w-3" />Fysisk møde</>}
                        {meeting.meeting_type === 'phone' && <><Phone className="h-3 w-3" />Telefon</>}
                        {meeting.meeting_type === 'check_in' && <><Calendar className="h-3 w-3" />Check-in</>}
                        {!['admin', 'online', 'physical', 'phone', 'check_in'].includes(meeting.meeting_type) && meeting.meeting_type}
                      </span>
                      {meeting.calendly_event_uuid && (
                        <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">
                          📅 Calendly
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Participants */}
                  {meeting.participants && meeting.participants.length > 0 && (
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <div className="flex flex-wrap gap-1">
                        {meeting.participants.map((p, idx) => (
                          <span key={idx} className="text-xs px-2 py-1 bg-muted rounded">
                            {p.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Reschedule count */}
                  {meeting.calendly_reschedule_count && meeting.calendly_reschedule_count > 0 && (
                    <div className="text-xs text-muted-foreground">
                      🔄 Omlagt {meeting.calendly_reschedule_count} gang{meeting.calendly_reschedule_count > 1 ? 'e' : ''}
                    </div>
                  )}

                  {meeting.notes && (
                    <div className="text-sm border-t pt-3">
                      <div className="flex items-start gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <p className="text-muted-foreground whitespace-pre-wrap flex-1">{meeting.notes}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
