import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { CheckCircle2, AlertCircle, XCircle, ChevronDown } from 'lucide-react';
import DocumentUpload from './DocumentUpload';

export interface Document {
  id: string;
  name_da: string;
  uploaded: boolean;
}

export interface Category {
  id: string;
  name_da: string;
  description_da: string;
  documents: Document[];
}

interface CategoryCardProps {
  category: Category;
  onUpload: (documentId: string, file: File) => Promise<void>;
}

const CategoryCard = ({ category, onUpload }: CategoryCardProps) => {
  const uploadedCount = category.documents.filter(d => d.uploaded).length;
  const totalCount = category.documents.length;
  
  const getStatusIcon = () => {
    if (uploadedCount === totalCount) {
      return <CheckCircle2 className="h-5 w-5 text-[hsl(var(--status-complete))]" />;
    } else if (uploadedCount > 0) {
      return <AlertCircle className="h-5 w-5 text-[hsl(var(--status-partial))]" />;
    }
    return <XCircle className="h-5 w-5 text-[hsl(var(--status-missing))]" />;
  };

  const getStatusColor = () => {
    if (uploadedCount === totalCount) return 'text-[hsl(var(--status-complete))]';
    if (uploadedCount > 0) return 'text-[hsl(var(--status-partial))]';
    return 'text-[hsl(var(--status-missing))]';
  };

  return (
    <Card className="border-border bg-card">
      <Accordion type="single" collapsible>
        <AccordionItem value="item-1" className="border-none">
          <CardHeader className="pb-3">
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center justify-between w-full pr-4">
                <div className="flex items-center gap-3">
                  {getStatusIcon()}
                  <div className="text-left">
                    <CardTitle className="text-lg text-card-foreground">{category.name_da}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">{category.description_da}</p>
                  </div>
                </div>
                <span className={`text-sm font-medium ${getStatusColor()}`}>
                  {uploadedCount}/{totalCount}
                </span>
              </div>
            </AccordionTrigger>
          </CardHeader>
          <AccordionContent>
            <CardContent className="pt-0">
              <div className="space-y-4">
                {category.documents.map((doc) => (
                  <DocumentUpload
                    key={doc.id}
                    document={doc}
                    onUpload={(file) => onUpload(doc.id, file)}
                  />
                ))}
              </div>
            </CardContent>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Card>
  );
};

export default CategoryCard;
