import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface TaskCompletionCelebrationProps {
  show: boolean;
  onComplete?: () => void;
}

export const TaskCompletionCelebration = ({ show, onComplete }: TaskCompletionCelebrationProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (show) {
      setIsVisible(true);
      const timer = setTimeout(() => {
        setIsVisible(false);
        onComplete?.();
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [show, onComplete]);

  if (!isVisible) return null;

  return (
    <div className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden">
      <span className={cn(
        "text-2xl font-bold text-success animate-float-up",
      )}>
        +1 ✓
      </span>
    </div>
  );
};

export default TaskCompletionCelebration;
