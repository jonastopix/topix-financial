import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useEmailTemplateMutations } from '@/hooks/useEmailTemplates';
import { Send } from 'lucide-react';

interface SendTestEmailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  templateId: string;
  templateName: string;
}

export function SendTestEmailDialog({ open, onOpenChange, templateId, templateName }: SendTestEmailDialogProps) {
  const [testEmail, setTestEmail] = useState('');
  const { sendTestEmail } = useEmailTemplateMutations();

  const handleSend = () => {
    sendTestEmail.mutate(
      { templateId, testEmail },
      {
        onSuccess: () => {
          onOpenChange(false);
          setTestEmail('');
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Send Test Email</DialogTitle>
          {templateName && (
            <p className="text-sm text-muted-foreground">
              Template: <strong>{templateName}</strong>
            </p>
          )}
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="test-email">Email Adresse</Label>
            <Input
              id="test-email"
              type="email"
              placeholder="test@example.com"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
            />
          </div>
          <p className="text-sm text-muted-foreground">
            Test emailen vil blive sendt med standard test værdier for alle variabler.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button
            onClick={handleSend}
            disabled={!testEmail || sendTestEmail.isPending}
            className="gap-2"
          >
            <Send className="w-4 h-4" />
            {sendTestEmail.isPending ? 'Sender...' : 'Send Test Email'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
