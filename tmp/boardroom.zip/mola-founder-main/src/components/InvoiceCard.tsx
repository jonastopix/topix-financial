import { Calendar, DollarSign } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { InvoiceStatusBadge } from "@/components/InvoiceStatusBadge";
import { formatCurrency } from "@/lib/formatters";
import { format } from "date-fns";
import { da } from "date-fns/locale";

import { IncomeEntry } from "@/hooks/useIncomeEntries";

interface InvoiceCardProps {
  entry: IncomeEntry;
}

export function InvoiceCard({ entry }: InvoiceCardProps) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{entry.description}</CardTitle>
            {entry.economic_invoice_number && (
              <p className="text-sm text-muted-foreground mt-1">
                Faktura: {entry.economic_invoice_number}
              </p>
            )}
          </div>
          <InvoiceStatusBadge status={entry.status} />
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <DollarSign className="h-4 w-4" />
            <span>Beløb</span>
          </div>
          <span className="text-lg font-semibold">{formatCurrency(entry.amount_dkk)}</span>
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>Dato</span>
          </div>
          <span>{format(new Date(entry.income_date), "d. MMM yyyy", { locale: da })}</span>
        </div>

        {entry.due_date && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Forfaldsdato</span>
            <span>{format(new Date(entry.due_date), "d. MMM yyyy", { locale: da })}</span>
          </div>
        )}

        {entry.paid_date && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Betalt</span>
            <span className="text-green-600">
              {format(new Date(entry.paid_date), "d. MMM yyyy", { locale: da })}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
