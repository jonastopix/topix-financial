import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2 } from 'lucide-react';

interface CompanySelectorProps {
  fullWidth?: boolean;
}

const CompanySelector = ({ fullWidth = false }: CompanySelectorProps) => {
  const { isAdmin, hasAdminAccess, activeRole, selectedCompanyId, setSelectedCompanyId } = useRole();

  const { data: companies } = useQuery({
    queryKey: ['active-companies'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return data;
    },
    enabled: isAdmin || (hasAdminAccess && activeRole === 'founder'),
  });

  // Show selector if user is active admin OR if they have admin access and are in founder view
  const shouldShow = isAdmin || (hasAdminAccess && activeRole === 'founder');
  
  if (!shouldShow) return null;

  return (
    <div className={`flex items-center ${fullWidth ? 'w-full' : 'gap-1 sm:gap-2'}`}>
      {!fullWidth && <Building2 className="h-4 w-4 text-muted-foreground hidden sm:block" />}
      <Select
        value={selectedCompanyId || 'all'}
        onValueChange={(value) => setSelectedCompanyId(value === 'all' ? null : value)}
      >
        <SelectTrigger className={fullWidth ? 'w-full h-11' : 'w-[140px] sm:w-[180px]'}>
          <SelectValue placeholder="Vælg selskab" />
        </SelectTrigger>
        <SelectContent className="z-[100] bg-popover">
          <SelectItem value="all">Alle selskaber</SelectItem>
          {companies?.map((company) => (
            <SelectItem key={company.id} value={company.id}>
              {company.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};

export default CompanySelector;