import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Pencil, Trash2 } from 'lucide-react';
import { format } from 'date-fns';

interface Fund {
  id: string;
  name: string;
  cvr: string;
  inception_date?: string;
  target_size_dkk?: number;
}

interface FundsListProps {
  funds: Fund[];
  onEdit: (fund: Fund) => void;
  onDelete: (fundId: string) => void;
}

export function FundsList({ funds, onEdit, onDelete }: FundsListProps) {
  const formatCurrency = (amount?: number) => {
    if (!amount) return '-';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="overflow-x-auto w-full max-w-full">
      <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Navn</TableHead>
          <TableHead>CVR Nr.</TableHead>
          <TableHead>Stiftelsesdato</TableHead>
          <TableHead className="text-right">Target Størrelse</TableHead>
          <TableHead className="text-right">Handlinger</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {funds.length === 0 ? (
          <TableRow>
            <TableCell colSpan={5} className="text-center text-muted-foreground">
              Ingen fonde oprettet endnu
            </TableCell>
          </TableRow>
        ) : (
          funds.map((fund) => (
            <TableRow key={fund.id}>
              <TableCell className="font-medium">{fund.name}</TableCell>
              <TableCell>{fund.cvr}</TableCell>
              <TableCell>
                {fund.inception_date ? format(new Date(fund.inception_date), 'dd/MM/yyyy') : '-'}
              </TableCell>
              <TableCell className="text-right">{formatCurrency(fund.target_size_dkk)}</TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(fund)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDelete(fund.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
    </div>
  );
}
