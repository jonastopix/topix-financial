import { useMemo } from 'react';
import { AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { DDCategoryItem } from './DDCategoryItem';
import { DDDocumentCategory, DDCategoryProgress, DDDocument } from '@/hooks/useDueDiligence';
import { CheckCircle2, Circle, Clock, XCircle } from 'lucide-react';

interface DDCategoryAccordionProps {
  caseId: string;
  mainCategory: DDDocumentCategory;
  subcategories: DDDocumentCategory[];
  categoryProgress: DDCategoryProgress[];
  documents: DDDocument[];
}

export function DDCategoryAccordion({
  caseId,
  mainCategory,
  subcategories,
  categoryProgress,
  documents,
}: DDCategoryAccordionProps) {
  // Calculate progress for this main category
  const progress = useMemo(() => {
    const total = subcategories.length;
    const completed = subcategories.filter(sub => {
      const prog = categoryProgress.find(p => p.category_id === sub.id);
      return prog?.status === 'completed';
    }).length;
    
    return total > 0 ? Math.round((completed / total) * 100) : 0;
  }, [subcategories, categoryProgress]);

  const getStatusIcon = () => {
    if (progress === 100) {
      return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    } else if (progress > 0) {
      return <Clock className="h-5 w-5 text-yellow-500" />;
    } else {
      return <Circle className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStatusBadge = () => {
    if (progress === 100) {
      return <Badge variant="default" className="bg-green-500">Færdig</Badge>;
    } else if (progress > 0) {
      return <Badge variant="secondary">I gang</Badge>;
    } else {
      return <Badge variant="outline">Ikke startet</Badge>;
    }
  };

  return (
    <AccordionItem value={mainCategory.id} className="border rounded-lg px-4">
      <AccordionTrigger className="hover:no-underline">
        <div className="flex items-center justify-between w-full pr-4">
          <div className="flex items-center gap-3">
            {getStatusIcon()}
            <div className="text-left">
              <p className="font-medium">{mainCategory.category_code} - {mainCategory.category_name}</p>
              {mainCategory.description && (
                <p className="text-sm text-muted-foreground">{mainCategory.description}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3">
            {getStatusBadge()}
            <div className="flex items-center gap-2 min-w-[120px]">
              <Progress value={progress} className="h-2 w-full" />
              <span className="text-sm font-medium text-muted-foreground whitespace-nowrap">{progress}%</span>
            </div>
          </div>
        </div>
      </AccordionTrigger>
      <AccordionContent>
        <div className="space-y-3 pt-4">
          {subcategories.length > 0 ? (
            subcategories.map(subcategory => {
              const prog = categoryProgress.find(p => p.category_id === subcategory.id);
              const catDocs = documents.filter(d => d.category_id === subcategory.id);
              
              return (
                <DDCategoryItem
                  key={subcategory.id}
                  caseId={caseId}
                  category={subcategory}
                  progress={prog}
                  documents={catDocs}
                />
              );
            })
          ) : mainCategory.category_code === '01' ? (
            <div className="bg-muted/50 rounded-lg p-6 space-y-4">
              <h4 className="font-semibold text-lg">Velkommen til datarummet</h4>
              <p className="text-sm text-muted-foreground">
                Her gennemgår vi due diligence processen for dit selskab. 
                Følg disse trin for at komme i gang:
              </p>
              <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
                <li>Gennemgå de forskellige dokumentkategorier nedenfor</li>
                <li>Upload de nødvendige dokumenter under hver kategori</li>
                <li>Marker kategorien som "Færdig" når alle dokumenter er uploadet</li>
                <li>Kontakt MOLA-teamet hvis du har spørgsmål</li>
              </ol>
              <p className="text-sm text-muted-foreground">
                Dokumenter markeret som påkrævede skal uploades for at 
                fuldføre due diligence processen.
              </p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Ingen underkategorier tilgængelige
            </p>
          )}
        </div>
      </AccordionContent>
    </AccordionItem>
  );
}
