import { Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

export const PasswordPolicyTooltip = () => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            className="inline-flex items-center justify-center rounded-full hover:bg-muted p-1 transition-colors"
            aria-label="Password politik information"
          >
            <Info className="h-4 w-4 text-muted-foreground" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="right" className="max-w-xs">
          <div className="space-y-2">
            <p className="font-semibold">Password Krav</p>
            <ul className="text-sm space-y-1 list-disc list-inside">
              <li>Mindst 8 tegn langt</li>
              <li>Mindst ét stort bogstav (A-Z)</li>
              <li>Mindst ét lille bogstav (a-z)</li>
              <li>Mindst ét tal (0-9)</li>
              <li>Mindst ét specialtegn (@$!%*?&#)</li>
              <li>Ikke et almindeligt password</li>
              <li>Ikke fundet i kendte data-læk</li>
            </ul>
            <p className="text-xs text-muted-foreground mt-2">
              Vi bruger Have I Been Pwned API til at tjekke om dit password er blevet eksponeret i data-læk. Dit password bliver aldrig sendt til tjenesten - kun en sikker hash.
            </p>
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};
