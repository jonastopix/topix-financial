import { Building2, Mail, Phone, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Customer {
  id: string;
  name: string;
  cvr?: string | null;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
  city?: string | null;
  zipcode?: string | null;
  is_active?: boolean | null;
  company_type?: string | null;
}

interface CustomerCardProps {
  customer: Customer;
}

export function CustomerCard({ customer }: CustomerCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-start justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            {customer.name}
          </CardTitle>
          <Badge variant={customer.is_active ? "default" : "secondary"}>
            {customer.is_active ? "Aktiv" : "Inaktiv"}
          </Badge>
        </div>
        {customer.cvr && (
          <p className="text-sm text-muted-foreground">CVR: {customer.cvr}</p>
        )}
      </CardHeader>
      <CardContent className="space-y-2">
        {customer.email && (
          <div className="flex items-center gap-2 text-sm">
            <Mail className="h-4 w-4 text-muted-foreground" />
            <span>{customer.email}</span>
          </div>
        )}
        {customer.phone && (
          <div className="flex items-center gap-2 text-sm">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span>{customer.phone}</span>
          </div>
        )}
        {(customer.address || customer.city) && (
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span>
              {customer.address}
              {customer.city && `, ${customer.zipcode} ${customer.city}`}
            </span>
          </div>
        )}
        {customer.company_type && (
          <Badge variant="outline" className="mt-2">
            {customer.company_type}
          </Badge>
        )}
      </CardContent>
    </Card>
  );
}
