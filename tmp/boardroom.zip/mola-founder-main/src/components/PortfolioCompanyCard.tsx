import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, ChevronRight, DollarSign, Heart, TrendingUp } from 'lucide-react';
import { getHealthStatus } from '@/lib/metricsCalculations';

interface PortfolioCompanyCardProps {
  company: {
    id: string;
    name: string;
    industry: string;
    financial: number;
    growth: number;
    transparency: number;
    relationship: number;
    healthIndex: number;
    latestValuation: number | null;
  };
  rank: number;
}

const PortfolioCompanyCard = ({ company, rank }: PortfolioCompanyCardProps) => {
  const navigate = useNavigate();
  const healthStatus = getHealthStatus(company.healthIndex);

  const formatCurrency = (amount: number) => {
    if (amount >= 1000000) {
      return `${(amount / 1000000).toFixed(1)}M DKK`;
    }
    return new Intl.NumberFormat('da-DK', { 
      style: 'currency', 
      currency: 'DKK', 
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getRankBadge = () => {
    if (rank === 1) return <Badge className="bg-yellow-500 text-black">🥇 #1</Badge>;
    if (rank === 2) return <Badge className="bg-gray-400 text-black">🥈 #2</Badge>;
    if (rank === 3) return <Badge className="bg-orange-600">🥉 #3</Badge>;
    return <Badge variant="outline">#{rank}</Badge>;
  };

  return (
    <Card 
      className="p-4 hover:bg-muted/50 transition-colors tap-safe cursor-pointer"
      onClick={() => navigate(`/company/${company.id}`)}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-3 min-w-0">
          {getRankBadge()}
          <div className="min-w-0">
            <h3 className="font-semibold text-base truncate">{company.name}</h3>
            {company.industry === 'ecommerce' && (
              <Badge variant="outline" className="text-xs mt-1">E-com</Badge>
            )}
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground flex-shrink-0" />
      </div>

      {/* Health Index */}
      <div className="flex items-center justify-between mb-4 p-3 rounded-lg bg-muted/50">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4" />
          <span className="text-sm font-medium">Health Index</span>
        </div>
        <Badge className={`${healthStatus.bgColor} ${healthStatus.color} border-0`}>
          {Math.round(company.healthIndex)}
        </Badge>
      </div>

      {/* Scores Grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-green-500" />
          <span className="text-sm text-muted-foreground">Financial</span>
          <span className={`font-bold ml-auto ${getScoreColor(company.financial)}`}>
            {Math.round(company.financial)}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-blue-500" />
          <span className="text-sm text-muted-foreground">Growth</span>
          <span className={`font-bold ml-auto ${getScoreColor(company.growth)}`}>
            {Math.round(company.growth)}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Heart className="h-4 w-4 text-pink-500" />
          <span className="text-sm text-muted-foreground">Relationship</span>
          <span className={`font-bold ml-auto ${getScoreColor(company.relationship)}`}>
            {Math.round(company.relationship)}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <DollarSign className="h-4 w-4 text-primary" />
          <span className="text-sm text-muted-foreground">Valuation</span>
          <span className="font-medium ml-auto text-sm">
            {company.latestValuation ? formatCurrency(company.latestValuation) : '-'}
          </span>
        </div>
      </div>
    </Card>
  );
};

export default PortfolioCompanyCard;
