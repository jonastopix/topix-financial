import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Car } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { MileageQuickSheet } from './MileageQuickSheet';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';

export function MileageQuickFAB() {
  const [open, setOpen] = useState(false);
  const isMobile = useIsMobile();
  const location = useLocation();
  const { user } = useAuth();
  const { activeRole } = useRole();
  
  // Hide on company pages (CompanyActivityFAB takes over)
  const isCompanyPage = /\/company\/[a-f0-9-]+/i.test(location.pathname);
  
  // Only show on mobile for authenticated users with admin/owner/fund_partner roles, and not on company pages
  const allowedRoles = ['owner', 'mola_admin', 'fund_partner'];
  if (!isMobile || !user || !allowedRoles.includes(activeRole) || isCompanyPage) {
    return null;
  }
  
  return (
    <>
      <Button
        onClick={() => setOpen(true)}
        size={isMobile ? "lg" : "default"}
        className={`
          fixed z-50 shadow-lg
          ${isMobile 
            ? 'bottom-20 right-4 h-14 w-14 rounded-full p-0' 
            : 'bottom-6 right-6 gap-2'
          }
          bg-primary hover:bg-primary/90
        `}
      >
        <Car className={isMobile ? 'h-6 w-6' : 'h-5 w-5'} />
        {!isMobile && <span>Registrer kørsel</span>}
      </Button>
      
      <MileageQuickSheet open={open} onOpenChange={setOpen} />
    </>
  );
}
