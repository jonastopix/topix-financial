import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Drawer, DrawerContent, DrawerTrigger } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { QuickTaskSheet } from './QuickTaskSheet';

export const QuickTaskFAB = () => {
  const isMobile = useIsMobile();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  
  // Hide on company pages (CompanyActivityFAB takes over)
  const isCompanyPage = /\/company\/[a-f0-9-]+/i.test(location.pathname);
  
  // Only show on mobile and not on company pages
  if (!isMobile || isCompanyPage) return null;
  
  return (
    <Drawer open={open} onOpenChange={setOpen}>
      <DrawerTrigger asChild>
        <Button
          size="icon"
          className="fixed bottom-20 right-4 h-14 w-14 rounded-full shadow-lg z-40 bg-primary hover:bg-primary/90"
          aria-label="Opret hurtig opgave"
        >
          <Plus className="h-7 w-7" />
        </Button>
      </DrawerTrigger>
      <DrawerContent>
        <QuickTaskSheet onSuccess={() => setOpen(false)} />
      </DrawerContent>
    </Drawer>
  );
};
