import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useTaskManagement, CreateTaskInput } from '@/hooks/useTaskManagement';
import { useRole } from '@/contexts/RoleContext';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, Repeat, Lock, Globe } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Switch } from '@/components/ui/switch';

interface CreateTaskDialogProps {
  companyId?: string;
  trigger?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export const CreateTaskDialog = ({ companyId, trigger, open: controlledOpen, onOpenChange }: CreateTaskDialogProps) => {
  const [internalOpen, setInternalOpen] = useState(false);
  
  // Support both controlled and uncontrolled modes
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const setOpen = isControlled ? (onOpenChange ?? (() => {})) : setInternalOpen;
  const [formData, setFormData] = useState<CreateTaskInput>({
    title: '',
    description: '',
    status: 'todo',
    priority: 'medium',
    due_date: '',
    assigned_to: '',
    company_id: companyId || '',
    is_private: true,
    is_recurring: false,
    recurrence_pattern: 'weekly',
    recurrence_interval: 1,
    recurrence_day_of_week: 1,
    recurrence_day_of_month: 1,
  });
  const [endCondition, setEndCondition] = useState<'never' | 'end_date' | 'count'>('never');

  const { createTask } = useTaskManagement();
  const { isAdmin, activeRole, selectedCompanyId } = useRole();
  
  // Founders, fund_partners and admins can assign tasks
  const canAssignTasks = isAdmin || activeRole === 'founder' || activeRole === 'fund_partner';

  const { data: companies } = useQuery({
    queryKey: ['companies-for-tasks'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
    enabled: isAdmin && !companyId,
  });

  const { data: users } = useQuery({
    queryKey: ['users-for-tasks', activeRole, selectedCompanyId],
    queryFn: async () => {
      let query = supabase
        .from('profiles')
        .select('id, full_name, company_name, company_id')
        .eq('is_active', true)
        .order('full_name');
      
      // For founders: Filter to only show users from their company
      if (activeRole === 'founder' && selectedCompanyId) {
        query = query.eq('company_id', selectedCompanyId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    enabled: canAssignTasks,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const submitData: CreateTaskInput = {
      ...formData,
      company_id: formData.company_id || undefined,
      assigned_to: formData.assigned_to || undefined,
      due_date: formData.due_date || undefined,
      description: formData.description || undefined,
    };

    // Add recurrence data if enabled
    if (formData.is_recurring) {
      submitData.next_occurrence_date = formData.due_date || new Date().toISOString().split('T')[0];
      if (endCondition === 'never') {
        submitData.recurrence_end_date = undefined;
        submitData.recurrence_count = undefined;
      }
      if (formData.recurrence_pattern !== 'weekly') {
        submitData.recurrence_day_of_week = undefined;
      }
      if (formData.recurrence_pattern !== 'monthly') {
        submitData.recurrence_day_of_month = undefined;
      }
    } else {
      // Clear all recurrence fields
      delete submitData.recurrence_pattern;
      delete submitData.recurrence_interval;
      delete submitData.recurrence_end_date;
      delete submitData.recurrence_count;
      delete submitData.recurrence_day_of_week;
      delete submitData.recurrence_day_of_month;
      delete submitData.next_occurrence_date;
    }

    createTask.mutate(submitData, {
      onSuccess: () => {
        setOpen(false);
        setFormData({
          title: '',
          description: '',
          status: 'todo',
          priority: 'medium',
          due_date: '',
          assigned_to: '',
          company_id: companyId || '',
          is_private: true,
          is_recurring: false,
          recurrence_pattern: 'weekly',
          recurrence_interval: 1,
          recurrence_day_of_week: 1,
          recurrence_day_of_month: 1,
        });
        setEndCondition('never');
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      {controlledOpen === undefined && (
        <DialogTrigger asChild>
          {trigger !== undefined ? trigger : (
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Ny opgave
            </Button>
          )}
        </DialogTrigger>
      )}
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Opret ny opgave</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Titel *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beskrivelse</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          {isAdmin && !companyId && (
            <div className="space-y-2">
              <Label htmlFor="company">Selskab</Label>
              <Select
                value={formData.company_id}
                onValueChange={(value) => setFormData({ ...formData, company_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Vælg selskab (valgfrit)" />
                </SelectTrigger>
                <SelectContent>
                  {companies?.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {canAssignTasks && (
            <div className="space-y-2">
              <Label htmlFor="assigned_to">Tildel til</Label>
              <Select
                value={formData.assigned_to}
                onValueChange={(value) => setFormData({ ...formData, assigned_to: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Vælg bruger (valgfrit)" />
                </SelectTrigger>
                <SelectContent>
                  {users?.map((user) => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.full_name || 'Ingen navn'} {user.company_name && `(${user.company_name})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Privacy Toggle */}
          <div className="flex items-center justify-between rounded-lg border p-3 bg-muted/30">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                {formData.is_private ? (
                  <Lock className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <Globe className="h-4 w-4 text-muted-foreground" />
                )}
                <Label htmlFor="is_private" className="font-medium">
                  {formData.is_private ? 'Privat opgave' : 'Offentlig opgave'}
                </Label>
              </div>
              <p className="text-xs text-muted-foreground">
                {formData.is_private 
                  ? 'Kun du og den ansvarlige kan se denne opgave' 
                  : 'Alle i virksomheden kan se denne opgave'}
              </p>
            </div>
            <Switch
              id="is_private"
              checked={!formData.is_private}
              onCheckedChange={(checked) => setFormData({ ...formData, is_private: !checked })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="priority">Prioritet</Label>
              <Select
                value={formData.priority}
                onValueChange={(value: any) => setFormData({ ...formData, priority: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Lav</SelectItem>
                  <SelectItem value="medium">Mellem</SelectItem>
                  <SelectItem value="high">Høj</SelectItem>
                  <SelectItem value="urgent">Akut</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="due_date">Deadline</Label>
              <Input
                id="due_date"
                type="date"
                value={formData.due_date}
                onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
              />
            </div>
          </div>

          {/* Recurring Task Section */}
          <div className="border-t pt-4 space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="is_recurring" 
                checked={formData.is_recurring}
                onCheckedChange={(checked) => setFormData({ ...formData, is_recurring: checked === true })}
              />
              <Label htmlFor="is_recurring" className="flex items-center gap-2 cursor-pointer">
                <Repeat className="h-4 w-4" />
                Gentag opgave
              </Label>
            </div>

            {formData.is_recurring && (
              <div className="space-y-4 pl-6 border-l-2 border-muted">
                <div className="space-y-2">
                  <Label htmlFor="recurrence_pattern">Gentagelse</Label>
                  <Select
                    value={formData.recurrence_pattern}
                    onValueChange={(value: any) => setFormData({ ...formData, recurrence_pattern: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Dagligt</SelectItem>
                      <SelectItem value="weekly">Ugentligt</SelectItem>
                      <SelectItem value="monthly">Månedligt</SelectItem>
                      <SelectItem value="yearly">Årligt</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="recurrence_interval">Gentag hver</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="recurrence_interval"
                      type="number"
                      min="1"
                      max="365"
                      value={formData.recurrence_interval}
                      onChange={(e) => setFormData({ ...formData, recurrence_interval: parseInt(e.target.value) })}
                      className="w-20"
                    />
                    <span className="text-sm text-muted-foreground">
                      {formData.recurrence_pattern === 'daily' && 'dag'}
                      {formData.recurrence_pattern === 'weekly' && 'uge'}
                      {formData.recurrence_pattern === 'monthly' && 'måned'}
                      {formData.recurrence_pattern === 'yearly' && 'år'}
                    </span>
                  </div>
                </div>

                {formData.recurrence_pattern === 'weekly' && (
                  <div className="space-y-2">
                    <Label htmlFor="day_of_week">Ugedag</Label>
                    <Select
                      value={formData.recurrence_day_of_week?.toString()}
                      onValueChange={(value) => setFormData({ ...formData, recurrence_day_of_week: parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Mandag</SelectItem>
                        <SelectItem value="2">Tirsdag</SelectItem>
                        <SelectItem value="3">Onsdag</SelectItem>
                        <SelectItem value="4">Torsdag</SelectItem>
                        <SelectItem value="5">Fredag</SelectItem>
                        <SelectItem value="6">Lørdag</SelectItem>
                        <SelectItem value="0">Søndag</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {formData.recurrence_pattern === 'monthly' && (
                  <div className="space-y-2">
                    <Label htmlFor="day_of_month">Dag i måneden</Label>
                    <Input
                      id="day_of_month"
                      type="number"
                      min="1"
                      max="31"
                      value={formData.recurrence_day_of_month}
                      onChange={(e) => setFormData({ ...formData, recurrence_day_of_month: parseInt(e.target.value) })}
                    />
                  </div>
                )}

                <div className="space-y-3">
                  <Label>Slutbetingelse</Label>
                  <RadioGroup value={endCondition} onValueChange={(value: any) => setEndCondition(value)}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="never" id="never" />
                      <Label htmlFor="never" className="font-normal cursor-pointer">
                        Gentag for evigt
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="end_date" id="end_date" />
                      <Label htmlFor="end_date" className="font-normal cursor-pointer">
                        Slut på dato
                      </Label>
                    </div>
                    {endCondition === 'end_date' && (
                      <Input
                        type="date"
                        value={formData.recurrence_end_date}
                        onChange={(e) => setFormData({ ...formData, recurrence_end_date: e.target.value })}
                        className="ml-6"
                      />
                    )}
                    
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="count" id="count" />
                      <Label htmlFor="count" className="font-normal cursor-pointer">
                        Efter antal gentagelser
                      </Label>
                    </div>
                    {endCondition === 'count' && (
                      <Input
                        type="number"
                        min="1"
                        value={formData.recurrence_count}
                        onChange={(e) => setFormData({ ...formData, recurrence_count: parseInt(e.target.value) })}
                        className="ml-6 w-32"
                      />
                    )}
                  </RadioGroup>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={createTask.isPending}>
              {createTask.isPending ? 'Opretter...' : 'Opret opgave'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateTaskDialog;
