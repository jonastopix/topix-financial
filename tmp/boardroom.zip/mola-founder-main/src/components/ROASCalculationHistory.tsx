import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Trash2, TrendingUp, History, FileText } from 'lucide-react';
import { useROASCalculations, ROASCalculation } from '@/hooks/useROASCalculations';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

interface ROASCalculationHistoryProps {
  companyId: string | undefined;
}

export function ROASCalculationHistory({ companyId }: ROASCalculationHistoryProps) {
  const { calculations, isLoading, deleteCalculation } = useROASCalculations(companyId);

  const chartData = useMemo(() => {
    if (!calculations?.length) return [];
    
    return [...calculations]
      .reverse()
      .map((calc) => ({
        date: format(new Date(calc.created_at), 'dd/MM', { locale: da }),
        breakevenROAS: Number(calc.breakeven_roas),
        contributionMargin: Number(calc.contribution_margin),
      }));
  }, [calculations]);

  const handleDelete = (id: string) => {
    deleteCalculation.mutate(id);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-[300px] w-full" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  if (!calculations?.length) {
    return (
      <Card className="glass-card">
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <History className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Ingen gemte beregninger</h3>
          <p className="text-muted-foreground max-w-sm">
            Gem dine første ROAS-beregninger for at se dem her og følge udviklingen over tid.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Trend Chart */}
      {chartData.length > 1 && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Breakeven ROAS Udvikling
            </CardTitle>
            <CardDescription>
              Se hvordan din breakeven ROAS har udviklet sig over tid
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorRoas" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="date" 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    className="text-xs fill-muted-foreground"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => value.toFixed(1)}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                    formatter={(value: number) => [value.toFixed(2), 'Breakeven ROAS']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="breakevenROAS" 
                    stroke="hsl(var(--primary))" 
                    fill="url(#colorRoas)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* History Table */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Gemte beregninger
          </CardTitle>
          <CardDescription>
            {calculations.length} beregning{calculations.length !== 1 ? 'er' : ''} gemt
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Dato</TableHead>
                  <TableHead className="text-right">AOV</TableHead>
                  <TableHead className="text-right">Vareforbrug</TableHead>
                  <TableHead className="text-right">Contribution Margin</TableHead>
                  <TableHead className="text-right">Breakeven ROAS</TableHead>
                  <TableHead>Noter</TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {calculations.map((calc) => (
                  <CalculationRow 
                    key={calc.id} 
                    calculation={calc} 
                    onDelete={handleDelete}
                    isDeleting={deleteCalculation.isPending}
                  />
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface CalculationRowProps {
  calculation: ROASCalculation;
  onDelete: (id: string) => void;
  isDeleting: boolean;
}

function CalculationRow({ calculation, onDelete, isDeleting }: CalculationRowProps) {
  const isPositive = Number(calculation.contribution_margin) > 0;
  
  const cogsDisplay = calculation.input_mode === 'cogs'
    ? `${Number(calculation.cost_of_goods).toFixed(0)} kr.`
    : `${Number(calculation.margin_percentage).toFixed(0)}% margin`;

  return (
    <TableRow>
      <TableCell className="font-medium">
        {format(new Date(calculation.created_at), 'd. MMM yyyy HH:mm', { locale: da })}
      </TableCell>
      <TableCell className="text-right tabular-nums">
        {Number(calculation.average_order_value).toFixed(0)} kr.
      </TableCell>
      <TableCell className="text-right tabular-nums">
        {cogsDisplay}
      </TableCell>
      <TableCell className={cn(
        "text-right tabular-nums font-medium",
        isPositive ? "text-primary" : "text-destructive"
      )}>
        {Number(calculation.contribution_margin).toFixed(2)} kr.
      </TableCell>
      <TableCell className="text-right">
        <Badge variant={isPositive ? "default" : "destructive"}>
          {Number(calculation.breakeven_roas).toFixed(2)}
        </Badge>
      </TableCell>
      <TableCell className="max-w-[200px] truncate text-muted-foreground">
        {calculation.notes || '—'}
      </TableCell>
      <TableCell>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Slet beregning?</AlertDialogTitle>
              <AlertDialogDescription>
                Er du sikker på, at du vil slette denne beregning? Denne handling kan ikke fortrydes.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuller</AlertDialogCancel>
              <AlertDialogAction 
                onClick={() => onDelete(calculation.id)}
                disabled={isDeleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Slet
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </TableCell>
    </TableRow>
  );
}
