import { useState } from 'react';
import { Search, Filter, ArrowUpDown, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import CreateTaskDialog from '@/components/CreateTaskDialog';

interface TasksToolbarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  statusFilter: string;
  onStatusFilterChange: (status: string) => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
}

const TasksToolbar = ({
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  sortBy,
  onSortChange,
}: TasksToolbarProps) => {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <CreateTaskDialog />

      {/* Search */}
      <div className="relative flex-1 min-w-[180px] max-w-[280px]">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Søg opgaver..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9 h-9"
        />
      </div>

      {/* Status Filter */}
      <Select value={statusFilter} onValueChange={onStatusFilterChange}>
        <SelectTrigger className="w-[140px] h-9">
          <Filter className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent className="bg-popover">
          <SelectItem value="open">Åbne opgaver</SelectItem>
          <SelectItem value="delegated">Uddelegerede</SelectItem>
          <SelectItem value="all">Alle opgaver</SelectItem>
          <SelectItem value="todo">Afventer</SelectItem>
          <SelectItem value="in_progress">I gang</SelectItem>
          <SelectItem value="done">Færdige</SelectItem>
        </SelectContent>
      </Select>

      {/* Sort */}
      <Select value={sortBy} onValueChange={onSortChange}>
        <SelectTrigger className="w-[140px] h-9">
          <ArrowUpDown className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
          <SelectValue placeholder="Sortér" />
        </SelectTrigger>
        <SelectContent className="bg-popover">
          <SelectItem value="due_date">Deadline</SelectItem>
          <SelectItem value="priority">Prioritet</SelectItem>
          <SelectItem value="created_at">Oprettet</SelectItem>
          <SelectItem value="title">Titel</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};

export default TasksToolbar;
