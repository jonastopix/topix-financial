import { NavLink } from '@/components/NavLink';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from '@/components/ui/sidebar';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { ClipboardList, Home, LifeBuoy, LogOut, Settings, Target, UserCircle } from 'lucide-react';

export function AppSidebar() {
  const { user, signOut } = useAuth();
  const { isAdmin } = useRole();
  const { open } = useSidebar();
  const isMobile = useIsMobile();

  const initials = (user?.email || 'U')
    .split('@')[0]
    .split(/[\s._-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');

  return (
    <Sidebar collapsible="icon" className={cn('transition-all duration-300', open ? 'w-64' : 'w-14')}>
      <SidebarHeader className="border-b border-border/50 p-4">
        <div className="flex items-center justify-between gap-2">
          <div className={cn('font-semibold tracking-tight', !open && 'opacity-0 w-0')}>The Boardroom</div>
          <SidebarTrigger />
        </div>
      </SidebarHeader>

      <SidebarContent className="px-2">
        <SidebarGroup>
          <SidebarGroupLabel>Overblik</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/" end activeClassName="bg-primary text-primary-foreground">
                    <Home className="h-4 w-4" />
                    {open && <span>Dashboard</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/monthly-report" activeClassName="bg-primary text-primary-foreground">
                    <ClipboardList className="h-4 w-4" />
                    {open && <span>Rapportering</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/milestones" activeClassName="bg-primary text-primary-foreground">
                    <Target className="h-4 w-4" />
                    {open && <span>Milestones</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>

              {isAdmin && (
                <SidebarMenuItem>
                  <SidebarMenuButton asChild>
                    <NavLink to="/admin/reporting" activeClassName="bg-primary text-primary-foreground">
                      <Settings className="h-4 w-4" />
                      {open && <span>Admin: Rapport-overblik</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Hjælp</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/support" activeClassName="bg-primary text-primary-foreground">
                    <LifeBuoy className="h-4 w-4" />
                    {open && <span>Support</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <NavLink to="/profile" activeClassName="bg-primary text-primary-foreground">
                    <UserCircle className="h-4 w-4" />
                    {open && <span>Profil</span>}
                  </NavLink>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-border/50 p-4">
        <div className={cn('flex items-center gap-3', !open && 'justify-center')}>
          <Avatar className="h-8 w-8">
            <AvatarFallback>{initials || 'U'}</AvatarFallback>
          </Avatar>

          {open && (
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{user?.email}</div>
              <div className="text-xs text-muted-foreground truncate">
                {isAdmin ? 'Admin' : 'Medlem'}
              </div>
            </div>
          )}

          <Button
            variant="ghost"
            size={isMobile || !open ? 'icon' : 'sm'}
            onClick={signOut}
            className={cn(!open && 'h-9 w-9 p-0')}
          >
            <LogOut className="h-4 w-4" />
            {open && !isMobile && <span className="ml-2">Log ud</span>}
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
