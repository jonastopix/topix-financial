import { useState } from 'react';
import { useCompanyContacts } from '@/hooks/useCompanyContacts';
import { useRole } from '@/contexts/RoleContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { UserPlus, Users } from 'lucide-react';
import AddContactDialog from './AddContactDialog';
import ContactCard from './ContactCard';

interface CompanyContactsViewProps {
  companyId: string;
}

const CompanyContactsView = ({ companyId }: CompanyContactsViewProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<any>(null);
  const { contacts, isLoading, deleteContact } = useCompanyContacts(companyId);
  const { isAdmin, activeRole } = useRole();
  const canManageContacts = isAdmin || activeRole === 'fund_partner';

  const handleEdit = (contact: any) => {
    setEditingContact(contact);
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
    setEditingContact(null);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Kontakter</h2>
          <p className="text-muted-foreground">
            {contacts?.length || 0} kontakter registreret
          </p>
        </div>
        {canManageContacts && (
          <Button onClick={() => setDialogOpen(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            Tilføj Kontakt
          </Button>
        )}
      </div>

      {!contacts || contacts.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Ingen kontakter endnu</p>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Tilføj CEO, CFO, eller andre nøglepersoner i selskabet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {contacts.map((contact) => (
            <ContactCard
              key={contact.id}
              contact={contact}
              onEdit={canManageContacts ? () => handleEdit(contact) : undefined}
              onDelete={
                canManageContacts
                  ? () => deleteContact.mutate(contact.id)
                  : undefined
              }
            />
          ))}
        </div>
      )}

      <AddContactDialog
        open={dialogOpen}
        onOpenChange={handleCloseDialog}
        companyId={companyId}
        editingContact={editingContact}
      />
    </div>
  );
};

export default CompanyContactsView;
