import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { usePortfolioPendingPR, PendingArticleWithCompany } from '@/hooks/usePortfolioPendingPR';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  Check,
  X,
  ExternalLink,
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  CheckCheck,
  XCircle,
} from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const getSentimentBadge = (sentiment: string | null) => {
  switch (sentiment) {
    case 'positive':
      return (
        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
          <TrendingUp className="h-3 w-3 mr-1" />
          Positiv
        </Badge>
      );
    case 'negative':
      return (
        <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
          <TrendingDown className="h-3 w-3 mr-1" />
          Negativ
        </Badge>
      );
    case 'neutral':
      return (
        <Badge className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200">
          <Minus className="h-3 w-3 mr-1" />
          Neutral
        </Badge>
      );
    default:
      return null;
  }
};

const formatDate = (dateString: string | null) => {
  if (!dateString) return '-';
  try {
    return new Date(dateString).toLocaleDateString('da-DK', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return '-';
  }
};

interface ArticleRowProps {
  article: PendingArticleWithCompany;
  onApprove: (id: string) => void;
  onDismiss: (id: string) => void;
  showCompany?: boolean;
}

function ArticleRow({ article, onApprove, onDismiss, showCompany = true }: ArticleRowProps) {
  const navigate = useNavigate();

  return (
    <TableRow>
      {showCompany && (
        <TableCell>
          <Button
            variant="link"
            className="p-0 h-auto font-medium"
            onClick={() => navigate(`/company/${article.company_id}?tab=pr`)}
          >
            {article.company_name}
          </Button>
        </TableCell>
      )}
      <TableCell className="max-w-xs">
        <div className="space-y-1">
          <p className="font-medium truncate" title={article.title}>
            {article.title}
          </p>
          {article.snippet && (
            <p className="text-xs text-muted-foreground truncate" title={article.snippet}>
              {article.snippet}
            </p>
          )}
        </div>
      </TableCell>
      <TableCell>{article.source || '-'}</TableCell>
      <TableCell>{getSentimentBadge(article.sentiment)}</TableCell>
      <TableCell className="text-muted-foreground text-sm">
        {formatDate(article.published_at)}
      </TableCell>
      <TableCell>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
            onClick={() => onApprove(article.id)}
            title="Godkend"
          >
            <Check className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
            onClick={() => onDismiss(article.id)}
            title="Afvis"
          >
            <X className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => window.open(article.url, '_blank')}
            title="Åbn artikel"
          >
            <ExternalLink className="h-4 w-4" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

export default function PendingPRSection() {
  const {
    pendingArticles,
    articlesByCompany,
    totalPending,
    isLoading,
    approve,
    dismiss,
    approveAll,
    dismissAll,
    isApprovingAll,
    isDismissingAll,
  } = usePortfolioPendingPR();

  const navigate = useNavigate();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-64" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (totalPending === 0) {
    return (
      <Card className="border-dashed">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto mb-2 h-12 w-12 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
            <Check className="h-6 w-6 text-green-600 dark:text-green-400" />
          </div>
          <CardTitle className="text-lg">Ingen ventende artikler</CardTitle>
          <CardDescription>
            Alle artikler er blevet gennemgået. Nye artikler vil dukke op her når de findes.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  const companyIds = Object.keys(articlesByCompany);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center">
              <Clock className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            </div>
            <div>
              <CardTitle className="flex items-center gap-2">
                Ventende Artikler
                <Badge variant="secondary" className="ml-2">
                  {totalPending}
                </Badge>
              </CardTitle>
              <CardDescription>
                Artikler der afventer godkendelse på tværs af {companyIds.length} selskab{companyIds.length !== 1 ? 'er' : ''}
              </CardDescription>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => dismissAll()}
              disabled={isDismissingAll}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <XCircle className="h-4 w-4 mr-1" />
              Afvis alle
            </Button>
            <Button
              size="sm"
              onClick={() => approveAll()}
              disabled={isApprovingAll}
              className="bg-green-600 hover:bg-green-700"
            >
              <CheckCheck className="h-4 w-4 mr-1" />
              Godkend alle
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {companyIds.length === 1 ? (
          // Single company - show flat table
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Selskab</TableHead>
                <TableHead>Titel</TableHead>
                <TableHead>Kilde</TableHead>
                <TableHead>Sentiment</TableHead>
                <TableHead>Dato</TableHead>
                <TableHead className="text-right">Handlinger</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingArticles?.map((article) => (
                <ArticleRow
                  key={article.id}
                  article={article}
                  onApprove={approve}
                  onDismiss={dismiss}
                />
              ))}
            </TableBody>
          </Table>
        ) : (
          // Multiple companies - group by company
          <Accordion type="multiple" defaultValue={companyIds.slice(0, 3)} className="space-y-2">
            {companyIds.map((companyId) => {
              const { companyName, articles } = articlesByCompany[companyId];
              return (
                <AccordionItem key={companyId} value={companyId} className="border rounded-lg px-4">
                  <AccordionTrigger className="hover:no-underline py-3">
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{companyName}</span>
                      <Badge variant="secondary">{articles.length}</Badge>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Titel</TableHead>
                          <TableHead>Kilde</TableHead>
                          <TableHead>Sentiment</TableHead>
                          <TableHead>Dato</TableHead>
                          <TableHead className="text-right">Handlinger</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {articles.map((article) => (
                          <ArticleRow
                            key={article.id}
                            article={article}
                            onApprove={approve}
                            onDismiss={dismiss}
                            showCompany={false}
                          />
                        ))}
                      </TableBody>
                    </Table>
                    <div className="mt-3 flex justify-end">
                      <Button
                        variant="link"
                        size="sm"
                        onClick={() => navigate(`/company/${companyId}?tab=pr`)}
                      >
                        Gå til {companyName} PR
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}
          </Accordion>
        )}
      </CardContent>
    </Card>
  );
}
