import { useState } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Check, Circle, Clock, ChevronRight, AlertCircle } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Task } from '@/hooks/useTaskManagement';
import TaskCompletionCelebration from '@/components/TaskCompletionCelebration';

interface TaskMobileRowProps {
  task: Task;
  onToggleStatus: (task: Task) => void;
  onClick: (task: Task) => void;
}

const TaskMobileRow = ({ task, onToggleStatus, onClick }: TaskMobileRowProps) => {
  const [showCelebration, setShowCelebration] = useState(false);
  const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done';
  const isDueSoon = task.due_date && !isOverdue && 
    new Date(task.due_date) <= new Date(Date.now() + 2 * 24 * 60 * 60 * 1000) && 
    task.status !== 'done';

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/10 text-red-600 border-red-200';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-200';
      case 'medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-500/10 text-green-600 border-green-200';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = () => {
    switch (task.status) {
      case 'done': return <Check className="h-3.5 w-3.5 text-green-600" />;
      case 'in_progress': return <Clock className="h-3.5 w-3.5 text-blue-600" />;
      default: return <Circle className="h-3.5 w-3.5 text-muted-foreground" />;
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'Kritisk';
      case 'high': return 'Høj';
      case 'medium': return 'Medium';
      case 'low': return 'Lav';
      default: return priority;
    }
  };

  const handleToggle = () => {
    if (task.status !== 'done') {
      setShowCelebration(true);
    }
    onToggleStatus(task);
  };

  return (
    <div 
      className={cn(
        "flex items-center gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors cursor-pointer relative overflow-hidden",
        task.status === 'done' && "opacity-60"
      )}
      onClick={() => onClick(task)}
    >
      {/* Celebration animation */}
      <TaskCompletionCelebration 
        show={showCelebration}
        onComplete={() => setShowCelebration(false)}
      />
      
      <div onClick={(e) => e.stopPropagation()}>
        <Checkbox
          checked={task.status === 'done'}
          onCheckedChange={handleToggle}
          className={cn("h-5 w-5", showCelebration && "animate-celebrate-pop")}
        />
      </div>
      
      <div className="flex-1 min-w-0">
        <p className={cn(
          "font-medium truncate text-sm",
          task.status === 'done' && "line-through text-muted-foreground"
        )}>
          {task.title}
        </p>
        
        <div className="flex items-center gap-2 mt-1 flex-wrap">
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            {getStatusIcon()}
          </div>
          
          <Badge 
            variant="outline" 
            className={cn("text-[10px] px-1.5 py-0", getPriorityColor(task.priority))}
          >
            {getPriorityLabel(task.priority)}
          </Badge>
          
          {task.due_date && (
            <span className={cn(
              "text-xs flex items-center gap-1",
              isOverdue && "text-red-600 font-medium",
              isDueSoon && !isOverdue && "text-orange-600"
            )}>
              {isOverdue && <AlertCircle className="h-3 w-3" />}
              {format(new Date(task.due_date), 'd. MMM', { locale: da })}
            </span>
          )}
          
          {task.company?.name && (
            <span className="text-xs text-muted-foreground truncate max-w-[100px]">
              {task.company.name}
            </span>
          )}
        </div>
      </div>
      
      <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
    </div>
  );
};

export default TaskMobileRow;
