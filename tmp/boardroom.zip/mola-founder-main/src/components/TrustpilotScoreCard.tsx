import { useState } from 'react';
import { Star, RefreshCw, ExternalLink, ChevronDown, ChevronUp, Settings } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { TrustpilotTrendBadge } from './TrustpilotTrendBadge';
import { useTrustpilotScores, TrustpilotProfile } from '@/hooks/useTrustpilotScores';
import { ManageTrustpilotProfilesDialog } from './ManageTrustpilotProfilesDialog';
import { formatDistanceToNow } from 'date-fns';
import { da } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface TrustpilotScoreCardProps {
  companyId: string;
  showManageButton?: boolean;
}

function StarRating({ score }: { score: number }) {
  const fullStars = Math.floor(score);
  const hasHalfStar = score - fullStars >= 0.5;
  
  return (
    <div className="flex items-center gap-0.5">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          size={16}
          className={cn(
            i < fullStars 
              ? 'fill-[#00b67a] text-[#00b67a]' 
              : i === fullStars && hasHalfStar
                ? 'fill-[#00b67a]/50 text-[#00b67a]'
                : 'fill-muted text-muted'
          )}
        />
      ))}
    </div>
  );
}

function RatingBreakdownBars({ breakdown }: { breakdown: { five: number; four: number; three: number; two: number; one: number } }) {
  const total = breakdown.five + breakdown.four + breakdown.three + breakdown.two + breakdown.one;
  if (total === 0) return null;

  const bars = [
    { label: '5', value: breakdown.five, color: 'bg-[#00b67a]' },
    { label: '4', value: breakdown.four, color: 'bg-[#73cf11]' },
    { label: '3', value: breakdown.three, color: 'bg-[#ffce00]' },
    { label: '2', value: breakdown.two, color: 'bg-[#ff8622]' },
    { label: '1', value: breakdown.one, color: 'bg-[#ff3722]' },
  ];

  return (
    <div className="space-y-1">
      {bars.map(bar => (
        <div key={bar.label} className="flex items-center gap-2 text-xs">
          <span className="w-3 text-muted-foreground">{bar.label}</span>
          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
            <div 
              className={cn('h-full rounded-full', bar.color)}
              style={{ width: `${(bar.value / total) * 100}%` }}
            />
          </div>
          <span className="w-8 text-right text-muted-foreground">{Math.round((bar.value / total) * 100)}%</span>
        </div>
      ))}
    </div>
  );
}

function ProfileRow({ 
  profile, 
  onRefresh, 
  isRefreshing 
}: { 
  profile: TrustpilotProfile; 
  onRefresh: () => void;
  isRefreshing: boolean;
}) {
  const score = profile.score;
  
  return (
    <div className="py-3 border-b last:border-b-0">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-lg">{profile.countryFlag}</span>
            <span className="font-medium">{profile.countryName}</span>
            {profile.isPrimary && (
              <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">Primær</span>
            )}
          </div>
          
          {score ? (
            <div className="mt-2 space-y-2">
              <div className="flex items-center gap-3 flex-wrap">
                <div className="flex items-center gap-1.5">
                  <StarRating score={score.score || 0} />
                  <span className="font-semibold">{score.score?.toFixed(1)}</span>
                  <span className="text-sm text-muted-foreground">
                    ({score.totalReviews?.toLocaleString('da-DK')} anmeldelser)
                  </span>
                </div>
              </div>
              
              {score.recentScore !== null && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">
                    Seneste {score.recentPeriodDays}d:
                  </span>
                  <span className="font-medium">{score.recentScore.toFixed(1)}</span>
                  <span className="text-muted-foreground">
                    ({score.recentReviewsCount} nye)
                  </span>
                  <TrustpilotTrendBadge 
                    direction={score.trendDirection} 
                    delta={score.trendDelta}
                    size="sm"
                  />
                </div>
              )}
              
              {score.ratingBreakdown && (
                <div className="mt-2">
                  <RatingBreakdownBars breakdown={score.ratingBreakdown} />
                </div>
              )}
              
              {score.lastFetchedAt && (
                <p className="text-xs text-muted-foreground">
                  Opdateret {formatDistanceToNow(new Date(score.lastFetchedAt), { locale: da, addSuffix: true })}
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground mt-1">Ingen data endnu</p>
          )}
        </div>
        
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => window.open(profile.trustpilotUrl, '_blank')}
            title="Åbn på Trustpilot"
          >
            <ExternalLink size={14} />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={onRefresh}
            disabled={isRefreshing}
            title="Opdater score"
          >
            <RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
          </Button>
        </div>
      </div>
    </div>
  );
}

export function TrustpilotScoreCard({ companyId, showManageButton = true }: TrustpilotScoreCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showManageDialog, setShowManageDialog] = useState(false);
  
  const { 
    profiles, 
    aggregated, 
    isLoading, 
    refreshProfile, 
    refreshAll, 
    isRefreshing 
  } = useTrustpilotScores(companyId);

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center gap-2">
            <Skeleton className="h-5 w-5" />
            <Skeleton className="h-5 w-24" />
          </div>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-8 w-32 mb-2" />
          <Skeleton className="h-4 w-48" />
        </CardContent>
      </Card>
    );
  }

  if (profiles.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <Star className="h-5 w-5 text-[#00b67a]" />
            Trustpilot
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">
            Ingen Trustpilot-profiler konfigureret
          </p>
          {showManageButton && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowManageDialog(true)}
            >
              <Settings size={14} className="mr-1" />
              Tilføj profil
            </Button>
          )}
        </CardContent>
        
        <ManageTrustpilotProfilesDialog
          companyId={companyId}
          open={showManageDialog}
          onOpenChange={setShowManageDialog}
        />
      </Card>
    );
  }

  return (
    <Card>
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <Star className="h-5 w-5 text-[#00b67a]" />
              Trustpilot
            </CardTitle>
            <div className="flex items-center gap-1">
              {showManageButton && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => setShowManageDialog(true)}
                  title="Administrer profiler"
                >
                  <Settings size={14} />
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => refreshAll()}
                disabled={isRefreshing}
                title="Opdater alle"
              >
                <RefreshCw size={14} className={isRefreshing ? 'animate-spin' : ''} />
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {/* Aggregated view */}
          <div className="space-y-2">
            {aggregated.averageScore !== null ? (
              <>
                <div className="flex items-center gap-2">
                  <StarRating score={aggregated.averageScore} />
                  <span className="text-2xl font-bold">{aggregated.averageScore.toFixed(1)}</span>
                  <span className="text-sm text-muted-foreground">
                    ({aggregated.totalReviews.toLocaleString('da-DK')} anmeldelser)
                  </span>
                </div>
                
                {aggregated.averageRecentScore !== null && aggregated.recentReviewsCount > 0 && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">Seneste 30 dage:</span>
                    <span className="font-medium">{aggregated.averageRecentScore.toFixed(1)}</span>
                    <span className="text-muted-foreground">
                      ({aggregated.recentReviewsCount} nye)
                    </span>
                    <TrustpilotTrendBadge 
                      direction={aggregated.overallTrend} 
                      delta={aggregated.trendDelta}
                      size="sm"
                    />
                  </div>
                )}
              </>
            ) : (
              <p className="text-sm text-muted-foreground">
                Klik opdater for at hente scores
              </p>
            )}
            
            {/* Country flags row */}
            <div className="flex items-center gap-1 pt-1">
              {profiles.map(p => (
                <span key={p.id} className="text-lg" title={p.countryName}>
                  {p.countryFlag}
                </span>
              ))}
            </div>
          </div>
          
          {/* Expand/collapse trigger */}
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="w-full mt-3">
              {isExpanded ? (
                <>
                  <ChevronUp size={14} className="mr-1" />
                  Skjul detaljer
                </>
              ) : (
                <>
                  <ChevronDown size={14} className="mr-1" />
                  Vis alle lande ({profiles.length})
                </>
              )}
            </Button>
          </CollapsibleTrigger>
          
          {/* Expanded content */}
          <CollapsibleContent>
            <div className="mt-3 border-t pt-3">
              {profiles.map(profile => (
                <ProfileRow
                  key={profile.id}
                  profile={profile}
                  onRefresh={() => refreshProfile(profile.id)}
                  isRefreshing={isRefreshing}
                />
              ))}
              
              <Button
                variant="outline"
                size="sm"
                className="w-full mt-3"
                onClick={() => refreshAll()}
                disabled={isRefreshing}
              >
                <RefreshCw size={14} className={cn('mr-1', isRefreshing && 'animate-spin')} />
                Opdater alle
              </Button>
            </div>
          </CollapsibleContent>
        </CardContent>
      </Collapsible>
      
      <ManageTrustpilotProfilesDialog
        companyId={companyId}
        open={showManageDialog}
        onOpenChange={setShowManageDialog}
      />
    </Card>
  );
}
