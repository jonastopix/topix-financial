import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, Circle, AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';
import { useBoardGovernance } from '@/hooks/useBoardGovernance';
import { format, isPast } from 'date-fns';
import { da } from 'date-fns/locale';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface BoardGovernanceChecklistProps {
  companyId: string;
  year: number;
  fiscalYearEndMonth: number;
  fiscalYearEndDay: number;
  canManage?: boolean;
}

export function BoardGovernanceChecklist({
  companyId,
  year,
  fiscalYearEndMonth,
  fiscalYearEndDay,
  canManage = false,
}: BoardGovernanceChecklistProps) {
  const { progress, templates, isLoading, initializeProgress, updateProgress, calculateDeadline, stats } = 
    useBoardGovernance(companyId, year);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    annual_requirements: true,
    quarterly_review: false,
    ad_hoc: false,
  });

  useEffect(() => {
    if (templates.length > 0 && progress.length === 0) {
      initializeProgress.mutate({ companyId, year });
    }
  }, [templates.length, progress.length, companyId, year]);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category],
    }));
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case 'annual_requirements': return 'Årlige krav';
      case 'quarterly_review': return 'Kvartalsvise reviews';
      case 'ad_hoc': return 'Ad-hoc opgaver';
      default: return category;
    }
  };

  const groupedProgress = templates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    const progressItem = progress.find(p => p.template_id === template.id);
    acc[template.category].push({
      template,
      progress: progressItem,
    });
    return acc;
  }, {} as Record<string, Array<{ template: any; progress: any }>>);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground">Indlæser...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Governance Checklist {year}</CardTitle>
          <div className="flex items-center gap-4">
            <div className="text-sm text-muted-foreground">
              {stats.completed} af {stats.total} gennemført
            </div>
            <Badge variant={stats.percentage === 100 ? 'default' : 'secondary'}>
              {Math.round(stats.percentage)}%
            </Badge>
          </div>
        </div>
        <Progress value={stats.percentage} className="mt-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.entries(groupedProgress).map(([category, items]) => (
          <div key={category} className="border rounded-lg">
            <button
              onClick={() => toggleCategory(category)}
              className="w-full p-4 flex items-center justify-between hover:bg-accent transition-colors"
            >
              <div className="flex items-center gap-2">
                <h3 className="font-semibold">{getCategoryName(category)}</h3>
                <Badge variant="outline">
                  {items.filter(i => i.progress?.completed).length}/{items.length}
                </Badge>
              </div>
              {expandedCategories[category] ? (
                <ChevronUp className="h-5 w-5" />
              ) : (
                <ChevronDown className="h-5 w-5" />
              )}
            </button>

            {expandedCategories[category] && (
              <div className="p-4 pt-0 space-y-2">
                {items.map(({ template, progress: progressItem }) => {
                  const deadline = calculateDeadline(
                    template,
                    fiscalYearEndMonth,
                    fiscalYearEndDay,
                    year
                  );
                  const isOverdue = deadline && isPast(deadline) && !progressItem?.completed;

                  return (
                    <div
                      key={template.id}
                      className={cn(
                        "flex items-start gap-3 p-3 rounded-lg border",
                        progressItem?.completed && "bg-muted/50",
                        isOverdue && "border-destructive bg-destructive/5"
                      )}
                    >
                      {canManage && progressItem ? (
                        <Checkbox
                          checked={progressItem.completed}
                          onCheckedChange={(checked) => {
                            updateProgress.mutate({
                              id: progressItem.id,
                              completed: checked as boolean,
                            });
                          }}
                          className="mt-1"
                        />
                      ) : (
                        <div className="mt-1">
                          {progressItem?.completed ? (
                            <CheckCircle2 className="h-5 w-5 text-primary" />
                          ) : (
                            <Circle className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                      )}

                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "font-medium",
                            progressItem?.completed && "line-through text-muted-foreground"
                          )}>
                            {template.item_name}
                          </span>
                          {template.required && (
                            <Badge variant="outline" className="text-xs">
                              Påkrævet
                            </Badge>
                          )}
                          {isOverdue && (
                            <Badge variant="destructive" className="flex items-center gap-1">
                              <AlertTriangle className="h-3 w-3" />
                              Overskredet
                            </Badge>
                          )}
                        </div>

                        {template.description && (
                          <p className="text-sm text-muted-foreground">
                            {template.description}
                          </p>
                        )}

                        {deadline && (
                          <p className={cn(
                            "text-xs",
                            isOverdue ? "text-destructive font-medium" : "text-muted-foreground"
                          )}>
                            Deadline: {format(deadline, 'PPP', { locale: da })}
                          </p>
                        )}

                        {progressItem?.completed_at && (
                          <p className="text-xs text-muted-foreground">
                            Gennemført: {format(new Date(progressItem.completed_at), 'PPP', { locale: da })}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
