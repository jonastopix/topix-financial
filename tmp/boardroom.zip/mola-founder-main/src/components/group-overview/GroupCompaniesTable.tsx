import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Building2, ExternalLink } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import type { GroupCompany } from '@/hooks/useGroupOverview';

interface GroupCompaniesTableProps {
  companies: GroupCompany[];
}

// Status values that count as "active" investments
const ACTIVE_STATUSES = ['active', 'new_investment', 'due_diligence'];

export function GroupCompaniesTable({ companies }: GroupCompaniesTableProps) {
  const [includeExits, setIncludeExits] = useState(false);
  const navigate = useNavigate();

  // Default: show only active companies. Toggle on = include exits
  const filteredCompanies = includeExits 
    ? companies
    : companies.filter(c => ACTIVE_STATUSES.includes(c.status));

  const activeCount = companies.filter(c => ACTIVE_STATUSES.includes(c.status)).length;
  const exitedCount = companies.filter(c => c.status === 'exited').length;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/10 text-green-700 border-green-200';
      case 'exited': return 'bg-blue-500/10 text-blue-700 border-blue-200';
      case 'bankruptcy': return 'bg-red-500/10 text-red-700 border-red-200';
      case 'new_investment': return 'bg-amber-500/10 text-amber-700 border-amber-200';
      case 'due_diligence': return 'bg-purple-500/10 text-purple-700 border-purple-200';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Aktiv';
      case 'exited': return 'Exited';
      case 'bankruptcy': return 'Konkurs';
      case 'new_investment': return 'Ny investering';
      case 'due_diligence': return 'Due Diligence';
      case 'rejected': return 'Afvist';
      default: return status;
    }
  };

  const formatAddress = (company: GroupCompany) => {
    const parts = [company.address, company.zipcode, company.city].filter(Boolean);
    return parts.length > 0 ? parts.join(', ') : '-';
  };

  const sortedCompanies = [...filteredCompanies].sort((a, b) => a.name.localeCompare(b.name, 'da'));

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Selskabsoversigt
            </CardTitle>
            <Badge variant="secondary" className="text-xs">
              {activeCount} aktive
              {exitedCount > 0 && ` • ${exitedCount} exits`}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              id="table-include-exits"
              checked={includeExits}
              onCheckedChange={setIncludeExits}
            />
            <Label htmlFor="table-include-exits" className="text-sm text-muted-foreground cursor-pointer">
              Inkluder exits
            </Label>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[180px]">Selskab</TableHead>
                <TableHead>CVR</TableHead>
                <TableHead className="min-w-[200px]">Adresse</TableHead>
                <TableHead>Fond</TableHead>
                <TableHead className="text-right">Investeret</TableHead>
                <TableHead className="text-right">Ejerandel</TableHead>
                <TableHead className="text-right min-w-[140px]">
                  {includeExits ? 'Værdi / Exit' : 'Seneste værdi'}
                </TableHead>
                <TableHead>Investeret dato</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedCompanies.map((company) => {
                const isExited = company.status === 'exited';
                
                return (
                  <TableRow 
                    key={company.id}
                    className={cn(
                      isExited && 'opacity-60',
                      'cursor-pointer hover:bg-muted/50 transition-colors'
                    )}
                    onClick={() => navigate(`/company/${company.id}`)}
                  >
                    <TableCell className={cn("font-medium", isExited && "line-through decoration-1")}>
                      <div className="flex items-center gap-2">
                        {company.name}
                        <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {company.cvr || '-'}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatAddress(company)}
                    </TableCell>
                    <TableCell>
                      {company.fundName || '-'}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(company.investedAmount)}
                    </TableCell>
                    <TableCell className="text-right">
                      {company.ownershipPct.toFixed(1)}%
                    </TableCell>
                    <TableCell className="text-right">
                      {isExited && company.exitProceeds ? (
                        <div>
                          <p className="font-medium text-green-600">{formatCurrency(company.exitProceeds)}</p>
                          {company.exitDate && (
                            <p className="text-xs text-muted-foreground">
                              Exit {format(new Date(company.exitDate), 'd. MMM yyyy', { locale: da })}
                            </p>
                          )}
                        </div>
                      ) : company.latestValuation ? (
                        <div>
                          <p className="font-medium">{formatCurrency(company.latestValuation)}</p>
                          {company.valuationDate && (
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(company.valuationDate), 'd. MMM yyyy', { locale: da })}
                            </p>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {company.investedAt 
                        ? format(new Date(company.investedAt), 'd. MMM yyyy', { locale: da })
                        : '-'
                      }
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline" 
                        className={cn('text-xs', getStatusColor(company.status))}
                      >
                        {getStatusLabel(company.status)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {filteredCompanies.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            {includeExits ? 'Ingen selskaber fundet' : 'Ingen aktive selskaber fundet'}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
