import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Building2, Briefcase, ZoomIn, ZoomOut, Minimize2, Maximize2, FileDown } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { GroupFund } from '@/hooks/useGroupOverview';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface OrgChartViewProps {
  funds: GroupFund[];
  includeExits?: boolean;
}

type ViewDensity = 'compact' | 'normal' | 'detailed';

export function OrgChartView({ funds, includeExits = false }: OrgChartViewProps) {
  const [scale, setScale] = useState(1);
  const [density, setDensity] = useState<ViewDensity>('normal');
  const navigate = useNavigate();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/10 text-green-700 border-green-200';
      case 'exited': return 'bg-blue-500/10 text-blue-700 border-blue-200';
      case 'bankruptcy': return 'bg-red-500/10 text-red-700 border-red-200';
      case 'new_investment': return 'bg-amber-500/10 text-amber-700 border-amber-200';
      case 'due_diligence': return 'bg-purple-500/10 text-purple-700 border-purple-200';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Aktiv';
      case 'exited': return 'Exit';
      case 'bankruptcy': return 'Konkurs';
      case 'new_investment': return 'Ny';
      case 'due_diligence': return 'DD';
      case 'rejected': return 'Afvist';
      default: return status;
    }
  };

  const zoomIn = () => setScale(prev => Math.min(prev + 0.1, 1.5));
  const zoomOut = () => setScale(prev => Math.max(prev - 0.1, 0.4));
  const resetZoom = () => setScale(1);

  const cycleDensity = () => {
    setDensity(prev => {
      if (prev === 'detailed') return 'normal';
      if (prev === 'normal') return 'compact';
      return 'detailed';
    });
  };

  const handleExportPDF = () => {
    const currentDate = format(new Date(), 'd. MMMM yyyy', { locale: da });
    
    // Calculate summary metrics for the exported funds
    const totalActiveCompanies = funds.reduce((sum, f) => {
      const activeCount = f.companies.filter(c => 
        ['active', 'new_investment', 'due_diligence'].includes(c.status)
      ).length;
      return sum + activeCount;
    }, 0);
    
    const totalActiveInvested = funds.reduce((sum, f) => {
      return sum + f.companies
        .filter(c => ['active', 'new_investment', 'due_diligence'].includes(c.status))
        .reduce((s, c) => s + c.investedAmount, 0);
    }, 0);
    
    const totalActiveValue = funds.reduce((sum, f) => {
      return sum + f.companies
        .filter(c => ['active', 'new_investment', 'due_diligence'].includes(c.status))
        .reduce((s, c) => {
          if (c.latestValuation && c.ownershipPct > 0) {
            return s + (c.latestValuation * c.ownershipPct / 100);
          }
          return s;
        }, 0);
    }, 0);

    const exitedCompanies = funds.flatMap(f => 
      f.companies.filter(c => c.status === 'exited')
    );
    
    const totalExitInvested = exitedCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
    const totalExitProceeds = exitedCompanies.reduce((sum, c) => sum + (c.exitProceeds || 0), 0);
    
    const calculateMOIC = (invested: number, proceeds: number) => {
      return invested > 0 ? (proceeds / invested).toFixed(2) + 'x' : '-';
    };

    // Generate HTML for PDF
    const html = `
<!DOCTYPE html>
<html lang="da">
<head>
  <meta charset="UTF-8">
  <title>MOLA Koncernstruktur - ${currentDate}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 15mm;
    }
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      color: #1a1a1a;
      background: white;
      padding: 20px;
      print-color-adjust: exact;
      -webkit-print-color-adjust: exact;
    }
    
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #2563eb;
      padding-bottom: 15px;
      margin-bottom: 20px;
    }
    
    .logo {
      font-size: 28px;
      font-weight: bold;
      color: #2563eb;
    }
    
    .date {
      color: #666;
      font-size: 14px;
    }
    
    .summary-section {
      display: flex;
      gap: 15px;
      margin-bottom: 25px;
      flex-wrap: wrap;
    }
    
    .summary-card {
      background: #f9fafb;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      padding: 12px 16px;
      min-width: 140px;
    }
    
    .summary-card.highlight {
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      border: none;
      color: white;
    }
    
    .summary-label {
      font-size: 10px;
      color: #666;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    
    .summary-card.highlight .summary-label { color: rgba(255,255,255,0.8); }
    
    .summary-value {
      font-size: 18px;
      font-weight: 700;
      margin-top: 2px;
    }
    
    .summary-subvalue {
      font-size: 10px;
      color: #888;
      margin-top: 2px;
    }
    
    .summary-card.highlight .summary-subvalue { color: rgba(255,255,255,0.7); }
    
    .fund-section {
      margin-bottom: 40px;
      page-break-inside: avoid;
    }
    
    .fund-card {
      background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      color: white;
      padding: 15px 25px;
      border-radius: 10px;
      text-align: center;
      width: fit-content;
      margin: 0 auto 10px;
      box-shadow: 0 4px 6px rgba(37, 99, 235, 0.3);
    }
    
    .fund-name {
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 5px;
    }
    
    .fund-details {
      font-size: 12px;
      opacity: 0.9;
    }
    
    .connector {
      width: 2px;
      height: 20px;
      background: #d1d5db;
      margin: 0 auto;
    }
    
    .horizontal-line {
      height: 2px;
      background: #d1d5db;
      margin: 0 auto;
    }
    
    .companies-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 15px;
      padding-top: 15px;
    }
    
    .company-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    
    .company-connector {
      width: 2px;
      height: 15px;
      background: #d1d5db;
    }
    
    .company-card {
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      padding: 12px 16px;
      min-width: 140px;
      max-width: 180px;
      text-align: center;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .company-card.exited {
      opacity: 0.6;
      background: #f9fafb;
    }
    
    .company-name {
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 4px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    
    .company-name.exited {
      text-decoration: line-through;
    }
    
    .company-cvr {
      font-size: 10px;
      color: #666;
      margin-bottom: 6px;
    }
    
    .company-metrics {
      display: flex;
      justify-content: center;
      gap: 10px;
      font-size: 11px;
      margin-bottom: 8px;
    }
    
    .metric {
      text-align: center;
    }
    
    .metric-value {
      font-weight: 600;
      color: #1a1a1a;
    }
    
    .metric-label {
      color: #888;
      font-size: 9px;
    }
    
    .status-badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 10px;
      font-weight: 500;
    }
    
    .status-active { background: #dcfce7; color: #166534; }
    .status-exited { background: #dbeafe; color: #1e40af; }
    .status-new_investment { background: #fef3c7; color: #92400e; }
    .status-due_diligence { background: #f3e8ff; color: #7c3aed; }
    .status-bankruptcy { background: #fee2e2; color: #991b1b; }
    
    .exits-section {
      margin-top: 30px;
      padding-top: 20px;
      border-top: 2px solid #e5e7eb;
    }
    
    .exits-section h3 {
      font-size: 14px;
      margin-bottom: 15px;
      color: #374151;
    }
    
    .exits-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 11px;
    }
    
    .exits-table th {
      background: #f3f4f6;
      padding: 8px;
      text-align: left;
      font-weight: 600;
      border-bottom: 2px solid #e5e7eb;
    }
    
    .exits-table td {
      padding: 8px;
      border-bottom: 1px solid #e5e7eb;
    }
    
    .exits-table .total-row {
      font-weight: 600;
      background: #f9fafb;
    }
    
    .footer {
      margin-top: 40px;
      padding-top: 15px;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 12px;
      color: #666;
    }
    
    .signature-line {
      border-top: 1px solid #333;
      width: 200px;
      padding-top: 5px;
      text-align: center;
    }

    @media print {
      body { padding: 0; }
      .fund-section { page-break-inside: avoid; }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">MOLA</div>
    <div class="date">Koncernstruktur • ${currentDate}</div>
  </div>
  
  <div class="summary-section">
    <div class="summary-card">
      <div class="summary-label">Aktive selskaber</div>
      <div class="summary-value">${totalActiveCompanies}</div>
      ${exitedCompanies.length > 0 ? `<div class="summary-subvalue">${exitedCompanies.length} exits</div>` : ''}
    </div>
    <div class="summary-card">
      <div class="summary-label">Investeret (aktiv)</div>
      <div class="summary-value">${formatCurrency(totalActiveInvested)}</div>
    </div>
    <div class="summary-card">
      <div class="summary-label">Porteføljeværdi</div>
      <div class="summary-value">${formatCurrency(totalActiveValue)}</div>
    </div>
    <div class="summary-card highlight">
      <div class="summary-label">Urealiseret afkast</div>
      <div class="summary-value">${totalActiveValue > 0 ? ((totalActiveValue / totalActiveInvested) || 0).toFixed(2) : '0.00'}x</div>
    </div>
  </div>
  
  ${funds.map(fund => {
    const activeCompanies = fund.companies.filter(c => 
      ['active', 'new_investment', 'due_diligence'].includes(c.status)
    );
    const activeInvested = activeCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
    
    if (activeCompanies.length === 0 && !includeExits) return '';
    
    const companiesToShow = includeExits ? fund.companies : activeCompanies;
    
    return `
    <div class="fund-section">
      <div class="fund-card">
        <div class="fund-name">${fund.name}</div>
        <div class="fund-details">
          CVR: ${fund.cvr} • ${activeCompanies.length} aktive selskaber • Investeret: ${formatCurrency(activeInvested)}
        </div>
      </div>
      
      ${companiesToShow.length > 0 ? `
        <div class="connector"></div>
        ${companiesToShow.length > 1 ? `<div class="horizontal-line" style="width: ${Math.min(companiesToShow.length * 160, 800)}px;"></div>` : ''}
        
        <div class="companies-grid">
          ${companiesToShow.map(company => {
            const isExited = company.status === 'exited';
            const statusClass = `status-${company.status}`;
            const statusLabel = company.status === 'active' ? 'Aktiv' : 
                               company.status === 'exited' ? 'Exit' : 
                               company.status === 'new_investment' ? 'Ny investering' :
                               company.status === 'due_diligence' ? 'Due Diligence' :
                               company.status === 'bankruptcy' ? 'Konkurs' : company.status;
            
            return `
              <div class="company-wrapper">
                <div class="company-connector"></div>
                <div class="company-card ${isExited ? 'exited' : ''}">
                  <div class="company-name ${isExited ? 'exited' : ''}">${company.name}</div>
                  <div class="company-cvr">${company.cvr || 'Intet CVR'}</div>
                  <div class="company-metrics">
                    <div class="metric">
                      <div class="metric-value">${company.ownershipPct.toFixed(1)}%</div>
                      <div class="metric-label">Ejerandel</div>
                    </div>
                    <div class="metric">
                      <div class="metric-value">${formatCurrency(company.investedAmount)}</div>
                      <div class="metric-label">Investeret</div>
                    </div>
                  </div>
                  <span class="status-badge ${statusClass}">${statusLabel}</span>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      ` : '<div style="text-align: center; color: #888; font-style: italic; margin-top: 10px;">Ingen aktive selskaber</div>'}
    </div>
  `}).join('')}
  
  ${includeExits && exitedCompanies.length > 0 ? `
  <div class="exits-section">
    <h3>Exits Historik (Track Record)</h3>
    <table class="exits-table">
      <thead>
        <tr>
          <th>Selskab</th>
          <th>Fond</th>
          <th style="text-align: right;">Investeret</th>
          <th style="text-align: right;">Exit-provenu</th>
          <th style="text-align: right;">MOIC</th>
          <th>Exit dato</th>
        </tr>
      </thead>
      <tbody>
        ${exitedCompanies.map(c => `
          <tr>
            <td>${c.name}</td>
            <td>${c.fundName || '-'}</td>
            <td style="text-align: right;">${formatCurrency(c.investedAmount)}</td>
            <td style="text-align: right;">${formatCurrency(c.exitProceeds || 0)}</td>
            <td style="text-align: right; font-weight: 600;">${calculateMOIC(c.investedAmount, c.exitProceeds || 0)}</td>
            <td>${c.exitDate || '-'}</td>
          </tr>
        `).join('')}
        <tr class="total-row">
          <td>TOTAL (${exitedCompanies.length} exits)</td>
          <td></td>
          <td style="text-align: right;">${formatCurrency(totalExitInvested)}</td>
          <td style="text-align: right;">${formatCurrency(totalExitProceeds)}</td>
          <td style="text-align: right;">${calculateMOIC(totalExitInvested, totalExitProceeds)}</td>
          <td></td>
        </tr>
      </tbody>
    </table>
  </div>
  ` : ''}
  
  <div class="footer">
    <div>MOLA • Genereret ${currentDate}</div>
    <div class="signature-line">Underskrift</div>
  </div>
  
  <script>
    window.onload = function() {
      window.print();
    }
  </script>
</body>
</html>
    `;

    // Open in new window and trigger print
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(html);
      printWindow.document.close();
    }
  };

  if (funds.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Ingen fonde fundet
      </div>
    );
  }

  const isCompact = density === 'compact';
  const isDetailed = density === 'detailed';

  return (
    <div className="space-y-3">
      {/* Controls */}
      <div className="flex items-center justify-between gap-2 pb-2 border-b">
        <div className="flex items-center gap-1">
          <Button variant="outline" size="sm" onClick={zoomOut} className="h-8 w-8 p-0">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={resetZoom} className="h-8 px-2 text-xs">
            {Math.round(scale * 100)}%
          </Button>
          <Button variant="outline" size="sm" onClick={zoomIn} className="h-8 w-8 p-0">
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={cycleDensity} className="h-8 gap-1.5">
            {isCompact ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
            <span className="text-xs">
              {isCompact ? 'Kompakt' : isDetailed ? 'Detaljeret' : 'Normal'}
            </span>
          </Button>
          <Button variant="outline" size="sm" onClick={handleExportPDF} className="h-8 gap-1.5">
            <FileDown className="h-4 w-4" />
            <span className="text-xs">Eksporter PDF</span>
          </Button>
        </div>
      </div>

      {/* Org Chart Container with scroll */}
      <div className="overflow-auto max-h-[60vh] border rounded-lg bg-muted/20 p-4">
        <div 
          className="min-w-fit transition-transform duration-200 origin-top-left"
          style={{ transform: `scale(${scale})` }}
        >
          <TooltipProvider delayDuration={200}>
            <div className={cn("space-y-8", isCompact && "space-y-4")}>
              {funds.map((fund) => (
                <div key={fund.id} className="min-w-fit">
                  {/* Fund node (top) */}
                  <div className="flex justify-center">
                    <div className={cn(
                      "bg-primary text-primary-foreground rounded-lg shadow-lg text-center transition-all",
                      isCompact ? "p-2 min-w-[140px]" : "p-3 min-w-[180px]"
                    )}>
                      <div className={cn(
                        "flex items-center justify-center gap-1.5",
                        !isCompact && "mb-1"
                      )}>
                        <Briefcase className={cn(isCompact ? "h-4 w-4" : "h-5 w-5")} />
                        <span className={cn(
                          "font-semibold truncate max-w-[150px]",
                          isCompact ? "text-xs" : "text-sm"
                        )}>
                          {fund.name}
                        </span>
                      </div>
                      {!isCompact && (
                        <>
                          <p className="text-xs opacity-80">CVR: {fund.cvr}</p>
                          <p className="text-xs mt-1 font-medium">
                            {formatCurrency(fund.totalInvested)}
                          </p>
                        </>
                      )}
                      {isDetailed && (
                        <p className="text-xs opacity-80">
                          {fund.companyCount} selskaber
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Connection line from fund */}
                  {fund.companies.length > 0 && (
                    <>
                      <div className="flex justify-center">
                        <div className={cn(
                          "w-0.5 bg-border",
                          isCompact ? "h-4" : "h-6"
                        )} />
                      </div>

                      {/* Horizontal line and vertical branches */}
                      <div className="relative">
                        {/* Horizontal connector line */}
                        {fund.companies.length > 1 && (
                          <div 
                            className="absolute top-0 h-0.5 bg-border"
                            style={{
                              left: `calc(50% - ${(fund.companies.length - 1) * (isCompact ? 50 : 70)}px)`,
                              width: `${(fund.companies.length - 1) * (isCompact ? 100 : 140)}px`,
                            }}
                          />
                        )}

                        {/* Company nodes */}
                        <div className={cn(
                          "flex justify-center flex-wrap lg:flex-nowrap",
                          isCompact ? "gap-2" : "gap-3"
                        )}>
                          {fund.companies.map((company) => {
                            const isExited = company.status === 'exited';
                            
                            return (
                              <Tooltip key={company.id}>
                                <TooltipTrigger asChild>
                                  <div 
                                    className={cn(
                                      "flex flex-col items-center cursor-pointer",
                                      isExited && "opacity-60"
                                    )}
                                    onClick={() => navigate(`/company/${company.id}`)}
                                  >
                                    {/* Vertical line down to company */}
                                    <div className={cn(
                                      "w-0.5 bg-border",
                                      isCompact ? "h-4" : "h-6"
                                    )} />
                                    
                                    {/* Company card */}
                                    <div className={cn(
                                      "bg-card border rounded-lg shadow-sm hover:shadow-md transition-all",
                                      isCompact ? "p-2 min-w-[100px] max-w-[120px]" : "p-2.5 min-w-[140px] max-w-[160px]",
                                      isExited && "bg-muted/50"
                                    )}>
                                      <div className={cn(
                                        "flex items-center gap-1.5",
                                        !isCompact && "mb-1"
                                      )}>
                                        <div className={cn(
                                          "rounded bg-muted shrink-0",
                                          isCompact ? "p-0.5" : "p-1"
                                        )}>
                                          <Building2 className={cn(
                                            "text-muted-foreground",
                                            isCompact ? "h-3 w-3" : "h-3.5 w-3.5"
                                          )} />
                                        </div>
                                        <span className={cn(
                                          "font-medium truncate",
                                          isCompact ? "text-[10px]" : "text-xs",
                                          isExited && "line-through decoration-1"
                                        )}>
                                          {company.name}
                                        </span>
                                      </div>
                                      
                                      {!isCompact && (
                                        <div className="space-y-0.5 text-[10px] text-muted-foreground mt-1">
                                          <p className="font-medium text-foreground">
                                            {company.ownershipPct.toFixed(0)}%
                                          </p>
                                          {isDetailed && (
                                            <>
                                              <p>{formatCurrency(company.investedAmount)}</p>
                                              <p>{company.cvr || '-'}</p>
                                            </>
                                          )}
                                        </div>
                                      )}

                                      <div className={cn("flex justify-start", isCompact ? "mt-1" : "mt-1.5")}>
                                        <Badge 
                                          variant="outline" 
                                          className={cn(
                                            getStatusColor(company.status),
                                            isCompact ? "text-[8px] px-1 py-0" : "text-[10px] px-1.5 py-0"
                                          )}
                                        >
                                          {getStatusLabel(company.status)}
                                        </Badge>
                                      </div>
                                    </div>
                                  </div>
                                </TooltipTrigger>
                                <TooltipContent side="bottom" className="max-w-[250px]">
                                  <div className="space-y-1">
                                    <p className={cn("font-semibold", isExited && "line-through")}>
                                      {company.name}
                                    </p>
                                    <p className="text-xs text-muted-foreground">
                                      {company.cvr ? `CVR: ${company.cvr}` : 'Intet CVR'}
                                    </p>
                                    <p className="text-xs">
                                      Investeret: {formatCurrency(company.investedAmount)}
                                    </p>
                                    <p className="text-xs">
                                      Ejerandel: {company.ownershipPct.toFixed(1)}%
                                    </p>
                                    {isExited && company.exitProceeds && (
                                      <p className="text-xs text-green-600 font-medium">
                                        Exit provenu: {formatCurrency(company.exitProceeds)}
                                      </p>
                                    )}
                                    {company.city && (
                                      <p className="text-xs text-muted-foreground">{company.city}</p>
                                    )}
                                  </div>
                                </TooltipContent>
                              </Tooltip>
                            );
                          })}
                        </div>
                      </div>
                    </>
                  )}

                  {fund.companies.length === 0 && (
                    <div className="flex justify-center mt-2">
                      <div className="text-xs text-muted-foreground italic">
                        Ingen selskaber
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </TooltipProvider>
        </div>
      </div>
    </div>
  );
}
