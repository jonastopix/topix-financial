import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Download, FileSpreadsheet, FileText, Loader2, Mail, Send } from 'lucide-react';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { supabase } from '@/integrations/supabase/client';
import type { GroupOverviewData, GroupCompany, GroupFund } from '@/hooks/useGroupOverview';
import type { PerspectiveType } from './PerspectiveSelector';

interface ExportGroupReportDialogProps {
  data: GroupOverviewData;
  perspective?: PerspectiveType;
  perspectiveLabel?: string;
  selectedFundId?: string | null;
}

export function ExportGroupReportDialog({ 
  data, 
  perspective = 'total',
  perspectiveLabel = 'Koncern Total',
  selectedFundId 
}: ExportGroupReportDialogProps) {
  const [open, setOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [includeValuations, setIncludeValuations] = useState(true);
  const [includeExits, setIncludeExits] = useState(true);
  
  // Email state
  const [recipientEmails, setRecipientEmails] = useState('');
  const [personalMessage, setPersonalMessage] = useState('');
  const [isSendingEmail, setIsSendingEmail] = useState(false);

  const formatDKK = (amount: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatCompact = (amount: number) => {
    if (amount >= 1_000_000_000) {
      return `${(amount / 1_000_000_000).toFixed(1)} mia.`;
    } else if (amount >= 1_000_000) {
      return `${(amount / 1_000_000).toFixed(1)}M`;
    } else if (amount >= 1_000) {
      return `${(amount / 1_000).toFixed(0)}K`;
    }
    return amount.toLocaleString('da-DK');
  };

  const calculateMOIC = (invested: number, proceeds: number) => {
    return invested > 0 ? (proceeds / invested).toFixed(2) + 'x' : '-';
  };

  // Get the metrics based on perspective
  const getMetrics = () => {
    if (perspective === 'mola') {
      return {
        activeInvested: data.molaActiveInvested,
        activeValue: data.molaActiveValue,
        exitedInvested: data.molaExitedInvested,
        totalDividends: data.molaTotalDividends,
        totalExitProceeds: data.molaTotalExitProceeds,
        dpi: data.molaDpi,
        tvpi: data.molaTvpi,
        totalInvestedAllTime: data.molaActiveInvested + data.molaExitedInvested,
      };
    }
    
    if (perspective === 'fund' && selectedFundId) {
      const fund = data.funds.find(f => f.id === selectedFundId);
      if (fund) {
        const fundExitedCompanies = fund.companies.filter(c => c.status === 'exited');
        const fundExitedInvested = fundExitedCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
        const fundExitProceeds = fundExitedCompanies.reduce((sum, c) => sum + (c.exitProceeds || 0), 0);
        const fundTotalInvested = fund.activeInvested + fundExitedInvested;
        
        return {
          activeInvested: fund.activeInvested,
          activeValue: fund.totalValue,
          exitedInvested: fundExitedInvested,
          totalDividends: 0,
          totalExitProceeds: fundExitProceeds,
          dpi: fundTotalInvested > 0 ? fundExitProceeds / fundTotalInvested : 0,
          tvpi: fundTotalInvested > 0 ? (fundExitProceeds + fund.totalValue) / fundTotalInvested : 0,
          totalInvestedAllTime: fundTotalInvested,
        };
      }
    }
    
    return {
      activeInvested: data.activeInvested,
      activeValue: data.activeValue,
      exitedInvested: data.exitedInvested,
      totalDividends: data.totalDividends,
      totalExitProceeds: data.totalExitProceeds,
      dpi: data.dpi,
      tvpi: data.tvpi,
      totalInvestedAllTime: data.totalInvestedAllTime,
    };
  };

  // Get funds and companies based on perspective
  const getDisplayData = () => {
    if (perspective === 'fund' && selectedFundId) {
      const fund = data.funds.find(f => f.id === selectedFundId);
      return {
        funds: fund ? [fund] : [],
        companies: fund?.companies || [],
        activeCompanies: fund?.activeCompanies || [],
        exitedCompanies: fund?.companies.filter(c => c.status === 'exited') || [],
      };
    }
    return {
      funds: data.funds,
      companies: data.companies,
      activeCompanies: data.activeCompanies,
      exitedCompanies: data.exitedCompanies,
    };
  };

  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const wb = XLSX.utils.book_new();
      const metrics = getMetrics();
      const displayData = getDisplayData();

      // ===== SHEET 1: Summary =====
      const summaryData: (string | number)[][] = [
        [`KONCERNOVERBLIK - MOLA (${perspectiveLabel})`],
        ['Genereret:', format(new Date(), 'd. MMMM yyyy', { locale: da })],
        ['Perspektiv:', perspectiveLabel],
        [''],
        ['AKTIV PORTEFØLJE'],
        ['Antal aktive selskaber', data.activeCompanyCount],
        ['Investeret (aktiv portefølje)', metrics.activeInvested],
        ['Porteføljeværdi (aktiv)', metrics.activeValue],
        ...(includeExits ? [
          [''],
          ['HISTORIK (INKL. EXITS)'],
          ['Antal exits', data.exitedCompanyCount],
          ['Historisk investeret (alle)', metrics.totalInvestedAllTime],
          [''],
          ['AFKAST'],
          ['Udbytter modtaget', metrics.totalDividends],
          ['Exit-provenu', metrics.totalExitProceeds],
          ['Total distributioner', metrics.totalDividends + metrics.totalExitProceeds],
          ['DPI (Distributions/Paid-In)', metrics.dpi.toFixed(2) + 'x'],
          ['TVPI (Total Value/Paid-In)', metrics.tvpi.toFixed(2) + 'x'],
        ] : [
          [''],
          ['UDBYTTE'],
          ['Udbytter modtaget', metrics.totalDividends],
        ]),
      ];
      const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
      summarySheet['!cols'] = [{ wch: 35 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, summarySheet, 'Sammenfatning');

      // ===== SHEET 2: Active Companies by Fund =====
      const activeCompaniesData: (string | number)[][] = [
        [`AKTIVE SELSKABER PR. FOND (${perspectiveLabel})`],
        [''],
      ];
      
      displayData.funds.forEach(fund => {
        const activeCompanies = fund.companies.filter(c => 
          ['active', 'new_investment', 'due_diligence'].includes(c.status)
        );
        if (activeCompanies.length === 0) return;
        
        // For Mola perspective, show Mola's ownership in the fund
        const fundHeader = perspective === 'mola' 
          ? `FOND: ${fund.name} (Mola Invest ApS ejer ${fund.molaOwnershipPct}%)`
          : `FOND: ${fund.name}`;
        
        activeCompaniesData.push([
          fundHeader,
          `CVR: ${fund.cvr}`,
          `Investeret: ${formatDKK(perspective === 'mola' ? fund.activeInvested * fund.molaOwnershipPct / 100 : fund.activeInvested)}`,
          `Værdi: ${formatDKK(perspective === 'mola' ? fund.totalValue * fund.molaOwnershipPct / 100 : fund.totalValue)}`,
          `Antal: ${fund.activeCompanyCount}`,
        ]);
        activeCompaniesData.push(['Selskab', 'CVR', 'Branche', 'Ejerandel %', 'Investeret DKK', 'Værdi DKK', 'Status', 'Investeret dato']);
        
        activeCompanies.forEach(c => {
          const molaValue = c.latestValuation && c.ownershipPct > 0 
            ? c.latestValuation * c.ownershipPct / 100 
            : 0;
          const displayInvested = perspective === 'mola' ? c.investedAmount * fund.molaOwnershipPct / 100 : c.investedAmount;
          const displayValue = perspective === 'mola' ? molaValue * fund.molaOwnershipPct / 100 : molaValue;
          
          activeCompaniesData.push([
            c.name,
            c.cvr || '',
            c.industry || '',
            c.ownershipPct,
            displayInvested,
            displayValue,
            c.status,
            c.investedAt || ''
          ]);
        });
        activeCompaniesData.push(['']);
      });

      const activeSheet = XLSX.utils.aoa_to_sheet(activeCompaniesData);
      activeSheet['!cols'] = [
        { wch: 25 }, { wch: 12 }, { wch: 15 }, { wch: 12 }, 
        { wch: 18 }, { wch: 18 }, { wch: 12 }, { wch: 15 }
      ];
      XLSX.utils.book_append_sheet(wb, activeSheet, 'Aktive Selskaber');

      // ===== SHEET 3: Exits History =====
      if (includeExits && displayData.exitedCompanies.length > 0) {
        const exitsHeaders = ['Selskab', 'CVR', 'Fond', 'Investeret DKK', 'Exit-provenu DKK', 'MOIC', 'Exit dato', 'Branche'];
        const exitsData = displayData.exitedCompanies.map(c => {
          const fund = data.funds.find(f => f.id === c.fundId);
          const molaFundOwnership = fund?.molaOwnershipPct || 100;
          const proceeds = c.exitProceeds || 0;
          const displayInvested = perspective === 'mola' ? c.investedAmount * molaFundOwnership / 100 : c.investedAmount;
          const displayProceeds = perspective === 'mola' ? proceeds * molaFundOwnership / 100 : proceeds;
          
          return [
            c.name,
            c.cvr || '',
            c.fundName || '',
            displayInvested,
            displayProceeds,
            calculateMOIC(displayInvested, displayProceeds),
            c.exitDate || '',
            c.industry || ''
          ];
        });
        
        // Add totals row
        const totalExitInvested = displayData.exitedCompanies.reduce((sum, c) => {
          const fund = data.funds.find(f => f.id === c.fundId);
          const molaFundOwnership = fund?.molaOwnershipPct || 100;
          return sum + (perspective === 'mola' ? c.investedAmount * molaFundOwnership / 100 : c.investedAmount);
        }, 0);
        const totalExitProceeds = displayData.exitedCompanies.reduce((sum, c) => {
          const fund = data.funds.find(f => f.id === c.fundId);
          const molaFundOwnership = fund?.molaOwnershipPct || 100;
          return sum + (perspective === 'mola' ? (c.exitProceeds || 0) * molaFundOwnership / 100 : (c.exitProceeds || 0));
        }, 0);
        exitsData.push([]);
        exitsData.push([
          'TOTAL',
          '',
          '',
          totalExitInvested,
          totalExitProceeds,
          calculateMOIC(totalExitInvested, totalExitProceeds),
          '',
          ''
        ]);

        const exitsSheet = XLSX.utils.aoa_to_sheet([exitsHeaders, ...exitsData]);
        exitsSheet['!cols'] = [
          { wch: 25 }, { wch: 12 }, { wch: 20 }, { wch: 18 },
          { wch: 18 }, { wch: 10 }, { wch: 12 }, { wch: 15 }
        ];
        XLSX.utils.book_append_sheet(wb, exitsSheet, 'Exits Historik');
      }

      // ===== SHEET 4: Funds Overview =====
      const fundsHeaders = perspective === 'mola' 
        ? ['Fond', 'CVR', 'Mola Ejerandel %', 'Aktive selskaber', 'Total selskaber', 'Investeret (aktiv) DKK', 'Mola-andel DKK', 'Porteføljeværdi DKK', 'Mola-værdi DKK']
        : ['Fond', 'CVR', 'Aktive selskaber', 'Total selskaber', 'Investeret (aktiv) DKK', 'Investeret (alle) DKK', 'Porteføljeværdi DKK'];
      
      const fundsData = displayData.funds.map(f => perspective === 'mola' ? [
        f.name,
        f.cvr,
        f.molaOwnershipPct,
        f.activeCompanyCount,
        f.companyCount,
        f.activeInvested,
        f.activeInvested * f.molaOwnershipPct / 100,
        f.totalValue,
        f.totalValue * f.molaOwnershipPct / 100
      ] : [
        f.name,
        f.cvr,
        f.activeCompanyCount,
        f.companyCount,
        f.activeInvested,
        f.totalInvested,
        f.totalValue
      ]);
      const fundsSheet = XLSX.utils.aoa_to_sheet([fundsHeaders, ...fundsData]);
      fundsSheet['!cols'] = perspective === 'mola' 
        ? [{ wch: 25 }, { wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 20 }, { wch: 18 }, { wch: 20 }, { wch: 18 }]
        : [{ wch: 25 }, { wch: 12 }, { wch: 15 }, { wch: 15 }, { wch: 20 }, { wch: 20 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, fundsSheet, 'Fonde');

      // Download
      const fileName = `Koncernoverblik_MOLA_${perspectiveLabel.replace(/\s+/g, '_')}_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
      XLSX.writeFile(wb, fileName);
      
      toast.success('Excel-fil eksporteret', {
        description: fileName
      });
      setOpen(false);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Eksport fejlede', {
        description: 'Kunne ikke generere Excel-fil'
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Kunne ikke åbne printvindue', {
        description: 'Tillad pop-ups i din browser'
      });
      return;
    }

    const html = generatePDFHTML();
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
    }, 500);

    setOpen(false);
  };

  const generatePDFHTML = (forEmail: boolean = false) => {
    const today = format(new Date(), 'd. MMMM yyyy', { locale: da });
    const metrics = getMetrics();
    const displayData = getDisplayData();
    
    // Generate fund sections with their companies
    const fundSectionsHTML = displayData.funds
      .filter(fund => fund.activeCompanyCount > 0)
      .map(fund => {
        const activeCompanies = fund.companies.filter(c => 
          ['active', 'new_investment', 'due_diligence'].includes(c.status)
        );
        
        const fundHeader = perspective === 'mola' 
          ? `${fund.name} (Mola Invest ApS ejer ${fund.molaOwnershipPct}%)`
          : fund.name;
        
        const displayInvested = perspective === 'mola' ? fund.activeInvested * fund.molaOwnershipPct / 100 : fund.activeInvested;
        const displayValue = perspective === 'mola' ? fund.totalValue * fund.molaOwnershipPct / 100 : fund.totalValue;
        
        const companiesRowsHTML = activeCompanies
          .sort((a, b) => b.investedAmount - a.investedAmount)
          .map(c => {
            const molaValue = c.latestValuation && c.ownershipPct > 0 
              ? c.latestValuation * c.ownershipPct / 100 
              : 0;
            const cDisplayInvested = perspective === 'mola' ? c.investedAmount * fund.molaOwnershipPct / 100 : c.investedAmount;
            const cDisplayValue = perspective === 'mola' ? molaValue * fund.molaOwnershipPct / 100 : molaValue;
            
            return `
              <tr>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.name}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.cvr || '-'}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.industry || '-'}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${c.ownershipPct.toFixed(1)}%</td>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatDKK(cDisplayInvested)}</td>
                <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${cDisplayValue > 0 ? formatDKK(cDisplayValue) : '-'}</td>
              </tr>
            `;
          }).join('');

        return `
          <div class="fund-section">
            <div class="fund-header">
              <div class="fund-name">${fundHeader}</div>
              <div class="fund-meta">CVR: ${fund.cvr} • ${fund.activeCompanyCount} selskaber • Investeret: ${formatDKK(displayInvested)} • Værdi: ${formatDKK(displayValue)}</div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Selskab</th>
                  <th>CVR</th>
                  <th>Branche</th>
                  <th style="text-align: right;">Ejerandel</th>
                  <th style="text-align: right;">Investeret</th>
                  <th style="text-align: right;">${perspective === 'mola' ? 'Mola-værdi' : 'MOLA-værdi'}</th>
                </tr>
              </thead>
              <tbody>
                ${companiesRowsHTML}
              </tbody>
            </table>
          </div>
        `;
      }).join('');

    // Generate exits section
    const exitsHTML = includeExits && displayData.exitedCompanies.length > 0 ? `
      <div class="exits-section">
        <h2>Exits Historik (Track Record)</h2>
        <table>
          <thead>
            <tr>
              <th>Selskab</th>
              <th>Fond</th>
              <th style="text-align: right;">Investeret</th>
              <th style="text-align: right;">Exit-provenu</th>
              <th style="text-align: right;">MOIC</th>
              <th>Exit dato</th>
            </tr>
          </thead>
          <tbody>
            ${displayData.exitedCompanies.map(c => {
              const fund = data.funds.find(f => f.id === c.fundId);
              const molaFundOwnership = fund?.molaOwnershipPct || 100;
              const proceeds = c.exitProceeds || 0;
              const displayInvested = perspective === 'mola' ? c.investedAmount * molaFundOwnership / 100 : c.investedAmount;
              const displayProceeds = perspective === 'mola' ? proceeds * molaFundOwnership / 100 : proceeds;
              
              return `
                <tr class="exited-row">
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.name}</td>
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.fundName || '-'}</td>
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatDKK(displayInvested)}</td>
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">${formatDKK(displayProceeds)}</td>
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right; font-weight: 600;">${calculateMOIC(displayInvested, displayProceeds)}</td>
                  <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${c.exitDate ? format(new Date(c.exitDate), 'MMM yyyy', { locale: da }) : '-'}</td>
                </tr>
              `;
            }).join('')}
            <tr class="totals-row">
              <td style="padding: 8px; font-weight: 600;">TOTAL (${displayData.exitedCompanies.length} exits)</td>
              <td style="padding: 8px;"></td>
              <td style="padding: 8px; text-align: right; font-weight: 600;">${formatDKK(metrics.exitedInvested)}</td>
              <td style="padding: 8px; text-align: right; font-weight: 600;">${formatDKK(metrics.totalExitProceeds)}</td>
              <td style="padding: 8px; text-align: right; font-weight: 600;">${calculateMOIC(metrics.exitedInvested, metrics.totalExitProceeds)}</td>
              <td style="padding: 8px;"></td>
            </tr>
          </tbody>
        </table>
      </div>
    ` : '';

    return `
      <!DOCTYPE html>
      <html lang="da">
      <head>
        <meta charset="UTF-8">
        <title>Koncernoverblik - MOLA (${perspectiveLabel})</title>
        <style>
          * { box-sizing: border-box; }
          @page { size: A4 portrait; margin: 15mm; }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            padding: 30px;
            max-width: 900px;
            margin: 0 auto;
            color: #1f2937;
            font-size: 12px;
            line-height: 1.4;
          }
          .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 30px;
            border-bottom: 3px solid #2563eb;
            padding-bottom: 15px;
          }
          .logo {
            font-size: 32px;
            font-weight: bold;
            color: #2563eb;
          }
          .subtitle { font-size: 14px; color: #6b7280; }
          .perspective-badge {
            display: inline-block;
            background: #2563eb;
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            margin-top: 8px;
          }
          .date { color: #6b7280; font-size: 12px; text-align: right; }
          
          h2 {
            color: #1f2937;
            margin: 25px 0 15px 0;
            font-size: 16px;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 8px;
          }
          
          .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 25px;
          }
          .summary-card {
            background: #f9fafb;
            padding: 12px;
            border-radius: 6px;
            border: 1px solid #e5e7eb;
          }
          .summary-card .label {
            font-size: 10px;
            color: #6b7280;
            margin-bottom: 3px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .summary-card .value {
            font-size: 18px;
            font-weight: bold;
            color: #1f2937;
          }
          .summary-card .subvalue {
            font-size: 10px;
            color: #6b7280;
            margin-top: 2px;
          }
          .summary-card.highlight {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            border: none;
          }
          .summary-card.highlight .label,
          .summary-card.highlight .value,
          .summary-card.highlight .subvalue { color: white; }
          
          .fund-section {
            margin-bottom: 30px;
            page-break-inside: avoid;
          }
          .fund-header {
            background: #1e3a5f;
            color: white;
            padding: 12px 16px;
            border-radius: 6px 6px 0 0;
          }
          .fund-name { font-size: 14px; font-weight: 600; }
          .fund-meta { font-size: 11px; opacity: 0.85; margin-top: 3px; }
          
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
            background: white;
            border: 1px solid #e5e7eb;
            border-top: none;
          }
          th {
            background: #f3f4f6;
            padding: 8px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #e5e7eb;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 0.3px;
          }
          td { padding: 8px; }
          
          .exits-section {
            margin-top: 35px;
            padding-top: 20px;
            border-top: 2px solid #e5e7eb;
          }
          .exited-row { background: #fafafa; }
          .totals-row { background: #f3f4f6; border-top: 2px solid #d1d5db; }
          
          .footer {
            margin-top: 40px;
            padding-top: 15px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            font-size: 11px;
            color: #6b7280;
          }
          .signature-line {
            width: 200px;
            border-top: 1px solid #1f2937;
            margin-top: 40px;
            padding-top: 6px;
            text-align: center;
          }
          
          @media print {
            body { padding: 0; }
            .fund-section { page-break-inside: avoid; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <div class="logo">MOLA</div>
            <div class="subtitle">Koncernoverblik</div>
            ${perspectiveLabel !== 'Koncern Total' ? `<div class="perspective-badge">${perspectiveLabel}</div>` : ''}
          </div>
          <div class="date">
            Genereret: ${today}<br/>
            <small>Fortroligt dokument</small>
          </div>
        </div>

        <h2>Nøgletal - Aktiv Portefølje${perspective === 'mola' ? ' (Mola Invest ApS andel)' : ''}</h2>
        <div class="summary-grid">
          <div class="summary-card">
            <div class="label">Aktive selskaber</div>
            <div class="value">${data.activeCompanyCount}</div>
            ${includeExits ? `<div class="subvalue">${data.exitedCompanyCount} exits historisk</div>` : ''}
          </div>
          <div class="summary-card">
            <div class="label">Investeret (aktiv)</div>
            <div class="value">${formatCompact(metrics.activeInvested)} DKK</div>
            ${includeExits ? `<div class="subvalue">Historisk: ${formatCompact(metrics.totalInvestedAllTime)} DKK</div>` : ''}
          </div>
          <div class="summary-card">
            <div class="label">Porteføljeværdi</div>
            <div class="value">${formatCompact(metrics.activeValue)} DKK</div>
          </div>
          ${includeExits ? `
          <div class="summary-card highlight">
            <div class="label">TVPI</div>
            <div class="value">${metrics.tvpi.toFixed(2)}x</div>
            <div class="subvalue">DPI: ${metrics.dpi.toFixed(2)}x</div>
          </div>
          ` : `
          <div class="summary-card">
            <div class="label">Udbytter modtaget</div>
            <div class="value">${formatDKK(metrics.totalDividends)}</div>
          </div>
          `}
        </div>
        
        ${includeExits ? `
        <div class="summary-grid" style="grid-template-columns: repeat(3, 1fr);">
          <div class="summary-card">
            <div class="label">Udbytter modtaget</div>
            <div class="value">${formatDKK(metrics.totalDividends)}</div>
          </div>
          <div class="summary-card">
            <div class="label">Exit-provenu</div>
            <div class="value">${formatDKK(metrics.totalExitProceeds)}</div>
          </div>
          <div class="summary-card">
            <div class="label">Total distributioner</div>
            <div class="value">${formatDKK(metrics.totalDividends + metrics.totalExitProceeds)}</div>
            <div class="subvalue">${formatDKK(metrics.totalDividends)} + ${formatDKK(metrics.totalExitProceeds)}</div>
          </div>
        </div>
        ` : ''}

        <h2>Koncernstruktur - Aktive Investeringer pr. Fond</h2>
        ${fundSectionsHTML}

        ${exitsHTML}

        <div class="footer">
          <div>
            <p>MOLA • Koncernoverblik • ${perspectiveLabel}</p>
            <p>Dokumentet er genereret automatisk og er fortroligt.</p>
            ${!forEmail ? `
            <div class="signature-line">
              Underskrift / Dato
            </div>
            ` : ''}
          </div>
          <div style="text-align: right;">
            <p>Side 1</p>
          </div>
        </div>
      </body>
      </html>
    `;
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Download className="h-4 w-4 mr-2" />
          Eksportér rapport
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Eksportér koncernoverblik</DialogTitle>
          <DialogDescription>
            Professionel rapport til banker og investorer
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Perspective info */}
          {perspectiveLabel !== 'Koncern Total' && (
            <div className="bg-primary/10 rounded-lg p-3 text-sm">
              <p className="font-medium text-primary">Perspektiv: {perspectiveLabel}</p>
              <p className="text-xs text-muted-foreground mt-1">
                Rapporten eksporteres med dette perspektiv
              </p>
            </div>
          )}

          {/* Summary preview */}
          <div className="bg-muted/50 rounded-lg p-3 text-sm space-y-1">
            <p><strong>{data.activeCompanyCount}</strong> aktive selskaber i rapporten</p>
            <p className="text-muted-foreground text-xs">
              {data.exitedCompanyCount} exits tilgængelige som track record
            </p>
          </div>

          {/* Options */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Inkludér i rapport</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="valuations" 
                  checked={includeValuations}
                  onCheckedChange={(checked) => setIncludeValuations(checked as boolean)}
                />
                <label htmlFor="valuations" className="text-sm">Værdiansættelser og porteføljeværdi</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="exits" 
                  checked={includeExits}
                  onCheckedChange={(checked) => setIncludeExits(checked as boolean)}
                />
                <label htmlFor="exits" className="text-sm">Exits historik med MOIC (track record)</label>
              </div>
            </div>
          </div>

          {/* Export buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={handleExportPDF}
              disabled={isExporting}
              className="h-20 flex-col"
            >
              <FileText className="h-6 w-6 mb-1" />
              <span>PDF / Print</span>
              <span className="text-[10px] text-muted-foreground">Bankvenlig format</span>
            </Button>
            <Button
              variant="outline"
              onClick={handleExportExcel}
              disabled={isExporting}
              className="h-20 flex-col"
            >
              {isExporting ? (
                <Loader2 className="h-6 w-6 mb-1 animate-spin" />
              ) : (
                <FileSpreadsheet className="h-6 w-6 mb-1" />
              )}
              <span>Excel</span>
              <span className="text-[10px] text-muted-foreground">Detaljeret data</span>
            </Button>
          </div>

          <Separator className="my-4" />

          {/* Email section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-primary" />
              <Label className="text-sm font-medium">Send rapport via e-mail</Label>
            </div>
            
            <div className="space-y-3">
              <div>
                <Label htmlFor="recipients" className="text-xs text-muted-foreground">
                  Modtager(e) - brug komma for flere
                </Label>
                <Input
                  id="recipients"
                  type="email"
                  placeholder="bank@example.com, investor@example.com"
                  value={recipientEmails}
                  onChange={(e) => setRecipientEmails(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="message" className="text-xs text-muted-foreground">
                  Personlig besked (valgfri)
                </Label>
                <Textarea
                  id="message"
                  placeholder="Hermed fremsendes koncernoverblik som aftalt..."
                  value={personalMessage}
                  onChange={(e) => setPersonalMessage(e.target.value)}
                  className="mt-1 min-h-[80px]"
                />
              </div>

              <Button
                onClick={handleSendEmail}
                disabled={isSendingEmail || !recipientEmails.trim()}
                className="w-full"
              >
                {isSendingEmail ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Sender...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Send rapport via e-mail
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  async function handleSendEmail() {
    const emails = recipientEmails
      .split(',')
      .map(e => e.trim())
      .filter(e => e.length > 0);
    
    if (emails.length === 0) {
      toast.error('Indtast mindst én modtager-email');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const invalidEmails = emails.filter(e => !emailRegex.test(e));
    if (invalidEmails.length > 0) {
      toast.error(`Ugyldig email-adresse: ${invalidEmails.join(', ')}`);
      return;
    }

    setIsSendingEmail(true);
    try {
      // Get user info for sender name
      const { data: userData } = await supabase.auth.getUser();
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name, company_name')
        .eq('id', userData?.user?.id || '')
        .single();

      const senderName = profile?.full_name || profile?.company_name || userData?.user?.email || 'MOLA';

      // Generate the HTML content (reuse existing function, but without signature for email)
      const htmlContent = generatePDFHTML(true);

      const { data, error } = await supabase.functions.invoke('send-group-report', {
        body: {
          recipients: emails,
          subject: `Koncernoverblik - MOLA (${perspectiveLabel}) - ${format(new Date(), 'd. MMMM yyyy', { locale: da })}`,
          htmlContent,
          personalMessage: personalMessage.trim() || undefined,
          senderName,
          perspectiveLabel,
        },
      });

      if (error) throw error;

      toast.success(`Rapport sendt til ${emails.length} modtager${emails.length > 1 ? 'e' : ''}`);
      setRecipientEmails('');
      setPersonalMessage('');
    } catch (error: any) {
      console.error('Error sending email:', error);
      toast.error(error.message || 'Kunne ikke sende rapporten. Prøv igen.');
    } finally {
      setIsSendingEmail(false);
    }
  }
}
