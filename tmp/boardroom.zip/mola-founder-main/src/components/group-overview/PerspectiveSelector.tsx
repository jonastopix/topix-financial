import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Building2, Layers, Target } from 'lucide-react';
import type { GroupFund } from '@/hooks/useGroupOverview';

export type PerspectiveType = 'total' | 'fund' | 'mola';

interface PerspectiveSelectorProps {
  perspective: PerspectiveType;
  onPerspectiveChange: (value: PerspectiveType) => void;
  selectedFundId: string | null;
  onSelectedFundChange: (fundId: string | null) => void;
  funds: GroupFund[];
}

export function PerspectiveSelector({
  perspective,
  onPerspectiveChange,
  selectedFundId,
  onSelectedFundChange,
  funds,
}: PerspectiveSelectorProps) {
  const perspectiveOptions = [
    { value: 'total' as const, label: 'Koncern Total', icon: Layers },
    { value: 'fund' as const, label: 'Fond-specifik', icon: Building2 },
    { value: 'mola' as const, label: 'Mola Invest ApS', icon: Target },
  ];

  return (
    <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground whitespace-nowrap">Perspektiv:</span>
        <Select value={perspective} onValueChange={(v) => onPerspectiveChange(v as PerspectiveType)}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {perspectiveOptions.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>
                <div className="flex items-center gap-2">
                  <opt.icon className="h-4 w-4" />
                  <span>{opt.label}</span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {perspective === 'fund' && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground whitespace-nowrap">Fond:</span>
          <Select 
            value={selectedFundId || ''} 
            onValueChange={(v) => onSelectedFundChange(v || null)}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Vælg fond..." />
            </SelectTrigger>
            <SelectContent>
              {funds.map(fund => (
                <SelectItem key={fund.id} value={fund.id}>
                  {fund.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {perspective === 'mola' && (
        <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
          Tal vægtet med Mola Invest ApS's ejerandel i hver fond
        </span>
      )}
    </div>
  );
}
