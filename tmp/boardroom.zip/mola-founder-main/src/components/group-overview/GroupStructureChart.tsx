import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Building2, Briefcase, ChevronDown, ChevronRight, List, Network, ExternalLink } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';
import { cn } from '@/lib/utils';
import type { GroupFund } from '@/hooks/useGroupOverview';
import { OrgChartView } from './OrgChartView';

interface GroupStructureChartProps {
  funds: GroupFund[];
}

type ViewMode = 'list' | 'orgchart';

// Status values that count as "active" investments
const ACTIVE_STATUSES = ['active', 'new_investment', 'due_diligence'];

export function GroupStructureChart({ funds }: GroupStructureChartProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('list');
  const [expandedFunds, setExpandedFunds] = useState<Set<string>>(new Set(funds.map(f => f.id)));
  const [includeExits, setIncludeExits] = useState(false);
  const navigate = useNavigate();

  // Default: show only active. Toggle on = include exits
  const filteredFunds = funds.map(fund => {
    const displayCompanies = includeExits 
      ? fund.companies
      : fund.companies.filter(c => ACTIVE_STATUSES.includes(c.status));
    
    return {
      ...fund,
      companies: displayCompanies,
      companyCount: displayCompanies.length,
      totalInvested: displayCompanies.reduce((sum, c) => sum + c.investedAmount, 0)
    };
  }).filter(fund => fund.companies.length > 0 || includeExits);

  const toggleFund = (fundId: string) => {
    const newExpanded = new Set(expandedFunds);
    if (newExpanded.has(fundId)) {
      newExpanded.delete(fundId);
    } else {
      newExpanded.add(fundId);
    }
    setExpandedFunds(newExpanded);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-500/10 text-green-700 border-green-200';
      case 'exited': return 'bg-blue-500/10 text-blue-700 border-blue-200';
      case 'bankruptcy': return 'bg-red-500/10 text-red-700 border-red-200';
      case 'new_investment': return 'bg-amber-500/10 text-amber-700 border-amber-200';
      case 'due_diligence': return 'bg-purple-500/10 text-purple-700 border-purple-200';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Aktiv';
      case 'exited': return 'Exited';
      case 'bankruptcy': return 'Konkurs';
      case 'new_investment': return 'Ny investering';
      case 'due_diligence': return 'Due Diligence';
      case 'rejected': return 'Afvist';
      default: return status;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Koncernstruktur
          </CardTitle>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2">
              <Switch
                id="active-filter"
                checked={includeExits}
                onCheckedChange={setIncludeExits}
              />
              <Label htmlFor="active-filter" className="text-sm text-muted-foreground cursor-pointer">
                Inkluder exits
              </Label>
            </div>
            <ToggleGroup 
              type="single" 
              value={viewMode} 
              onValueChange={(value) => value && setViewMode(value as ViewMode)}
              className="bg-muted rounded-lg p-1"
            >
              <ToggleGroupItem value="list" aria-label="Liste visning" className="data-[state=on]:bg-background px-3">
                <List className="h-4 w-4 mr-1" />
                <span className="text-sm">Liste</span>
              </ToggleGroupItem>
              <ToggleGroupItem value="orgchart" aria-label="Org-diagram visning" className="data-[state=on]:bg-background px-3">
                <Network className="h-4 w-4 mr-1" />
                <span className="text-sm">Org-diagram</span>
              </ToggleGroupItem>
            </ToggleGroup>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {viewMode === 'orgchart' ? (
          <OrgChartView funds={filteredFunds} includeExits={includeExits} />
        ) : (
          <>
            {filteredFunds.map((fund) => (
              <div key={fund.id} className="border rounded-lg overflow-hidden">
                {/* Fund header */}
                <button
                  onClick={() => toggleFund(fund.id)}
                  className="w-full flex items-center justify-between p-4 bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {expandedFunds.has(fund.id) ? (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    )}
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Briefcase className="h-5 w-5 text-primary" />
                    </div>
                    <div className="text-left">
                      <p className="font-semibold">{fund.name}</p>
                      <p className="text-xs text-muted-foreground">CVR: {fund.cvr}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-right">
                    <div>
                      <p className="text-sm font-medium">{fund.companyCount} selskaber</p>
                      <p className="text-xs text-muted-foreground">
                        Investeret: {formatCurrency(fund.totalInvested)}
                      </p>
                    </div>
                  </div>
                </button>

                {/* Companies under fund */}
                {expandedFunds.has(fund.id) && fund.companies.length > 0 && (
                  <div className="border-t divide-y">
                    {fund.companies.map((company) => {
                      const isExited = company.status === 'exited';
                      
                      return (
                        <div 
                          key={company.id} 
                          className={cn(
                            "p-4 pl-14 flex items-center justify-between hover:bg-muted/40 transition-colors cursor-pointer",
                            isExited && "opacity-60"
                          )}
                          onClick={() => navigate(`/company/${company.id}`)}
                        >
                          <div className="flex items-center gap-3">
                            <div className="p-1.5 rounded bg-muted">
                              <Building2 className="h-4 w-4 text-muted-foreground" />
                            </div>
                            <div>
                              <p className={cn("font-medium text-sm", isExited && "line-through decoration-1")}>
                                {company.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {company.cvr ? `CVR: ${company.cvr}` : 'Intet CVR'}
                                {company.city && ` • ${company.city}`}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right text-sm">
                              <p className="font-medium">{formatCurrency(company.investedAmount)}</p>
                              <p className="text-xs text-muted-foreground">
                                {company.ownershipPct.toFixed(1)}% ejerandel
                              </p>
                            </div>
                            <Badge 
                              variant="outline" 
                              className={cn('text-xs', getStatusColor(company.status))}
                            >
                              {getStatusLabel(company.status)}
                            </Badge>
                            <ExternalLink className="h-4 w-4 text-muted-foreground" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {expandedFunds.has(fund.id) && fund.companies.length === 0 && (
                  <div className="p-4 pl-14 text-sm text-muted-foreground">
                    Ingen selskaber i denne fond
                  </div>
                )}
              </div>
            ))}

            {funds.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                Ingen fonde fundet
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
