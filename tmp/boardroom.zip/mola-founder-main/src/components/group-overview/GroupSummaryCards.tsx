import { Card, CardContent } from '@/components/ui/card';
import { Building2, TrendingUp, Wallet, PiggyBank, ArrowUpRight, History } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface GroupSummaryCardsProps {
  // Active portfolio
  activeCompanyCount: number;
  activeInvested: number;
  activeValue: number;
  // Exited
  exitedCompanyCount: number;
  exitedInvested: number;
  // All time
  totalInvestedAllTime: number;
  totalDividends: number;
  totalExitProceeds: number;
  dpi: number;
  tvpi: number;
  // Perspective info
  perspectiveLabel?: string;
  isMolaPerspective?: boolean;
}

export function GroupSummaryCards({
  activeCompanyCount,
  activeInvested,
  activeValue,
  exitedCompanyCount,
  exitedInvested,
  totalInvestedAllTime,
  totalDividends,
  totalExitProceeds,
  dpi,
  tvpi,
  perspectiveLabel,
  isMolaPerspective = false
}: GroupSummaryCardsProps) {
  const labelSuffix = isMolaPerspective ? ' (Mola-andel)' : '';
  
  return (
    <TooltipProvider delayDuration={200}>
      {/* Perspective indicator */}
      {perspectiveLabel && perspectiveLabel !== 'Koncern Total' && (
        <div className="mb-4 flex items-center gap-2">
          <span className="text-sm font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
            Viser: {perspectiveLabel}
          </span>
        </div>
      )}
      
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        {/* Active companies */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-blue-500/10">
              <Building2 className="h-4 w-4 text-blue-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">Aktive selskaber</p>
              <Tooltip>
                <TooltipTrigger asChild>
                  <p className="text-lg font-bold truncate pr-10 cursor-help">
                    {activeCompanyCount}
                  </p>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{exitedCompanyCount} exits historisk</p>
                  <p className="text-xs text-muted-foreground">Total: {activeCompanyCount + exitedCompanyCount} investeringer</p>
                </TooltipContent>
              </Tooltip>
              {exitedCompanyCount > 0 && (
                <p className="text-[10px] text-muted-foreground truncate">
                  + {exitedCompanyCount} exits
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Active invested */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-primary/10">
              <Wallet className="h-4 w-4 text-primary" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">
                Investeret (aktiv){labelSuffix}
              </p>
              <Tooltip>
                <TooltipTrigger asChild>
                  <p className="text-lg font-bold truncate pr-10 cursor-help">
                    {formatCurrency(activeInvested)}
                  </p>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Aktiv portefølje: {formatCurrency(activeInvested)}</p>
                  <p>Exits: {formatCurrency(exitedInvested)}</p>
                  <p className="font-medium border-t pt-1 mt-1">Total historisk: {formatCurrency(totalInvestedAllTime)}</p>
                  {isMolaPerspective && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Vægtet med Mola Invest ApS's ejerandel
                    </p>
                  )}
                </TooltipContent>
              </Tooltip>
              <p className="text-[10px] text-muted-foreground truncate">
                I aktiv portefølje
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Portfolio value (active only) */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-green-500/10">
              <TrendingUp className="h-4 w-4 text-green-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">
                Porteføljeværdi{labelSuffix}
              </p>
              <p className="text-lg font-bold truncate pr-10">
                {formatCurrency(activeValue)}
              </p>
              <p className="text-[10px] text-muted-foreground truncate">
                Baseret på seneste værdiansættelser
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Dividends received */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-purple-500/10">
              <PiggyBank className="h-4 w-4 text-purple-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">
                Udbytter modtaget{labelSuffix}
              </p>
              <p className="text-lg font-bold truncate pr-10">
                {formatCurrency(totalDividends)}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Exit proceeds */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-amber-500/10">
              <ArrowUpRight className="h-4 w-4 text-amber-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">
                Exit-provenu{labelSuffix}
              </p>
              <p className="text-lg font-bold truncate pr-10">
                {formatCurrency(totalExitProceeds)}
              </p>
              {exitedCompanyCount > 0 && (
                <p className="text-[10px] text-muted-foreground truncate">
                  Fra {exitedCompanyCount} exits
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* DPI */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-emerald-500/10">
              <History className="h-4 w-4 text-emerald-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">DPI</p>
              <Tooltip>
                <TooltipTrigger asChild>
                  <p className="text-lg font-bold truncate pr-10 cursor-help">
                    {dpi.toFixed(2)}x
                  </p>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="font-medium">Distributions to Paid-In</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    (Udbytte + Exits) / Total investeret
                  </p>
                  <p className="text-xs mt-1">
                    ({formatCurrency(totalDividends + totalExitProceeds)}) / ({formatCurrency(totalInvestedAllTime)})
                  </p>
                </TooltipContent>
              </Tooltip>
              <p className="text-[10px] text-muted-foreground truncate">
                Distributions to Paid-In
              </p>
            </div>
          </CardContent>
        </Card>

        {/* TVPI */}
        <Card className="relative overflow-hidden">
          <CardContent className="p-4">
            <div className="absolute top-3 right-3 p-2 rounded-lg bg-cyan-500/10">
              <TrendingUp className="h-4 w-4 text-cyan-500" />
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground font-medium">TVPI</p>
              <Tooltip>
                <TooltipTrigger asChild>
                  <p className="text-lg font-bold truncate pr-10 cursor-help">
                    {tvpi.toFixed(2)}x
                  </p>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="font-medium">Total Value to Paid-In</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    (Distributions + Aktiv værdi) / Total investeret
                  </p>
                  <p className="text-xs mt-1">
                    ({formatCurrency(totalDividends + totalExitProceeds + activeValue)}) / ({formatCurrency(totalInvestedAllTime)})
                  </p>
                </TooltipContent>
              </Tooltip>
              <p className="text-[10px] text-muted-foreground truncate">
                Total Value to Paid-In
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
}
