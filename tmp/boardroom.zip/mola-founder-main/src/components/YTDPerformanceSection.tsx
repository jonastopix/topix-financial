import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, DollarSign, Activity, Target, Percent } from 'lucide-react';
import { AnimatedNumber } from '@/components/AnimatedNumber';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Info } from 'lucide-react';

interface YTDPerformanceProps {
  data: {
    ytdRevenue: number;
    ytdEBITDA: number;
    budgetYTDRevenue: number;
    budgetYTDEBITDA: number;
    revenueVsBudgetPct: number;
    ebitdaVsBudgetPct: number;
    ebitdaMarginYTD: number;
    marketingPctYTD: number;
    revenueROI: number;
    ebitdaROI: number;
    isOnTarget: boolean;
  };
  year: number;
  periodLabel?: string;
}

export function YTDPerformanceSection({ data, year, periodLabel }: YTDPerformanceProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value) + ' kr';
  };

  const formatPercent = (value: number, decimals: number = 1) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  const getTrendBadge = (pct: number) => {
    if (pct >= 0) {
      return (
        <Badge variant="success" className="ml-2">
          <TrendingUp className="h-3 w-3 mr-1" />
          +{formatPercent(pct)}%
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive" className="ml-2">
          <TrendingDown className="h-3 w-3 mr-1" />
          {formatPercent(pct)}%
        </Badge>
      );
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">{periodLabel || `YTD Performance ${year}`}</h2>
        <Badge variant={data.isOnTarget ? 'success' : 'warning'} className="text-sm">
          <Target className="h-4 w-4 mr-1" />
          {data.isOnTarget ? 'On Target' : 'Off Target'}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6 bg-gradient-to-br from-success/10 to-background border-success/20">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">Omsætning YTD</p>
              <p className="text-3xl font-bold">
                {formatCurrency(data.ytdRevenue)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Budget: {formatCurrency(data.budgetYTDRevenue)}
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-success" />
          </div>
          {getTrendBadge(data.revenueVsBudgetPct)}
        </Card>

        <Card className="p-6 bg-gradient-to-br from-primary/10 to-background border-primary/20">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground mb-1">EBITDA YTD</p>
              <p className="text-3xl font-bold">
                {formatCurrency(data.ytdEBITDA)}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Budget: {formatCurrency(data.budgetYTDEBITDA)}
              </p>
            </div>
            <Activity className="h-8 w-8 text-primary" />
          </div>
          {getTrendBadge(data.ebitdaVsBudgetPct)}
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Nøgletal</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <TooltipProvider>
            <div className="space-y-1">
              <div className="flex items-center gap-1">
                <p className="text-sm text-muted-foreground">Revenue ROI</p>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">YTD Omsætning / Marketing Cost × 100</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-2xl font-bold text-success">
                {formatPercent(data.revenueROI, 0)}%
              </p>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1">
                <p className="text-sm text-muted-foreground">EBITDA ROI</p>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">YTD EBITDA / Marketing Cost × 100</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-2xl font-bold text-primary">
                {formatPercent(data.ebitdaROI, 0)}%
              </p>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1">
                <p className="text-sm text-muted-foreground">EBITDA Margin</p>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">YTD EBITDA / YTD Omsætning × 100</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-2xl font-bold">
                {formatPercent(data.ebitdaMarginYTD, 1)}%
              </p>
            </div>

            <div className="space-y-1">
              <div className="flex items-center gap-1">
                <p className="text-sm text-muted-foreground">Marketing %</p>
                <Tooltip>
                  <TooltipTrigger>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Marketing Cost / YTD Omsætning × 100</p>
                  </TooltipContent>
                </Tooltip>
              </div>
              <p className="text-2xl font-bold text-warning">
                {formatPercent(data.marketingPctYTD, 1)}%
              </p>
            </div>
          </TooltipProvider>
        </div>
      </Card>
    </div>
  );
}
