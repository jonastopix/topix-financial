import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building2, TrendingUp, TrendingDown, ChevronRight } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';
import { PortfolioTrendChart } from './PortfolioTrendChart';
import { useRole } from '@/contexts/RoleContext';
import { useNavigate } from 'react-router-dom';

interface PortfolioFinancialOverviewProps {
  data: {
    ytdRevenue: number;
    ytdEBITDA: number;
    budgetYTDRevenue: number;
    budgetYTDEBITDA: number;
    revenueVsBudgetPct: number;
    ebitdaVsBudgetPct: number;
    ebitdaMarginYTD: number;
    marketingPctYTD: number;
    revenueROI: number;
    ebitdaROI: number;
    isOnTarget: boolean;
    reportedMonths: number;
  };
  companies: Array<{
    company: { id: string; name: string };
    ytdPerformance: any;
  }>;
  monthlyTrend: Array<{
    period: string;
    period_year: number;
    period_month: number;
    revenue: number;
    ebitda: number;
    margin: number;
  }>;
  year: number;
}

export function PortfolioFinancialOverview({ data, companies, monthlyTrend, year }: PortfolioFinancialOverviewProps) {
  const { setSelectedCompanyId } = useRole();
  const navigate = useNavigate();

  const formatCurrencyValue = (value: number) => formatCurrency(value, 0);
  const formatPercent = (value: number, decimals: number = 1) => `${value.toFixed(decimals)}%`;

  const getTrendBadge = (pct: number) => {
    const isPositive = pct >= 0;
    return (
      <Badge variant={isPositive ? 'default' : 'destructive'} className="ml-2">
        {isPositive ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
        {formatPercent(Math.abs(pct))}
      </Badge>
    );
  };

  const handleCompanyClick = (companyId: string) => {
    setSelectedCompanyId(companyId);
    navigate('/financial-dashboard');
  };

  const activeCompaniesCount = companies.filter(c => c.ytdPerformance !== null).length;

  return (
    <div className="space-y-6 pb-24 md:pb-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold">Portfolio Oversigt</h2>
          <p className="text-muted-foreground mt-1 text-sm sm:text-base">
            YTD {year} • {activeCompaniesCount} aktive selskaber med data
          </p>
        </div>
        <Badge variant={data.isOnTarget ? 'default' : 'secondary'} className="text-sm sm:text-lg px-3 sm:px-4 py-1 sm:py-2 w-fit">
          {data.isOnTarget ? 'On Target' : 'Off Target'}
        </Badge>
      </div>

      {/* Main Metrics */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="p-6">
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total YTD Revenue</p>
              <p className="text-2xl lg:text-4xl font-bold mt-2 truncate">{formatCurrencyValue(data.ytdRevenue)}</p>
              <div className="flex items-center mt-2">
                <p className="text-sm text-muted-foreground">
                  Budget: {formatCurrencyValue(data.budgetYTDRevenue)}
                </p>
                {getTrendBadge(data.revenueVsBudgetPct)}
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="space-y-4">
            <div>
              <p className="text-sm font-medium text-muted-foreground">Total YTD EBITDA</p>
              <p className="text-2xl lg:text-4xl font-bold mt-2 truncate">{formatCurrencyValue(data.ytdEBITDA)}</p>
              <div className="flex items-center mt-2">
                <p className="text-sm text-muted-foreground">
                  Budget: {formatCurrencyValue(data.budgetYTDEBITDA)}
                </p>
                {getTrendBadge(data.ebitdaVsBudgetPct)}
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Portfolio Trend Chart */}
      <PortfolioTrendChart data={monthlyTrend} />

      {/* Key Ratios */}
      <Card className="p-4 sm:p-6">
        <h3 className="text-lg font-semibold mb-4">Portfolio Nøgletal</h3>
        <div className="grid gap-4 sm:gap-6 grid-cols-2 md:grid-cols-4">
          <div>
            <p className="text-sm text-muted-foreground mb-1">EBITDA Margin</p>
            <p className="text-lg sm:text-xl lg:text-2xl font-bold truncate">{formatPercent(data.ebitdaMarginYTD)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Marketing %</p>
            <p className="text-lg sm:text-xl lg:text-2xl font-bold truncate">{formatPercent(data.marketingPctYTD)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Revenue ROI</p>
            <p className="text-lg sm:text-xl lg:text-2xl font-bold truncate">{formatPercent(data.revenueROI, 0)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">EBITDA ROI</p>
            <p className="text-lg sm:text-xl lg:text-2xl font-bold truncate">{formatPercent(data.ebitdaROI, 0)}</p>
          </div>
        </div>
      </Card>

      {/* Company Breakdown */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Selskaber i Portfolio</h3>
        <div className="space-y-3">
          {companies
            .filter(c => c.ytdPerformance !== null)
            .sort((a, b) => b.ytdPerformance!.ytdRevenue - a.ytdPerformance!.ytdRevenue)
            .map(({ company, ytdPerformance }) => (
              <div
                key={company.id}
                onClick={() => handleCompanyClick(company.id)}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-accent/50 hover:border-primary/50 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3 flex-1">
                  <Building2 className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                  <div className="flex-1">
                    <p className="font-medium group-hover:text-primary transition-colors">{company.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {ytdPerformance!.reportedMonths} måneder rapporteret
                    </p>
                  </div>
                </div>
                <div className="text-right flex items-center gap-3">
                  <div>
                    <p className="font-semibold">{formatCurrencyValue(ytdPerformance!.ytdRevenue)}</p>
                    <p className="text-sm text-muted-foreground">
                      EBITDA: {formatCurrencyValue(ytdPerformance!.ytdEBITDA)}
                    </p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </div>
            ))}
        </div>
      </Card>
    </div>
  );
}
