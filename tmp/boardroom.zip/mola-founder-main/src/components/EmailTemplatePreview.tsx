import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { RotateCcw } from 'lucide-react';

interface EmailTemplatePreviewProps {
  htmlBody: string;
  variables: string[];
}

const getDefaultValue = (variable: string): string => {
  const defaults: Record<string, string> = {
    'inviter_name': 'Morten Larsen',
    'role_name': 'Fund Partner',
    'company_name': 'Test Virksomhed A/S',
    'fund_name': 'MOLA Fund I',
    'invitation_url': 'https://founder.molainvest.dk/accept-invitation/abc123',
    'status_class': 'received',
    'status_title': 'Din anmodning er modtaget',
    'status_message': 'Vi behandler din anmodning og vender tilbage snarest.',
    'request_type': 'Dataeksport',
    'download_url': 'https://founder.molainvest.dk/download/data-export-123',
    'rejection_reason': '',
  };
  return defaults[variable] || `Test ${variable}`;
};

export function EmailTemplatePreview({ htmlBody, variables }: EmailTemplatePreviewProps) {
  const [variableValues, setVariableValues] = useState<Record<string, string>>(
    () => variables.reduce((acc, variable) => ({
      ...acc,
      [variable]: getDefaultValue(variable)
    }), {})
  );

  const replaceVariables = (html: string) => {
    let result = html;
    variables.forEach((variable) => {
      const value = variableValues[variable] || `{{${variable}}}`;
      // Replace simple variables like {{variable}}
      result = result.replace(new RegExp(`{{${variable}}}`, 'g'), value);
      
      // Handle conditional variables like {{#variable}}...{{/variable}}
      if (value && value !== `{{${variable}}}`) {
        result = result.replace(
          new RegExp(`{{#${variable}}}([\\s\\S]*?){{/${variable}}}`, 'g'),
          '$1'
        );
      } else {
        result = result.replace(
          new RegExp(`{{#${variable}}}[\\s\\S]*?{{/${variable}}}`, 'g'),
          ''
        );
      }
    });
    return result;
  };

  const resetToDefaults = () => {
    setVariableValues(
      variables.reduce((acc, variable) => ({
        ...acc,
        [variable]: getDefaultValue(variable)
      }), {})
    );
  };

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-base">Test Værdier</Label>
          <Button 
            variant="outline" 
            size="sm"
            onClick={resetToDefaults}
            className="h-8"
          >
            <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
            Reset til Test Data
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {variables.map((variable) => (
            <div key={variable} className="space-y-1.5">
              <Label htmlFor={variable} className="text-sm font-medium">{variable}</Label>
              <Input
                id={variable}
                value={variableValues[variable] || ''}
                onChange={(e) => setVariableValues({ ...variableValues, [variable]: e.target.value })}
                placeholder={`Test ${variable}...`}
                className="h-9"
              />
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-base">Preview</Label>
        <Card className="bg-muted/50 p-0 overflow-hidden">
          <iframe
            className="w-full h-[600px] border-0 bg-background"
            srcDoc={replaceVariables(htmlBody)}
            title="Email Preview"
            sandbox="allow-same-origin"
          />
        </Card>
      </div>
    </div>
  );
}
