import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Calendar, Info } from 'lucide-react';
import { AnimatedNumber } from '@/components/AnimatedNumber';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface ForecastSectionProps {
  data: {
    reportedMonths: number;
    projectedRevenue: number;
    projectedEBITDA: number;
    projectedVsBudgetRevenuePct: number;
    projectedVsBudgetEBITDAPct: number;
    fullYearBudgetRevenue: number;
    fullYearBudgetEBITDA: number;
    confidenceLevel: 'low' | 'medium' | 'high';
    method: 'simple-runrate' | 'trend-adjusted' | 'advanced-seasonal' | 'insufficient-data';
    bestCaseRevenue?: number;
    worstCaseRevenue?: number;
    bestCaseEBITDA?: number;
    worstCaseEBITDA?: number;
  };
  year: number;
}

export function ForecastSection({ data, year }: ForecastSectionProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value) + ' kr';
  };

  const formatPercent = (value: number, decimals: number = 1) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals,
    }).format(value);
  };

  const getTrendBadge = (pct: number, hasBudget: boolean) => {
    if (!hasBudget) {
      return (
        <Badge variant="secondary" className="ml-2">
          <Calendar className="h-3 w-3 mr-1" />
          {data.reportedMonths} mdr run-rate
        </Badge>
      );
    }
    
    if (pct >= 0) {
      return (
        <Badge variant="success" className="ml-2">
          <TrendingUp className="h-3 w-3 mr-1" />
          +{formatPercent(pct)}%
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive" className="ml-2">
          <TrendingDown className="h-3 w-3 mr-1" />
          {formatPercent(pct)}%
        </Badge>
      );
    }
  };

  const hasBudget = data.fullYearBudgetRevenue > 0;

  const getConfidenceBadge = () => {
    const variants = {
      high: { variant: 'success' as const, label: 'Høj Confidence' },
      medium: { variant: 'default' as const, label: 'Medium Confidence' },
      low: { variant: 'secondary' as const, label: 'Lav Confidence' }
    };
    return variants[data.confidenceLevel];
  };

  const getMethodLabel = () => {
    const labels = {
      'simple-runrate': 'Simpel run-rate',
      'trend-adjusted': 'Trend-justeret',
      'advanced-seasonal': 'Avanceret med sæson',
      'insufficient-data': 'Utilstrækkelig data'
    };
    return labels[data.method];
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-2xl font-bold">Helårs Forecast {year}</h2>
        <div className="flex items-center gap-2">
          <Badge variant={getConfidenceBadge().variant}>
            {getConfidenceBadge().label}
          </Badge>
          <Badge variant="outline" className="text-sm">
            <Calendar className="h-4 w-4 mr-1" />
            {data.reportedMonths} mdr
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6 bg-gradient-to-br from-primary/10 to-background border-primary/20">
          <TooltipProvider>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-1 mb-1">
                  <p className="text-sm font-medium text-muted-foreground">Projected Omsætning</p>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-3 w-3 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">Gennemsnitlig månedlig omsætning × 12</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-3xl font-bold">
                  {formatCurrency(data.projectedRevenue)}
                </p>
                {hasBudget && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Budget: {formatCurrency(data.fullYearBudgetRevenue)}
                  </p>
                )}
              </div>
            </div>
            {getTrendBadge(data.projectedVsBudgetRevenuePct, hasBudget)}
          </TooltipProvider>
        </Card>

        <Card className="p-6 bg-gradient-to-br from-success/10 to-background border-success/20">
          <TooltipProvider>
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center gap-1 mb-1">
                  <p className="text-sm font-medium text-muted-foreground">Projected EBITDA</p>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-3 w-3 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs">Gennemsnitlig månedlig EBITDA × 12</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
                <p className="text-3xl font-bold">
                  {formatCurrency(data.projectedEBITDA)}
                </p>
                {hasBudget && (
                  <p className="text-xs text-muted-foreground mt-1">
                    Budget: {formatCurrency(data.fullYearBudgetEBITDA)}
                  </p>
                )}
              </div>
            </div>
            {getTrendBadge(data.projectedVsBudgetEBITDAPct, hasBudget)}
          </TooltipProvider>
        </Card>
      </div>

      {/* Forecast Range */}
      {data.bestCaseRevenue && data.worstCaseRevenue && (
        <Card className="p-4 bg-gradient-to-br from-muted/50 to-background">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-muted-foreground" />
              <p className="text-sm font-medium">Forecast Range (Most Likely Scenario)</p>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Omsætning Range</p>
                <p className="font-medium">
                  {formatCurrency(data.worstCaseRevenue)} - {formatCurrency(data.bestCaseRevenue)}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-1">EBITDA Range</p>
                <p className="font-medium">
                  {formatCurrency(data.worstCaseEBITDA || 0)} - {formatCurrency(data.bestCaseEBITDA || 0)}
                </p>
              </div>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-4 bg-muted/50">
        <p className="text-sm text-muted-foreground text-center">
          <Info className="h-4 w-4 inline mr-1" />
          Metode: <strong>{getMethodLabel()}</strong> baseret på {data.reportedMonths} rapporterede måneder
          {data.method === 'advanced-seasonal' && ' med sæsonmønstre fra tidligere år'}
        </p>
      </Card>
    </div>
  );
}
