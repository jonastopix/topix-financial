import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useRecentMilestones } from '@/hooks/useMilestones';
import { TrendingUp, Trophy, Users, DollarSign, Zap, Star } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';

interface MilestoneInsightsWidgetProps {
  companyId?: string;
}

const getMilestoneIcon = (type: string) => {
  switch (type) {
    case 'best_month_revenue':
      return <DollarSign className="h-5 w-5 text-primary" />;
    case 'best_month_ebitda':
      return <TrendingUp className="h-5 w-5 text-success" />;
    case 'best_month_customers':
      return <Users className="h-5 w-5 text-info" />;
    case 'fastest_growth':
      return <Zap className="h-5 w-5 text-warning" />;
    case 'first_profitable':
      return <Star className="h-5 w-5 text-success" />;
    case 'revenue_milestone':
      return <Trophy className="h-5 w-5 text-primary" />;
    default:
      return <Trophy className="h-5 w-5" />;
  }
};

const getMilestoneTitle = (type: string, metadata?: Record<string, any>) => {
  switch (type) {
    case 'best_month_revenue':
      return 'Din bedste måned nogensinde! 🎉';
    case 'best_month_ebitda':
      return 'Bedste EBITDA nogensinde! 💰';
    case 'best_month_customers':
      return 'Flest nye kunder nogensinde! 👥';
    case 'fastest_growth':
      return 'Hurtigste vækst! 🚀';
    case 'first_profitable':
      return 'Første profitable måned! 🌟';
    case 'revenue_milestone':
      return `${metadata?.threshold_label || 'Revenue'} Milestone! 🏆`;
    default:
      return 'New Milestone!';
  }
};

const getMilestoneDescription = (
  type: string,
  value: number,
  previousBest?: number,
  metadata?: Record<string, any>
) => {
  const improvement = metadata?.improvement_pct;
  const monthName = metadata?.period_month 
    ? new Date(2024, metadata.period_month - 1).toLocaleString('da-DK', { month: 'long' })
    : '';

  switch (type) {
    case 'best_month_revenue':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">{formatCurrency(value)}</div>
          {previousBest && (
            <div className="text-sm text-muted-foreground">
              Forrige best: {formatCurrency(previousBest)}
              {improvement && <span className="text-success ml-2">+{improvement}%</span>}
            </div>
          )}
          <div className="text-xs text-muted-foreground mt-1">{monthName} {metadata?.period_year}</div>
        </div>
      );
    case 'best_month_ebitda':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">{formatCurrency(value)}</div>
          {previousBest && (
            <div className="text-sm text-muted-foreground">
              Forrige best: {formatCurrency(previousBest)}
              {improvement && <span className="text-success ml-2">+{improvement}%</span>}
            </div>
          )}
          <div className="text-xs text-muted-foreground mt-1">{monthName} {metadata?.period_year}</div>
        </div>
      );
    case 'best_month_customers':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">{value} nye kunder</div>
          {previousBest && (
            <div className="text-sm text-muted-foreground">
              Forrige best: {previousBest} kunder
              {metadata?.improvement && <span className="text-success ml-2">+{metadata.improvement}</span>}
            </div>
          )}
          <div className="text-xs text-muted-foreground mt-1">{monthName} {metadata?.period_year}</div>
        </div>
      );
    case 'fastest_growth':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">+{metadata?.growth_pct}% vækst</div>
          {previousBest && (
            <div className="text-sm text-muted-foreground">
              Forrige best: +{previousBest.toFixed(1)}%
            </div>
          )}
          <div className="text-xs text-muted-foreground mt-1">Month-over-month</div>
        </div>
      );
    case 'first_profitable':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">{formatCurrency(value)} EBITDA</div>
          <div className="text-sm text-success">Din første profitable måned!</div>
          <div className="text-xs text-muted-foreground mt-1">{monthName} {metadata?.period_year}</div>
        </div>
      );
    case 'revenue_milestone':
      return (
        <div>
          <div className="text-2xl font-bold text-foreground">{metadata?.threshold_label}</div>
          <div className="text-sm text-muted-foreground">Første gang over denne grænse!</div>
          <div className="text-xs text-muted-foreground mt-1">{monthName} {metadata?.period_year}</div>
        </div>
      );
    default:
      return <div className="text-sm text-muted-foreground">{formatCurrency(value)}</div>;
  }
};

export default function MilestoneInsightsWidget({ companyId }: MilestoneInsightsWidgetProps) {
  const { data: milestones, isLoading } = useRecentMilestones(companyId, 5);

  if (isLoading) {
    return (
      <Card className="min-h-[400px]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Milestones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex gap-4 p-4 rounded-lg border">
              <Skeleton className="h-12 w-12 rounded-lg flex-shrink-0" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-8 w-1/2" />
                <Skeleton className="h-4 w-1/3" />
              </div>
              <Skeleton className="h-6 w-16 rounded-full" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!milestones || milestones.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Milestones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            Ingen milestones endnu. Fortsæt med at rapportere dine tal, så tracker vi dine bedrifter!
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          🎉 Dine Seneste Milestones
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {milestones.map((milestone) => (
          <div
            key={milestone.id}
            className="flex gap-4 p-4 rounded-lg border border-border bg-card/50 hover:bg-accent/20 transition-colors"
          >
            <div className="flex-shrink-0 mt-1">
              {getMilestoneIcon(milestone.milestone_type)}
            </div>
            <div className="flex-1">
              <div className="font-semibold text-foreground mb-1">
                {getMilestoneTitle(milestone.milestone_type, milestone.metadata)}
              </div>
              {getMilestoneDescription(
                milestone.milestone_type,
                milestone.milestone_value,
                milestone.previous_best,
                milestone.metadata
              )}
            </div>
            <Badge variant="secondary" className="self-start">
              {new Date(milestone.achieved_at).toLocaleDateString('da-DK', {
                day: 'numeric',
                month: 'short'
              })}
            </Badge>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
