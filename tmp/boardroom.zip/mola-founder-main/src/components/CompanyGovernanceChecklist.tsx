import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ChevronDown, ChevronRight, AlertTriangle, CheckCircle2, Clock, FileText, MessageSquare } from 'lucide-react';
import { format, isPast, isBefore, addDays } from 'date-fns';
import { da } from 'date-fns/locale';
import { useCompanyGovernance, GovernanceProgressWithTemplate } from '@/hooks/useCompanyGovernance';
import { cn } from '@/lib/utils';

interface CompanyGovernanceChecklistProps {
  companyId: string;
  year?: number;
  fiscalYearEndMonth?: number;
  fiscalYearEndDay?: number;
  canManage?: boolean;
}

const CATEGORY_NAMES: Record<string, string> = {
  finansiel_kontrol: 'Finansiel Kontrol',
  forsikringer: 'Forsikringer',
  personale: 'Personale',
  compliance: 'Compliance',
};

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  finansiel_kontrol: '💰',
  forsikringer: '🛡️',
  personale: '👥',
  compliance: '📋',
};

export function CompanyGovernanceChecklist({
  companyId,
  year,
  fiscalYearEndMonth = 12,
  fiscalYearEndDay = 31,
  canManage = true,
}: CompanyGovernanceChecklistProps) {
  const currentYear = year || new Date().getFullYear();
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<GovernanceProgressWithTemplate | null>(null);
  const [note, setNote] = useState('');

  const {
    progress,
    isLoading,
    initializeProgress,
    updateProgress,
    stats,
  } = useCompanyGovernance(companyId, currentYear, fiscalYearEndMonth, fiscalYearEndDay);

  // Initialize progress when templates are loaded
  useEffect(() => {
    if (progress.length === 0 && !isLoading) {
      initializeProgress.mutate();
    }
  }, [progress.length, isLoading]);

  // Expand categories with overdue items by default
  useEffect(() => {
    if (progress.length > 0) {
      const categoriesWithOverdue = new Set(
        progress.filter(p => p.isOverdue).map(p => p.template.category)
      );
      // Also expand first category if none have overdue items
      if (categoriesWithOverdue.size === 0 && progress.length > 0) {
        categoriesWithOverdue.add(progress[0].template.category);
      }
      setExpandedCategories(categoriesWithOverdue);
    }
  }, [progress]);

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(category)) {
        next.delete(category);
      } else {
        next.add(category);
      }
      return next;
    });
  };

  const handleToggleComplete = (item: GovernanceProgressWithTemplate) => {
    if (!item.id) {
      // Need to initialize first
      initializeProgress.mutate();
      return;
    }
    
    if (!item.completed) {
      // Opening dialog to add optional note before completing
      setSelectedItem(item);
      setNote(item.notes || '');
      setNoteDialogOpen(true);
    } else {
      // Uncompleting - just toggle directly
      updateProgress.mutate({
        progressId: item.id,
        completed: false,
        notes: null,
      });
    }
  };

  const handleConfirmComplete = () => {
    if (!selectedItem?.id) return;
    
    updateProgress.mutate({
      progressId: selectedItem.id,
      completed: true,
      notes: note.trim() || null,
    });
    
    setNoteDialogOpen(false);
    setSelectedItem(null);
    setNote('');
  };

  const getDeadlineStatus = (item: GovernanceProgressWithTemplate) => {
    if (item.completed) {
      return { color: 'bg-success/10 text-success border-success/30', icon: CheckCircle2, text: 'Fuldført' };
    }
    
    const now = new Date();
    const deadline = item.deadline;
    
    if (isPast(deadline)) {
      return { color: 'bg-destructive/10 text-destructive border-destructive/30', icon: AlertTriangle, text: 'Overskredet' };
    }
    
    // Within 30 days
    if (isBefore(deadline, addDays(now, 30))) {
      return { color: 'bg-warning/10 text-warning border-warning/30', icon: Clock, text: 'Snart' };
    }
    
    return { color: 'bg-muted text-muted-foreground', icon: Clock, text: 'Planlagt' };
  };

  // Group by category
  const groupedProgress = progress.reduce((acc, item) => {
    const category = item.template.category;
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {} as Record<string, GovernanceProgressWithTemplate[]>);

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Indlæser governance checklist...
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Selskabs-Governance {currentYear}
            </CardTitle>
            <CardDescription>
              Årlig governance checklist med deadlines baseret på regnskabsår
            </CardDescription>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{stats.completionPercentage}%</div>
            <div className="text-sm text-muted-foreground">
              {stats.completedCount} af {stats.totalCount} punkter
            </div>
          </div>
        </div>
        <Progress value={stats.completionPercentage} className="mt-4" />
        
        {stats.overdueCount > 0 && (
          <div className="flex items-center gap-2 mt-3 p-3 rounded-lg bg-destructive/10 border border-destructive/30">
            <AlertTriangle className="h-4 w-4 text-destructive" />
            <span className="text-sm text-destructive font-medium">
              {stats.overdueCount} punkt{stats.overdueCount > 1 ? 'er' : ''} har overskredet deadline
            </span>
          </div>
        )}
      </CardHeader>
      
      <CardContent className="space-y-4">
        {Object.entries(groupedProgress).map(([category, items]) => {
          const isExpanded = expandedCategories.has(category);
          const categoryCompleted = items.filter(i => i.completed).length;
          const categoryTotal = items.length;
          const hasOverdue = items.some(i => i.isOverdue);
          
          return (
            <Collapsible key={category} open={isExpanded} onOpenChange={() => toggleCategory(category)}>
              <CollapsibleTrigger asChild>
                <Button
                  variant="ghost"
                  className={cn(
                    "w-full justify-between p-4 h-auto",
                    hasOverdue && "border-l-4 border-l-destructive"
                  )}
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                    <span className="text-lg">{CATEGORY_ICONS[category]}</span>
                    <span className="font-medium">{CATEGORY_NAMES[category] || category}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {hasOverdue && (
                      <Badge variant="destructive" className="text-xs">
                        Overskredet
                      </Badge>
                    )}
                    <Badge variant="secondary">
                      {categoryCompleted}/{categoryTotal}
                    </Badge>
                  </div>
                </Button>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="space-y-2 pl-4 pr-2 pb-2">
                {items.map((item) => {
                  const status = getDeadlineStatus(item);
                  const StatusIcon = status.icon;
                  
                  return (
                    <div
                      key={item.template_id}
                      className={cn(
                        "flex items-start gap-3 p-3 rounded-lg border transition-colors",
                        item.completed && "bg-muted/30 border-muted",
                        item.isOverdue && !item.completed && "border-destructive/50 bg-destructive/5"
                      )}
                    >
                      {canManage && (
                        <Checkbox
                          checked={item.completed || false}
                          onCheckedChange={() => handleToggleComplete(item)}
                          className="mt-1"
                          disabled={updateProgress.isPending}
                        />
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className={cn(
                              "font-medium",
                              item.completed && "line-through text-muted-foreground"
                            )}>
                              {item.template.item_name}
                            </div>
                            {item.template.description && (
                              <p className="text-sm text-muted-foreground mt-0.5">
                                {item.template.description}
                              </p>
                            )}
                          </div>
                          
                          <div className="flex items-center gap-2 flex-shrink-0">
                            {item.template.required && (
                              <Badge variant="outline" className="text-xs">
                                Påkrævet
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3 mt-2 text-sm">
                          <Badge variant="outline" className={cn("text-xs", status.color)}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {status.text}
                          </Badge>
                          <span className="text-muted-foreground">
                            Deadline: {format(item.deadline, 'd. MMMM yyyy', { locale: da })}
                          </span>
                          {item.completed && item.completed_at && (
                            <span className="text-success text-xs">
                              Fuldført {format(new Date(item.completed_at), 'd. MMM yyyy', { locale: da })}
                              {item.completedByName && ` af ${item.completedByName}`}
                            </span>
                          )}
                        </div>
                        
                        {item.notes && (
                          <div className="flex items-start gap-2 mt-2 p-2 rounded bg-muted/50">
                            <MessageSquare className="h-3 w-3 mt-0.5 text-muted-foreground flex-shrink-0" />
                            <p className="text-sm text-muted-foreground italic">
                              {item.notes}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </CollapsibleContent>
            </Collapsible>
          );
        })}
        
        {Object.keys(groupedProgress).length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            Ingen governance punkter fundet
          </div>
        )}
      </CardContent>
      
      {/* Note Dialog for completion */}
      <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Fuldfør punkt</DialogTitle>
            <DialogDescription>
              {selectedItem?.template.item_name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="completion-note">Note (valgfri)</Label>
              <Textarea
                id="completion-note"
                placeholder="Tilføj en note om hvad der blev gjort..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setNoteDialogOpen(false)}>
              Annuller
            </Button>
            <Button onClick={handleConfirmComplete} disabled={updateProgress.isPending}>
              Marker som fuldført
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
