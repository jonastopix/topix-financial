import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Building2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { CompanyActivitySheet } from './CompanyActivitySheet';
import { useIsMobile } from '@/hooks/use-mobile';

interface ActivityShortcutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ActivityShortcutDialog({ open, onOpenChange }: ActivityShortcutDialogProps) {
  const location = useLocation();
  const isMobile = useIsMobile();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<{ id: string; name: string } | null>(null);
  const [showActivitySheet, setShowActivitySheet] = useState(false);

  // Check if we're on a company page
  const companyIdMatch = location.pathname.match(/\/company\/([a-f0-9-]+)/i);
  const currentCompanyId = companyIdMatch?.[1];

  // Fetch current company if on company page
  const { data: currentCompany } = useQuery({
    queryKey: ['company-for-shortcut', currentCompanyId],
    queryFn: async () => {
      if (!currentCompanyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('id', currentCompanyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!currentCompanyId && open,
  });

  // Fetch all active companies for selection
  const { data: companies = [] } = useQuery({
    queryKey: ['companies-for-activity-shortcut', searchQuery],
    queryFn: async () => {
      let query = supabase
        .from('companies')
        .select('id, name, logo_url')
        .eq('is_active', true)
        .order('name');
      
      if (searchQuery) {
        query = query.ilike('name', `%${searchQuery}%`);
      }
      
      const { data, error } = await query.limit(20);
      if (error) throw error;
      return data || [];
    },
    enabled: open && !currentCompanyId,
  });

  // If on company page, skip selection and go directly to activity sheet
  useEffect(() => {
    if (open && currentCompany) {
      setSelectedCompany(currentCompany);
      setShowActivitySheet(true);
    }
  }, [open, currentCompany]);

  // Reset state when dialog closes
  useEffect(() => {
    if (!open) {
      setSearchQuery('');
      setSelectedCompany(null);
      setShowActivitySheet(false);
    }
  }, [open]);

  const handleCompanySelect = (company: { id: string; name: string }) => {
    setSelectedCompany(company);
    setShowActivitySheet(true);
  };

  const handleActivitySuccess = () => {
    setShowActivitySheet(false);
    onOpenChange(false);
  };

  const handleActivitySheetClose = () => {
    if (currentCompanyId) {
      // If we came from a company page, close everything
      onOpenChange(false);
    } else {
      // Otherwise, go back to company selection
      setShowActivitySheet(false);
      setSelectedCompany(null);
    }
  };

  // If showing activity sheet
  if (showActivitySheet && selectedCompany) {
    if (isMobile) {
      return (
        <Drawer open={open} onOpenChange={handleActivitySheetClose}>
          <DrawerContent className="max-h-[85vh]">
            <CompanyActivitySheet
              companyId={selectedCompany.id}
              companyName={selectedCompany.name}
              onSuccess={handleActivitySuccess}
            />
          </DrawerContent>
        </Drawer>
      );
    }

    return (
      <Sheet open={open} onOpenChange={handleActivitySheetClose}>
        <SheetContent side="right" className="w-[400px] sm:w-[450px]">
          <CompanyActivitySheet
            companyId={selectedCompany.id}
            companyName={selectedCompany.name}
            onSuccess={handleActivitySuccess}
          />
        </SheetContent>
      </Sheet>
    );
  }

  // Company selection dialog (only shown when not on a company page)
  return (
    <Dialog open={open && !currentCompanyId} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Registrer aktivitet</DialogTitle>
          <DialogDescription>
            Vælg et selskab for at registrere aktivitet
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Søg efter selskab..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              autoFocus
            />
          </div>

          <ScrollArea className="h-[300px]">
            <div className="space-y-1">
              {companies.map((company) => (
                <button
                  key={company.id}
                  onClick={() => handleCompanySelect(company)}
                  className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-accent transition-colors text-left"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={company.logo_url || undefined} alt={company.name} />
                    <AvatarFallback>
                      <Building2 className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <span className="font-medium">{company.name}</span>
                </button>
              ))}
              {companies.length === 0 && searchQuery && (
                <p className="text-center text-muted-foreground py-8">
                  Ingen selskaber fundet
                </p>
              )}
            </div>
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
