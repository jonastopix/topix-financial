import { useState } from 'react';
import { useFunds } from '@/hooks/useFunds';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface FundPartnerAssignmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  currentFundId?: string | null;
  onSuccess?: () => void;
}

export function FundPartnerAssignmentDialog({
  open,
  onOpenChange,
  userId,
  currentFundId,
  onSuccess,
}: FundPartnerAssignmentDialogProps) {
  const { data: funds, isLoading: fundsLoading } = useFunds();
  const [selectedFundId, setSelectedFundId] = useState<string>(currentFundId || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAssign = async () => {
    if (!selectedFundId) {
      toast.error('Vælg venligst en fond');
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ fund_id: selectedFundId })
        .eq('id', userId);

      if (error) throw error;

      toast.success('Fond tildelt fund partner');
      onSuccess?.();
      onOpenChange(false);
    } catch (error: any) {
      toast.error('Fejl ved tildeling: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Tildel Fond til Fund Partner</DialogTitle>
          <DialogDescription>
            Vælg hvilken fond denne fund partner skal have adgang til.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="fund">Vælg Fond</Label>
            <Select
              value={selectedFundId}
              onValueChange={setSelectedFundId}
              disabled={fundsLoading}
            >
              <SelectTrigger id="fund">
                <SelectValue placeholder="Vælg en fond..." />
              </SelectTrigger>
              <SelectContent>
                {funds?.map((fund) => (
                  <SelectItem key={fund.id} value={fund.id}>
                    {fund.name} ({fund.cvr})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Annuller
          </Button>
          <Button onClick={handleAssign} disabled={isSubmitting || !selectedFundId}>
            {isSubmitting ? 'Tildeler...' : 'Tildel Fond'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
