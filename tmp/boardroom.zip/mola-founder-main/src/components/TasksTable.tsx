import { useState } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Check, Circle, Clock, MoreHorizontal, Calendar, AlertCircle, Trash2, Lock } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';
import { Task, useTaskManagement } from '@/hooks/useTaskManagement';
import TaskDetailsDialog from '@/components/TaskDetailsDialog';
import TaskCompletionCelebration from '@/components/TaskCompletionCelebration';

interface TasksTableProps {
  tasks: Task[];
}

const TasksTable = ({ tasks }: TasksTableProps) => {
  const { updateTask, deleteTask } = useTaskManagement();
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [celebratingTaskId, setCelebratingTaskId] = useState<string | null>(null);

  const handleStatusChange = (task: Task, newStatus: string) => {
    updateTask.mutate({ id: task.id, status: newStatus as Task['status'] });
  };

  const handlePriorityChange = (task: Task, newPriority: string) => {
    updateTask.mutate({ id: task.id, priority: newPriority as Task['priority'] });
  };

  const handleDateChange = (task: Task, date: Date | undefined) => {
    updateTask.mutate({ 
      id: task.id, 
      due_date: date ? format(date, 'yyyy-MM-dd') : null 
    });
  };

  const handleToggleComplete = (task: Task) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    if (newStatus === 'done') {
      setCelebratingTaskId(task.id);
    }
    updateTask.mutate({ id: task.id, status: newStatus });
  };

  const handleDelete = (task: Task) => {
    deleteTask.mutate(task.id);
  };

  const handleRowClick = (task: Task) => {
    setSelectedTask(task);
    setShowDetails(true);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-500/10 text-red-600 border-red-200';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-200';
      case 'medium': return 'bg-yellow-500/10 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-500/10 text-green-600 border-green-200';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'done': return <Check className="h-3.5 w-3.5 text-green-600" />;
      case 'in_progress': return <Clock className="h-3.5 w-3.5 text-blue-600" />;
      default: return <Circle className="h-3.5 w-3.5 text-muted-foreground" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'done': return 'Færdig';
      case 'in_progress': return 'I gang';
      default: return 'Afventer';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'Kritisk';
      case 'high': return 'Høj';
      case 'medium': return 'Medium';
      case 'low': return 'Lav';
      default: return priority;
    }
  };

  const isOverdue = (task: Task) => 
    task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done';

  const isDueSoon = (task: Task) => 
    task.due_date && !isOverdue(task) && 
    new Date(task.due_date) <= new Date(Date.now() + 2 * 24 * 60 * 60 * 1000) && 
    task.status !== 'done';

  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 border rounded-lg bg-card">
        <p className="text-muted-foreground">Ingen opgaver endnu</p>
        <p className="text-sm text-muted-foreground mt-1">
          Klik på "Ny opgave" for at oprette din første opgave
        </p>
      </div>
    );
  }

  return (
    <>
      <div className="border rounded-lg overflow-hidden bg-card">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50 hover:bg-muted/50">
              <TableHead className="w-10"></TableHead>
              <TableHead className="min-w-[200px]">Opgave</TableHead>
              <TableHead className="w-[100px]">Person</TableHead>
              <TableHead className="w-[120px]">Status</TableHead>
              <TableHead className="w-[110px]">Prioritet</TableHead>
              <TableHead className="w-[130px]">Deadline</TableHead>
              <TableHead className="w-[150px]">Selskab</TableHead>
              <TableHead className="w-10"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tasks.map((task) => (
              <TableRow 
                key={task.id}
                className={cn(
                  "h-12 cursor-pointer relative",
                  task.status === 'done' && "opacity-60"
                )}
                onClick={() => handleRowClick(task)}
              >
                {/* Celebration animation */}
                <TaskCompletionCelebration 
                  show={celebratingTaskId === task.id}
                  onComplete={() => setCelebratingTaskId(null)}
                />
                
                {/* Checkbox */}
                <TableCell className="pr-0" onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={task.status === 'done'}
                    onCheckedChange={() => handleToggleComplete(task)}
                    className={cn(celebratingTaskId === task.id && "animate-celebrate-pop")}
                  />
                </TableCell>

                {/* Title */}
                <TableCell className="font-medium">
                  <div className="flex items-center gap-2">
                    {task.is_private && (
                      <span title="Privat opgave">
                        <Lock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                      </span>
                    )}
                    <span className={cn(
                      "truncate block max-w-[300px]",
                      task.status === 'done' && "line-through text-muted-foreground"
                    )}>
                      {task.title}
                    </span>
                  </div>
                </TableCell>

                {/* Assignee */}
                <TableCell onClick={(e) => e.stopPropagation()}>
                  {task.assigned_profile ? (
                    <div className="flex items-center gap-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs bg-primary/10 text-primary">
                          {task.assigned_profile.full_name?.charAt(0) || '?'}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                  ) : (
                    <span className="text-muted-foreground text-sm">-</span>
                  )}
                </TableCell>

                {/* Status */}
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <Select
                    value={task.status}
                    onValueChange={(value) => handleStatusChange(task, value)}
                  >
                    <SelectTrigger className="h-7 w-full border-0 bg-transparent hover:bg-muted/50 px-2">
                      <div className="flex items-center gap-1.5">
                        {getStatusIcon(task.status)}
                        <span className="text-xs">{getStatusLabel(task.status)}</span>
                      </div>
                    </SelectTrigger>
                    <SelectContent className="bg-popover">
                      <SelectItem value="todo">
                        <div className="flex items-center gap-2">
                          <Circle className="h-3.5 w-3.5 text-muted-foreground" />
                          Afventer
                        </div>
                      </SelectItem>
                      <SelectItem value="in_progress">
                        <div className="flex items-center gap-2">
                          <Clock className="h-3.5 w-3.5 text-blue-600" />
                          I gang
                        </div>
                      </SelectItem>
                      <SelectItem value="done">
                        <div className="flex items-center gap-2">
                          <Check className="h-3.5 w-3.5 text-green-600" />
                          Færdig
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>

                {/* Priority */}
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <Select
                    value={task.priority}
                    onValueChange={(value) => handlePriorityChange(task, value)}
                  >
                    <SelectTrigger className="h-7 w-full border-0 bg-transparent hover:bg-muted/50 px-1">
                      <Badge 
                        variant="outline" 
                        className={cn("text-[10px] px-1.5", getPriorityColor(task.priority))}
                      >
                        {getPriorityLabel(task.priority)}
                      </Badge>
                    </SelectTrigger>
                    <SelectContent className="bg-popover">
                      <SelectItem value="low">
                        <Badge variant="outline" className={getPriorityColor('low')}>Lav</Badge>
                      </SelectItem>
                      <SelectItem value="medium">
                        <Badge variant="outline" className={getPriorityColor('medium')}>Medium</Badge>
                      </SelectItem>
                      <SelectItem value="high">
                        <Badge variant="outline" className={getPriorityColor('high')}>Høj</Badge>
                      </SelectItem>
                      <SelectItem value="urgent">
                        <Badge variant="outline" className={getPriorityColor('urgent')}>Kritisk</Badge>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>

                {/* Due Date */}
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className={cn(
                          "h-7 px-2 justify-start font-normal text-xs",
                          isOverdue(task) && "text-red-600",
                          isDueSoon(task) && "text-orange-600"
                        )}
                      >
                        {isOverdue(task) && <AlertCircle className="h-3 w-3 mr-1" />}
                        {task.due_date ? (
                          format(new Date(task.due_date), 'd. MMM yyyy', { locale: da })
                        ) : (
                          <span className="text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Tilføj
                          </span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-popover" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={task.due_date ? new Date(task.due_date) : undefined}
                        onSelect={(date) => handleDateChange(task, date)}
                        initialFocus
                        className="pointer-events-auto"
                      />
                    </PopoverContent>
                  </Popover>
                </TableCell>

                {/* Company */}
                <TableCell>
                  {task.company?.name ? (
                    <span className="text-sm truncate block max-w-[140px]">
                      {task.company.name}
                    </span>
                  ) : (
                    <span className="text-muted-foreground text-sm">-</span>
                  )}
                </TableCell>

                {/* Actions */}
                <TableCell onClick={(e) => e.stopPropagation()}>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-popover">
                      <DropdownMenuItem 
                        onClick={() => handleDelete(task)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Slet opgave
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {selectedTask && (
        <TaskDetailsDialog
          task={selectedTask}
          open={showDetails}
          onOpenChange={(open) => {
            setShowDetails(open);
            if (!open) setSelectedTask(null);
          }}
        />
      )}
    </>
  );
};

export default TasksTable;
