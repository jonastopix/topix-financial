import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TrustpilotTrendBadgeProps {
  direction: 'up' | 'down' | 'stable';
  delta: number;
  showLabel?: boolean;
  size?: 'sm' | 'md';
}

export function TrustpilotTrendBadge({ 
  direction, 
  delta, 
  showLabel = true,
  size = 'md' 
}: TrustpilotTrendBadgeProps) {
  const Icon = direction === 'up' ? TrendingUp : direction === 'down' ? TrendingDown : Minus;
  
  const sizeClasses = size === 'sm' 
    ? 'text-xs px-1.5 py-0.5 gap-0.5' 
    : 'text-sm px-2 py-1 gap-1';
  
  const iconSize = size === 'sm' ? 12 : 14;
  
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full font-medium',
        sizeClasses,
        direction === 'up' && 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
        direction === 'down' && 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
        direction === 'stable' && 'bg-muted text-muted-foreground'
      )}
    >
      <Icon className="shrink-0" size={iconSize} />
      {showLabel && (
        <span>
          {direction === 'up' && '+'}
          {delta.toFixed(1)}
        </span>
      )}
    </span>
  );
}
