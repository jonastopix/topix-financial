import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useFundingRounds, useFundingRoundMutations, FundingRound } from '@/hooks/useFundingRounds';
import { FundingRoundsTable } from './FundingRoundsTable';
import { AddFundingRoundDialog } from './AddFundingRoundDialog';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp } from 'lucide-react';
import { formatDKK } from '@/lib/returnsCalculations';
import { formatPercentage } from '@/lib/formatters';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface CompanyFundingRoundsProps {
  companyId: string;
}

export function CompanyFundingRounds({ companyId }: CompanyFundingRoundsProps) {
  const { data: rounds, isLoading } = useFundingRounds(companyId);
  const { createFundingRound, updateFundingRound, deleteFundingRound } = useFundingRoundMutations();
  
  const [editingRound, setEditingRound] = useState<FundingRound | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const handleEdit = (round: FundingRound) => {
    setEditingRound(round);
  };

  const handleDelete = (id: string) => {
    setDeleteId(id);
  };

  const confirmDelete = () => {
    if (deleteId) {
      deleteFundingRound.mutate({ id: deleteId, companyId });
      setDeleteId(null);
    }
  };

  const totalInvested = rounds?.reduce((sum, r) => sum + r.invested_amount_dkk, 0) || 0;
  const totalEquity = rounds?.reduce((sum, r) => sum + r.equity_acquired_pct, 0) || 0;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Funding Rounds
              </CardTitle>
              <CardDescription>
                Alle investeringer og follow-up financing
              </CardDescription>
            </div>
            <AddFundingRoundDialog
              companyId={companyId}
              onAdd={(data) => {
                if (editingRound) {
                  updateFundingRound.mutate({ 
                    id: editingRound.id,
                    ...data
                  });
                  setEditingRound(null);
                } else {
                  createFundingRound.mutate(data);
                }
              }}
              editData={editingRound ? { ...editingRound } : undefined}
              {...(editingRound ? {
                open: true,
                onOpenChange: (open: boolean) => {
                  if (!open) setEditingRound(null);
                }
              } : {})}
            />
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {rounds && rounds.length > 0 && (
            <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div>
                <div className="text-sm text-muted-foreground">Total Investeret</div>
                <div className="text-2xl font-bold">{formatDKK(totalInvested)}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Total Ejerandel</div>
                <div className="text-2xl font-bold">{formatPercentage(totalEquity, 2)}</div>
              </div>
            </div>
          )}
          
          <FundingRoundsTable
            rounds={rounds || []}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil slette funding round permanent. Company totals vil blive opdateret automatisk.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Slet</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
