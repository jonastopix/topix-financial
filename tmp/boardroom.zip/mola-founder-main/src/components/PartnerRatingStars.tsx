import { useState } from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRatePartner, useDeletePartnerRating } from '@/hooks/usePartnerRatings';
import { useAuth } from '@/contexts/AuthContext';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface PartnerRatingStarsProps {
  partnerId: string;
  averageRating: number;
  ratingCount: number;
  userRating: number | null;
  size?: 'sm' | 'md';
  showCount?: boolean;
  interactive?: boolean;
}

export const PartnerRatingStars = ({
  partnerId,
  averageRating,
  ratingCount,
  userRating,
  size = 'sm',
  showCount = true,
  interactive = true,
}: PartnerRatingStarsProps) => {
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const { user } = useAuth();
  const ratePartner = useRatePartner();
  const deleteRating = useDeletePartnerRating();

  const displayRating = hoverRating ?? userRating ?? averageRating;
  const iconSize = size === 'sm' ? 'h-4 w-4' : 'h-5 w-5';

  const handleClick = (rating: number) => {
    if (!interactive || !user) return;
    
    // If clicking same rating, remove it
    if (userRating === rating) {
      deleteRating.mutate(partnerId);
    } else {
      ratePartner.mutate({ partnerId, rating });
    }
  };

  const handleMouseEnter = (rating: number) => {
    if (interactive && user) {
      setHoverRating(rating);
    }
  };

  const handleMouseLeave = () => {
    setHoverRating(null);
  };

  return (
    <div className="flex items-center gap-1.5">
      <TooltipProvider>
        <div className="flex items-center gap-0.5">
          {[1, 2, 3, 4, 5].map((star) => {
            const isFilled = star <= Math.round(displayRating);
            const isUserRated = userRating !== null && star <= userRating;
            const isHovered = hoverRating !== null && star <= hoverRating;

            return (
              <Tooltip key={star}>
                <TooltipTrigger asChild>
                  <button
                    type="button"
                    onClick={() => handleClick(star)}
                    onMouseEnter={() => handleMouseEnter(star)}
                    onMouseLeave={handleMouseLeave}
                    disabled={!interactive || !user || ratePartner.isPending}
                    className={cn(
                      'transition-all duration-150',
                      interactive && user && 'cursor-pointer hover:scale-110',
                      !interactive || !user ? 'cursor-default' : ''
                    )}
                  >
                    <Star
                      className={cn(
                        iconSize,
                        'transition-colors duration-150',
                        isHovered
                          ? 'fill-yellow-400 text-yellow-400'
                          : isUserRated
                          ? 'fill-yellow-500 text-yellow-500'
                          : isFilled
                          ? 'fill-yellow-400/70 text-yellow-400/70'
                          : 'fill-transparent text-muted-foreground/40'
                      )}
                    />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="top" className="text-xs">
                  {user
                    ? userRating === star
                      ? 'Klik for at fjerne din rating'
                      : `Giv ${star} stjerne${star > 1 ? 'r' : ''}`
                    : 'Log ind for at rate'}
                </TooltipContent>
              </Tooltip>
            );
          })}
        </div>
      </TooltipProvider>

      {showCount && (
        <span className="text-xs text-muted-foreground">
          {ratingCount > 0 ? (
            <>
              {averageRating.toFixed(1)} ({ratingCount})
            </>
          ) : (
            'Ingen ratings'
          )}
        </span>
      )}

      {userRating !== null && (
        <span className="text-xs text-primary font-medium ml-1">
          Din: {userRating}★
        </span>
      )}
    </div>
  );
};
