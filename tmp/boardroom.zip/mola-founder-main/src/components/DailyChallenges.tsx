import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { Target, Check, Sparkles, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useDailyChallenges } from '@/hooks/useDailyChallenges';

export function DailyChallenges() {
  const {
    challenges,
    isLoading,
    completedCount,
    totalCount,
    xpEarned,
    totalXpAvailable,
    allCompleted,
    generateChallenges,
  } = useDailyChallenges();

  // Generate challenges on mount if none exist
  useEffect(() => {
    if (!isLoading && challenges.length === 0) {
      generateChallenges();
    }
  }, [isLoading, challenges.length, generateChallenges]);

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Target className="h-4 w-4" />
            Daglige Udfordringer
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={allCompleted ? 'border-green-500/50 bg-green-500/5' : ''}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium flex items-center gap-2">
            <Target className="h-4 w-4" />
            Daglige Udfordringer
          </CardTitle>
          <Badge variant={allCompleted ? 'default' : 'secondary'} className="text-xs">
            {completedCount}/{totalCount}
          </Badge>
        </div>
        {allCompleted && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-green-600 text-xs mt-1"
          >
            <Sparkles className="h-3 w-3" />
            Alle udfordringer fuldført i dag!
          </motion.div>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {challenges.map((challenge, index) => (
          <motion.div
            key={challenge.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className={`p-3 rounded-lg border ${
              challenge.is_completed 
                ? 'bg-green-500/10 border-green-500/30' 
                : 'bg-muted/50 border-border'
            }`}
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                {challenge.is_completed ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="flex-shrink-0"
                  >
                    <Check className="h-4 w-4 text-green-500" />
                  </motion.div>
                ) : (
                  <Target className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                )}
                <span className={`text-sm ${challenge.is_completed ? 'line-through text-muted-foreground' : ''}`}>
                  {challenge.challenge_description}
                </span>
              </div>
              <Badge 
                variant="outline" 
                className={`text-xs flex-shrink-0 ${
                  challenge.is_completed ? 'bg-green-500/20 text-green-600 border-green-500/30' : ''
                }`}
              >
                <Zap className="h-3 w-3 mr-1" />
                {challenge.xp_reward} XP
              </Badge>
            </div>
            
            {!challenge.is_completed && (
              <div className="space-y-1">
                <Progress 
                  value={(challenge.current_count / challenge.target_count) * 100} 
                  className="h-1.5"
                />
                <p className="text-xs text-muted-foreground">
                  {challenge.current_count} / {challenge.target_count}
                </p>
              </div>
            )}
          </motion.div>
        ))}

        {challenges.length > 0 && (
          <div className="pt-2 border-t flex items-center justify-between text-xs text-muted-foreground">
            <span>XP optjent i dag</span>
            <span className="font-medium text-foreground">
              {xpEarned} / {totalXpAvailable} XP
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
