import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Task, useTaskManagement } from '@/hooks/useTaskManagement';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';
import { useAuth } from '@/contexts/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar, Building2, User, Clock, Repeat, Link as LinkIcon, Edit, Lock, Globe, Check, AlertCircle } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import EditRecurrenceDialog from './EditRecurrenceDialog';
import { cn } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import TaskCompletionCelebration from '@/components/TaskCompletionCelebration';

interface TaskDetailsDialogProps {
  task: Task;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const TaskDetailsDialog = ({ task, open, onOpenChange }: TaskDetailsDialogProps) => {
  const { updateTask, deleteTask } = useTaskManagement();
  const { isAdmin, activeRole, selectedCompanyId } = useRole();
  const { user } = useAuth();
  const isMobile = useIsMobile();
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingRecurrence, setIsEditingRecurrence] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [editedTask, setEditedTask] = useState({
    title: task.title,
    description: task.description || '',
    status: task.status,
    priority: task.priority,
    due_date: task.due_date || '',
    assigned_to: task.assigned_to || '',
    company_id: task.company_id || '',
    is_private: task.is_private,
  });

  // On mobile, start in view mode; on desktop, start in edit mode
  // Reset when dialog opens
  useEffect(() => {
    if (open) {
      setIsEditing(!isMobile);
    }
  }, [open, isMobile]);

  const canAssignTasks = isAdmin || activeRole === 'founder' || activeRole === 'fund_partner';
  const canChangeCompany = isAdmin || activeRole === 'fund_partner';

  // Fetch fund_id for fund_partners
  const { data: userProfile } = useQuery({
    queryKey: ['user-profile-fund', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('fund_id')
        .eq('id', user!.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: activeRole === 'fund_partner' && !!user && open,
  });

  // Fetch users for assignment
  const { data: users } = useQuery({
    queryKey: ['users-for-tasks-edit', activeRole, selectedCompanyId],
    queryFn: async () => {
      let query = supabase
        .from('profiles')
        .select('id, full_name, company_name, company_id')
        .eq('is_active', true)
        .order('full_name');
      
      if (activeRole === 'founder' && selectedCompanyId) {
        query = query.eq('company_id', selectedCompanyId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    enabled: canAssignTasks && open,
  });

  // Fetch companies - for admins: all, for fund_partners: only their fund's companies
  const { data: companies } = useQuery({
    queryKey: ['companies-for-tasks-edit', activeRole, userProfile?.fund_id],
    queryFn: async () => {
      let query = supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      
      // Fund partners can only see companies in their fund
      if (activeRole === 'fund_partner' && userProfile?.fund_id) {
        query = query.eq('fund_id', userProfile.fund_id);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
    enabled: canChangeCompany && open,
  });

  const handleSave = () => {
    updateTask.mutate({
      id: task.id,
      ...editedTask,
      due_date: editedTask.due_date || null,
      assigned_to: editedTask.assigned_to || null,
      company_id: editedTask.company_id || null,
      is_private: editedTask.is_private,
    });
    onOpenChange(false);
  };

  const handleDelete = () => {
    if (confirm('Er du sikker på at du vil slette denne opgave?')) {
      deleteTask.mutate(task.id);
      onOpenChange(false);
    }
  };

  const handleMarkAsDone = () => {
    if (task.status !== 'done') {
      setShowCelebration(true);
    }
    updateTask.mutate({
      id: task.id,
      status: task.status === 'done' ? 'todo' : 'done',
    });
    if (task.status !== 'done') {
      // Close after a short delay to show the celebration
      setTimeout(() => onOpenChange(false), 500);
    }
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      // Reset to view mode when closing on mobile
      setIsEditing(false);
    }
    onOpenChange(newOpen);
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'Akut';
      case 'high':
        return 'Høj';
      case 'medium':
        return 'Mellem';
      case 'low':
        return 'Lav';
      default:
        return priority;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-destructive text-destructive-foreground';
      case 'high':
        return 'bg-orange-500 text-white';
      case 'medium':
        return 'bg-yellow-500 text-black';
      case 'low':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'todo':
        return 'Ikke påbegyndt';
      case 'in_progress':
        return 'I gang';
      case 'done':
        return 'Færdig';
      case 'cancelled':
        return 'Annulleret';
      default:
    return status;
    }
  };

  const getRecurrenceDescription = () => {
    if (!task.is_recurring) return null;
    
    const pattern = task.recurrence_pattern;
    const interval = task.recurrence_interval || 1;
    
    let description = `Gentages hver${interval > 1 ? ` ${interval}.` : ''}`;
    
    switch (pattern) {
      case 'daily':
        description += ` dag`;
        break;
      case 'weekly':
        const days = ['søndag', 'mandag', 'tirsdag', 'onsdag', 'torsdag', 'fredag', 'lørdag'];
        const dayName = task.recurrence_day_of_week !== undefined ? days[task.recurrence_day_of_week] : '';
        description += ` uge${dayName ? ` om ${dayName}en` : ''}`;
        break;
      case 'monthly':
        description += ` måned${task.recurrence_day_of_month ? ` den ${task.recurrence_day_of_month}.` : ''}`;
        break;
      case 'yearly':
        description += ` år`;
        break;
    }
    
    if (task.recurrence_end_date) {
      description += ` til ${format(new Date(task.recurrence_end_date), 'dd MMM yyyy', { locale: da })}`;
    } else if (task.recurrence_count) {
      description += ` (${task.recurrence_count} gentagelser)`;
    }
    
    return description;
  };

  // Calculate if overdue
  const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'done';

  // View mode content (read-only)
  const renderViewMode = () => (
    <div className="space-y-4 relative overflow-hidden">
      <TaskCompletionCelebration 
        show={showCelebration} 
        onComplete={() => setShowCelebration(false)} 
      />
      
      {/* Title */}
      <div>
        <h3 className={cn(
          "text-lg font-semibold",
          task.status === 'done' && "line-through text-muted-foreground"
        )}>
          {task.title}
        </h3>
      </div>

      {/* Description */}
      {task.description && (
        <div className="text-sm text-muted-foreground whitespace-pre-wrap">
          {task.description}
        </div>
      )}

      <Separator />

      {/* Details Grid */}
      <div className="space-y-3">
        {/* Status & Priority */}
        <div className="flex flex-wrap gap-2">
          <Badge variant={task.status === 'done' ? 'default' : 'secondary'}>
            {getStatusLabel(task.status)}
          </Badge>
          <Badge className={getPriorityColor(task.priority)}>
            {getPriorityLabel(task.priority)}
          </Badge>
          {task.is_private && (
            <Badge variant="outline" className="gap-1">
              <Lock className="h-3 w-3" />
              Privat
            </Badge>
          )}
        </div>

        {/* Deadline */}
        {task.due_date && (
          <div className="flex items-center gap-2 text-sm">
            <Calendar className={cn("h-4 w-4", isOverdue ? "text-destructive" : "text-muted-foreground")} />
            <span className={isOverdue ? "text-destructive font-medium" : ""}>
              {format(new Date(task.due_date), 'dd. MMMM yyyy', { locale: da })}
              {isOverdue && (
                <span className="ml-2 inline-flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  Overskredet
                </span>
              )}
            </span>
          </div>
        )}

        {/* Assigned to */}
        {task.assigned_profile && (
          <div className="flex items-center gap-2 text-sm">
            <User className="h-4 w-4 text-muted-foreground" />
            <span>{task.assigned_profile.full_name || 'Ikke angivet'}</span>
          </div>
        )}

        {/* Company */}
        {task.company && (
          <div className="flex items-center gap-2 text-sm">
            <Building2 className="h-4 w-4 text-muted-foreground" />
            <span>{task.company.name}</span>
          </div>
        )}

        {/* Recurring info */}
        {task.is_recurring && (
          <div className="flex items-center gap-2 text-sm">
            <Repeat className="h-4 w-4 text-primary" />
            <span>{getRecurrenceDescription()}</span>
          </div>
        )}

        {/* Parent Task Info */}
        {task.parent_task && (
          <div className="flex items-center gap-2 text-sm">
            <LinkIcon className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Del af:</span>
            <span>{task.parent_task.title}</span>
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div className="flex flex-col gap-2 pt-4 border-t">
        <Button 
          onClick={handleMarkAsDone}
          className={cn(
            "w-full",
            task.status === 'done' && "bg-muted text-muted-foreground hover:bg-muted/80"
          )}
          variant={task.status === 'done' ? 'outline' : 'default'}
        >
          <Check className="h-4 w-4 mr-2" />
          {task.status === 'done' ? 'Marker som ikke udført' : 'Marker som udført'}
        </Button>
        <Button 
          variant="outline" 
          onClick={() => setIsEditing(true)}
          className="w-full"
        >
          <Edit className="h-4 w-4 mr-2" />
          Rediger opgave
        </Button>
      </div>
    </div>
  );

  // Edit mode content
  const renderEditMode = () => (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="title">Titel</Label>
        <Input
          id="title"
          value={editedTask.title}
          onChange={(e) => setEditedTask({ ...editedTask, title: e.target.value })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Beskrivelse</Label>
        <Textarea
          id="description"
          value={editedTask.description}
          onChange={(e) => setEditedTask({ ...editedTask, description: e.target.value })}
          rows={4}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <Select
            value={editedTask.status}
            onValueChange={(value) => setEditedTask({ ...editedTask, status: value as Task['status'] })}
          >
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todo">Ikke påbegyndt</SelectItem>
              <SelectItem value="in_progress">I gang</SelectItem>
              <SelectItem value="done">Færdig</SelectItem>
              <SelectItem value="cancelled">Annulleret</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Prioritet</Label>
          <Select
            value={editedTask.priority}
            onValueChange={(value) => setEditedTask({ ...editedTask, priority: value as Task['priority'] })}
          >
            <SelectTrigger id="priority">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="urgent">Akut</SelectItem>
              <SelectItem value="high">Høj</SelectItem>
              <SelectItem value="medium">Mellem</SelectItem>
              <SelectItem value="low">Lav</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="due_date">Deadline</Label>
        <Input
          id="due_date"
          type="date"
          value={editedTask.due_date}
          onChange={(e) => setEditedTask({ ...editedTask, due_date: e.target.value })}
        />
      </div>

      {/* Assigned to - for admin, founder, fund_partner */}
      {canAssignTasks && (
        <div className="space-y-2">
          <Label htmlFor="assigned_to">Tildelt til</Label>
          <Select
            value={editedTask.assigned_to || "__none__"}
            onValueChange={(value) => setEditedTask({ 
              ...editedTask, 
              assigned_to: value === "__none__" ? '' : value 
            })}
          >
            <SelectTrigger id="assigned_to">
              <SelectValue placeholder="Vælg bruger (valgfrit)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">Ingen tildelt</SelectItem>
              {users?.map((u) => (
                <SelectItem key={u.id} value={u.id}>
                  {u.full_name || 'Ingen navn'} {u.company_name && `(${u.company_name})`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Company - for admins and fund_partners */}
      {canChangeCompany && (
        <div className="space-y-2">
          <Label htmlFor="company_id">Virksomhed</Label>
          <Select
            value={editedTask.company_id || "__none__"}
            onValueChange={(value) => setEditedTask({ 
              ...editedTask, 
              company_id: value === "__none__" ? '' : value 
            })}
          >
            <SelectTrigger id="company_id">
              <SelectValue placeholder="Vælg virksomhed (valgfrit)" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="__none__">Ingen virksomhed</SelectItem>
              {companies?.map((company) => (
                <SelectItem key={company.id} value={company.id}>
                  {company.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Privacy Toggle */}
      <div className="flex items-center justify-between rounded-lg border p-3 bg-muted/30">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            {editedTask.is_private ? (
              <Lock className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Globe className="h-4 w-4 text-muted-foreground" />
            )}
            <Label htmlFor="is_private_edit" className="font-medium">
              {editedTask.is_private ? 'Privat opgave' : 'Offentlig opgave'}
            </Label>
          </div>
          <p className="text-xs text-muted-foreground">
            {editedTask.is_private 
              ? 'Kun du og den ansvarlige kan se denne opgave' 
              : 'Alle i virksomheden kan se denne opgave'}
          </p>
        </div>
        <Switch
          id="is_private_edit"
          checked={!editedTask.is_private}
          onCheckedChange={(checked) => setEditedTask({ ...editedTask, is_private: !checked })}
        />
      </div>

      {/* Recurring Task Info */}
      {task.is_recurring && (
        <>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Repeat className="h-4 w-4 text-primary" />
                <span className="font-medium">Gentagende opgave</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsEditingRecurrence(true)}
              >
                <Edit className="h-3 w-3 mr-1" />
                Rediger
              </Button>
            </div>
            <p className="text-sm text-muted-foreground">
              {getRecurrenceDescription()}
            </p>
            {task.next_occurrence_date && (
              <p className="text-sm">
                <span className="text-muted-foreground">Næste:</span>{' '}
                {format(new Date(task.next_occurrence_date), 'dd MMM yyyy', { locale: da })}
              </p>
            )}
          </div>
        </>
      )}

      {/* Parent Task Info */}
      {task.parent_task && (
        <>
          <Separator />
          <div className="flex items-center gap-2 text-sm">
            <LinkIcon className="h-4 w-4 text-muted-foreground" />
            <span className="text-muted-foreground">Del af gentagende opgave:</span>
            <span className="font-medium">{task.parent_task.title}</span>
          </div>
        </>
      )}

      <div className="flex justify-between pt-4 border-t">
        <Button variant="destructive" onClick={handleDelete}>
          Slet opgave
        </Button>
        <div className="flex gap-2">
          {isMobile && (
            <Button variant="outline" onClick={() => setIsEditing(false)}>
              Tilbage
            </Button>
          )}
          {!isMobile && (
            <Button variant="outline" onClick={() => handleOpenChange(false)}>
              Annuller
            </Button>
          )}
          <Button onClick={handleSave}>Gem</Button>
        </div>
      </div>
    </div>
  );

  return (
    <>
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? 'Rediger opgave' : 'Opgavedetaljer'}
          </DialogTitle>
        </DialogHeader>

        {isMobile && !isEditing ? renderViewMode() : renderEditMode()}
      </DialogContent>
    </Dialog>

    {task.is_recurring && (
      <EditRecurrenceDialog
        task={task}
        open={isEditingRecurrence}
        onOpenChange={setIsEditingRecurrence}
      />
    )}
    </>
  );
};

export default TaskDetailsDialog;
