import { FundingRound } from '@/hooks/useFundingRounds';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Pencil, Trash2, Users } from 'lucide-react';
import { formatDKK } from '@/lib/returnsCalculations';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface FundingRoundsTableProps {
  rounds: FundingRound[];
  onEdit: (round: FundingRound) => void;
  onDelete: (id: string) => void;
}

const ROUND_TYPE_LABELS: Record<string, string> = {
  seed: 'Seed',
  series_a: 'Series A',
  series_b: 'Series B',
  series_c: 'Series C',
  follow_on: 'Follow-on',
  bridge: 'Bridge',
  secondary: 'Secondary',
};

export function FundingRoundsTable({ rounds, onEdit, onDelete }: FundingRoundsTableProps) {
  if (rounds.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Ingen funding rounds endnu
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Round Navn</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Dato</TableHead>
            <TableHead className="text-right">Beløb</TableHead>
            <TableHead className="text-right">Ejerandel</TableHead>
            <TableHead className="text-right">Pre-money</TableHead>
            <TableHead className="text-right">Post-money</TableHead>
            <TableHead className="text-right">Handlinger</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rounds.map((round) => (
            <TableRow key={round.id}>
              <TableCell className="font-medium">{round.round_name}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {ROUND_TYPE_LABELS[round.round_type] || round.round_type}
                  {round.is_secondary && (
                    <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950/30 dark:text-purple-300 dark:border-purple-800">
                      <Users className="h-3 w-3 mr-1" />
                      Old Shares
                    </Badge>
                  )}
                </div>
                {round.seller_name && (
                  <div className="text-xs text-muted-foreground mt-0.5">
                    Fra: {round.seller_name}
                  </div>
                )}
              </TableCell>
              <TableCell>
                {format(new Date(round.invested_at), 'dd MMM yyyy', { locale: da })}
              </TableCell>
              <TableCell className="text-right font-mono">
                {formatDKK(round.invested_amount_dkk)}
              </TableCell>
              <TableCell className="text-right">{round.equity_acquired_pct}%</TableCell>
              <TableCell className="text-right font-mono">
                {round.pre_money_valuation_dkk ? formatDKK(round.pre_money_valuation_dkk) : '-'}
              </TableCell>
              <TableCell className="text-right font-mono">
                {round.post_money_valuation_dkk ? formatDKK(round.post_money_valuation_dkk) : '-'}
              </TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onEdit(round)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(round.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
