import { useState, useEffect } from 'react';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { Send, Mail, Plus, X, FlaskConical, Building2, Landmark } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useMileageEntries, useMileageSettings, PayingEntityType } from '@/hooks/useMileage';
const formatDKK = (value: number) => value.toLocaleString('da-DK', { style: 'currency', currency: 'DKK' });
import { toast } from 'sonner';

export interface SendMileageReportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entityId: string;
  entityType: PayingEntityType;
}

export function SendMileageReportDialog({ open, onOpenChange, entityId, entityType }: SendMileageReportDialogProps) {
  const queryClient = useQueryClient();
  const { data: settings } = useMileageSettings();
  
  // Fetch entries based on entity type
  const { data: allUnsubmittedEntries = [] } = useMileageEntries({ isSubmitted: false });
  
  // Filter entries for this specific entity
  const entries = allUnsubmittedEntries.filter(entry => {
    if (entityType === 'company') {
      return entry.paying_company_id === entityId;
    } else if (entityType === 'fund') {
      return entry.paying_fund_id === entityId;
    }
    return false;
  });
  
  // Fetch entity info (company or fund)
  const { data: entityInfo } = useQuery({
    queryKey: ['paying-entity-info', entityId, entityType],
    queryFn: async () => {
      if (entityType === 'company') {
        const { data, error } = await supabase
          .from('companies')
          .select('name, accountant_name, accountant_email')
          .eq('id', entityId)
          .single();
        if (error) throw error;
        return data;
      } else if (entityType === 'fund') {
        const { data, error } = await supabase
          .from('funds')
          .select('name')
          .eq('id', entityId)
          .single();
        if (error) throw error;
        return { name: data.name, accountant_name: null, accountant_email: null };
      }
      return null;
    },
    enabled: open && !!entityId,
  });
  
  const [emails, setEmails] = useState<string[]>([]);
  const [newEmail, setNewEmail] = useState('');
  const [isSending, setIsSending] = useState(false);
  
  // Pre-populate with accountant email when dialog opens (for companies)
  useEffect(() => {
    if (open && entityInfo?.accountant_email && emails.length === 0) {
      setEmails([entityInfo.accountant_email]);
    }
  }, [open, entityInfo?.accountant_email]);
  
  // Reset emails when dialog closes
  useEffect(() => {
    if (!open) {
      setEmails([]);
      setNewEmail('');
    }
  }, [open]);
  
  const totalKm = entries.reduce((sum, e) => sum + Number(e.distance_km), 0);
  const totalAmount = entries.reduce((sum, e) => sum + Number(e.amount_dkk), 0);
  const entityName = entityInfo?.name || entries[0]?.paying_company?.name || entries[0]?.paying_fund?.name || 'Ukendt';
  
  const EntityIcon = entityType === 'fund' ? Landmark : Building2;
  
  const addEmail = () => {
    const email = newEmail.trim().toLowerCase();
    if (email && email.includes('@') && !emails.includes(email)) {
      setEmails([...emails, email]);
      setNewEmail('');
    }
  };
  
  const removeEmail = (email: string) => {
    setEmails(emails.filter(e => e !== email));
  };
  
  const handleSend = async (testMode: boolean = false) => {
    if (emails.length === 0) {
      toast.error('Tilføj mindst én email-modtager');
      return;
    }
    
    if (!testMode && !settings?.employee_name) {
      toast.error('Konfigurer først dine kørselsindstillinger');
      return;
    }
    
    setIsSending(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('send-mileage-report', {
        body: {
          entityId: testMode ? null : entityId,
          entityType: entityType,
          emails,
          testMode,
        },
      });
      
      if (error) throw error;
      
      if (testMode) {
        toast.success('Test-rapport sendt til ' + emails.join(', '));
      } else {
        toast.success('Kørselsrapport sendt til ' + emails.join(', '));
        queryClient.invalidateQueries({ queryKey: ['mileage-entries'] });
        queryClient.invalidateQueries({ queryKey: ['mileage-submissions'] });
      }
      onOpenChange(false);
    } catch (error: any) {
      console.error('Error sending mileage report:', error);
      toast.error('Kunne ikke sende rapport: ' + (error.message || 'Ukendt fejl'));
    } finally {
      setIsSending(false);
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Send kørselsrapport</DialogTitle>
          <DialogDescription>
            Send SKAT-godkendt kørselsrapport til bogholderi
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Summary */}
          <div className="rounded-lg bg-muted p-4">
            <div className="flex items-center gap-2 mb-2">
              <EntityIcon className="h-4 w-4 text-muted-foreground" />
              <h4 className="font-medium">{entityName}</h4>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-muted-foreground">Antal kørsler</p>
                <p className="font-medium">{entries.length}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Total km</p>
                <p className="font-medium">{totalKm.toFixed(1)} km</p>
              </div>
              <div>
                <p className="text-muted-foreground">Beløb til udbetaling</p>
                <p className="font-medium text-lg">{formatDKK(totalAmount)}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Medarbejder</p>
                <p className="font-medium">{settings?.employee_name || 'Ikke angivet'}</p>
              </div>
            </div>
          </div>
          
          {/* Email recipients */}
          <div className="space-y-2">
            <Label>Send til (email)</Label>
            {entityInfo?.accountant_name && entityInfo?.accountant_email && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-md px-3 py-2">
                <Building2 className="h-4 w-4" />
                <span>Bogholder: <strong>{entityInfo.accountant_name}</strong></span>
              </div>
            )}
            <div className="flex gap-2">
              <Input
                type="email"
                placeholder="bogholderi@firma.dk"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addEmail())}
              />
              <Button type="button" variant="outline" onClick={addEmail}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {emails.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {emails.map((email) => (
                  <Badge key={email} variant="secondary" className="gap-1">
                    <Mail className="h-3 w-3" />
                    {email}
                    <button onClick={() => removeEmail(email)}>
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button 
              variant="secondary" 
              onClick={() => handleSend(true)} 
              disabled={isSending || emails.length === 0}
            >
              {isSending ? (
                'Sender...'
              ) : (
                <>
                  <FlaskConical className="h-4 w-4 mr-2" />
                  Send test
                </>
              )}
            </Button>
            <Button onClick={() => handleSend(false)} disabled={isSending || emails.length === 0}>
              {isSending ? (
                'Sender...'
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Send rapport
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
