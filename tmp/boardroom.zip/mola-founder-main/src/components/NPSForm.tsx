import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Heart } from 'lucide-react';

interface NPSFormProps {
  companyId: string;
  onSubmit: () => void;
}

const NPSForm = ({ companyId, onSubmit }: NPSFormProps) => {
  const [score, setScore] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (score === null) {
      toast({
        title: 'Vælg en score',
        description: 'Vælg venligst en score fra 0-10',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    const now = new Date();
    const quarter = Math.floor(now.getMonth() / 3) + 1;
    const year = now.getFullYear();

    const { error } = await supabase.from('nps_responses').insert({
      company_id: companyId,
      score,
      comment: comment || null,
      period_quarter: quarter,
      period_year: year,
    });

    setSubmitting(false);

    if (error) {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke gemme din feedback',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Tak for dit svar! 🙏',
      description: 'Din NPS-score er blevet gemt',
    });

    setScore(null);
    setComment('');
    onSubmit();
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Heart className="h-6 w-6 text-pink-500" />
        <h3 className="text-xl font-semibold">MOLA Relationship Pulse (Kvartalsvis)</h3>
      </div>

      <p className="text-muted-foreground mb-4">
        Hvor sandsynligt er det, at du vil anbefale MOLA til andre founders?
      </p>

      <div className="flex items-center justify-between mb-6 text-sm text-muted-foreground">
        <span>Usandsynligt</span>
        <span>Meget sandsynligt</span>
      </div>

      <div className="grid grid-cols-11 gap-2 mb-6">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
          <Button
            key={num}
            variant={score === num ? 'default' : 'outline'}
            onClick={() => setScore(num)}
            className={`aspect-square p-0 transition-all ${
              score === num ? 'scale-110 shadow-lg' : ''
            } ${
              num <= 6 ? 'hover:border-red-500/50' : 
              num <= 8 ? 'hover:border-yellow-500/50' : 
              'hover:border-green-500/50'
            }`}
          >
            {num}
          </Button>
        ))}
      </div>

      <Textarea
        placeholder="Kommentar (valgfri) - Del gerne dine tanker om samarbejdet"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        className="mb-4"
        rows={4}
      />

      <Button onClick={handleSubmit} disabled={submitting} className="w-full">
        {submitting ? 'Sender...' : 'Send Feedback'}
      </Button>
    </Card>
  );
};

export default NPSForm;