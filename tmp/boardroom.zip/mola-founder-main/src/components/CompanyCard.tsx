import { Building2, TrendingUp, Calendar, ExternalLink } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { formatPercentage } from '@/lib/formatters';

interface CompanyCardProps {
  id: string;
  name: string;
  cvr?: string;
  logo_url?: string;
  industry?: string;
  status: string;
  invested_amount_dkk?: number;
  equity_share_pct?: number;
  total_invested_amount_dkk?: number;
  total_equity_share_pct?: number;
  fund_id?: string;
  healthScore?: number;
  latestReportDate?: string;
}

const CompanyCard = ({
  id,
  name,
  cvr,
  logo_url,
  industry,
  status,
  invested_amount_dkk,
  equity_share_pct,
  total_invested_amount_dkk,
  total_equity_share_pct,
  healthScore = 0,
  latestReportDate,
}: CompanyCardProps) => {
  const navigate = useNavigate();

  // Use total_* if available, otherwise fall back to single round values
  const displayInvestedAmount = total_invested_amount_dkk ?? invested_amount_dkk;
  const displayEquityShare = total_equity_share_pct ?? equity_share_pct;

  const formatCurrency = (amount: number | null | undefined) => {
    if (!amount) return 'N/A';
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-500/10 text-green-700 border-green-500/20';
      case 'exited':
        return 'bg-gray-500/10 text-gray-700 border-gray-500/20';
      case 'new_investment':
        return 'bg-blue-500/10 text-blue-700 border-blue-500/20';
      case 'monitoring':
        return 'bg-yellow-500/10 text-yellow-700 border-yellow-500/20';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Aktiv';
      case 'exited':
        return 'Exited';
      case 'new_investment':
        return 'Ny investering';
      case 'monitoring':
        return 'Under overvågning';
      default:
        return status;
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer group">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {logo_url ? (
              <img
                src={logo_url}
                alt={`${name} logo`}
                className="h-12 w-12 rounded-lg object-cover flex-shrink-0"
              />
            ) : (
              <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Building2 className="h-6 w-6 text-primary" />
              </div>
            )}
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-lg truncate group-hover:text-primary transition-colors">
                {name}
              </h3>
              {cvr && (
                <p className="text-sm text-muted-foreground">CVR: {cvr}</p>
              )}
            </div>
          </div>
          <Badge variant="outline" className={getStatusColor(status)}>
            {getStatusLabel(status)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Health Score */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Sundhedsindeks</span>
            <span className={`font-semibold ${getHealthColor(healthScore)}`}>
              {healthScore}/100
            </span>
          </div>
          <Progress value={healthScore} className="h-2" />
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4 pt-2">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Investeret</p>
            <p className="text-sm font-semibold">
              {formatCurrency(displayInvestedAmount)}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Ejerandel</p>
            <p className="text-sm font-semibold">
              {displayEquityShare ? formatPercentage(displayEquityShare, 2) : 'N/A'}
            </p>
          </div>
        </div>

        {/* Industry & Latest Report */}
        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {industry && (
              <Badge variant="secondary" className="text-xs">
                {industry}
              </Badge>
            )}
          </div>
          {latestReportDate && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Calendar className="h-3 w-3" />
              <span>{latestReportDate}</span>
            </div>
          )}
        </div>

        {/* Action Button */}
        <Button
          variant="outline"
          className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
          onClick={() => navigate(`/company/${id}`)}
        >
          <span>Se detaljer</span>
          <ExternalLink className="h-4 w-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default CompanyCard;
