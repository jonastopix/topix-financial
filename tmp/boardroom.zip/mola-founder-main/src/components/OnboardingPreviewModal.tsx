import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { ONBOARDING_CONFIG } from '@/config/onboardingSteps';
import { OnboardingStepContent } from '@/components/OnboardingStep';

interface OnboardingPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function OnboardingPreviewModal({ isOpen, onClose }: OnboardingPreviewModalProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [direction, setDirection] = useState(1);
  
  const steps = ONBOARDING_CONFIG.founder?.steps ?? [];

  // Reset step when modal opens
  useEffect(() => {
    if (isOpen) {
      setCurrentStepIndex(0);
      setDirection(1);
    }
  }, [isOpen]);

  if (!isOpen || steps.length === 0) return null;

  const currentStep = steps[currentStepIndex];
  const isLastStep = currentStepIndex === steps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      onClose();
    } else {
      setDirection(1);
      setCurrentStepIndex(prev => prev + 1);
    }
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0
    })
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="relative z-10 w-full max-w-lg mx-4"
      >
        <div className="bg-card rounded-2xl shadow-2xl overflow-hidden border border-border">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-20 p-2 rounded-full hover:bg-muted transition-colors"
          >
            <X className="h-5 w-5 text-muted-foreground" />
          </button>

          {/* Progress indicators */}
          <div className="flex gap-2 px-8 pt-6">
            {steps.map((_, idx) => (
              <div
                key={idx}
                className={`h-1 flex-1 rounded-full transition-colors duration-300 ${
                  idx <= currentStepIndex ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>

          {/* Content */}
          <div className="px-8 py-6 min-h-[280px] relative overflow-hidden">
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={currentStepIndex}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              >
                <OnboardingStepContent step={currentStep} />
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer */}
          <div className="px-8 pb-6 flex justify-end gap-3">
            <Button variant="ghost" onClick={onClose}>
              Luk
            </Button>
            <Button
              onClick={handleNext}
              variant={currentStep.ctaVariant === 'primary' ? 'default' : 'outline'}
            >
              {currentStep.cta}
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
