import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  AlertTriangle, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  ArrowRight,
  Building2,
  Zap,
  Target
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { format, isToday, isTomorrow, differenceInDays } from 'date-fns';
import { da } from 'date-fns/locale';
import { useTaskManagement } from '@/hooks/useTaskManagement';
import { useUpcomingMeetings } from '@/hooks/useUpcomingMeetings';
import { useRecentlyVisitedCompanies } from '@/hooks/useRecentlyVisitedCompanies';
import { cn } from '@/lib/utils';

const TodaysFocusSection = () => {
  const navigate = useNavigate();
  const { tasks, isLoading: tasksLoading } = useTaskManagement();
  const { data: meetings = [], isLoading: meetingsLoading } = useUpcomingMeetings(7);
  const { companies: recentCompanies, isLoading: recentLoading } = useRecentlyVisitedCompanies();

  // Filter urgent tasks (due today or overdue)
  const urgentTasks = tasks?.filter(t => {
    if (t.status === 'done' || t.status === 'cancelled') return false;
    if (!t.due_date) return false;
    const dueDate = new Date(t.due_date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return dueDate <= today;
  }) || [];

  // Today's meetings
  const todaysMeetings = meetings.filter(m => isToday(new Date(m.meeting_date)));
  const upcomingMeetings = meetings.filter(m => !isToday(new Date(m.meeting_date))).slice(0, 3);

  const formatMeetingDate = (dateStr: string) => {
    const date = new Date(dateStr);
    if (isToday(date)) return 'I dag';
    if (isTomorrow(date)) return 'I morgen';
    const days = differenceInDays(date, new Date());
    if (days < 7) return format(date, 'EEEE', { locale: da });
    return format(date, 'd. MMM', { locale: da });
  };

  const isLoading = tasksLoading || meetingsLoading || recentLoading;

  if (isLoading) {
    return (
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-background">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <Skeleton className="h-6 w-32" />
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const hasUrgentItems = urgentTasks.length > 0 || todaysMeetings.length > 0;

  return (
    <Card className={cn(
      "border-primary/20 transition-all duration-300",
      hasUrgentItems 
        ? "bg-gradient-to-br from-orange-500/10 via-primary/5 to-background" 
        : "bg-gradient-to-br from-primary/5 to-background"
    )}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">Today's Focus</CardTitle>
            {hasUrgentItems && (
              <Badge variant="destructive" className="ml-2">
                {urgentTasks.length + todaysMeetings.length} kræver handling
              </Badge>
            )}
          </div>
          <span className="text-sm text-muted-foreground">
            {format(new Date(), 'EEEE d. MMMM', { locale: da })}
          </span>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Urgent Tasks */}
          <Card className="bg-card/80 backdrop-blur">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className={cn(
                    "h-4 w-4",
                    urgentTasks.length > 0 ? "text-destructive" : "text-muted-foreground"
                  )} />
                  <span className="text-sm font-medium">Haster</span>
                </div>
                {urgentTasks.length > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {urgentTasks.length}
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-0 px-4 pb-4">
              {urgentTasks.length === 0 ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground py-2">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                  Ingen hastende opgaver
                </div>
              ) : (
                <div className="space-y-2">
                  {urgentTasks.slice(0, 2).map(task => (
                    <Link 
                      key={task.id} 
                      to="/tasks"
                      className="block p-2 rounded-md bg-destructive/10 hover:bg-destructive/20 transition-colors"
                    >
                      <p className="text-sm font-medium truncate">{task.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {task.due_date && format(new Date(task.due_date), 'd. MMM', { locale: da })}
                      </p>
                    </Link>
                  ))}
                  {urgentTasks.length > 2 && (
                    <Link to="/tasks" className="text-xs text-primary hover:underline">
                      +{urgentTasks.length - 2} flere
                    </Link>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Today's Meetings */}
          <Card className="bg-card/80 backdrop-blur">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className={cn(
                    "h-4 w-4",
                    todaysMeetings.length > 0 ? "text-primary" : "text-muted-foreground"
                  )} />
                  <span className="text-sm font-medium">Møder i dag</span>
                </div>
                {todaysMeetings.length > 0 && (
                  <Badge className="text-xs">{todaysMeetings.length}</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-0 px-4 pb-4">
              {todaysMeetings.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">Ingen møder i dag</p>
              ) : (
                <div className="space-y-2">
                  {todaysMeetings.slice(0, 2).map(meeting => (
                    <Link
                      key={meeting.id}
                      to={`/company/${meeting.company_id}?tab=meetings`}
                      className="block p-2 rounded-md bg-primary/10 hover:bg-primary/20 transition-colors"
                    >
                      <p className="text-sm font-medium truncate">{meeting.title}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {meeting.duration_minutes} min
                        <span>•</span>
                        {meeting.company_name}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Upcoming Meetings */}
          <Card className="bg-card/80 backdrop-blur">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Kommende</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0 px-4 pb-4">
              {upcomingMeetings.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">Ingen kommende møder</p>
              ) : (
                <div className="space-y-2">
                  {upcomingMeetings.map(meeting => (
                    <Link
                      key={meeting.id}
                      to={`/company/${meeting.company_id}?tab=meetings`}
                      className="flex items-center gap-2 p-1.5 rounded-md hover:bg-accent transition-colors"
                    >
                      <span className="text-xs font-medium text-primary min-w-[60px]">
                        {formatMeetingDate(meeting.meeting_date)}
                      </span>
                      <span className="text-sm truncate">{meeting.company_name}</span>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recently Visited */}
          <Card className="bg-card/80 backdrop-blur">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Senest besøgt</span>
                </div>
              </div>
            </CardHeader>
            <CardContent className="pt-0 px-4 pb-4">
              {recentCompanies.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">Ingen besøgte selskaber endnu</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {recentCompanies.slice(0, 4).map(company => (
                    <Button
                      key={company.id}
                      variant="outline"
                      size="sm"
                      className="h-auto py-1.5 px-2"
                      onClick={() => navigate(`/company/${company.id}`)}
                    >
                      <Avatar className="h-5 w-5 mr-1.5">
                        <AvatarImage src={company.logo_url || undefined} />
                        <AvatarFallback className="text-[10px]">
                          {company.name.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs truncate max-w-[80px]">{company.name}</span>
                    </Button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" asChild>
              <Link to="/tasks">
                Alle opgaver
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link to="/portfolio/companies">
                Portfolio
                <ArrowRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TodaysFocusSection;
