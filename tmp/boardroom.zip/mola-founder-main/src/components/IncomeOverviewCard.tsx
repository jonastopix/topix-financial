import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useIncomeEntries } from "@/hooks/useIncomeEntries";
import { formatCurrency } from "@/lib/formatters";

interface IncomeOverviewCardProps {
  className?: string;
}

export function IncomeOverviewCard({ className }: IncomeOverviewCardProps) {
  const { incomeEntries } = useIncomeEntries();

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const thisMonthIncome = incomeEntries?.filter(entry => {
    const entryDate = new Date(entry.income_date);
    return entryDate.getMonth() === currentMonth && entryDate.getFullYear() === currentYear;
  }).reduce((sum, entry) => sum + entry.amount_dkk, 0) || 0;

  const lastMonthIncome = incomeEntries?.filter(entry => {
    const entryDate = new Date(entry.income_date);
    const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    return entryDate.getMonth() === lastMonth && entryDate.getFullYear() === lastMonthYear;
  }).reduce((sum, entry) => sum + entry.amount_dkk, 0) || 0;

  const change = lastMonthIncome > 0 
    ? ((thisMonthIncome - lastMonthIncome) / lastMonthIncome) * 100 
    : 0;

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>Indkomst Oversigt</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-6">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Denne Måned</p>
            <p className="text-2xl font-bold">{formatCurrency(thisMonthIncome)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Sidste Måned</p>
            <p className="text-2xl font-bold">{formatCurrency(lastMonthIncome)}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground mb-1">Ændring</p>
            <p className={`text-2xl font-bold ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              {change >= 0 ? '+' : ''}{change.toFixed(1)}%
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
