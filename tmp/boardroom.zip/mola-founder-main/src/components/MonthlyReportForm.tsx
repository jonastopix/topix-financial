import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { DollarSign, TrendingUp, Droplet, Users, Target, Megaphone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface MonthlyReportFormProps {
  companyId?: string;
  onSubmit: () => void;
}

const MonthlyReportForm = ({ companyId, onSubmit }: MonthlyReportFormProps) => {
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [revenue, setRevenue] = useState('');
  const [budgetRevenue, setBudgetRevenue] = useState('');
  const [ebitda, setEbitda] = useState('');
  const [budgetEbitda, setBudgetEbitda] = useState('');
  const [marketingCost, setMarketingCost] = useState('');
  const [budgetMarketingCost, setBudgetMarketingCost] = useState('');
  const [liquidity, setLiquidity] = useState('');
  const [newCustomers, setNewCustomers] = useState('');
  const [comments, setComments] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!companyId || !month || !year || !revenue || !ebitda || !liquidity || !newCustomers) {
      toast({
        title: "Udfyld alle påkrævede felter",
        description: "Måned, år, omsætning, EBITDA, likviditet og nye kunder skal udfyldes.",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    const { error } = await supabase.from('monthly_reports').insert({
      company_id: companyId,
      period_month: parseInt(month),
      period_year: parseInt(year),
      revenue_dkk: parseFloat(revenue),
      budget_revenue_dkk: budgetRevenue ? parseFloat(budgetRevenue) : null,
      ebitda_dkk: parseFloat(ebitda),
      budget_ebitda_dkk: budgetEbitda ? parseFloat(budgetEbitda) : null,
      marketing_cost_dkk: marketingCost ? parseFloat(marketingCost) : null,
      budget_marketing_cost_dkk: budgetMarketingCost ? parseFloat(budgetMarketingCost) : null,
      cash_dkk: parseFloat(liquidity),
      new_customers: parseInt(newCustomers),
      note: comments || null,
    });

    setSubmitting(false);

    if (error) {
      toast({
        title: "Fejl",
        description: error.message.includes('duplicate') 
          ? "Der findes allerede en rapport for denne måned/år"
          : "Kunne ikke gemme rapporten",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Rapport gemt!",
      description: "Din månedlige rapport er blevet gemt succesfuldt.",
    });

    // Trigger auto-calculation of market-based valuation
    try {
      console.log('Triggering valuation calculation for company:', companyId);
      const { error: valuationError } = await supabase.functions.invoke('calculate-valuation', {
        body: { company_id: companyId }
      });

      if (valuationError) {
        console.error('Valuation calculation error:', valuationError);
        // Don't show error to user - this is a background process
      } else {
        console.log('Valuation calculation triggered successfully');
      }
    } catch (valuationError) {
      console.error('Failed to trigger valuation calculation:', valuationError);
      // Don't block the user if valuation fails
    }

    // Reset form
    setMonth('');
    setYear('');
    setRevenue('');
    setBudgetRevenue('');
    setEbitda('');
    setBudgetEbitda('');
    setMarketingCost('');
    setBudgetMarketingCost('');
    setLiquidity('');
    setNewCustomers('');
    setComments('');
    
    onSubmit();
  };

  return (
    <Card className="p-6">
      <h2 className="text-xl font-semibold mb-6">Rapportér månedlige tal</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="month">Måned</Label>
            <Input
              id="month"
              type="number"
              min="1"
              max="12"
              placeholder="1-12"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="year">År</Label>
            <Input
              id="year"
              type="number"
              placeholder="2025"
              value={year}
              onChange={(e) => setYear(e.target.value)}
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="revenue" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-green-500" />
              Omsætning (kr.)
            </Label>
            <Input
              id="revenue"
              type="number"
              placeholder="1200000"
              value={revenue}
              onChange={(e) => setRevenue(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="budgetRevenue" className="flex items-center gap-2">
              <Target className="h-4 w-4 text-green-500" />
              Omsætning Budget (kr.)
            </Label>
            <Input
              id="budgetRevenue"
              type="number"
              placeholder="1100000"
              value={budgetRevenue}
              onChange={(e) => setBudgetRevenue(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="ebitda" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-blue-500" />
              Resultat før skat (kr.)
            </Label>
            <Input
              id="ebitda"
              type="number"
              placeholder="180000"
              value={ebitda}
              onChange={(e) => setEbitda(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="budgetEbitda" className="flex items-center gap-2">
              <Target className="h-4 w-4 text-blue-500" />
              Resultat før skat Budget (kr.)
            </Label>
            <Input
              id="budgetEbitda"
              type="number"
              placeholder="150000"
              value={budgetEbitda}
              onChange={(e) => setBudgetEbitda(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="marketingCost" className="flex items-center gap-2">
              <Megaphone className="h-4 w-4 text-orange-500" />
              Marketing omk (kr.)
            </Label>
            <Input
              id="marketingCost"
              type="number"
              placeholder="120000"
              value={marketingCost}
              onChange={(e) => setMarketingCost(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="budgetMarketingCost" className="flex items-center gap-2">
              <Target className="h-4 w-4 text-orange-500" />
              Marketing omk Budget (kr.)
            </Label>
            <Input
              id="budgetMarketingCost"
              type="number"
              placeholder="100000"
              value={budgetMarketingCost}
              onChange={(e) => setBudgetMarketingCost(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="liquidity" className="flex items-center gap-2">
            <Droplet className="h-4 w-4 text-cyan-500" />
            Likvid beholdning (kr.)
          </Label>
          <Input
            id="liquidity"
            type="number"
            placeholder="1150000"
            value={liquidity}
            onChange={(e) => setLiquidity(e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="newCustomers" className="flex items-center gap-2">
            <Users className="h-4 w-4 text-purple-500" />
            Nye kunder
          </Label>
          <Input
            id="newCustomers"
            type="number"
            placeholder="63"
            value={newCustomers}
            onChange={(e) => setNewCustomers(e.target.value)}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="comments">Kommentar (valgfri)</Label>
          <Textarea
            id="comments"
            placeholder="Tilføj eventuelle kommentarer..."
            value={comments}
            onChange={(e) => setComments(e.target.value)}
            rows={3}
          />
        </div>

        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting ? 'Gemmer...' : 'Gem månedens rapport'}
        </Button>
      </form>
    </Card>
  );
};

export default MonthlyReportForm;