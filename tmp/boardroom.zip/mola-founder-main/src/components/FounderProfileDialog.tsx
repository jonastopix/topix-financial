import { Mail, Linkedin, Building2, X, Handshake, Briefcase } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';

interface FounderProfileDialogProps {
  founder: {
    id: string;
    full_name: string | null;
    title?: string;
    bio?: string;
    skills?: string[];
    linkedin_url?: string;
    avatar_url?: string;
    email?: string;
    can_help_with?: string;
    company: {
      id: string;
      name: string;
      logo_url?: string;
      industry?: string;
      description?: string;
      business_model?: string;
      target_market?: string;
    } | null;
    badges?: Array<{ code: string; label: string }>;
  } | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const industryLabels: Record<string, string> = {
  e_commerce: 'E-commerce',
  saas: 'SaaS',
  marketplace: 'Marketplace',
  fintech: 'Fintech',
  healthtech: 'Healthtech',
  proptech: 'Proptech',
  edtech: 'Edtech',
  cleantech: 'Cleantech',
  foodtech: 'Foodtech',
  logistics: 'Logistik',
  manufacturing: 'Produktion',
  media: 'Medie',
  services: 'Services',
  retail: 'Retail',
  other: 'Anden'
};

const businessModelLabels: Record<string, string> = {
  subscription: 'Abonnement',
  licensing: 'Licens',
  transaction: 'Transaktionsbaseret',
  advertising: 'Annoncering',
  marketplace: 'Markedsplads',
  saas: 'SaaS',
  other: 'Anden'
};

const targetMarketLabels: Record<string, string> = {
  b2b: 'B2B',
  b2c: 'B2C',
  b2b2c: 'B2B2C',
  b2g: 'B2G'
};

export const FounderProfileDialog = ({ founder, open, onOpenChange }: FounderProfileDialogProps) => {
  if (!founder) return null;

  const getInitials = (name: string | null | undefined) => {
    if (!name) return '??';
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleEmailClick = () => {
    if (founder.email) {
      window.location.href = `mailto:${founder.email}?subject=MOLA Founder Network - Hej ${founder.full_name}`;
    }
  };

  const handleLinkedInClick = () => {
    if (founder.linkedin_url) {
      window.open(founder.linkedin_url, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">Founder Profil</DialogTitle>
        </DialogHeader>

        {/* Header with Avatar and Basic Info */}
        <div className="flex items-start gap-4 pb-4">
          <Avatar className="h-20 w-20 border-2 border-border">
            <AvatarImage src={founder.avatar_url} alt={founder.full_name || 'Founder'} />
            <AvatarFallback className="bg-primary/10 text-primary text-xl">
              {getInitials(founder.full_name)}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-bold truncate">
              {founder.full_name || 'Ukendt bruger'}
            </h2>
            {founder.title && (
              <p className="text-lg text-muted-foreground">{founder.title}</p>
            )}
            {founder.company && (
              <div className="flex items-center gap-2 mt-2">
                {founder.company.logo_url ? (
                  <img
                    src={founder.company.logo_url}
                    alt={founder.company.name}
                    className="h-6 w-6 rounded object-cover"
                  />
                ) : (
                  <Building2 className="h-5 w-5 text-muted-foreground" />
                )}
                <span className="text-muted-foreground font-medium">
                  {founder.company.name}
                </span>
                {founder.company.industry && (
                  <Badge variant="outline" className="text-xs">
                    {industryLabels[founder.company.industry] || founder.company.industry}
                  </Badge>
                )}
              </div>
            )}
          </div>
        </div>

        <Separator />

        {/* Bio */}
        {founder.bio && (
          <div className="space-y-2 py-4">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
              Om mig
            </h3>
            <p className="text-sm leading-relaxed">{founder.bio}</p>
          </div>
        )}

        {/* Can Help With - Highlighted Section */}
        {founder.can_help_with && (
          <div className="space-y-2 py-4 bg-primary/5 rounded-lg p-4 border border-primary/20">
            <h3 className="font-semibold text-sm text-primary uppercase tracking-wide flex items-center gap-2">
              <Handshake className="h-4 w-4" />
              Jeg kan hjælpe med
            </h3>
            <p className="text-sm leading-relaxed">{founder.can_help_with}</p>
          </div>
        )}

        {/* Skills */}
        {founder.skills && founder.skills.length > 0 && (
          <div className="space-y-2 py-4">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
              Kompetencer
            </h3>
            <div className="flex flex-wrap gap-2">
              {founder.skills.map((skill) => (
                <Badge key={skill} variant="secondary">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Badges */}
        {founder.badges && founder.badges.length > 0 && (
          <div className="space-y-2 py-4">
            <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide">
              Præstationer
            </h3>
            <div className="flex flex-wrap gap-2">
              {founder.badges.map((badge) => (
                <Badge key={badge.code} variant="outline" className="border-yellow-500/50 text-yellow-700">
                  🏆 {badge.label}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Company Details */}
        {founder.company && (founder.company.description || founder.company.business_model || founder.company.target_market) && (
          <>
            <Separator />
            <div className="space-y-3 py-4">
              <h3 className="font-semibold text-sm text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Briefcase className="h-4 w-4" />
                Om virksomheden
              </h3>
              
              {founder.company.description && (
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {founder.company.description}
                </p>
              )}
              
              <div className="flex flex-wrap gap-3">
                {founder.company.business_model && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">Forretningsmodel: </span>
                    <span className="font-medium">
                      {businessModelLabels[founder.company.business_model] || founder.company.business_model}
                    </span>
                  </div>
                )}
                {founder.company.target_market && (
                  <div className="text-sm">
                    <span className="text-muted-foreground">Målgruppe: </span>
                    <span className="font-medium">
                      {targetMarketLabels[founder.company.target_market] || founder.company.target_market}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </>
        )}

        <Separator />

        {/* Contact Buttons */}
        <div className="flex gap-3 pt-4">
          {founder.email && (
            <Button className="flex-1" onClick={handleEmailClick}>
              <Mail className="h-4 w-4 mr-2" />
              Send email
            </Button>
          )}
          {founder.linkedin_url && (
            <Button variant="outline" className="flex-1" onClick={handleLinkedInClick}>
              <Linkedin className="h-4 w-4 mr-2" />
              LinkedIn
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
