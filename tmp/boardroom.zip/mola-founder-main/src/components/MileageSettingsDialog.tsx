import { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { useQuery } from '@tanstack/react-query';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useMileageSettings, useMileageMutations } from '@/hooks/useMileage';
import { supabase } from '@/integrations/supabase/client';

interface MileageSettingsForm {
  employee_name: string;
  private_address: string;
  office_address: string;
  accountant_name: string;
  accountant_email: string;
  default_paying_fund_id: string;
}

interface MileageSettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function MileageSettingsDialog({ open, onOpenChange }: MileageSettingsDialogProps) {
  const { data: settings, isLoading } = useMileageSettings();
  const { upsertSettings } = useMileageMutations();

  // Fetch all funds for default paying fund dropdown
  const { data: funds = [] } = useQuery({
    queryKey: ['funds-for-mileage-settings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data;
    },
  });
  
  const form = useForm<MileageSettingsForm>({
    defaultValues: {
      employee_name: '',
      private_address: '',
      office_address: '',
      accountant_name: '',
      accountant_email: '',
      default_paying_fund_id: '',
    },
  });
  
  useEffect(() => {
    if (settings) {
      form.reset({
        employee_name: settings.employee_name || '',
        private_address: settings.private_address || '',
        office_address: settings.office_address || '',
        accountant_name: settings.accountant_name || '',
        accountant_email: settings.accountant_email || '',
        default_paying_fund_id: settings.default_paying_fund_id || '',
      });
    }
  }, [settings, form]);
  
  const onSubmit = async (data: MileageSettingsForm) => {
    await upsertSettings.mutateAsync({
      employee_name: data.employee_name,
      private_address: data.private_address,
      office_address: data.office_address || null,
      accountant_name: data.accountant_name || null,
      accountant_email: data.accountant_email || null,
      default_paying_fund_id: data.default_paying_fund_id || null,
    });
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Kørselsindstillinger</DialogTitle>
          <DialogDescription>
            Konfigurer dine standardadresser til kørselsregnskab
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="employee_name"
              rules={{ required: 'Medarbejdernavn er påkrævet' }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Medarbejdernavn</FormLabel>
                  <FormControl>
                    <Input placeholder="Dit fulde navn" {...field} />
                  </FormControl>
                  <FormDescription>
                    Vises på kørselsrapporter til SKAT
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="private_address"
              rules={{ required: 'Privatadresse er påkrævet' }}
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Privatadresse</FormLabel>
                  <FormControl>
                    <Input placeholder="Strandvejen 100, 2900 Hellerup" {...field} />
                  </FormControl>
                  <FormDescription>
                    Din bopælsadresse
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="office_address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kontoradresse (valgfri)</FormLabel>
                  <FormControl>
                    <Input placeholder="Amagertorv 1, 1160 København K" {...field} />
                  </FormControl>
                  <FormDescription>
                    Dit primære arbejdssted
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="default_paying_fund_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Standard betalingsfund</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg standard fund..." />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {funds.map((fund) => (
                        <SelectItem key={fund.id} value={fund.id}>
                          {fund.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Forvælges automatisk ved ny kørselsregistrering
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="border-t pt-4 mt-4">
              <h4 className="font-medium mb-4">Bogholderikontakt</h4>
              
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="accountant_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bogholder navn</FormLabel>
                      <FormControl>
                        <Input placeholder="Anna Hansen" {...field} />
                      </FormControl>
                      <FormDescription>
                        Kontaktperson for kørselsrapporter
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="accountant_email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bogholder email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="bogholderi@firma.dk" {...field} />
                      </FormControl>
                      <FormDescription>
                        Udfyldes automatisk ved afsendelse af kørselsrapport
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <div className="rounded-lg bg-muted p-4">
              <h4 className="font-medium mb-2">SKAT-satser 2026</h4>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>Høj sats: <strong>3,94 kr/km</strong> (op til 20.000 km/år)</p>
                <p>Lav sats: <strong>2,28 kr/km</strong> (over 20.000 km/år)</p>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Annuller
              </Button>
              <Button type="submit" disabled={upsertSettings.isPending}>
                {upsertSettings.isPending ? 'Gemmer...' : 'Gem indstillinger'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
