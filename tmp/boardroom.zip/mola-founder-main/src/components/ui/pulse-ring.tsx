import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface PulseRingProps {
  show: boolean;
  variant?: 'success' | 'destructive' | 'primary';
  children: ReactNode;
  className?: string;
}

export function PulseRing({ show, variant = 'primary', children, className }: PulseRingProps) {
  const variantColors = {
    success: 'hsl(var(--success))',
    destructive: 'hsl(var(--destructive))',
    primary: 'hsl(var(--primary))',
  };

  return (
    <div className={cn('relative', className)}>
      {show && (
        <div 
          className="absolute inset-0 rounded-lg animate-kpi-pulse pointer-events-none"
          style={{ 
            '--pulse-color': variantColors[variant],
          } as React.CSSProperties}
        />
      )}
      {children}
    </div>
  );
}
