import { useState, useEffect } from 'react';
import { Keyboard, X, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useSidebar } from '@/components/ui/sidebar';

const STORAGE_KEY = 'keyboard-shortcuts-hint-visible';

const shortcuts = [
  { key: 'T', description: 'Ny opgave' },
  { key: 'A', description: 'Ny aktivitet' },
  { key: '⌘K', description: 'Søg' },
];

export function KeyboardShortcutsHint() {
  const { open } = useSidebar();
  const [isVisible, setIsVisible] = useState(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored === null ? true : stored === 'true';
  });
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, String(isVisible));
  }, [isVisible]);

  // Don't show when sidebar is collapsed
  if (!open) return null;

  // If hidden completely, show small button to bring it back
  if (!isVisible) {
    return (
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsVisible(true)}
        className="w-full flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground"
      >
        <Keyboard className="h-3.5 w-3.5" />
        <span>Vis genveje</span>
      </Button>
    );
  }

  return (
    <div className="bg-muted/50 rounded-lg p-2 space-y-1.5">
      <div className="flex items-center justify-between">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          <Keyboard className="h-3.5 w-3.5" />
          <span>Genveje</span>
          <ChevronUp 
            className={cn(
              "h-3 w-3 transition-transform",
              !isExpanded && "rotate-180"
            )} 
          />
        </button>
        <button
          onClick={() => setIsVisible(false)}
          className="text-muted-foreground hover:text-foreground transition-colors p-0.5 rounded hover:bg-muted"
          title="Skjul genveje"
        >
          <X className="h-3 w-3" />
        </button>
      </div>

      {isExpanded && (
        <div className="space-y-0.5">
          {shortcuts.map((shortcut) => (
            <div
              key={shortcut.key}
              className="flex items-center justify-between text-xs"
            >
              <span className="text-muted-foreground">{shortcut.description}</span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-background border border-border rounded shadow-sm">
                {shortcut.key}
              </kbd>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
