import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DDStatusBadge } from '@/components/DDStatusBadge';
import { AlertTriangle, Calendar, ChevronRight, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DDCaseCardProps {
  caseItem: {
    id: string;
    status: string;
    deadline: string | null;
    started_at: string | null;
    progressPercentage: number;
    completedCategories: number;
    totalCategories: number;
    companies?: { name: string } | null;
  };
}

const DDCaseCard = ({ caseItem }: DDCaseCardProps) => {
  const navigate = useNavigate();

  const getDeadlineInfo = () => {
    if (!caseItem.deadline) return null;
    const deadlineDate = new Date(caseItem.deadline);
    const today = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    const isOverdue = daysUntil < 0;
    const isNear = daysUntil >= 0 && daysUntil <= 7;
    return { deadlineDate, isOverdue, isNear, daysUntil };
  };

  const deadlineInfo = getDeadlineInfo();

  return (
    <Card 
      className="p-4 hover:bg-muted/50 transition-colors tap-safe"
      onClick={() => navigate(`/portfolio/due-diligence/${caseItem.id}`)}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-base truncate mb-2">
            {caseItem.companies?.name}
          </h3>
          <DDStatusBadge status={caseItem.status as any} />
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground flex-shrink-0 mt-1" />
      </div>

      {/* Progress bar */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">Fremskridt</span>
          <span className="font-medium">{caseItem.progressPercentage}%</span>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div
            className={cn(
              "rounded-full h-2 transition-all",
              caseItem.status === 'approved' && "bg-green-600",
              caseItem.status === 'rejected' && "bg-red-600",
              caseItem.status === 'in_progress' && "bg-blue-600",
              caseItem.status === 'pending_review' && "bg-yellow-600",
              caseItem.status === 'not_started' && "bg-gray-400"
            )}
            style={{ width: `${caseItem.progressPercentage}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          {caseItem.completedCategories} af {caseItem.totalCategories} kategorier
        </p>
      </div>

      {/* Info row */}
      <div className="mt-4 flex items-center gap-4 text-sm">
        {deadlineInfo && (
          <div className={cn(
            "flex items-center gap-1.5",
            deadlineInfo.isOverdue && "text-destructive",
            deadlineInfo.isNear && !deadlineInfo.isOverdue && "text-yellow-600"
          )}>
            {(deadlineInfo.isOverdue || deadlineInfo.isNear) && (
              <AlertTriangle className="h-4 w-4" />
            )}
            <Calendar className="h-4 w-4" />
            <span>{deadlineInfo.deadlineDate.toLocaleDateString('da-DK')}</span>
          </div>
        )}
        {caseItem.started_at && (
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{new Date(caseItem.started_at).toLocaleDateString('da-DK')}</span>
          </div>
        )}
      </div>
    </Card>
  );
};

export default DDCaseCard;
