import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { CalendarPlus } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Drawer, DrawerContent, DrawerTrigger } from '@/components/ui/drawer';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-mobile';
import { useRole } from '@/contexts/RoleContext';
import { supabase } from '@/integrations/supabase/client';
import { CompanyActivitySheet } from './CompanyActivitySheet';

export function CompanyActivityFAB() {
  const location = useLocation();
  const isMobile = useIsMobile();
  const { isAdmin, activeRole } = useRole();
  const [open, setOpen] = useState(false);

  // Extract company ID from URL
  const companyIdMatch = location.pathname.match(/\/company\/([a-f0-9-]+)/i);
  const companyId = companyIdMatch?.[1];

  // Fetch company name
  const { data: company } = useQuery({
    queryKey: ['company-name', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('name')
        .eq('id', companyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  // Only show on company pages
  if (!companyId) return null;

  // Only show for users who can log activity
  const canLogActivity = isAdmin || activeRole === 'fund_partner';
  if (!canLogActivity) return null;

  const companyName = company?.name || 'Selskab';

  const fabButton = (
    <Button
      size="icon"
      className="fixed z-40 shadow-lg bg-primary hover:bg-primary/90
                 bottom-20 right-4 h-14 w-14 rounded-full
                 md:bottom-6 md:right-6 md:h-12 md:w-auto md:rounded-lg md:px-4"
      aria-label="Registrer aktivitet"
    >
      <CalendarPlus className="h-6 w-6 md:h-5 md:w-5" />
      <span className="hidden md:inline md:ml-2">Registrer aktivitet</span>
    </Button>
  );

  // Use Drawer on mobile, Sheet on desktop
  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={setOpen}>
        <DrawerTrigger asChild>
          {fabButton}
        </DrawerTrigger>
        <DrawerContent>
          <CompanyActivitySheet 
            companyId={companyId} 
            companyName={companyName}
            onSuccess={() => setOpen(false)} 
          />
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        {fabButton}
      </SheetTrigger>
      <SheetContent side="right" className="w-[400px] sm:w-[450px]">
        <CompanyActivitySheet 
          companyId={companyId} 
          companyName={companyName}
          onSuccess={() => setOpen(false)} 
        />
      </SheetContent>
    </Sheet>
  );
}
