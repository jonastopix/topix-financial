import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { formatCompact, formatPercentage } from '@/lib/formatters';
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend 
} from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Activity, Users } from 'lucide-react';

export function TrendAnalysisChart() {
  const currentYear = new Date().getFullYear();

  const { data: trendData, isLoading } = useQuery({
    queryKey: ['portfolio-trends', currentYear],
    queryFn: async () => {
      // Get all companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true);
      
      if (companiesError) throw companiesError;

      // Get monthly reports for the last 12 months
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', companies?.map(c => c.id) || [])
        .gte('period_year', currentYear - 1);
      
      if (reportsError) throw reportsError;

      // Aggregate data by month
      const monthlyData: Record<string, any> = {};

      reports?.forEach(report => {
        const key = `${report.period_year}-${String(report.period_month).padStart(2, '0')}`;
        
        if (!monthlyData[key]) {
          monthlyData[key] = {
            period: key,
            totalRevenue: 0,
            totalEbitda: 0,
            totalNewCustomers: 0,
            companies: 0,
            avgMargin: 0,
          };
        }

        monthlyData[key].totalRevenue += Number(report.revenue_dkk) || 0;
        monthlyData[key].totalEbitda += Number(report.ebitda_dkk) || 0;
        monthlyData[key].totalNewCustomers += report.new_customers || 0;
        monthlyData[key].companies += 1;
      });

      // Calculate averages and format data
      const formattedData = Object.values(monthlyData)
        .map((data: any) => ({
          ...data,
          avgRevenue: data.companies > 0 ? data.totalRevenue / data.companies : 0,
          avgEbitda: data.companies > 0 ? data.totalEbitda / data.companies : 0,
          avgMargin: data.totalRevenue > 0 ? (data.totalEbitda / data.totalRevenue) * 100 : 0,
        }))
        .sort((a, b) => a.period.localeCompare(b.period))
        .slice(-12); // Last 12 months

      return formattedData;
    },
  });

  if (isLoading || !trendData) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Trend Analysis</h2>
        </div>
        <p className="text-muted-foreground">Indlæser...</p>
      </Card>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const formatMonth = (period: string) => {
    const [year, month] = period.split('-');
    return `${month}/${year.slice(2)}`;
  };

  // Find latest month with actual data (not future months with 0)
  const latestDataPoint = [...trendData].reverse().find(d => d.totalRevenue > 0 || d.totalEbitda > 0) || trendData[trendData.length - 1];
  
  // Find previous month with data for comparison
  const latestIndex = trendData.findIndex(d => d.period === latestDataPoint.period);
  const previousDataPoint = latestIndex > 0 ? trendData[latestIndex - 1] : null;

  // Calculate changes
  const revenueChange = previousDataPoint && previousDataPoint.totalRevenue > 0 
    ? ((latestDataPoint.totalRevenue - previousDataPoint.totalRevenue) / previousDataPoint.totalRevenue) * 100 
    : 0;
  const ebitdaChange = previousDataPoint && previousDataPoint.totalEbitda > 0 
    ? ((latestDataPoint.totalEbitda - previousDataPoint.totalEbitda) / previousDataPoint.totalEbitda) * 100 
    : 0;
  const marginChange = previousDataPoint 
    ? latestDataPoint.avgMargin - previousDataPoint.avgMargin 
    : 0;
  const customersChange = previousDataPoint 
    ? latestDataPoint.totalNewCustomers - previousDataPoint.totalNewCustomers 
    : 0;

  const TrendIndicator = ({ value, isPercentage = true }: { value: number; isPercentage?: boolean }) => {
    if (value === 0) return null;
    const isPositive = value > 0;
    return (
      <div className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-success' : 'text-destructive'}`}>
        {isPositive ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
        <span>
          {isPositive ? '+' : ''}{isPercentage ? formatPercentage(value, 1) : value}
        </span>
      </div>
    );
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <TrendingUp className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-bold">Portfolio Trend Analysis</h2>
      </div>

      <Tabs defaultValue="revenue" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="revenue">Omsætning</TabsTrigger>
          <TabsTrigger value="ebitda">EBITDA</TabsTrigger>
          <TabsTrigger value="margin">Margin</TabsTrigger>
          <TabsTrigger value="customers">Kunder</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="space-y-4">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">Total omsætning (seneste måned)</p>
              <p className="text-2xl font-bold">
                {formatCurrency(latestDataPoint.totalRevenue)}
              </p>
              <TrendIndicator value={revenueChange} />
            </div>
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">Gennemsnit per selskab</p>
              <p className="text-2xl font-bold">
                {formatCurrency(latestDataPoint.avgRevenue)}
              </p>
              <TrendIndicator value={revenueChange} />
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="period" 
                tickFormatter={formatMonth}
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => formatCompact(value, 1)}
              />
              <Tooltip 
                formatter={(value: number) => formatCurrency(value)}
                labelFormatter={formatMonth}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="totalRevenue" 
                name="Total omsætning"
                stroke="hsl(var(--primary))" 
                strokeWidth={3}
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>

        <TabsContent value="ebitda" className="space-y-4">
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">Total EBITDA (seneste måned)</p>
              <p className="text-2xl font-bold">
                {formatCurrency(latestDataPoint.totalEbitda)}
              </p>
              <TrendIndicator value={ebitdaChange} />
            </div>
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">Gennemsnit per selskab</p>
              <p className="text-2xl font-bold">
                {formatCurrency(latestDataPoint.avgEbitda)}
              </p>
              <TrendIndicator value={ebitdaChange} />
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="period" 
                tickFormatter={formatMonth}
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => formatCompact(value, 1)}
              />
              <Tooltip 
                formatter={(value: number) => formatCurrency(value)}
                labelFormatter={formatMonth}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="totalEbitda" name="Total EBITDA" fill="hsl(var(--primary))" />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>

        <TabsContent value="margin" className="space-y-4">
          <div className="p-4 rounded-lg bg-muted/50 mb-4">
            <p className="text-sm text-muted-foreground">Gennemsnitlig EBITDA-margin</p>
            <p className="text-2xl font-bold">
              {formatPercentage(latestDataPoint.avgMargin, 1)}
            </p>
            <TrendIndicator value={marginChange} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="period" 
                tickFormatter={formatMonth}
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickFormatter={(value) => formatPercentage(value, 0)}
              />
              <Tooltip 
                formatter={(value: number) => formatPercentage(value, 1)}
                labelFormatter={formatMonth}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="avgMargin" 
                name="EBITDA Margin"
                stroke="hsl(var(--chart-2))" 
                strokeWidth={3}
                dot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </TabsContent>

        <TabsContent value="customers" className="space-y-4">
          <div className="p-4 rounded-lg bg-muted/50 mb-4">
            <p className="text-sm text-muted-foreground">Nye kunder (seneste måned)</p>
            <p className="text-2xl font-bold">
              {latestDataPoint.totalNewCustomers}
            </p>
            <TrendIndicator value={customersChange} isPercentage={false} />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="period" 
                tickFormatter={formatMonth}
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
              />
              <Tooltip 
                labelFormatter={formatMonth}
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="totalNewCustomers" name="Nye kunder" fill="hsl(var(--chart-3))" />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
