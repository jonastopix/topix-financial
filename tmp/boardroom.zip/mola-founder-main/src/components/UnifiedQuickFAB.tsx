import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Plus, CalendarPlus, CheckSquare, Car, X } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Drawer, DrawerContent, DrawerTrigger, DrawerClose } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { supabase } from '@/integrations/supabase/client';
import { QuickTaskSheet } from './QuickTaskSheet';
import { MileageQuickSheet } from './MileageQuickSheet';
import { CompanyActivitySheet } from './CompanyActivitySheet';
import { ActivityShortcutDialog } from './ActivityShortcutDialog';
import { cn } from '@/lib/utils';

interface QuickAction {
  id: string;
  label: string;
  icon: React.ElementType;
  roles?: string[];
  onClick: () => void;
}

interface UnifiedQuickFABProps {
  /** When true, renders as an inline button (for nav bar) instead of fixed FAB */
  inline?: boolean;
}

export function UnifiedQuickFAB({ inline = false }: UnifiedQuickFABProps) {
  const location = useLocation();
  const isMobile = useIsMobile();
  const { user } = useAuth();
  const { activeRole, isAdmin } = useRole();
  
  const [menuOpen, setMenuOpen] = useState(false);
  const [taskSheetOpen, setTaskSheetOpen] = useState(false);
  const [mileageSheetOpen, setMileageSheetOpen] = useState(false);
  const [activityDialogOpen, setActivityDialogOpen] = useState(false);
  const [companyActivityOpen, setCompanyActivityOpen] = useState(false);

  // Extract company ID from URL
  const companyIdMatch = location.pathname.match(/\/company\/([a-f0-9-]+)/i);
  const companyId = companyIdMatch?.[1];
  const isCompanyPage = !!companyId;
  const isTasksPage = location.pathname === '/tasks';

  // Fetch company name for company pages
  const { data: company } = useQuery({
    queryKey: ['company-fab', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('name')
        .eq('id', companyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  // Only show for authenticated users on mobile (unless inline mode)
  if (!inline && (!isMobile || !user)) return null;
  if (inline && !user) return null;

  // Roles that can log activity and mileage
  const canLogActivity = isAdmin || activeRole === 'fund_partner';
  const canLogMileage = ['owner', 'mola_admin', 'fund_partner'].includes(activeRole);

  const companyName = company?.name || 'Selskab';

  // Handle direct actions for specific pages
  const handleFabClick = () => {
    if (isCompanyPage && canLogActivity) {
      // On company page, open activity registration directly
      setCompanyActivityOpen(true);
    } else if (isTasksPage) {
      // On tasks page, open task creation directly
      setTaskSheetOpen(true);
    } else {
      // Otherwise, show the quick menu
      setMenuOpen(true);
    }
  };

  // Define available actions based on role
  const actions: QuickAction[] = [];

  if (canLogActivity) {
    actions.push({
      id: 'activity',
      label: 'Registrer aktivitet',
      icon: CalendarPlus,
      onClick: () => {
        setMenuOpen(false);
        setActivityDialogOpen(true);
      },
    });
  }

  actions.push({
    id: 'task',
    label: 'Opret opgave',
    icon: CheckSquare,
    onClick: () => {
      setMenuOpen(false);
      setTaskSheetOpen(true);
    },
  });

  if (canLogMileage) {
    actions.push({
      id: 'mileage',
      label: 'Registrer kørsel',
      icon: Car,
      onClick: () => {
        setMenuOpen(false);
        setMileageSheetOpen(true);
      },
    });
  }

  // Menu content component
  const MenuContent = () => (
    <div className="p-4 pb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Hurtige handlinger</h3>
        <DrawerClose asChild>
          <Button variant="ghost" size="icon">
            <X className="h-5 w-5" />
          </Button>
        </DrawerClose>
      </div>
      <div className="grid gap-3">
        {actions.map((action) => (
          <Button
            key={action.id}
            variant="outline"
            className="h-16 justify-start gap-4 text-left"
            onClick={action.onClick}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
              <action.icon className="h-5 w-5 text-primary" />
            </div>
            <span className="text-base font-medium">{action.label}</span>
          </Button>
        ))}
      </div>
    </div>
  );

  // Inline button for bottom nav
  const inlineButton = (
    <button
      className={cn(
        "flex flex-col items-center justify-center gap-1 p-2 min-w-[64px] min-h-[48px] rounded-lg transition-colors tap-safe",
        "text-muted-foreground hover:text-foreground hover:bg-muted/50"
      )}
      onClick={handleFabClick}
      aria-label="Registrer"
    >
      <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
        <Plus className="h-5 w-5 text-primary-foreground" />
      </div>
      <span className="text-xs font-medium">Registrer</span>
    </button>
  );

  // Main FAB button (fixed position)
  const fabButton = (
    <Button
      size="icon"
      className="fixed bottom-20 right-4 h-14 w-14 rounded-full shadow-lg z-50 bg-primary hover:bg-primary/90"
      aria-label="Hurtige handlinger"
      onClick={handleFabClick}
    >
      <Plus className="h-7 w-7" />
    </Button>
  );

  // Choose which button to render
  const triggerButton = inline ? inlineButton : fabButton;

  return (
    <>
      {/* Main trigger - show menu drawer when needed */}
      {!isCompanyPage && !isTasksPage ? (
        <Drawer open={menuOpen} onOpenChange={setMenuOpen}>
          <DrawerTrigger asChild>
            {triggerButton}
          </DrawerTrigger>
          <DrawerContent>
            <MenuContent />
          </DrawerContent>
        </Drawer>
      ) : (
        triggerButton
      )}

      {/* Task creation sheet */}
      <Drawer open={taskSheetOpen} onOpenChange={setTaskSheetOpen}>
        <DrawerContent>
          <QuickTaskSheet onSuccess={() => setTaskSheetOpen(false)} />
        </DrawerContent>
      </Drawer>

      {/* Mileage registration sheet */}
      <MileageQuickSheet open={mileageSheetOpen} onOpenChange={setMileageSheetOpen} />

      {/* Activity shortcut dialog (for non-company pages) */}
      <ActivityShortcutDialog open={activityDialogOpen} onOpenChange={setActivityDialogOpen} />

      {/* Company activity sheet (for company pages) */}
      {isCompanyPage && (
        <Drawer open={companyActivityOpen} onOpenChange={setCompanyActivityOpen}>
          <DrawerContent>
            <CompanyActivitySheet
              companyId={companyId!}
              companyName={companyName}
              onSuccess={() => setCompanyActivityOpen(false)}
            />
          </DrawerContent>
        </Drawer>
      )}
    </>
  );
}
