import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Activity, AlertCircle, CheckCircle2, TrendingUp } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface CompanyHealthIndexProps {
  score: number;
}

const CompanyHealthIndex = ({ score: targetScore }: CompanyHealthIndexProps) => {
  const [score, setScore] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setScore(targetScore);
    }, 100);

    return () => clearTimeout(timer);
  }, [targetScore]);

  const getHealthStatus = (score: number) => {
    if (score >= 80) {
      return {
        label: 'Sund',
        color: 'text-green-500',
        icon: CheckCircle2,
      };
    } else if (score >= 50) {
      return {
        label: 'Stabil',
        color: 'text-yellow-500',
        icon: TrendingUp,
      };
    } else {
      return {
        label: 'Risiko',
        color: 'text-red-500',
        icon: AlertCircle,
      };
    }
  };

  const status = getHealthStatus(score);
  const StatusIcon = status.icon;

  const circumference = 2 * Math.PI * 70;
  const offset = circumference - (score / 100) * circumference;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Company Health Index</h3>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger>
              <Activity className="h-5 w-5 text-muted-foreground cursor-help" />
            </TooltipTrigger>
            <TooltipContent side="left" className="max-w-xs">
              <p className="font-semibold mb-2">Sådan beregnes Health Index:</p>
              <ul className="text-sm space-y-1">
                <li>• Financial (40%): YTD vækst & EBITDA-margin</li>
                <li>• Growth (30%): YOY omsætningsvækst</li>
                <li>• Transparency (20%): Rapporteringskonsistens</li>
                <li>• Relationship (10%): NPS score</li>
              </ul>
              <p className="mt-2 text-xs">
                🟢 {'>'}80% = Sund | 🟡 50-80% = Stabil | 🔴 {'<'}50% = Risiko
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="flex flex-col items-center justify-center py-8">
        <div className="relative w-48 h-48">
          <svg className="transform -rotate-90 w-48 h-48">
            <circle
              cx="96"
              cy="96"
              r="70"
              stroke="currentColor"
              strokeWidth="12"
              fill="transparent"
              className="text-muted"
            />
            <circle
              cx="96"
              cy="96"
              r="70"
              stroke="currentColor"
              strokeWidth="12"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              className={`${status.color} transition-all duration-1000 ease-out`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-4xl font-bold ${status.color}`}>
              {Math.round(score)}
            </span>
            <span className="text-sm text-muted-foreground">/ 100</span>
          </div>
        </div>

        <div className={`flex items-center gap-2 mt-4 ${status.color}`}>
          <StatusIcon className="h-5 w-5" />
          <span className="font-semibold text-lg">{status.label}</span>
        </div>
      </div>
    </Card>
  );
};

export default CompanyHealthIndex;