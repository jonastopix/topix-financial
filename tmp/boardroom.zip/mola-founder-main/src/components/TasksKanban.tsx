import { useState } from 'react';
import { Task, useTaskManagement } from '@/hooks/useTaskManagement';
import TaskCard from './TaskCard';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface TasksKanbanProps {
  tasks: Task[];
}

const TasksKanban = ({ tasks }: TasksKanbanProps) => {
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverColumn, setDragOverColumn] = useState<string | null>(null);
  const { updateTask } = useTaskManagement();

  const columns = [
    { id: 'todo' as const, title: 'Ikke påbegyndt', tasks: tasks.filter(t => t.status === 'todo') },
    { id: 'in_progress' as const, title: 'I gang', tasks: tasks.filter(t => t.status === 'in_progress') },
    { id: 'done' as const, title: 'Færdig', tasks: tasks.filter(t => t.status === 'done') },
  ];

  const handleDragStart = (taskId: string) => {
    setDraggedTaskId(taskId);
  };

  const handleDragEnd = () => {
    setDraggedTaskId(null);
    setDragOverColumn(null);
  };

  const handleDragOver = (e: React.DragEvent, columnId: string) => {
    e.preventDefault();
    setDragOverColumn(columnId);
  };

  const handleDragLeave = () => {
    setDragOverColumn(null);
  };

  const handleDrop = (e: React.DragEvent, columnId: 'todo' | 'in_progress' | 'done') => {
    e.preventDefault();
    if (draggedTaskId) {
      const task = tasks.find(t => t.id === draggedTaskId);
      if (task && task.status !== columnId) {
        updateTask.mutate({ id: draggedTaskId, status: columnId });
      }
    }
    setDraggedTaskId(null);
    setDragOverColumn(null);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {columns.map((column) => (
        <Card 
          key={column.id} 
          className={cn(
            "flex flex-col transition-all duration-200",
            dragOverColumn === column.id && "ring-2 ring-primary bg-primary/5"
          )}
          onDragOver={(e) => handleDragOver(e, column.id)}
          onDragLeave={handleDragLeave}
          onDrop={(e) => handleDrop(e, column.id)}
        >
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center justify-between">
              {column.title}
              <span className="text-sm font-normal text-muted-foreground">
                {column.tasks.length}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 flex-1 min-h-[100px]">
            {column.tasks.length === 0 ? (
              <div className="text-center text-sm text-muted-foreground py-8">
                Ingen opgaver
              </div>
            ) : (
              column.tasks.map((task) => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  onDragStart={handleDragStart}
                  onDragEnd={handleDragEnd}
                  isDragging={draggedTaskId === task.id}
                />
              ))
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default TasksKanban;
