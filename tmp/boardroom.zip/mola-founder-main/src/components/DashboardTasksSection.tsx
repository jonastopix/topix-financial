import { useState, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useNavigate } from "react-router-dom";
import { useTaskManagement } from "@/hooks/useTaskManagement";
import CreateTaskDialog from "@/components/CreateTaskDialog";
import TaskDetailsDialog from "@/components/TaskDetailsDialog";
import TasksTable from "@/components/TasksTable";
import TaskMobileRow from "@/components/TaskMobileRow";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  Search, 
  Plus, 
  ArrowRight, 
  AlertTriangle,
  Clock,
  CheckCircle2,
  ListTodo
} from "lucide-react";
import { format, isPast, addDays, isWithinInterval, isToday } from "date-fns";
import { da } from "date-fns/locale";

export const DashboardTasksSection = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { tasks, isLoading, updateTask } = useTaskManagement();
  
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("open");
  const [sortOrder, setSortOrder] = useState<string>("due_date");
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Task statistics
  const taskStats = useMemo(() => {
    if (!tasks) return { active: 0, overdue: 0, dueThisWeek: 0, completed: 0 };
    
    const now = new Date();
    const weekEnd = addDays(now, 7);
    
    const active = tasks.filter(t => !['done', 'cancelled'].includes(t.status)).length;
    const overdue = tasks.filter(t => 
      t.due_date && 
      isPast(new Date(t.due_date)) && 
      !isToday(new Date(t.due_date)) &&
      !['done', 'cancelled'].includes(t.status)
    ).length;
    const dueThisWeek = tasks.filter(t => 
      t.due_date && 
      isWithinInterval(new Date(t.due_date), { start: now, end: weekEnd }) &&
      !['done', 'cancelled'].includes(t.status)
    ).length;
    const completed = tasks.filter(t => t.status === 'done').length;
    
    return { active, overdue, dueThisWeek, completed };
  }, [tasks]);

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    if (!tasks) return [];
    
    let filtered = [...tasks];
    
    // Status filter
    if (statusFilter === "open") {
      filtered = filtered.filter(t => !['done', 'cancelled'].includes(t.status));
    } else if (statusFilter !== "all") {
      filtered = filtered.filter(t => t.status === statusFilter);
    }
    
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(t => 
        t.title.toLowerCase().includes(query) ||
        t.company?.name?.toLowerCase().includes(query)
      );
    }
    
    // Sort
    filtered.sort((a, b) => {
      // Priority order: urgent > high > medium > low
      const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
      
      if (sortOrder === "priority") {
        return (priorityOrder[a.priority as keyof typeof priorityOrder] || 3) - 
               (priorityOrder[b.priority as keyof typeof priorityOrder] || 3);
      } else if (sortOrder === "due_date") {
        // Overdue tasks first, then by date
        const aDate = a.due_date ? new Date(a.due_date) : new Date('2099-12-31');
        const bDate = b.due_date ? new Date(b.due_date) : new Date('2099-12-31');
        return aDate.getTime() - bDate.getTime();
      } else if (sortOrder === "title") {
        return a.title.localeCompare(b.title);
      }
      return 0;
    });
    
    return filtered;
  }, [tasks, statusFilter, searchQuery, sortOrder]);

  // Show max 12 tasks in dashboard
  const displayedTasks = filteredTasks.slice(0, 12);
  const remainingCount = Math.max(0, filteredTasks.length - 12);

  const handleTaskClick = (task: any) => {
    setSelectedTask(task);
    setIsDialogOpen(true);
  };

  const handleToggleStatus = (task: any) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    updateTask.mutate({ id: task.id, status: newStatus });
  };

  if (isLoading) {
    return (
      <Card className="border-none shadow-lg">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-none shadow-lg bg-gradient-to-br from-background to-muted/20">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <ListTodo className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="text-xl font-semibold">Dine opgaver</CardTitle>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(), "EEEE d. MMMM", { locale: da })}
                </p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <CreateTaskDialog 
                trigger={
                  <Button size="sm" className="gap-1.5">
                    <Plus className="h-4 w-4" />
                    Ny opgave
                  </Button>
                }
              />
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => navigate('/tasks')}
                className="gap-1.5"
              >
                Se alle
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Quick Stats */}
          <div className="flex flex-wrap gap-3 mt-4">
            <Badge variant="secondary" className="gap-1.5 py-1 px-2.5">
              <ListTodo className="h-3.5 w-3.5" />
              {taskStats.active} aktive
            </Badge>
            {taskStats.overdue > 0 && (
              <Badge variant="destructive" className="gap-1.5 py-1 px-2.5">
                <AlertTriangle className="h-3.5 w-3.5" />
                {taskStats.overdue} overskredet
              </Badge>
            )}
            <Badge variant="outline" className="gap-1.5 py-1 px-2.5 border-amber-500/50 text-amber-600">
              <Clock className="h-3.5 w-3.5" />
              {taskStats.dueThisWeek} denne uge
            </Badge>
            <Badge variant="outline" className="gap-1.5 py-1 px-2.5 border-green-500/50 text-green-600">
              <CheckCircle2 className="h-3.5 w-3.5" />
              {taskStats.completed} afsluttet
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Toolbar */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Søg i opgaver..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="open">Åbne</SelectItem>
                  <SelectItem value="all">Alle</SelectItem>
                  <SelectItem value="todo">Afventer</SelectItem>
                  <SelectItem value="in_progress">I gang</SelectItem>
                  <SelectItem value="done">Afsluttet</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortOrder} onValueChange={setSortOrder}>
                <SelectTrigger className="w-[130px]">
                  <SelectValue placeholder="Sortering" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="due_date">Deadline</SelectItem>
                  <SelectItem value="priority">Prioritet</SelectItem>
                  <SelectItem value="title">Titel</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Tasks Display */}
          {displayedTasks.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <ListTodo className="h-12 w-12 mx-auto mb-3 opacity-40" />
              <p className="font-medium">Ingen opgaver fundet</p>
              <p className="text-sm">
                {searchQuery ? "Prøv at søge efter noget andet" : "Opret din første opgave for at komme i gang"}
              </p>
            </div>
          ) : isMobile ? (
            <div className="space-y-2">
              {displayedTasks.map((task) => (
                <TaskMobileRow
                  key={task.id}
                  task={task}
                  onToggleStatus={() => handleToggleStatus(task)}
                  onClick={() => handleTaskClick(task)}
                />
              ))}
            </div>
          ) : (
            <div className="rounded-lg border overflow-hidden">
              <TasksTable tasks={displayedTasks} />
            </div>
          )}
          
          {/* Show more indicator */}
          {remainingCount > 0 && (
            <div className="flex items-center justify-center pt-2">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/tasks')}
                className="text-muted-foreground hover:text-foreground gap-1.5"
              >
                +{remainingCount} flere opgaver
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Task Details Dialog */}
      {selectedTask && (
        <TaskDetailsDialog
          task={selectedTask}
          open={isDialogOpen}
          onOpenChange={setIsDialogOpen}
        />
      )}
    </>
  );
};
