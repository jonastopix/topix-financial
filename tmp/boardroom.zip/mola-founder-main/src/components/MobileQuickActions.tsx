import { CalendarPlus, CheckSquare, Car, FileText, Receipt } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { useRole } from '@/contexts/RoleContext';
import { cn } from '@/lib/utils';

interface QuickAction {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  roles?: ('admin' | 'founder' | 'fund_partner')[];
}

interface MobileQuickActionsProps {
  onAction: (actionId: string) => void;
}

export const MobileQuickActions = ({ onAction }: MobileQuickActionsProps) => {
  const { isAdmin, activeRole } = useRole();
  
  const canLogActivity = isAdmin || activeRole === 'fund_partner';
  const isFounder = activeRole === 'founder';

  const actions: QuickAction[] = [
    ...(canLogActivity ? [{
      id: 'activity',
      label: 'Aktivitet',
      icon: CalendarPlus,
      description: 'Registrer møde eller opkald',
    }] : []),
    {
      id: 'task',
      label: 'Opgave',
      icon: CheckSquare,
      description: 'Opret ny opgave',
    },
    ...(canLogActivity ? [{
      id: 'mileage',
      label: 'Kørsel',
      icon: Car,
      description: 'Registrer kørsel',
    }] : []),
    ...(canLogActivity ? [{
      id: 'mileage-history',
      label: 'Kørselsregnskab',
      icon: Receipt,
      description: 'Se overblik over kørsel',
    }] : []),
    ...(isFounder ? [{
      id: 'report',
      label: 'Rapport',
      icon: FileText,
      description: 'Indberet månedsrapport',
    }] : []),
  ];

  // Ensure we have exactly 4 items for a nice 2x2 grid
  const displayActions = actions.slice(0, 4);

  return (
    <div className="grid grid-cols-2 gap-3">
      {displayActions.map((action) => {
        const Icon = action.icon;
        return (
          <Card
            key={action.id}
            className={cn(
              "p-4 flex flex-col items-center justify-center gap-2 cursor-pointer",
              "active:scale-[0.98] transition-all duration-150",
              "hover:bg-accent/50 min-h-[100px]"
            )}
            onClick={() => onAction(action.id)}
          >
            <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon className="h-6 w-6 text-primary" />
            </div>
            <span className="font-medium text-sm">{action.label}</span>
            <span className="text-xs text-muted-foreground text-center line-clamp-1">
              {action.description}
            </span>
          </Card>
        );
      })}
    </div>
  );
};
