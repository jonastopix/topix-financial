import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Star, Building2 } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { useUpdateTrustedPartner, TrustedPartner, TrustedPartnerCategory } from '@/hooks/useTrustedPartners';

interface EditTrustedPartnerDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  partner: TrustedPartner | null;
  categories: TrustedPartnerCategory[] | undefined;
  showMolaRecommended?: boolean;
}

export const EditTrustedPartnerDialog = ({
  open,
  onOpenChange,
  partner,
  categories,
  showMolaRecommended = true,
}: EditTrustedPartnerDialogProps) => {
  const [form, setForm] = useState({
    category_id: '',
    company_name: '',
    contact_name: '',
    contact_title: '',
    email: '',
    phone: '',
    mobile_phone: '',
    website: '',
    linkedin_url: '',
    description: '',
    is_mola_recommended: false,
  });

  const updatePartner = useUpdateTrustedPartner();

  // Populate form when partner changes
  useEffect(() => {
    if (partner) {
      setForm({
        category_id: partner.category_id || '',
        company_name: partner.company_name || '',
        contact_name: partner.contact_name || '',
        contact_title: partner.contact_title || '',
        email: partner.email || '',
        phone: partner.phone || '',
        mobile_phone: (partner as any).mobile_phone || '',
        website: partner.website || '',
        linkedin_url: partner.linkedin_url || '',
        description: partner.description || '',
        is_mola_recommended: partner.is_mola_recommended || false,
      });
    }
  }, [partner]);

  const getIcon = (iconName: string) => {
    const IconComponent = (LucideIcons as any)[iconName];
    return IconComponent ? <IconComponent className="h-4 w-4" /> : <Building2 className="h-4 w-4" />;
  };

  const handleSave = async () => {
    if (!partner) return;
    await updatePartner.mutateAsync({
      id: partner.id,
      ...form,
    });
    onOpenChange(false);
  };

  const activeCategories = categories?.filter(c => c.is_active) || [];

  if (!partner) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Rediger Partner</DialogTitle>
          <DialogDescription>
            Opdater oplysninger for {partner.company_name}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2 md:col-span-2">
            <Label>Kategori *</Label>
            <Select
              value={form.category_id}
              onValueChange={(value) => setForm({ ...form, category_id: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Vælg kategori" />
              </SelectTrigger>
              <SelectContent>
                {activeCategories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    <div className="flex items-center gap-2">
                      {getIcon(category.icon_name)}
                      {category.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Firmanavn *</Label>
            <Input
              value={form.company_name}
              onChange={(e) => setForm({ ...form, company_name: e.target.value })}
              placeholder="f.eks. Kromann Reumert"
            />
          </div>
          <div className="space-y-2">
            <Label>Kontaktperson</Label>
            <Input
              value={form.contact_name}
              onChange={(e) => setForm({ ...form, contact_name: e.target.value })}
              placeholder="f.eks. Thomas Jensen"
            />
          </div>
          <div className="space-y-2">
            <Label>Titel</Label>
            <Input
              value={form.contact_title}
              onChange={(e) => setForm({ ...form, contact_title: e.target.value })}
              placeholder="f.eks. Partner"
            />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="email@firma.dk"
            />
          </div>
          <div className="space-y-2">
            <Label>Telefon (fastnet)</Label>
            <Input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="+45 12 34 56 78"
            />
          </div>
          <div className="space-y-2">
            <Label>Mobil</Label>
            <Input
              value={form.mobile_phone}
              onChange={(e) => setForm({ ...form, mobile_phone: e.target.value })}
              placeholder="+45 12 34 56 78"
            />
          </div>
          <div className="space-y-2">
            <Label>Website</Label>
            <Input
              value={form.website}
              onChange={(e) => setForm({ ...form, website: e.target.value })}
              placeholder="https://www.firma.dk"
            />
          </div>
          <div className="space-y-2">
            <Label>LinkedIn</Label>
            <Input
              value={form.linkedin_url}
              onChange={(e) => setForm({ ...form, linkedin_url: e.target.value })}
              placeholder="https://linkedin.com/in/..."
            />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Beskrivelse</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Hvad kan de hjælpe med? (max 500 tegn)"
              maxLength={500}
              rows={3}
            />
          </div>
          {showMolaRecommended && (
            <div className="md:col-span-2 flex items-center gap-3 p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
              <Switch
                checked={form.is_mola_recommended}
                onCheckedChange={(checked) => setForm({ ...form, is_mola_recommended: checked })}
              />
              <div>
                <Label className="flex items-center gap-2">
                  <Star className="h-4 w-4 text-amber-500" />
                  MOLA Anbefalet
                </Label>
                <p className="text-xs text-muted-foreground">Marker som særligt anbefalet partner</p>
              </div>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={!form.company_name || !form.category_id || updatePartner.isPending}
          >
            {updatePartner.isPending ? 'Gemmer...' : 'Gem ændringer'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
