import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Truck, MessageSquare, HeadphonesIcon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface QuickActionsPanelProps {
  companyId: string;
  hasMissingReport?: boolean;
  needsShippingUpdate?: boolean;
  needsNPSResponse?: boolean;
}

export function QuickActionsPanel({ 
  companyId, 
  hasMissingReport, 
  needsShippingUpdate, 
  needsNPSResponse 
}: QuickActionsPanelProps) {
  const navigate = useNavigate();

  return (
    <Card className="p-6 glass-card">
      <h3 className="text-xl font-semibold mb-6">Hurtige handlinger</h3>
      <div className="grid gap-4 sm:grid-cols-2">
        <Button 
          variant={hasMissingReport ? 'gradient' : 'outline'}
          className="justify-start h-auto py-4 gap-3"
          onClick={() => navigate('/monthly-report')}
        >
          <FileText className="h-5 w-5" />
          <div className="flex-1 text-left">
            <p className="font-semibold">Indberet månedlig rapport</p>
            {hasMissingReport && (
              <Badge variant="destructive" className="mt-1 text-xs">
                Mangler denne måned
              </Badge>
            )}
          </div>
        </Button>

        <Button 
          variant={needsShippingUpdate ? 'gradient' : 'outline'}
          className="justify-start h-auto py-4 gap-3"
          onClick={() => navigate('/shipping')}
        >
          <Truck className="h-5 w-5" />
          <div className="flex-1 text-left">
            <p className="font-semibold">Opdater shipping priser</p>
            {needsShippingUpdate && (
              <Badge variant="warning" className="mt-1 text-xs">
                Kræver opdatering
              </Badge>
            )}
          </div>
        </Button>

        <Button 
          variant={needsNPSResponse ? 'gradient' : 'outline'}
          className="justify-start h-auto py-4 gap-3"
          onClick={() => navigate('/insights')}
        >
          <MessageSquare className="h-5 w-5" />
          <div className="flex-1 text-left">
            <p className="font-semibold">Submit NPS feedback</p>
            {needsNPSResponse && (
              <Badge variant="default" className="mt-1 text-xs">
                Ny periode tilgængelig
              </Badge>
            )}
          </div>
        </Button>

        <Button 
          variant="outline"
          className="justify-start h-auto py-4 gap-3"
          onClick={() => navigate('/support')}
        >
          <HeadphonesIcon className="h-5 w-5" />
          <div className="flex-1 text-left">
            <p className="font-semibold">Kontakt support</p>
          </div>
        </Button>
      </div>

      <div className="mt-8 pt-6 border-t border-border/50">
        <h4 className="text-sm font-semibold mb-4">Nyttige links</h4>
        <div className="flex flex-wrap gap-2">
          {/* Resource Hub - midlertidigt skjult
          <Button 
            variant="link" 
            className="p-0 h-auto text-sm story-link"
            onClick={() => navigate('/resources')}
          >
            Ressourcer & værktøjer
          </Button>
          <span className="text-muted-foreground">•</span>
          */}
          <Button 
            variant="link" 
            className="p-0 h-auto text-sm story-link"
            onClick={() => navigate('/contact')}
          >
            Kontakt MOLA teamet
          </Button>
        </div>
      </div>
    </Card>
  );
}
