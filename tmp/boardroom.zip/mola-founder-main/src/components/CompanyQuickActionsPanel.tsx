import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Mail, 
  CheckSquare, 
  FileText, 
  Edit, 
  GitCompare,
  Phone,
  ExternalLink,
  TrendingUp
} from 'lucide-react';
import { useState } from 'react';
import CreateTaskDialog from './CreateTaskDialog';
import CompanyComparisonDialog from './CompanyComparisonDialog';
import { EditCompanyDialog } from './EditCompanyDialog';
import { ExportCompanyReportDialog } from './ExportCompanyReportDialog';
import { useNavigate } from 'react-router-dom';
import { useCompanyManagement } from '@/hooks/useCompanyManagement';
import { useQueryClient } from '@tanstack/react-query';
import { useRole } from '@/contexts/RoleContext';

interface CompanyQuickActionsPanelProps {
  companyId: string;
  companyName: string;
  companyEmail?: string | null;
  companyPhone?: string | null;
  googleDriveUrl?: string | null;
  company: any;
}

export function CompanyQuickActionsPanel({ 
  companyId, 
  companyName,
  companyEmail,
  companyPhone,
  googleDriveUrl,
  company
}: CompanyQuickActionsPanelProps) {
  const [comparisonDialogOpen, setComparisonDialogOpen] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { updateCompany, archiveCompany } = useCompanyManagement();
  const { activeRole } = useRole();
  
  // Only admin and fund_partner can export company reports
  const canExportReport = ['owner', 'mola_admin', 'fund_partner'].includes(activeRole || '');

  const handleSendEmail = () => {
    if (companyEmail) {
      window.location.href = `mailto:${companyEmail}?subject=Vedr. ${companyName}`;
    }
  };

  const handleCall = () => {
    if (companyPhone) {
      window.location.href = `tel:${companyPhone}`;
    }
  };

  const handleCompanyUpdate = async (id: string, data: any) => {
    await updateCompany.mutateAsync({ id, data });
    // Refresh company data
    queryClient.invalidateQueries({ queryKey: ['company', companyId] });
  };

  const handleCompanyArchive = async (id: string) => {
    await archiveCompany.mutateAsync(id);
    // Redirect to portfolio after archiving
    navigate('/portfolio/companies');
  };

  return (
    <>
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Button 
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={handleSendEmail}
            disabled={!companyEmail}
          >
            <Mail className="h-4 w-4" />
            <span>Send Email</span>
          </Button>

          <Button 
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={handleCall}
            disabled={!companyPhone}
          >
            <Phone className="h-4 w-4" />
            <span>Ring op</span>
          </Button>

          <CreateTaskDialog 
            companyId={companyId}
            trigger={
              <Button 
                variant="outline"
                className="justify-start gap-3 h-auto py-3"
              >
                <CheckSquare className="h-4 w-4" />
                <span>Opret opgave</span>
              </Button>
            }
          />

          <Button 
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={() => navigate(`/monthly-report?company=${companyId}`)}
          >
            <FileText className="h-4 w-4" />
            <span>Se rapporter</span>
          </Button>

          <EditCompanyDialog
            company={company}
            onSubmit={handleCompanyUpdate}
            onArchive={handleCompanyArchive}
          />

          <Button 
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={() => setComparisonDialogOpen(true)}
          >
            <GitCompare className="h-4 w-4" />
            <span>Sammenlign</span>
          </Button>

          <Button 
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={() => navigate('/exits-history')}
          >
            <TrendingUp className="h-4 w-4" />
            <span>Returns analyse</span>
          </Button>

          {canExportReport && (
            <ExportCompanyReportDialog
              companyId={companyId}
              companyName={companyName}
              company={company}
            />
          )}

          {googleDriveUrl && (
            <Button 
              variant="outline"
              className="justify-start gap-3 h-auto py-3"
              onClick={() => window.open(googleDriveUrl, '_blank')}
            >
              <ExternalLink className="h-4 w-4" />
              <span>Google Drive</span>
            </Button>
          )}
        </div>
      </Card>

      <CompanyComparisonDialog
        open={comparisonDialogOpen}
        onOpenChange={setComparisonDialogOpen}
        currentCompanyId={companyId}
        currentCompanyName={companyName}
      />
    </>
  );
}
