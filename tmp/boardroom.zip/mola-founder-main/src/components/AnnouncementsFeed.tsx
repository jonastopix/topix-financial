import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Bell, AlertCircle, Info } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface Announcement {
  id: string;
  message: string;
  type: string;
  priority: string;
  created_at: string;
  link_url?: string;
}

interface AnnouncementsFeedProps {
  announcements: Announcement[];
}

const typeIcons = {
  general: Info,
  important: AlertCircle,
  urgent: AlertCircle,
};

const priorityVariants = {
  low: 'outline',
  medium: 'secondary',
  high: 'destructive',
} as const;

export function AnnouncementsFeed({ announcements }: AnnouncementsFeedProps) {
  if (!announcements || announcements.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Nyheder fra MOLA</h3>
        </div>
        <p className="text-sm text-muted-foreground">Ingen aktuelle beskeder</p>
      </Card>
    );
  }

  return (
    <Card className="p-6 glass-card hover-lift">
      <div className="flex items-center gap-2 mb-6">
        <div className="p-2 rounded-lg bg-primary/10">
          <Bell className="h-5 w-5 text-primary" />
        </div>
        <h3 className="text-xl font-semibold">Nyheder fra MOLA</h3>
      </div>
      <div className="space-y-4">
        {announcements.slice(0, 5).map((announcement, index) => {
          const Icon = typeIcons[announcement.type as keyof typeof typeIcons] || Info;
          const variant = priorityVariants[announcement.priority as keyof typeof priorityVariants] || 'outline';

          return (
            <div 
              key={announcement.id} 
              className="p-4 rounded-lg border border-border/50 bg-card/50 hover:bg-card/80 transition-all animate-fade-up"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant={variant} className="text-xs">
                      {announcement.priority}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(announcement.created_at), 'dd. MMM yyyy', { locale: da })}
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{announcement.message}</p>
                  {announcement.link_url && (
                    <a 
                      href={announcement.link_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary hover:underline mt-2 inline-flex items-center gap-1 story-link"
                    >
                      Læs mere →
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
