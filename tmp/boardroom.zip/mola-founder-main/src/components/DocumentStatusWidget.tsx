import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { FileText, AlertCircle, CheckCircle2 } from 'lucide-react';
import { useAllCompaniesDocumentStatus } from '@/hooks/useCompanyDocumentStatus';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

const DocumentStatusWidget = () => {
  const navigate = useNavigate();
  const { data: companiesStatus, isLoading } = useAllCompaniesDocumentStatus();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Dokument Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!companiesStatus?.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Dokument Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Ingen aktive selskaber</p>
        </CardContent>
      </Card>
    );
  }

  const criticalCompanies = companiesStatus.filter(c => c.status === 'critical');
  const warningCompanies = companiesStatus.filter(c => c.status === 'warning');
  const goodCompanies = companiesStatus.filter(c => c.status === 'good');

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Dokument Status
          </span>
          <div className="flex gap-2">
            {criticalCompanies.length > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertCircle className="h-3 w-3" />
                {criticalCompanies.length}
              </Badge>
            )}
            {warningCompanies.length > 0 && (
              <Badge className="gap-1 bg-warning text-warning-foreground">
                <AlertCircle className="h-3 w-3" />
                {warningCompanies.length}
              </Badge>
            )}
            {goodCompanies.length > 0 && (
              <Badge className="gap-1 bg-success text-success-foreground">
                <CheckCircle2 className="h-3 w-3" />
                {goodCompanies.length}
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2 max-h-[400px] overflow-y-auto">
        {companiesStatus
          .sort((a, b) => {
            const statusOrder = { critical: 0, warning: 1, good: 2 };
            return statusOrder[a.status] - statusOrder[b.status];
          })
          .map((company) => (
            <div
              key={company.companyId}
              onClick={() => navigate(`/company/${company.companyId}?tab=documents`)}
              className={cn(
                "p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md",
                company.status === 'critical' && "border-destructive/20 bg-destructive/5 hover:bg-destructive/10",
                company.status === 'warning' && "border-warning/20 bg-warning/5 hover:bg-warning/10",
                company.status === 'good' && "border-success/20 bg-success/5 hover:bg-success/10"
              )}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <span className="font-medium text-sm truncate">{company.companyName}</span>
                  {company.status === 'critical' && company.missingCritical.length > 0 && (
                    <Badge variant="destructive" className="text-xs shrink-0">
                      {company.missingCritical.length} kritiske
                    </Badge>
                  )}
                </div>
                <span className={cn(
                  "text-xs font-semibold shrink-0",
                  company.status === 'critical' && "text-destructive",
                  company.status === 'warning' && "text-warning",
                  company.status === 'good' && "text-success"
                )}>
                  {company.uploadedDocuments}/{company.totalDocuments}
                </span>
              </div>
              <Progress 
                value={company.completionRate} 
                className={cn(
                  "h-1.5",
                  company.status === 'critical' && "[&>div]:bg-destructive",
                  company.status === 'warning' && "[&>div]:bg-warning",
                  company.status === 'good' && "[&>div]:bg-success"
                )}
              />
              <p className="text-xs text-muted-foreground mt-1">
                {company.completionRate}% fuldført
              </p>
            </div>
          ))}
      </CardContent>
    </Card>
  );
};

export default DocumentStatusWidget;
