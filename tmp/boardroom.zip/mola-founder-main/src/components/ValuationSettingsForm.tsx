import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Alert, AlertDescription } from './ui/alert';
import { Calculator, TrendingUp, Info, Sparkles, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useMonthlyReports } from '@/hooks/useCompanyData';
import { calculateLTMMetrics, calculateMarketBasedValuation } from '@/lib/valuationCalculations';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Badge } from './ui/badge';

interface ValuationSettingsFormProps {
  companyId: string;
  onSaved?: () => void;
}

export function ValuationSettingsForm({ companyId, onSaved }: ValuationSettingsFormProps) {
  const [revenueMultiple, setRevenueMultiple] = useState('2.50');
  const [ebitdaMultiple, setEbitdaMultiple] = useState('8.00');
  const [activeMarkets, setActiveMarkets] = useState('1');
  const [revenueWeight, setRevenueWeight] = useState([50]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewValuation, setPreviewValuation] = useState<number | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  const [aiReasoning, setAiReasoning] = useState<string | null>(null);
  const [isAISuggested, setIsAISuggested] = useState(false);

  const { data: monthlyReports } = useMonthlyReports(companyId);
  const queryClient = useQueryClient();

  const [ltmEBITDA, setLtmEBITDA] = useState<number | null>(null);

  // Calculate preview valuation whenever inputs change
  useEffect(() => {
    if (!monthlyReports || monthlyReports.length === 0) {
      setPreviewValuation(null);
      setLtmEBITDA(null);
      return;
    }

    const revMult = parseFloat(revenueMultiple) || 0;
    const ebitMult = parseFloat(ebitdaMultiple) || 0;
    const revWeight = revenueWeight[0] || 50;

    if (revMult <= 0 || ebitMult <= 0) {
      setPreviewValuation(null);
      setLtmEBITDA(null);
      return;
    }

    const ltmMetrics = calculateLTMMetrics(monthlyReports);
    setLtmEBITDA(ltmMetrics.ltmEBITDA);
    
    const breakdown = calculateMarketBasedValuation({
      ltmRevenue: ltmMetrics.ltmRevenue,
      ltmEBITDA: ltmMetrics.ltmEBITDA,
      revenueMultiple: revMult,
      ebitdaMultiple: ebitMult,
      revenueWeight: revWeight,
    });

    setPreviewValuation(breakdown.totalValuation);
  }, [revenueMultiple, ebitdaMultiple, revenueWeight, monthlyReports]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const revMult = parseFloat(revenueMultiple);
      const ebitMult = parseFloat(ebitdaMultiple);
      const markets = parseInt(activeMarkets);
      const revWeight = revenueWeight[0];

      // Validate inputs
      if (revMult < 0.1 || revMult > 100) {
        toast.error('Revenue multiple skal være mellem 0.1 og 100');
        return;
      }
      if (ebitMult < 0.1 || ebitMult > 100) {
        toast.error('EBITDA multiple skal være mellem 0.1 og 100');
        return;
      }
      if (markets < 1 || markets > 200) {
        toast.error('Antal markeder skal være mellem 1 og 200');
        return;
      }

      // 1. Save settings
      const { error: settingsError } = await supabase
        .from('company_valuation_settings')
        .insert({
          company_id: companyId,
          revenue_multiple: revMult,
          ebitda_multiple: ebitMult,
          active_markets: markets,
          valuation_weight_revenue_pct: revWeight,
        });

      if (settingsError) {
        console.error('Error saving settings:', settingsError);
        toast.error('Fejl ved gemning af indstillinger');
        throw settingsError;
      }

      // 2. Calculate and save initial valuation
      if (monthlyReports && monthlyReports.length > 0) {
        const ltmMetrics = calculateLTMMetrics(monthlyReports);
        const breakdown = calculateMarketBasedValuation({
          ltmRevenue: ltmMetrics.ltmRevenue,
          ltmEBITDA: ltmMetrics.ltmEBITDA,
          revenueMultiple: revMult,
          ebitdaMultiple: ebitMult,
          revenueWeight: revWeight,
        });

        const sourceText = ltmMetrics.isAnnualized
          ? `Market-based (${ltmMetrics.monthsUsed}M annualized, ${markets} markets)`
          : `Market-based (LTM, ${markets} markets)`;

        const { error: valuationError } = await supabase.from('valuations').insert({
          company_id: companyId,
          post_money_valuation_dkk: breakdown.totalValuation,
          as_of_date: new Date().toISOString().split('T')[0],
          source: sourceText,
        });

        if (valuationError) {
          console.error('Error saving valuation:', valuationError);
          toast.error('Indstillinger gemt, men valuation kunne ikke beregnes');
        }
      }

      // Refresh queries
      await queryClient.invalidateQueries({ queryKey: ['valuation-settings', companyId] });
      await queryClient.invalidateQueries({ queryKey: ['company-returns-data', companyId] });

      toast.success('Valuation parametre gemt og beregnet!');
      onSaved?.();
    } catch (error) {
      console.error('Error in handleSubmit:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGetAISuggestions = async () => {
    setIsLoadingAI(true);
    setAiReasoning(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('suggest-valuation-multiples', {
        body: { companyId }
      });

      if (error) throw error;

      if (data) {
        setRevenueMultiple(data.revenue_multiple.toFixed(2));
        setEbitdaMultiple(data.ebitda_multiple.toFixed(2));
        setRevenueWeight([data.suggested_revenue_weight || 50]);
        setAiReasoning(data.reasoning);
        setIsAISuggested(true);
        
        if (data.is_fallback) {
          toast.info('Bruger standard værdier', {
            description: 'AI kunne ikke generere forslag, standard værdier er indsat.'
          });
        } else {
          toast.success('AI-forslag hentet!', {
            description: 'Gennemse forslagene og justér efter behov.'
          });
        }
      }
    } catch (error) {
      console.error('Error getting AI suggestions:', error);
      toast.error('Kunne ikke hente AI-forslag', {
        description: 'Prøv igen eller indtast værdier manuelt.'
      });
    } finally {
      setIsLoadingAI(false);
    }
  };

  const hasData = monthlyReports && monthlyReports.length > 0;

  return (
    <Card className="p-6 border-primary/20 bg-primary/5">
      <div className="flex items-center gap-3 mb-4">
        <Calculator className="h-6 w-6 text-primary" />
        <div>
          <h3 className="text-lg font-semibold">Definer Valuation Parametre</h3>
          <p className="text-sm text-muted-foreground">
            Aktiver markedsbaseret værdiansættelse
          </p>
        </div>
      </div>

      {!hasData && (
        <Alert className="mb-4">
          <Info className="h-4 w-4" />
          <AlertDescription>
            Ingen finansiel data tilgængelig. Upload monthly reports for at beregne valuation.
          </AlertDescription>
        </Alert>
      )}

      <div className="mb-6">
        <Button
          type="button"
          variant="outline"
          onClick={handleGetAISuggestions}
          disabled={isLoadingAI}
          className="w-full"
        >
          {isLoadingAI ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Henter AI-forslag...
            </>
          ) : (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Hent AI-forslag til multipler
            </>
          )}
        </Button>
      </div>

      {aiReasoning && (
        <Alert className="mb-6 border-primary/30 bg-primary/5">
          <Sparkles className="h-4 w-4 text-primary" />
          <AlertDescription>
            <div className="font-semibold mb-2">💡 AI Begrundelse:</div>
            <div className="text-sm">{aiReasoning}</div>
          </AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="revenue-multiple">Revenue Multiple</Label>
              {isAISuggested && (
                <Badge variant="secondary" className="text-xs">
                  AI-foreslået
                </Badge>
              )}
            </div>
            <Input
              id="revenue-multiple"
              type="number"
              step="0.1"
              min="0.1"
              max="100"
              value={revenueMultiple}
              onChange={(e) => {
                setRevenueMultiple(e.target.value);
                setIsAISuggested(false);
              }}
              placeholder="2.50"
            />
            <p className="text-xs text-muted-foreground">0.1 - 100</p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="ebitda-multiple">EBITDA Multiple</Label>
              {isAISuggested && (
                <Badge variant="secondary" className="text-xs">
                  AI-foreslået
                </Badge>
              )}
            </div>
            <Input
              id="ebitda-multiple"
              type="number"
              step="0.1"
              min="0.1"
              max="100"
              value={ebitdaMultiple}
              onChange={(e) => {
                setEbitdaMultiple(e.target.value);
                setIsAISuggested(false);
              }}
              placeholder="8.00"
            />
            <p className="text-xs text-muted-foreground">0.1 - 100</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="active-markets">Antal Aktive Markeder</Label>
            <Input
              id="active-markets"
              type="number"
              min="1"
              max="200"
              value={activeMarkets}
              onChange={(e) => setActiveMarkets(e.target.value)}
              placeholder="1"
            />
            <p className="text-xs text-muted-foreground">1 - 200</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label>Vægtning</Label>
            <div className="text-sm font-medium">
              Revenue {revenueWeight[0]}% • EBITDA {100 - revenueWeight[0]}%
            </div>
          </div>
          <Slider
            value={revenueWeight}
            onValueChange={setRevenueWeight}
            max={100}
            step={5}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>100% Revenue</span>
            <span>100% EBITDA</span>
          </div>
        </div>

        {hasData && previewValuation !== null && (
          <div className="space-y-3">
            {ltmEBITDA !== null && ltmEBITDA <= 0 && (
              <Alert className="border-blue-200 bg-blue-50">
                <Info className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-900">
                  <strong>EBITDA negativ:</strong> Kun revenue multiple anvendes til beregningen
                </AlertDescription>
              </Alert>
            )}
            <div className="p-4 rounded-lg bg-muted/50 border">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium">Preview Beregning</span>
              </div>
              <div className="text-2xl font-bold text-primary">
                {new Intl.NumberFormat('da-DK', {
                  style: 'currency',
                  currency: 'DKK',
                  minimumFractionDigits: 0,
                  maximumFractionDigits: 0,
                }).format(previewValuation)}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                Baseret på tilgængelige finansielle data
              </p>
            </div>
          </div>
        )}

        <Button type="submit" disabled={isSubmitting || !hasData} className="w-full">
          <Calculator className="h-4 w-4 mr-2" />
          {isSubmitting ? 'Gemmer...' : 'Gem og Beregn Valuation'}
        </Button>
      </form>
    </Card>
  );
}
