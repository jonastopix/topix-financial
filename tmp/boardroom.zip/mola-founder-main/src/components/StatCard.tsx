import { Card } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';
import { AnimatedNumber } from './AnimatedNumber';
import { cn } from '@/lib/utils';
import { formatPercentage } from '@/lib/formatters';

interface StatCardProps {
  title: string;
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  className?: string;
  variant?: 'default' | 'gradient' | 'glass';
}

export function StatCard({ 
  title, 
  value, 
  prefix = '',
  suffix = '',
  decimals = 0,
  icon: Icon, 
  trend,
  className,
  variant = 'default'
}: StatCardProps) {
  const cardClasses = cn(
    "p-6 hover-lift animate-fade-up",
    variant === 'glass' && 'glass-card',
    variant === 'gradient' && 'gradient-primary text-primary-foreground',
    className
  );

  return (
    <Card className={cardClasses}>
      <div className="flex items-center justify-between mb-3">
        <p className={cn(
          "text-sm font-medium",
          variant === 'gradient' ? 'text-primary-foreground/80' : 'text-muted-foreground'
        )}>
          {title}
        </p>
        <div className={cn(
          "p-2 rounded-lg",
          variant === 'gradient' ? 'bg-white/20' : 'bg-primary/10'
        )}>
          <Icon className={cn(
            "h-5 w-5",
            variant === 'gradient' ? 'text-white' : 'text-primary'
          )} />
        </div>
      </div>
      
      <div className="space-y-2">
        <p className="text-2xl lg:text-3xl font-bold truncate">
          <AnimatedNumber 
            value={value} 
            decimals={decimals}
            prefix={prefix}
            suffix={suffix}
          />
        </p>
        
        {trend && (
          <div className="flex items-center gap-2">
            <span className={cn(
              "text-sm font-medium",
              trend.isPositive ? 'text-success' : 'text-destructive'
            )}>
              {trend.isPositive ? '↑' : '↓'} {formatPercentage(Math.abs(trend.value), 1)}
            </span>
            <span className={cn(
              "text-xs",
              variant === 'gradient' ? 'text-primary-foreground/60' : 'text-muted-foreground'
            )}>
              vs. sidste måned
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}
