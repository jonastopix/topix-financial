import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { RealtimeChannel } from '@supabase/supabase-js';
import { Trophy } from 'lucide-react';

interface CelebrationEvent {
  type: string;
  message: string;
  icon?: string;
}

export function GlobalCelebration() {
  const [celebration, setCelebration] = useState<CelebrationEvent | null>(null);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);

  useEffect(() => {
    const celebrationChannel = supabase
      .channel('global-celebrations')
      .on('broadcast', { event: 'celebration' }, (payload) => {
        const event = payload.payload as CelebrationEvent;
        setCelebration(event);
        
        // Clear after 6 seconds
        setTimeout(() => {
          setCelebration(null);
        }, 6000);
      })
      .subscribe();

    setChannel(celebrationChannel);

    return () => {
      if (celebrationChannel) {
        celebrationChannel.unsubscribe();
      }
    };
  }, []);

  // Generate confetti pieces
  const confettiPieces = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    delay: Math.random() * 2,
    duration: 2 + Math.random() * 2,
    color: ['#FFD700', '#FF6B6B', '#4ECDC4', '#A855F7', '#3B82F6'][Math.floor(Math.random() * 5)],
    size: 8 + Math.random() * 8,
  }));

  return (
    <AnimatePresence>
      {celebration && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] pointer-events-none overflow-hidden"
        >
          {/* Confetti */}
          {confettiPieces.map((piece) => (
            <motion.div
              key={piece.id}
              initial={{ 
                y: -20, 
                x: `${piece.x}vw`,
                rotate: 0,
                opacity: 1 
              }}
              animate={{ 
                y: '110vh',
                rotate: 720,
                opacity: 0
              }}
              transition={{
                duration: piece.duration,
                delay: piece.delay,
                ease: 'linear',
              }}
              className="absolute"
              style={{
                width: piece.size,
                height: piece.size,
                backgroundColor: piece.color,
                borderRadius: Math.random() > 0.5 ? '50%' : '2px',
              }}
            />
          ))}
          
          {/* Celebration Message */}
          <motion.div
            initial={{ scale: 0, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0, y: 50 }}
            transition={{ type: 'spring', damping: 15, stiffness: 200 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card border border-border rounded-2xl shadow-2xl p-8 max-w-md text-center pointer-events-auto"
          >
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="mb-4"
            >
              <span className="text-6xl">
                {celebration.icon || '🎉'}
              </span>
            </motion.div>
            
            <div className="flex items-center justify-center gap-2 mb-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              <h3 className="text-lg font-bold text-foreground">Milestone opnået!</h3>
              <Trophy className="h-5 w-5 text-yellow-500" />
            </div>
            
            <p className="text-muted-foreground">
              {celebration.message}
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Helper function to broadcast a celebration (call from edge functions or after important events)
export async function broadcastCelebration(message: string, icon?: string) {
  const channel = supabase.channel('global-celebrations');
  await channel.subscribe();
  await channel.send({
    type: 'broadcast',
    event: 'celebration',
    payload: {
      type: 'milestone',
      message,
      icon,
    },
  });
  channel.unsubscribe();
}
