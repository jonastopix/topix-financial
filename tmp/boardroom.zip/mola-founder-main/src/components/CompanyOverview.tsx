import { TrendingUp, TrendingDown, Calendar, DollarSign, LineChart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const MetricCard = ({ 
  title, 
  icon: Icon, 
  metrics 
}: { 
  title: string; 
  icon: any; 
  metrics: { label: string; value: string; change: number }[] 
}) => {
  return (
    <Card className="hover:shadow-lg transition-all duration-300">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-5 w-5 text-primary" />
      </CardHeader>
      <CardContent className="space-y-3">
        {metrics.map((metric, idx) => (
          <div key={idx} className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{metric.label}</span>
              <div className="flex items-center gap-1">
                {metric.change > 0 ? (
                  <TrendingUp className="h-3 w-3 text-accent" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-destructive" />
                )}
                <span className={metric.change > 0 ? "text-accent text-xs font-medium" : "text-destructive text-xs font-medium"}>
                  {metric.change > 0 ? '+' : ''}{metric.change}%
                </span>
              </div>
            </div>
            <div className="text-2xl font-bold">{metric.value}</div>
            {/* Mini trend line */}
            <div className="h-8 flex items-end gap-1">
              {[40, 55, 48, 65, 58, 72, 68, 80].map((height, i) => (
                <div 
                  key={i} 
                  className="flex-1 bg-gradient-to-t from-primary to-primary/50 rounded-sm transition-all duration-300"
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};

const CompanyOverview = () => {
  const lastMonthData = {
    title: "Seneste måned (oktober 2025)",
    icon: Calendar,
    metrics: [
      { label: "Omsætning", value: "1.200.000 kr.", change: 12 },
      { label: "EBITDA", value: "180.000 kr.", change: 9 }
    ]
  };

  const ytdData = {
    title: "Year-to-Date (2025)",
    icon: DollarSign,
    metrics: [
      { label: "Omsætning YTD", value: "9.800.000 kr.", change: 22 },
      { label: "EBITDA YTD", value: "1.150.000 kr.", change: 18 },
      { label: "Vækst mod budget", value: "+8%", change: 8 }
    ]
  };

  const yoyData = {
    title: "Year-over-Year (YOY)",
    icon: LineChart,
    metrics: [
      { label: "Omsætning vs 2024", value: "+26%", change: 26 },
      { label: "EBITDA vs 2024", value: "+18%", change: 18 },
      { label: "Marginforbedring", value: "+3,4 p.p.", change: 3.4 }
    ]
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Company Overview</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard {...lastMonthData} />
        <MetricCard {...ytdData} />
        <MetricCard {...yoyData} />
      </div>
    </div>
  );
};

export default CompanyOverview;
