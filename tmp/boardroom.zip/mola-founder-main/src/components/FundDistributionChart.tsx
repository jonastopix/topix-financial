import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { DollarSign } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

// Modern, contrast-rich color palette
const COLORS = [
  'hsl(217, 91%, 60%)', // Bright blue
  'hsl(142, 71%, 45%)', // Emerald green
  'hsl(280, 85%, 60%)', // Purple
  'hsl(25, 95%, 53%)',  // Orange
  'hsl(348, 83%, 47%)', // Rose red
  'hsl(199, 89%, 48%)', // Cyan
  'hsl(48, 96%, 53%)',  // Yellow
  'hsl(262, 83%, 58%)', // Violet
];

export function FundDistributionChart({ fundFilter }: { fundFilter?: string }) {
  const { data: fundDistribution, isLoading } = useQuery({
    queryKey: ['fund-distribution', fundFilter],
    queryFn: async () => {
      let query = supabase
        .from('companies')
        .select(`
          invested_amount_dkk,
          fund_id,
          funds (
            name,
            cvr
          )
        `)
        .eq('is_active', true);

      if (fundFilter && fundFilter !== 'all') {
        query = query.eq('fund_id', fundFilter);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Group by fund
      const fundMap = new Map<string, { name: string; value: number }>();
      
      data?.forEach(company => {
        const fundName = company.funds?.name || 'Ingen fond';
        const amount = company.invested_amount_dkk || 0;
        
        if (fundMap.has(fundName)) {
          fundMap.get(fundName)!.value += amount;
        } else {
          fundMap.set(fundName, { name: fundName, value: amount });
        }
      });

      return Array.from(fundMap.values()).filter(f => f.value > 0);
    },
  });

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <DollarSign className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Fordeling pr. fond</h2>
        </div>
        <div className="flex items-center justify-center min-h-[300px]">
          <p className="text-muted-foreground">Indlæser...</p>
        </div>
      </Card>
    );
  }

  if (!fundDistribution || fundDistribution.length === 0) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <DollarSign className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Fordeling pr. fond</h2>
        </div>
        <div className="flex items-center justify-center min-h-[300px]">
          <p className="text-muted-foreground">Ingen data tilgængelig</p>
        </div>
      </Card>
    );
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Calculate total for percentages
  const total = fundDistribution.reduce((sum, item) => sum + item.value, 0);

  // Custom label renderer - show percentage inside slices for better visibility
  const renderCustomLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, value }: any) => {
    const percent = ((value / total) * 100).toFixed(1);
    if (parseFloat(percent) < 10) return null; // Skip small segments
    
    // Calculate position in the middle of the segment
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);
    
    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor="middle" 
        dominantBaseline="central" 
        fontWeight="bold"
        fontSize="14"
      >
        {percent}%
      </text>
    );
  };

  // Enhanced legend with percentage
  const renderLegend = (props: any) => {
    const { payload } = props;
    return (
      <div className="flex flex-col gap-2 text-sm">
        {payload.map((entry: any, index: number) => {
          const percent = ((entry.payload.value / total) * 100).toFixed(1);
          return (
            <div key={`legend-${index}`} className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2 min-w-0">
                <div 
                  className="w-3 h-3 rounded-sm flex-shrink-0" 
                  style={{ backgroundColor: entry.color }}
                />
                <span className="truncate">{entry.value}</span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="text-muted-foreground">{percent}%</span>
                <span className="font-medium">{formatCurrency(entry.payload.value)}</span>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <DollarSign className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-bold">Fordeling pr. fond</h2>
      </div>
      <div className="grid lg:grid-cols-[1fr,300px] gap-8 items-center">
        <ResponsiveContainer width="100%" height={280}>
          <PieChart>
            <Pie
              data={fundDistribution}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={3}
              dataKey="value"
              label={renderCustomLabel}
              labelLine={false}
            >
              {fundDistribution.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              formatter={(value: number, name: string, props: any) => [
                formatCurrency(value),
                props.payload.name
              ]}
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                padding: '12px',
              }}
              itemStyle={{
                color: 'hsl(var(--foreground))',
              }}
              labelStyle={{
                color: 'hsl(var(--foreground))',
                fontWeight: 'bold',
                marginBottom: '4px',
              }}
            />
            <Legend content={renderLegend} />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
