import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FounderDeal } from "@/hooks/useFounderDeals";
import { Building2, Calendar, Users, ExternalLink } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface FounderDealCardProps {
  deal: FounderDeal;
  onViewDetails: () => void;
}

export function FounderDealCard({ deal, onViewDetails }: FounderDealCardProps) {
  const isExpiringSoon = deal.valid_until && 
    new Date(deal.valid_until).getTime() - Date.now() < 30 * 24 * 60 * 60 * 1000;
  
  const isAlmostFull = deal.max_redemptions && 
    deal.current_redemptions / deal.max_redemptions > 0.8;

  const getDiscountLabel = () => {
    if (deal.discount_type === 'percentage' && deal.discount_value) {
      return `${deal.discount_value}% rabat`;
    } else if (deal.discount_type === 'fixed_amount' && deal.discount_value) {
      return `${deal.discount_value} kr. rabat`;
    } else if (deal.discount_type === 'trial_extension') {
      return 'Forlænget prøveperiode';
    }
    return 'Special tilbud';
  };

  return (
    <Card className="group hover-lift glass-card transition-all duration-300 hover:border-primary/50">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="w-12 h-12 border-2 border-primary/10">
            <AvatarImage src={deal.companies?.logo_url || undefined} />
            <AvatarFallback className="bg-gradient-to-br from-primary/20 to-primary/10">
              {deal.companies?.name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex-1">
                <h3 className="font-semibold text-lg group-hover:text-primary transition-colors line-clamp-1">
                  {deal.title}
                </h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  <Building2 className="w-3.5 h-3.5" />
                  <span>{deal.companies?.name}</span>
                </div>
              </div>
              
              <Badge className="bg-gradient-to-r from-accent to-accent-glow shrink-0">
                {getDiscountLabel()}
              </Badge>
            </div>

            {deal.description && (
              <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
                {deal.description}
              </p>
            )}

            <div className="flex flex-wrap gap-1.5 mb-3">
              {deal.categories.map((cat) => (
                <Badge key={cat} variant="outline" className="text-xs">
                  {cat}
                </Badge>
              ))}
            </div>

            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-4">
                {deal.current_redemptions > 0 && (
                  <div className="flex items-center gap-1">
                    <Users className="w-3.5 h-3.5" />
                    <span>{deal.current_redemptions} anvendt</span>
                  </div>
                )}
                
                {deal.valid_until && (
                  <div className={`flex items-center gap-1 ${isExpiringSoon ? 'text-orange-500' : ''}`}>
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Udløber {new Date(deal.valid_until).toLocaleDateString('da-DK')}</span>
                  </div>
                )}
              </div>

              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onViewDetails}
                className="hover:text-primary"
              >
                Se detaljer
                <ExternalLink className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>

            {isAlmostFull && (
              <div className="mt-2">
                <Badge variant="outline" className="text-orange-500 border-orange-500/30">
                  Kun få tilbage
                </Badge>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
