import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { formatCurrency } from "@/lib/formatters";

interface QuarterlyIncomeChartProps {
  data: Array<{ quarter: string; total: number }>;
  year: number;
}

export function QuarterlyIncomeChart({ data, year }: QuarterlyIncomeChartProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Kvartalsvis Indkomst {year}</h3>
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="quarter" />
          <YAxis tickFormatter={(value) => formatCurrency(value)} />
          <Tooltip formatter={(value) => formatCurrency(value as number)} />
          <Legend />
          <Bar dataKey="total" fill="hsl(var(--primary))" name="Total Indkomst" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
