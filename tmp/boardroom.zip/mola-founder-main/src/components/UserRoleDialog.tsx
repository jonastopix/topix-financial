import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Shield, User, Crown, Briefcase, FileCheck, Eye } from 'lucide-react';
import { useRole } from '@/contexts/RoleContext';
import { FundPartnerAssignmentDialog } from './FundPartnerAssignmentDialog';

interface UserRoleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  currentRoles: string[];
  userName: string;
  userFundId?: string | null;
  onAddRole: (args: { userId: string; role: string }) => void;
  onRemoveRole: (args: { userId: string; role: string }) => void;
}

const availableRoles = [
  { 
    value: 'owner', 
    label: 'Owner', 
    icon: Crown, 
    description: 'Fuld adgang til alt inkl. brugeradministration',
    restricted: true 
  },
  { 
    value: 'mola_admin', 
    label: 'MOLA Admin', 
    icon: Shield, 
    description: 'MOLA ansatte - fuld adgang til alle data' 
  },
  { 
    value: 'fund_partner', 
    label: 'Fund Partner', 
    icon: Briefcase, 
    description: 'Kan se virksomheder i deres fond + DD opgaver' 
  },
  { 
    value: 'founder', 
    label: 'Founder/CEO', 
    icon: User, 
    description: 'Kan se egen virksomheds data' 
  },
  { 
    value: 'dd_partner', 
    label: 'DD Partner', 
    icon: FileCheck, 
    description: 'Advokat/revisor - kan se ALT om tildelte selskaber' 
  },
  { 
    value: 'external_viewer', 
    label: 'Ekstern Partner', 
    icon: Eye, 
    description: 'Bank/revisor rådgiver - read-only adgang til alt' 
  },
];

export function UserRoleDialog({
  open,
  onOpenChange,
  userId,
  currentRoles,
  userName,
  userFundId,
  onAddRole,
  onRemoveRole,
}: UserRoleDialogProps) {
  const { isOwner } = useRole();
  const [selectedRoles, setSelectedRoles] = useState<string[]>(currentRoles);
  const [showFundAssignment, setShowFundAssignment] = useState(false);

  const handleToggleRole = (role: string, checked: boolean) => {
    if (checked) {
      setSelectedRoles([...selectedRoles, role]);
      // If adding fund_partner role, show fund assignment dialog
      if (role === 'fund_partner') {
        setShowFundAssignment(true);
      }
    } else {
      setSelectedRoles(selectedRoles.filter((r) => r !== role));
    }
  };

  const handleSave = () => {
    // Find added and removed roles
    const added = selectedRoles.filter((r) => !currentRoles.includes(r));
    const removed = currentRoles.filter((r) => !selectedRoles.includes(r));

    added.forEach((role) => onAddRole({ userId, role }));
    removed.forEach((role) => onRemoveRole({ userId, role }));

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle>Administrer roller</DialogTitle>
          <DialogDescription>
            Opdater roller for <strong>{userName}</strong>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {availableRoles.map((role) => {
            const Icon = role.icon;
            const isRestricted = role.restricted && !isOwner;
            const isDisabled = isRestricted;
            
            return (
              <div 
                key={role.value} 
                className={`flex items-start space-x-3 p-3 rounded-lg border border-border/50 ${
                  isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-accent/5'
                }`}
              >
                <Checkbox
                  id={role.value}
                  checked={selectedRoles.includes(role.value)}
                  onCheckedChange={(checked) => handleToggleRole(role.value, checked as boolean)}
                  disabled={isDisabled}
                />
                <div className="flex-1 space-y-1">
                  <Label 
                    htmlFor={role.value} 
                    className={`flex items-center gap-2 ${isDisabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                  >
                    <Icon className={`h-4 w-4 ${role.value === 'owner' ? 'text-yellow-500' : 'text-muted-foreground'}`} />
                    <span className="font-medium">{role.label}</span>
                    {isRestricted && (
                      <span className="text-xs text-muted-foreground">(Kun owner)</span>
                    )}
                  </Label>
                  <p className="text-sm text-muted-foreground">{role.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button onClick={handleSave} variant="gradient">
            Gem ændringer
          </Button>
        </div>
      </DialogContent>

      <FundPartnerAssignmentDialog
        open={showFundAssignment}
        onOpenChange={setShowFundAssignment}
        userId={userId}
        currentFundId={userFundId}
      />
    </Dialog>
  );
}
