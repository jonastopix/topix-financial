import { useState, useEffect } from 'react';
import { Task, useTaskManagement } from '@/hooks/useTaskManagement';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface EditRecurrenceDialogProps {
  task: Task;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const EditRecurrenceDialog = ({ task, open, onOpenChange }: EditRecurrenceDialogProps) => {
  const { updateTask } = useTaskManagement();
  const [formData, setFormData] = useState({
    recurrence_pattern: task.recurrence_pattern || 'weekly',
    recurrence_interval: task.recurrence_interval || 1,
    recurrence_day_of_week: task.recurrence_day_of_week ?? 1,
    recurrence_day_of_month: task.recurrence_day_of_month ?? 1,
    end_condition: task.recurrence_end_date ? 'end_date' : task.recurrence_count ? 'count' : 'never',
    recurrence_end_date: task.recurrence_end_date || '',
    recurrence_count: task.recurrence_count || 10,
  });

  useEffect(() => {
    if (open) {
      setFormData({
        recurrence_pattern: task.recurrence_pattern || 'weekly',
        recurrence_interval: task.recurrence_interval || 1,
        recurrence_day_of_week: task.recurrence_day_of_week ?? 1,
        recurrence_day_of_month: task.recurrence_day_of_month ?? 1,
        end_condition: task.recurrence_end_date ? 'end_date' : task.recurrence_count ? 'count' : 'never',
        recurrence_end_date: task.recurrence_end_date || '',
        recurrence_count: task.recurrence_count || 10,
      });
    }
  }, [open, task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const updates = {
      id: task.id,
      recurrence_pattern: formData.recurrence_pattern as Task['recurrence_pattern'],
      recurrence_interval: formData.recurrence_interval,
      recurrence_day_of_week: formData.recurrence_pattern === 'weekly' ? formData.recurrence_day_of_week : null,
      recurrence_day_of_month: formData.recurrence_pattern === 'monthly' ? formData.recurrence_day_of_month : null,
      recurrence_end_date: formData.end_condition === 'end_date' ? formData.recurrence_end_date : null,
      recurrence_count: formData.end_condition === 'count' ? formData.recurrence_count : null,
    };

    updateTask.mutate(updates, {
      onSuccess: () => {
        onOpenChange(false);
      },
    });
  };

  const getPatternLabel = () => {
    switch (formData.recurrence_pattern) {
      case 'daily': return 'dag';
      case 'weekly': return 'uge';
      case 'monthly': return 'måned';
      case 'yearly': return 'år';
      default: return 'periode';
    }
  };

  const weekDays = [
    { value: 1, label: 'Mandag' },
    { value: 2, label: 'Tirsdag' },
    { value: 3, label: 'Onsdag' },
    { value: 4, label: 'Torsdag' },
    { value: 5, label: 'Fredag' },
    { value: 6, label: 'Lørdag' },
    { value: 0, label: 'Søndag' },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Rediger gentagelse</DialogTitle>
        </DialogHeader>

        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Dette ændrer kun fremtidige gentagelser, ikke allerede oprettede opgaver.
          </AlertDescription>
        </Alert>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="pattern">Gentagelsesmønster</Label>
            <Select
              value={formData.recurrence_pattern}
              onValueChange={(value) => setFormData({ ...formData, recurrence_pattern: value as any })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Dagligt</SelectItem>
                <SelectItem value="weekly">Ugentligt</SelectItem>
                <SelectItem value="monthly">Månedligt</SelectItem>
                <SelectItem value="yearly">Årligt</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="interval">Gentag hver</Label>
            <div className="flex items-center gap-2">
              <Input
                id="interval"
                type="number"
                min="1"
                max="365"
                value={formData.recurrence_interval}
                onChange={(e) => setFormData({ ...formData, recurrence_interval: parseInt(e.target.value) })}
                className="w-20"
              />
              <span className="text-sm text-muted-foreground">{getPatternLabel()}</span>
            </div>
          </div>

          {formData.recurrence_pattern === 'weekly' && (
            <div className="space-y-2">
              <Label htmlFor="day_of_week">Ugedag</Label>
              <Select
                value={formData.recurrence_day_of_week.toString()}
                onValueChange={(value) => setFormData({ ...formData, recurrence_day_of_week: parseInt(value) })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {weekDays.map((day) => (
                    <SelectItem key={day.value} value={day.value.toString()}>
                      {day.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {formData.recurrence_pattern === 'monthly' && (
            <div className="space-y-2">
              <Label htmlFor="day_of_month">Dag i måneden</Label>
              <Input
                id="day_of_month"
                type="number"
                min="1"
                max="31"
                value={formData.recurrence_day_of_month}
                onChange={(e) => setFormData({ ...formData, recurrence_day_of_month: parseInt(e.target.value) })}
              />
            </div>
          )}

          <div className="space-y-3">
            <Label>Slutbetingelse</Label>
            <RadioGroup value={formData.end_condition} onValueChange={(value) => setFormData({ ...formData, end_condition: value })}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="never" id="never" />
                <Label htmlFor="never" className="font-normal cursor-pointer">
                  Gentag for evigt
                </Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="end_date" id="end_date" />
                <Label htmlFor="end_date" className="font-normal cursor-pointer">
                  Slut på dato
                </Label>
              </div>
              {formData.end_condition === 'end_date' && (
                <Input
                  type="date"
                  value={formData.recurrence_end_date}
                  onChange={(e) => setFormData({ ...formData, recurrence_end_date: e.target.value })}
                  className="ml-6"
                />
              )}
              
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="count" id="count" />
                <Label htmlFor="count" className="font-normal cursor-pointer">
                  Efter antal gentagelser
                </Label>
              </div>
              {formData.end_condition === 'count' && (
                <Input
                  type="number"
                  min="1"
                  value={formData.recurrence_count}
                  onChange={(e) => setFormData({ ...formData, recurrence_count: parseInt(e.target.value) })}
                  className="ml-6 w-32"
                />
              )}
            </RadioGroup>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={updateTask.isPending}>
              {updateTask.isPending ? 'Gemmer...' : 'Gem ændringer'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditRecurrenceDialog;
