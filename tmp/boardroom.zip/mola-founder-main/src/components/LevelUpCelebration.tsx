import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Trophy, Sparkles } from 'lucide-react';
import { LEVELS } from '@/hooks/useGamification';
import { Button } from '@/components/ui/button';

interface LevelUpCelebrationProps {
  level: number | null;
  onClose: () => void;
}

export function LevelUpCelebration({ level, onClose }: LevelUpCelebrationProps) {
  const levelConfig = LEVELS.find(l => l.level === level);

  useEffect(() => {
    if (level) {
      // Auto-close after 5 seconds
      const timer = setTimeout(onClose, 5000);
      return () => clearTimeout(timer);
    }
  }, [level, onClose]);

  return (
    <AnimatePresence>
      {level && levelConfig && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          {/* Floating particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              initial={{
                opacity: 0,
                scale: 0,
                x: 0,
                y: 0,
              }}
              animate={{
                opacity: [0, 1, 0],
                scale: [0, 1, 0.5],
                x: (Math.random() - 0.5) * 400,
                y: (Math.random() - 0.5) * 400,
              }}
              transition={{
                duration: 2,
                delay: Math.random() * 0.5,
                ease: 'easeOut',
              }}
              className="absolute pointer-events-none"
            >
              <Sparkles className="w-6 h-6 text-yellow-400" />
            </motion.div>
          ))}

          {/* Main celebration card */}
          <motion.div
            initial={{ scale: 0.5, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.5, opacity: 0, y: 50 }}
            transition={{ type: 'spring', damping: 15 }}
            className="relative bg-card border-2 border-primary rounded-2xl p-8 shadow-2xl max-w-sm mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Trophy icon */}
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ type: 'spring', delay: 0.2, damping: 10 }}
              className="absolute -top-8 left-1/2 -translate-x-1/2"
            >
              <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-4 rounded-full shadow-lg">
                <Trophy className="w-10 h-10 text-white" />
              </div>
            </motion.div>

            {/* Content */}
            <div className="text-center mt-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <p className="text-muted-foreground text-sm uppercase tracking-wide mb-2">
                  Tillykke!
                </p>
                <h2 className="text-2xl font-bold mb-1">Level Up!</h2>
              </motion.div>

              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.4, type: 'spring' }}
                className="my-6"
              >
                <div className={`text-6xl font-bold ${levelConfig.color}`}>
                  {level}
                </div>
                <div className="text-xl font-semibold mt-2">
                  {levelConfig.title}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
                className="flex justify-center gap-1 mb-6"
              >
                {Array.from({ length: level }).map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ scale: 0, rotate: -180 }}
                    animate={{ scale: 1, rotate: 0 }}
                    transition={{ delay: 0.6 + i * 0.1 }}
                  >
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  </motion.div>
                ))}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
              >
                <Button onClick={onClose} className="w-full">
                  Fantastisk! 🎉
                </Button>
              </motion.div>
            </div>

            {/* Decorative corner stars */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              className="absolute -top-2 -right-2"
            >
              <Star className="w-6 h-6 fill-primary text-primary" />
            </motion.div>
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
              className="absolute -bottom-2 -left-2"
            >
              <Star className="w-4 h-4 fill-primary text-primary" />
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
