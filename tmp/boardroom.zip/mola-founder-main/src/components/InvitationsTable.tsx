import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, RefreshCw, XCircle } from 'lucide-react';
import { useInvitations } from '@/hooks/useInvitations';

interface Invitation {
  id: string;
  email: string;
  invited_role: string;
  status: string;
  created_at: string;
  expires_at: string;
  invited_by_profile?: { full_name: string };
  company?: { name: string };
  fund?: { name: string };
}

export function InvitationsTable() {
  const { invitations, isLoading, cancelInvitation, resendInvitation } = useInvitations();

  if (isLoading) {
    return <div className="text-center py-8 text-muted-foreground">Indlæser invitationer...</div>;
  }

  if (!invitations || invitations.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Ingen invitationer endnu. Klik på "Inviter bruger" for at komme i gang.
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string }> = {
      pending: { variant: 'default', label: 'Afventer' },
      accepted: { variant: 'secondary', label: 'Accepteret' },
      expired: { variant: 'destructive', label: 'Udløbet' },
      cancelled: { variant: 'outline', label: 'Annulleret' },
    };
    const config = variants[status] || variants.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getRoleName = (role: string) => {
    const roleNames: Record<string, string> = {
      founder: 'Founder',
      fund_partner: 'Fund Partner',
      investor: 'Investor',
      mola_admin: 'MOLA Admin',
      dd_partner: 'DD Partner',
      external_viewer: 'External Viewer',
    };
    return roleNames[role] || role;
  };

  return (
    <div className="rounded-md border border-border overflow-x-auto w-full max-w-full">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Email</TableHead>
            <TableHead>Rolle</TableHead>
            <TableHead>Virksomhed/Fond</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Inviteret af</TableHead>
            <TableHead>Dato</TableHead>
            <TableHead>Udløber</TableHead>
            <TableHead className="w-[70px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {invitations.map((invitation: Invitation) => (
            <TableRow key={invitation.id}>
              <TableCell className="font-medium">{invitation.email}</TableCell>
              <TableCell>{getRoleName(invitation.invited_role)}</TableCell>
              <TableCell>
                {invitation.company?.name || invitation.fund?.name || '-'}
              </TableCell>
              <TableCell>{getStatusBadge(invitation.status)}</TableCell>
              <TableCell>{invitation.invited_by_profile?.full_name || '-'}</TableCell>
              <TableCell>
                {format(new Date(invitation.created_at), 'dd MMM yyyy', { locale: da })}
              </TableCell>
              <TableCell>
                {format(new Date(invitation.expires_at), 'dd MMM yyyy', { locale: da })}
              </TableCell>
              <TableCell>
                {invitation.status === 'pending' && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => resendInvitation(invitation as any)}>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Gensend invitation
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => cancelInvitation(invitation.id)}
                        className="text-destructive"
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Annuller invitation
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}