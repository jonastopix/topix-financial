import { useState, useEffect } from 'react';
import { Check, X, Loader2 } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import {
  validatePassword,
  checkPasswordLeaked,
  isCommonPassword,
  debounce,
  type PasswordValidationResult,
} from '@/lib/passwordValidation';

interface PasswordStrengthMeterProps {
  password: string;
  onValidationChange?: (isValid: boolean, isLeaked: boolean) => void;
}

export const PasswordStrengthMeter = ({ password, onValidationChange }: PasswordStrengthMeterProps) => {
  const [validation, setValidation] = useState<PasswordValidationResult | null>(null);
  const [isCheckingLeaked, setIsCheckingLeaked] = useState(false);
  const [isLeaked, setIsLeaked] = useState(false);
  const [isCommon, setIsCommon] = useState(false);

  // Debounced leak check to avoid too many API calls
  const checkLeakedDebounced = debounce(async (pwd: string) => {
    if (!pwd || pwd.length < 8) {
      setIsLeaked(false);
      return;
    }

    setIsCheckingLeaked(true);
    try {
      const leaked = await checkPasswordLeaked(pwd);
      setIsLeaked(leaked);
      
      // Update validation result
      if (validation) {
        const updatedValidation = {
          ...validation,
          feedback: {
            ...validation.feedback,
            isNotLeaked: !leaked,
          },
        };
        setValidation(updatedValidation);

        // Notify parent of validation status
        const isValid = 
          updatedValidation.feedback.hasMinLength &&
          updatedValidation.feedback.hasUppercase &&
          updatedValidation.feedback.hasLowercase &&
          updatedValidation.feedback.hasNumber &&
          updatedValidation.feedback.hasSpecial &&
          !leaked &&
          !isCommon;
        
        onValidationChange?.(isValid, leaked);
      }
    } finally {
      setIsCheckingLeaked(false);
    }
  }, 500); // 500ms debounce

  useEffect(() => {
    if (!password) {
      setValidation(null);
      setIsLeaked(false);
      setIsCommon(false);
      onValidationChange?.(false, false);
      return;
    }

    // Basic validation
    const result = validatePassword(password);
    setValidation(result);

    // Check for common passwords
    const common = isCommonPassword(password);
    setIsCommon(common);

    // Trigger debounced leak check
    if (password.length >= 8) {
      checkLeakedDebounced(password);
    } else {
      setIsLeaked(false);
      onValidationChange?.(false, false);
    }
  }, [password]);

  if (!password || !validation) {
    return null;
  }

  const strengthColors = {
    'very-weak': 'hsl(var(--destructive))',
    'weak': 'hsl(var(--destructive))',
    'medium': 'hsl(var(--warning) / 0.8)',
    'strong': 'hsl(var(--success) / 0.8)',
    'very-strong': 'hsl(var(--success))',
  };

  const strengthLabels = {
    'very-weak': 'Meget svag',
    'weak': 'Svag',
    'medium': 'Middel',
    'strong': 'Stærk',
    'very-strong': 'Meget stærk',
  };

  const progressValue = (validation.score / 4) * 100;

  const requirements = [
    { label: 'Mindst 8 tegn', met: validation.feedback.hasMinLength },
    { label: 'Stort bogstav (A-Z)', met: validation.feedback.hasUppercase },
    { label: 'Lille bogstav (a-z)', met: validation.feedback.hasLowercase },
    { label: 'Tal (0-9)', met: validation.feedback.hasNumber },
    { label: 'Specialtegn (fx !@#$%&*_-+)', met: validation.feedback.hasSpecial },
  ];

  return (
    <div className="space-y-3 mt-2">
      {/* Strength bar */}
      <div className="space-y-1">
        <div className="flex justify-between items-center text-sm">
          <span className="text-muted-foreground">Password styrke:</span>
          <span 
            className="font-medium"
            style={{ color: strengthColors[validation.strength] }}
          >
            {strengthLabels[validation.strength]}
          </span>
        </div>
        <Progress 
          value={progressValue} 
          className="h-2"
          style={{
            ['--progress-background' as any]: strengthColors[validation.strength],
          }}
        />
        <p className="text-xs text-muted-foreground">
          Estimeret tid at cracke: {validation.estimatedCrackTime}
        </p>
      </div>

      {/* Requirements checklist */}
      <div className="space-y-1.5">
        {requirements.map((req, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            {req.met ? (
              <Check className="h-4 w-4 text-success" />
            ) : (
              <X className="h-4 w-4 text-muted-foreground" />
            )}
            <span className={req.met ? 'text-success' : 'text-muted-foreground'}>
              {req.label}
            </span>
          </div>
        ))}

        {/* Common password check */}
        {isCommon && (
          <div className="flex items-center gap-2 text-sm">
            <X className="h-4 w-4 text-destructive" />
            <span className="text-destructive">
              Dette er et meget almindeligt password
            </span>
          </div>
        )}

        {/* Leaked password check */}
        <div className="flex items-center gap-2 text-sm">
          {isCheckingLeaked ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              <span className="text-muted-foreground">Tjekker for læk...</span>
            </>
          ) : isLeaked ? (
            <>
              <X className="h-4 w-4 text-destructive" />
              <span className="text-destructive">
                Dette password er fundet i et data-læk
              </span>
            </>
          ) : validation.feedback.isNotLeaked !== null ? (
            <>
              <Check className="h-4 w-4 text-success" />
              <span className="text-success">
                Ikke fundet i kendte data-læk
              </span>
            </>
          ) : null}
        </div>
      </div>

      {/* Warning if password is weak or leaked */}
      {(validation.score < 3 || isLeaked || isCommon) && (
        <div className="text-xs text-destructive bg-destructive/10 border border-destructive/20 rounded-md p-2">
          ⚠️ Dette password opfylder ikke sikkerhedskravene
        </div>
      )}
    </div>
  );
};
