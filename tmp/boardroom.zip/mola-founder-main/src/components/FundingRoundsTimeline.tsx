import { useFundingRounds } from '@/hooks/useFundingRounds';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, DollarSign, Percent, Calendar, FileText, Users } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';

const formatDate = (dateString: string) => {
  return new Date(dateString).toLocaleDateString('da-DK', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};

interface FundingRoundsTimelineProps {
  companyId: string;
}

export function FundingRoundsTimeline({ companyId }: FundingRoundsTimelineProps) {
  const { data: fundingRounds = [], isLoading } = useFundingRounds(companyId);

  if (isLoading) {
    return (
      <Card className="p-6">
        <p className="text-muted-foreground">Indlæser funding rounds...</p>
      </Card>
    );
  }

  if (fundingRounds.length === 0) {
    return (
      <Card className="p-6">
        <p className="text-muted-foreground">Ingen funding rounds endnu</p>
      </Card>
    );
  }

  // Sort by date descending (newest first)
  const sortedRounds = [...fundingRounds].sort((a, b) => 
    new Date(b.invested_at).getTime() - new Date(a.invested_at).getTime()
  );

  const getRoundTypeColor = (type: string, isSecondary?: boolean) => {
    if (isSecondary || type === 'secondary') {
      return 'bg-purple-500';
    }
    switch (type) {
      case 'initial':
        return 'bg-blue-500';
      case 'follow_on':
        return 'bg-green-500';
      case 'bridge':
        return 'bg-yellow-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getRoundTypeBadgeVariant = (type: string) => {
    switch (type) {
      case 'initial':
        return 'default';
      case 'follow_on':
        return 'secondary';
      case 'bridge':
        return 'outline';
      case 'secondary':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getRoundTypeLabel = (type: string, isSecondary?: boolean) => {
    if (isSecondary || type === 'secondary') {
      return 'Secondary';
    }
    switch (type) {
      case 'initial':
        return 'Initial';
      case 'follow_on':
        return 'Follow-on';
      case 'bridge':
        return 'Bridge';
      default:
        return type;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold">Investeringshistorik</h3>
          <p className="text-muted-foreground">Tidslinje over alle funding rounds</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total investeret</p>
          <p className="text-2xl font-bold">
            {formatCurrency(fundingRounds.reduce((sum, r) => sum + (r.invested_amount_dkk || 0), 0))}
          </p>
        </div>
      </div>

      <div className="relative">
        {/* Timeline line */}
        <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-border" />

        {/* Timeline items */}
        <div className="space-y-8">
          {sortedRounds.map((round, index) => (
            <div key={round.id} className="relative flex gap-6">
              {/* Timeline dot */}
              <div className="relative z-10 flex-shrink-0">
                <div className={`h-16 w-16 rounded-full ${getRoundTypeColor(round.round_type, round.is_secondary)} flex items-center justify-center shadow-lg`}>
                  {round.is_secondary ? (
                    <Users className="h-8 w-8 text-white" />
                  ) : (
                    <TrendingUp className="h-8 w-8 text-white" />
                  )}
                </div>
              </div>

              {/* Content card */}
              <Card className={`flex-1 p-6 hover:shadow-md transition-shadow ${round.is_secondary ? 'border-purple-200 dark:border-purple-800' : ''}`}>
                <div className="space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-xl font-bold">{round.round_name}</h4>
                        <Badge variant={getRoundTypeBadgeVariant(round.round_type)} className={round.is_secondary ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300' : ''}>
                          {getRoundTypeLabel(round.round_type, round.is_secondary)}
                        </Badge>
                        {round.is_secondary && (
                          <Badge variant="outline" className="text-purple-600 border-purple-300 dark:text-purple-400 dark:border-purple-700">
                            Old Shares
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDate(round.invested_at)}</span>
                        {round.seller_name && (
                          <>
                            <span className="mx-1">•</span>
                            <Users className="h-4 w-4" />
                            <span>Fra: {round.seller_name}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Metrics grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <DollarSign className="h-4 w-4" />
                        <span>{round.is_secondary ? 'Købspris' : 'Investeret'}</span>
                      </div>
                      <p className="text-lg font-semibold">
                        {formatCurrency(round.invested_amount_dkk)}
                      </p>
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Percent className="h-4 w-4" />
                        <span>Ejerandel</span>
                      </div>
                      <p className="text-lg font-semibold">
                        {round.equity_acquired_pct?.toFixed(2)}%
                      </p>
                    </div>

                    {round.pre_money_valuation_dkk && (
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <TrendingUp className="h-4 w-4" />
                          <span>Pre-money</span>
                        </div>
                        <p className="text-lg font-semibold">
                          {formatCurrency(round.pre_money_valuation_dkk)}
                        </p>
                      </div>
                    )}

                    {round.post_money_valuation_dkk && (
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <TrendingUp className="h-4 w-4" />
                          <span>Post-money</span>
                        </div>
                        <p className="text-lg font-semibold">
                          {formatCurrency(round.post_money_valuation_dkk)}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Note */}
                  {round.note && (
                    <div className="pt-3 border-t">
                      <div className="flex items-start gap-2 text-sm">
                        <FileText className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <p className="text-muted-foreground">{round.note}</p>
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            </div>
          ))}
        </div>

        {/* End marker */}
        <div className="relative flex gap-6 mt-8">
          <div className="relative z-10 flex-shrink-0">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </div>
          <div className="flex-1 flex items-center">
            <p className="text-muted-foreground">Company founded / Initial contact</p>
          </div>
        </div>
      </div>
    </div>
  );
}
