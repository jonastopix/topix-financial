import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MoreVertical, Shield, User as UserIcon, CheckCircle, XCircle } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface User {
  id: string;
  email: string;
  full_name: string;
  company_name: string;
  roles: string[];
  is_active: boolean;
  last_sign_in_at: string | null;
  created_at: string;
}

interface UserManagementTableProps {
  users: User[];
  onManageRoles: (userId: string) => void;
  onToggleStatus: (userId: string, currentStatus: boolean) => void;
}

export function UserManagementTable({ users, onManageRoles, onToggleStatus }: UserManagementTableProps) {
  return (
    <div className="glass-card rounded-xl border border-border/50 overflow-x-auto w-full max-w-full">
      <Table>
        <TableHeader>
          <TableRow className="border-border/50">
            <TableHead>Bruger</TableHead>
            <TableHead>Company</TableHead>
            <TableHead>Roller</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Seneste Login</TableHead>
            <TableHead className="text-right">Handlinger</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id} className="border-border/50">
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-medium text-foreground">{user.full_name || 'Uden navn'}</span>
                  <span className="text-sm text-muted-foreground">{user.email}</span>
                </div>
              </TableCell>
              <TableCell>
                <span className="text-sm text-foreground">{user.company_name || '-'}</span>
              </TableCell>
              <TableCell>
                <div className="flex gap-1 flex-wrap">
                  {user.roles.map((role) => (
                    <Badge
                      key={role}
                      variant={role === 'mola_admin' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {role === 'mola_admin' ? (
                        <>
                          <Shield className="h-3 w-3 mr-1" />
                          Admin
                        </>
                      ) : (
                        <>
                          <UserIcon className="h-3 w-3 mr-1" />
                          Founder
                        </>
                      )}
                    </Badge>
                  ))}
                </div>
              </TableCell>
              <TableCell>
                <Badge variant={user.is_active ? 'success' : 'secondary'} className="text-xs">
                  {user.is_active ? (
                    <>
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Aktiv
                    </>
                  ) : (
                    <>
                      <XCircle className="h-3 w-3 mr-1" />
                      Inaktiv
                    </>
                  )}
                </Badge>
              </TableCell>
              <TableCell>
                <span className="text-sm text-muted-foreground">
                  {user.last_sign_in_at
                    ? format(new Date(user.last_sign_in_at), 'dd. MMM yyyy', { locale: da })
                    : 'Aldrig'}
                </span>
              </TableCell>
              <TableCell className="text-right">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glass-card">
                    <DropdownMenuItem onClick={() => onManageRoles(user.id)}>
                      <Shield className="h-4 w-4 mr-2" />
                      Administrer roller
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem
                      onClick={() => onToggleStatus(user.id, user.is_active)}
                      className={!user.is_active ? 'text-success' : 'text-destructive'}
                    >
                      {user.is_active ? (
                        <>
                          <XCircle className="h-4 w-4 mr-2" />
                          Deaktiver bruger
                        </>
                      ) : (
                        <>
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Aktiver bruger
                        </>
                      )}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
