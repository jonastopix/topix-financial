import { Card } from '@/components/ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface MonthlyReport {
  period_month: number;
  period_year: number;
  revenue_dkk: number;
  ebitda_dkk: number;
  budget_revenue_dkk?: number;
  budget_ebitda_dkk?: number;
}

interface ForecastReport {
  period_month: number;
  period_year: number;
  revenue_dkk: number;
  ebitda_dkk: number;
  isForecast: true;
}

interface HistoricalTrendChartProps {
  reports: MonthlyReport[];
  forecastReports?: ForecastReport[];
  title?: string;
}

export function HistoricalTrendChart({ reports, forecastReports, title = 'Historisk Trend' }: HistoricalTrendChartProps) {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  // Combine actual reports with forecast
  const allReports = forecastReports 
    ? [...reports, ...forecastReports]
    : reports;

  // Sort reports by date and prepare data
  const chartData = [...allReports]
    .sort((a, b) => {
      if (a.period_year !== b.period_year) return a.period_year - b.period_year;
      return a.period_month - b.period_month;
    })
    .map(report => {
      const date = new Date(report.period_year, report.period_month - 1);
      const isForecast = 'isForecast' in report && report.isForecast;
      
      return {
        name: format(date, 'MMM yyyy', { locale: da }),
        // Actual values (only for non-forecast data)
        revenue: !isForecast ? Number(report.revenue_dkk) : null,
        ebitda: !isForecast ? Number(report.ebitda_dkk) : null,
        budgetRevenue: !isForecast && 'budget_revenue_dkk' in report && report.budget_revenue_dkk ? Number(report.budget_revenue_dkk) : null,
        budgetEBITDA: !isForecast && 'budget_ebitda_dkk' in report && report.budget_ebitda_dkk ? Number(report.budget_ebitda_dkk) : null,
        // Forecast values
        forecastRevenue: isForecast ? Number(report.revenue_dkk) : null,
        forecastEBITDA: isForecast ? Number(report.ebitda_dkk) : null,
      };
    });

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {formatCurrency(entry.value)} kr
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const CustomLegend = ({ payload }: any) => {
    return (
      <div className="flex flex-wrap justify-center gap-4 mt-4">
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2">
            <div 
              className="w-3 h-3 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-sm text-muted-foreground">{entry.value}</span>
          </div>
        ))}
      </div>
    );
  };

  if (!chartData || chartData.length === 0) {
    return (
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">{title}</h3>
        <p className="text-center text-muted-foreground py-8">
          Ingen data tilgængelig for at vise trend
        </p>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
          <XAxis 
            dataKey="name" 
            className="text-xs"
            tick={{ fill: 'hsl(var(--muted-foreground))' }}
          />
          <YAxis 
            className="text-xs"
            tick={{ fill: 'hsl(var(--muted-foreground))' }}
            tickFormatter={(value) => formatCurrency(value)}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend content={<CustomLegend />} />
          <Line 
            type="monotone" 
            dataKey="revenue" 
            stroke="hsl(var(--success))" 
            strokeWidth={2}
            name="Oms"
            dot={{ fill: 'hsl(var(--success))', r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="budgetRevenue" 
            stroke="hsl(var(--success))" 
            strokeWidth={2}
            strokeDasharray="5 5"
            name="Oms budget"
            dot={false}
          />
          <Line 
            type="monotone" 
            dataKey="ebitda" 
            stroke="hsl(var(--primary))" 
            strokeWidth={2}
            name="EBITDA"
            dot={{ fill: 'hsl(var(--primary))', r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="budgetEBITDA" 
            stroke="hsl(var(--primary))" 
            strokeWidth={2}
            strokeDasharray="5 5"
            name="EBITDA budget"
            dot={false}
          />
          <Line 
            type="monotone" 
            dataKey="forecastRevenue" 
            stroke="hsl(var(--success))" 
            strokeWidth={2}
            strokeDasharray="8 4"
            name="Oms forecast"
            dot={false}
            opacity={0.7}
            connectNulls
          />
          <Line 
            type="monotone" 
            dataKey="forecastEBITDA" 
            stroke="hsl(var(--primary))" 
            strokeWidth={2}
            strokeDasharray="8 4"
            name="EBITDA forecast"
            dot={false}
            opacity={0.7}
            connectNulls
          />
        </LineChart>
      </ResponsiveContainer>
      <p className="text-xs text-muted-foreground text-center mt-4">
        Solid linje = Faktisk | Tynd stiplet = Budget | Tyk stiplet = Forecast baseret på trend og sæson
      </p>
    </Card>
  );
}
