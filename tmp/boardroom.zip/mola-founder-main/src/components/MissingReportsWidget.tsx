import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertCircle, Mail } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useSendReportReminder } from '@/hooks/useSendReportReminder';

interface CompanyWithReports {
  id: string;
  name: string;
  lastReportMonth?: number;
  lastReportYear?: number;
}

export const MissingReportsWidget = () => {
  const navigate = useNavigate();
  const { mutate: sendReminder, isPending } = useSendReportReminder();

  const { data: companies, isLoading } = useQuery({
    queryKey: ['companies-with-missing-reports'],
    queryFn: async () => {
      // Fetch all active companies (exclude exited, bankruptcy, rejected)
      const { data: companiesData, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, status')
        .eq('is_active', true)
        .not('status', 'in', '(exited,bankruptcy,rejected)')
        .order('name');

      if (companiesError) throw companiesError;

      // Fetch all monthly reports
      const { data: reportsData, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('company_id, period_month, period_year, revenue_dkk')
        .order('period_year', { ascending: false })
        .order('period_month', { ascending: false });

      if (reportsError) throw reportsError;

      // Calculate expected report month
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth() + 1;
      const currentDay = now.getDate();

      let expectedMonth = currentMonth - 1;
      let expectedYear = currentYear;
      
      if (expectedMonth === 0) {
        expectedMonth = 12;
        expectedYear = currentYear - 1;
      }

      // Only check if we're past the 20th deadline
      const isPastDeadline = currentDay > 20;
      if (!isPastDeadline) {
        return [];
      }

      // Map companies with their latest report
      const companiesWithReports: CompanyWithReports[] = (companiesData || []).map(company => {
        // Find latest report with actual data (revenue_dkk IS NOT NULL) for this company
        const companyReports = (reportsData || [])
          .filter(r => r.company_id === company.id && r.revenue_dkk !== null && Number(r.revenue_dkk) > 0)
          .sort((a, b) => {
            if (a.period_year !== b.period_year) {
              return b.period_year - a.period_year;
            }
            return b.period_month - a.period_month;
          });

        const latestReport = companyReports[0];

        return {
          id: company.id,
          name: company.name,
          lastReportMonth: latestReport?.period_month,
          lastReportYear: latestReport?.period_year,
        };
      });

      // Filter to only companies missing the expected report
      return companiesWithReports.filter(company => {
        if (!company.lastReportMonth || !company.lastReportYear) {
          return true; // No reports at all
        }

        // Check if last report is older than expected
        return (
          company.lastReportYear < expectedYear ||
          (company.lastReportYear === expectedYear && company.lastReportMonth < expectedMonth)
        );
      });
    },
  });

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="h-20 animate-pulse bg-muted rounded" />
      </Card>
    );
  }

  if (!companies || companies.length === 0) {
    return null;
  }

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  let expectedMonth = currentMonth - 1;
  let expectedYear = now.getFullYear();
  
  if (expectedMonth === 0) {
    expectedMonth = 12;
    expectedYear--;
  }

  const monthNames = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];

  return (
    <Card className="p-6 border-destructive/50 bg-destructive/5">
      <div className="flex items-center gap-2 mb-4">
        <div className="h-10 w-10 rounded-lg bg-destructive/10 flex items-center justify-center">
          <AlertCircle className="h-5 w-5 text-destructive" />
        </div>
        <div>
          <h3 className="font-semibold">Manglende månedsrapporter</h3>
          <p className="text-xs text-muted-foreground">
            Deadline overskredet for {monthNames[expectedMonth - 1]} {expectedYear}
          </p>
        </div>
        <Badge variant="destructive" className="ml-auto">
          {companies.length}
        </Badge>
      </div>

      <div className="space-y-2">
        {companies.map((company) => (
          <div
            key={company.id}
            className="flex items-center justify-between p-3 rounded-lg bg-background hover:bg-muted/50 transition-colors"
          >
            <div
              onClick={() => navigate(`/company/${company.id}`)}
              className="flex-1 cursor-pointer"
            >
              <p className="font-medium">{company.name}</p>
              {company.lastReportMonth && company.lastReportYear ? (
                <p className="text-xs text-muted-foreground">
                  Seneste: {monthNames[company.lastReportMonth - 1]} {company.lastReportYear}
                </p>
              ) : (
                <p className="text-xs text-muted-foreground">Ingen rapporter endnu</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  sendReminder({ companyId: company.id });
                }}
                disabled={isPending}
              >
                <Mail className="h-4 w-4 mr-1" />
                Send påmindelse
              </Button>
              <Badge variant="outline" className="text-destructive border-destructive/50">
                Forsinket
              </Badge>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};
