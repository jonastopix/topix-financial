import { useEffect, useState } from 'react';
import { CheckCircle2, TrendingUp, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ConfettiCelebrationProps {
  show: boolean;
}

const ConfettiCelebration = ({ show }: ConfettiCelebrationProps) => {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; delay: number; color: string }>>([]);

  useEffect(() => {
    if (show) {
      // Generate random confetti particles
      const newParticles = Array.from({ length: 50 }, (_, i) => ({
        id: i,
        x: Math.random() * 100,
        delay: Math.random() * 0.5,
        color: ['hsl(var(--accent))', 'hsl(var(--primary))', 'hsl(var(--warning))'][Math.floor(Math.random() * 3)]
      }));
      setParticles(newParticles);
    }
  }, [show]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none overflow-hidden">
      {/* Confetti particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute top-0 w-2 h-2 rounded-full animate-confetti-fall"
          style={{
            left: `${particle.x}%`,
            backgroundColor: particle.color,
            animationDelay: `${particle.delay}s`,
          }}
        />
      ))}

      {/* Success message overlay */}
      <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm animate-fade-up">
        <div className="text-center space-y-4 animate-scale-in">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-success/20 mb-4">
            <CheckCircle2 className="h-10 w-10 text-success animate-bounce" />
          </div>
          <h2 className="text-4xl font-bold gradient-text flex items-center justify-center gap-3">
            <Sparkles className="h-8 w-8 text-accent" />
            Fantastisk!
            <Sparkles className="h-8 w-8 text-accent" />
          </h2>
          <p className="text-xl text-muted-foreground">
            Din månedlige rapport er gemt
          </p>
          <div className="flex items-center justify-center gap-2 text-success">
            <TrendingUp className="h-5 w-5" />
            <span className="text-sm font-medium">
              Værdiberegning opdateres automatisk
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfettiCelebration;
