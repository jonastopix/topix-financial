import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Pencil, Search, Upload, X, Trash2, Plus } from 'lucide-react';
import { CompanyFormData, CompanyStatus } from '@/hooks/useCompanyManagement';
import { useFunds } from '@/hooks/useReturnsData';
import { useCVRLookup } from '@/hooks/useCVRLookup';
import { useRole } from '@/contexts/RoleContext';
import { useCompanyLogo } from '@/hooks/useCompanyLogo';

interface EditCompanyDialogProps {
  company: any;
  onSubmit: (id: string, data: Partial<CompanyFormData>) => Promise<void> | void;
  onArchive?: (id: string) => Promise<void> | void;
}

export function EditCompanyDialog({ company, onSubmit, onArchive }: EditCompanyDialogProps) {
  const [open, setOpen] = useState(false);
  const [showArchiveDialog, setShowArchiveDialog] = useState(false);
  const { data: funds } = useFunds();
  const { lookupCVR, isLoading } = useCVRLookup();
  const { isAdmin } = useRole();
  const { uploadLogo, deleteLogo, isUploading } = useCompanyLogo();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [brandAliases, setBrandAliases] = useState<string[]>(company.brand_aliases || []);
  const [newBrandAlias, setNewBrandAlias] = useState('');
  const [formData, setFormData] = useState<CompanyFormData>({
    name: company.name || '',
    cvr: company.cvr || '',
    industry: company.industry || 'other',
    description: company.description || '',
    business_model: company.business_model || '',
    target_market: company.target_market || '',
    growth_stage: company.growth_stage || '',
    logo_url: company.logo_url || '',
    fund_id: company.fund_id || '',
    invested_amount_dkk: company.invested_amount_dkk || 0,
    equity_share_pct: company.equity_share_pct || 0,
    invested_at: company.invested_at || '',
    is_active: company.is_active ?? true,
    status: company.status || 'new_investment',
    founded_date: company.founded_date || '',
    company_type: company.company_type || '',
    address: company.address || '',
    city: company.city || '',
    zipcode: company.zipcode || '',
    phone: company.phone || '',
    email: company.email || '',
    google_drive_url: company.google_drive_url || '',
    has_board: company.has_board || false,
    board_formation_date: company.board_formation_date || '',
    fiscal_year_end_month: company.fiscal_year_end_month || 12,
    fiscal_year_end_day: company.fiscal_year_end_day || 31,
    accountant_name: company.accountant_name || '',
    accountant_email: company.accountant_email || '',
  } as any);

  useEffect(() => {
    if (open) {
      setFormData({
        name: company.name || '',
        cvr: company.cvr || '',
        industry: company.industry || 'other',
        description: company.description || '',
        business_model: company.business_model || '',
        target_market: company.target_market || '',
        growth_stage: company.growth_stage || '',
        logo_url: company.logo_url || '',
        fund_id: company.fund_id || '',
        invested_amount_dkk: company.invested_amount_dkk || 0,
        equity_share_pct: company.equity_share_pct || 0,
        invested_at: company.invested_at || '',
        is_active: company.is_active ?? true,
        status: company.status || 'new_investment',
        founded_date: company.founded_date || '',
        company_type: company.company_type || '',
        address: company.address || '',
        city: company.city || '',
        zipcode: company.zipcode || '',
        phone: company.phone || '',
        email: company.email || '',
        google_drive_url: company.google_drive_url || '',
        accountant_name: company.accountant_name || '',
        accountant_email: company.accountant_email || '',
      });
      setLogoPreview(company.logo_url || null);
      setBrandAliases(company.brand_aliases || []);
      setNewBrandAlias('');
    }
  }, [open, company]);

  const handleAddBrandAlias = () => {
    const trimmed = newBrandAlias.trim();
    if (trimmed && !brandAliases.includes(trimmed)) {
      setBrandAliases([...brandAliases, trimmed]);
      setNewBrandAlias('');
    }
  };

  const handleRemoveBrandAlias = (aliasToRemove: string) => {
    setBrandAliases(brandAliases.filter(a => a !== aliasToRemove));
  };

  const handleCVRLookup = async () => {
    if (!formData.cvr) return;
    const { data } = await lookupCVR(formData.cvr);
    if (data) {
      setFormData({
        ...formData,
        name: data.name,
        founded_date: data.startdate,
        company_type: data.companytype,
        industry: data.industrydesc || formData.industry,
        address: data.address,
        city: data.city,
        zipcode: data.zipcode,
        phone: data.phone,
        email: data.email,
      });
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const logoUrl = await uploadLogo(file, company.id);
    if (logoUrl) {
      setFormData({ ...formData, logo_url: logoUrl });
      setLogoPreview(logoUrl);
    }
  };

  const handleLogoRemove = async () => {
    await deleteLogo(company.id);
    setFormData({ ...formData, logo_url: '' });
    setLogoPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Clean up empty strings to null for date fields and optional fields
    const cleanedData = {
      ...formData,
      founded_date: formData.founded_date || null,
      invested_at: formData.invested_at || null,
      cvr: formData.cvr || null,
      company_type: formData.company_type || null,
      address: formData.address || null,
      city: formData.city || null,
      zipcode: formData.zipcode || null,
      phone: formData.phone || null,
      email: formData.email || null,
      logo_url: formData.logo_url || null,
      google_drive_url: formData.google_drive_url || null,
      fund_id: formData.fund_id || null,
      description: formData.description || null,
      business_model: formData.business_model || null,
      target_market: formData.target_market || null,
      growth_stage: formData.growth_stage || null,
      brand_aliases: brandAliases,
      accountant_name: formData.accountant_name || null,
      accountant_email: formData.accountant_email || null,
    };
    
    await onSubmit(company.id, cleanedData as any);
    setOpen(false);
  };

  const handleArchive = async () => {
    if (onArchive) {
      await onArchive(company.id);
      setShowArchiveDialog(false);
      setOpen(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline"
          className="justify-start gap-3 h-auto py-3 w-full"
        >
          <Pencil className="h-4 w-4" />
          <span>Rediger info</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Rediger Selskab</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto px-1">
            <div className="grid grid-cols-2 gap-4 pb-4">
              <div className="space-y-2">
                <Label htmlFor="name">Navn *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cvr">CVR Nummer</Label>
                <div className="flex gap-2">
                  <Input
                    id="cvr"
                    value={formData.cvr}
                    onChange={(e) => setFormData({ ...formData, cvr: e.target.value })}
                    placeholder="fx 12345678"
                    pattern="\d{8}"
                    maxLength={8}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCVRLookup}
                    disabled={!formData.cvr || !/^\d{8}$/.test(formData.cvr) || isLoading}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="founded_date">Stiftelsesdato</Label>
                <Input
                  id="founded_date"
                  type="date"
                  value={formData.founded_date || ''}
                  onChange={(e) => setFormData({ ...formData, founded_date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="company_type">Selskabsform</Label>
                <Input
                  id="company_type"
                  value={formData.company_type || ''}
                  onChange={(e) => setFormData({ ...formData, company_type: e.target.value })}
                  placeholder="fx ApS, A/S"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="industry">Industri</Label>
                <Select
                  value={formData.industry}
                  onValueChange={(value) => setFormData({ ...formData, industry: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="saas">SaaS</SelectItem>
                    <SelectItem value="e-commerce">E-commerce</SelectItem>
                    <SelectItem value="marketplace">Marketplace</SelectItem>
                    <SelectItem value="fintech">Fintech</SelectItem>
                    <SelectItem value="healthtech">Sundhedsteknologi</SelectItem>
                    <SelectItem value="proptech">Ejendomsteknologi</SelectItem>
                    <SelectItem value="edtech">Uddannelsesteknologi</SelectItem>
                    <SelectItem value="cleantech">Grøn teknologi</SelectItem>
                    <SelectItem value="foodtech">Fødevareteknologi</SelectItem>
                    <SelectItem value="logistics">Logistik</SelectItem>
                    <SelectItem value="manufacturing">Produktion</SelectItem>
                    <SelectItem value="media">Medier & underholdning</SelectItem>
                    <SelectItem value="services">Professionelle tjenester</SelectItem>
                    <SelectItem value="retail">Detailhandel</SelectItem>
                    <SelectItem value="other">Andet</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Brand Aliases Section for PR Search */}
              <div className="col-span-2 space-y-2 border rounded-lg p-3 bg-muted/30">
                <Label htmlFor="brand_aliases">Brandnavne (til PR-søgning)</Label>
                <p className="text-xs text-muted-foreground">
                  Tilføj alternative navne virksomheden er kendt under i medierne. Disse bruges primært ved PR-søgning.
                </p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {brandAliases.map((alias, idx) => (
                    <Badge key={idx} variant="secondary" className="gap-1">
                      {alias}
                      <button
                        type="button"
                        onClick={() => handleRemoveBrandAlias(alias)}
                        className="ml-1 hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="brand_aliases"
                    value={newBrandAlias}
                    onChange={(e) => setNewBrandAlias(e.target.value)}
                    placeholder="fx 'Bland Selv Frø' for Rn Group ApS"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddBrandAlias();
                      }
                    }}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAddBrandAlias}
                    disabled={!newBrandAlias.trim()}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="col-span-2 space-y-2">
                <Label htmlFor="description">Beskrivelse</Label>
                <textarea
                  id="description"
                  className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  value={formData.description || ''}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Beskriv kort hvad virksomheden laver, fx 'Online abonnementstjeneste til software til bogføring målrettet SMV'er'"
                  maxLength={500}
                />
                <p className="text-xs text-muted-foreground">
                  {(formData.description || '').length}/500 tegn
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="business_model">Forretningsmodel</Label>
                <Select
                  value={formData.business_model || undefined}
                  onValueChange={(value) => setFormData({ ...formData, business_model: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg forretningsmodel" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="subscription">Abonnement</SelectItem>
                    <SelectItem value="licensing">Licensiering</SelectItem>
                    <SelectItem value="transaction">Transaktionsbaseret</SelectItem>
                    <SelectItem value="marketplace">Marketplace</SelectItem>
                    <SelectItem value="freemium">Freemium</SelectItem>
                    <SelectItem value="advertising">Annoncering</SelectItem>
                    <SelectItem value="ecommerce">E-handel</SelectItem>
                    <SelectItem value="consulting">Konsulent/Service</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="target_market">Målgruppe</Label>
                <Select
                  value={formData.target_market || undefined}
                  onValueChange={(value) => setFormData({ ...formData, target_market: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg målgruppe" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="b2b">B2B - Business to Business</SelectItem>
                    <SelectItem value="b2c">B2C - Business to Consumer</SelectItem>
                    <SelectItem value="b2b2c">B2B2C - Business to Business to Consumer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="growth_stage">Vækststadie</Label>
                <Select
                  value={formData.growth_stage || undefined}
                  onValueChange={(value) => setFormData({ ...formData, growth_stage: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg vækststadie" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="seed">Seed - Tidlig fase</SelectItem>
                    <SelectItem value="early">Early - Tidlig vækst</SelectItem>
                    <SelectItem value="growth">Growth - Vækstfase</SelectItem>
                    <SelectItem value="mature">Mature - Moden</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value as CompanyStatus })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="new_investment">🟡 Ny investering</SelectItem>
                    <SelectItem value="due_diligence">🔵 Due Diligence</SelectItem>
                    <SelectItem value="active">🟢 Aktiv</SelectItem>
                    <SelectItem value="exited">🎯 Solgt</SelectItem>
                    <SelectItem value="bankruptcy">🔴 Konkurs</SelectItem>
                    <SelectItem value="rejected">⚫ Afvist</SelectItem>
                    <SelectItem value="archived">📦 Arkiveret</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="fund">Fond</Label>
                <Select
                  value={formData.fund_id || undefined}
                  onValueChange={(value) => setFormData({ ...formData, fund_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg fond" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {funds?.map((fund) => (
                      <SelectItem key={fund.id} value={fund.id}>
                        {fund.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="invested_amount">Investeret Beløb (DKK)</Label>
                <Input
                  id="invested_amount"
                  type="number"
                  value={formData.invested_amount_dkk}
                  onChange={(e) => setFormData({ ...formData, invested_amount_dkk: parseFloat(e.target.value) })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="equity_share">Ejerandel (%)</Label>
                <Input
                  id="equity_share"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.equity_share_pct}
                  onChange={(e) => setFormData({ ...formData, equity_share_pct: parseFloat(e.target.value) })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="invested_at">Investerings Dato</Label>
                <Input
                  id="invested_at"
                  type="date"
                  value={formData.invested_at}
                  onChange={(e) => setFormData({ ...formData, invested_at: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Adresse</Label>
                <Input
                  id="address"
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Vejnavn 1"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">By</Label>
                <Input
                  id="city"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="København"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zipcode">Postnummer</Label>
                <Input
                  id="zipcode"
                  value={formData.zipcode || ''}
                  onChange={(e) => setFormData({ ...formData, zipcode: e.target.value })}
                  placeholder="1234"
                  maxLength={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefon</Label>
                <Input
                  id="phone"
                  value={formData.phone || ''}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+45 12345678"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email || ''}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="[email protected]"
                />
              </div>

              {/* Board Governance Section */}
              <div className="col-span-2 space-y-4 border-t pt-4 mt-4">
                <h3 className="font-semibold">Bestyrelse & Regnskabsår</h3>
                
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="has_board"
                    checked={formData.has_board || false}
                    onChange={(e) => setFormData({ ...formData, has_board: e.target.checked })}
                    className="h-4 w-4"
                  />
                  <Label htmlFor="has_board" className="cursor-pointer">
                    Selskabet har en bestyrelse
                  </Label>
                </div>

                {formData.has_board && (
                  <div className="grid grid-cols-2 gap-4 pl-6">
                    <div className="space-y-2">
                      <Label htmlFor="board_formation_date">Bestyrelse etableret</Label>
                      <Input
                        id="board_formation_date"
                        type="date"
                        value={formData.board_formation_date || ''}
                        onChange={(e) => setFormData({ ...formData, board_formation_date: e.target.value })}
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fiscal_year_end_month">Regnskabsår slutter måned</Label>
                    <Select
                      value={(formData.fiscal_year_end_month || 12).toString()}
                      onValueChange={(value) => setFormData({ ...formData, fiscal_year_end_month: parseInt(value) })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-background z-50">
                        <SelectItem value="1">Januar</SelectItem>
                        <SelectItem value="2">Februar</SelectItem>
                        <SelectItem value="3">Marts</SelectItem>
                        <SelectItem value="4">April</SelectItem>
                        <SelectItem value="5">Maj</SelectItem>
                        <SelectItem value="6">Juni</SelectItem>
                        <SelectItem value="7">Juli</SelectItem>
                        <SelectItem value="8">August</SelectItem>
                        <SelectItem value="9">September</SelectItem>
                        <SelectItem value="10">Oktober</SelectItem>
                        <SelectItem value="11">November</SelectItem>
                        <SelectItem value="12">December</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="fiscal_year_end_day">Regnskabsår slutter dag</Label>
                    <Input
                      id="fiscal_year_end_day"
                      type="number"
                      min="1"
                      max="31"
                      value={formData.fiscal_year_end_day || 31}
                      onChange={(e) => setFormData({ ...formData, fiscal_year_end_day: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <p className="text-xs text-muted-foreground">
                  Regnskabsår: {formData.fiscal_year_end_month || 12}/{formData.fiscal_year_end_day || 31}
                </p>
              </div>

              <div className="space-y-2 col-span-2">
                <Label htmlFor="logo">Logo</Label>
                <div className="flex items-center gap-4">
                  {logoPreview && (
                    <div className="relative">
                      <img
                        src={logoPreview}
                        alt="Logo preview"
                        className="h-20 w-20 object-contain rounded-lg border-2 border-border bg-background"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute -top-2 -right-2 h-6 w-6"
                        onClick={handleLogoRemove}
                        disabled={isUploading}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                  <div className="flex-1">
                    <Input
                      ref={fileInputRef}
                      id="logo"
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      disabled={isUploading}
                      className="hidden"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                      className="w-full"
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      {isUploading ? 'Uploader...' : logoPreview ? 'Skift logo' : 'Upload logo'}
                    </Button>
                    <p className="text-xs text-muted-foreground mt-1">
                      Max 5MB. Logo tilpasses automatisk til 200x200px.
                    </p>
                  </div>
                </div>
              </div>

              {/* Accountant Contact Section */}
              <div className="col-span-2 space-y-3 border rounded-lg p-4 bg-muted/30">
                <div>
                  <Label className="text-base font-semibold">Bogholderikontakt</Label>
                  <p className="text-xs text-muted-foreground">
                    Fast kontaktperson til regnskab og kørselsrapporter for denne virksomhed
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="accountant_name">Bogholders navn</Label>
                    <Input
                      id="accountant_name"
                      value={formData.accountant_name || ''}
                      onChange={(e) => setFormData({ ...formData, accountant_name: e.target.value })}
                      placeholder="fx Anna Jensen"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="accountant_email">Bogholders email</Label>
                    <Input
                      id="accountant_email"
                      type="email"
                      value={formData.accountant_email || ''}
                      onChange={(e) => setFormData({ ...formData, accountant_email: e.target.value })}
                      placeholder="fx bogholder@firma.dk"
                    />
                  </div>
                </div>
              </div>

              {isAdmin && (
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="google_drive_url">Google Drive URL (kun synlig for admins)</Label>
                  <Input
                    id="google_drive_url"
                    value={formData.google_drive_url || ''}
                    onChange={(e) => setFormData({ ...formData, google_drive_url: e.target.value })}
                    placeholder="https://drive.google.com/..."
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-between gap-2 pt-4 border-t bg-background">
            {isAdmin && onArchive && (
              <Button 
                type="button" 
                variant="destructive"
                onClick={() => setShowArchiveDialog(true)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Arkivér selskab
              </Button>
            )}
            <div className="flex gap-2 ml-auto">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Annuller
              </Button>
              <Button type="submit">Gem Ændringer</Button>
            </div>
          </div>
        </form>
      </DialogContent>

      <AlertDialog open={showArchiveDialog} onOpenChange={setShowArchiveDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Arkivér selskab?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil arkivere selskabet <strong>{company.name}</strong> og skjule det fra normale lister. 
              Alle historiske data bevares og kan bruges til statistik og exit-beregninger. 
              Selskabet kan genaktiveres senere hvis nødvendigt.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction onClick={handleArchive} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Arkivér
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Dialog>
  );
}
