import { Bot, TrendingUp, DollarSign, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const AIInsightsPlaceholder = () => {
  const insights = [
    {
      icon: TrendingUp,
      text: "Omsætning +12% mod sidste måned",
      color: "text-accent"
    },
    {
      icon: DollarSign,
      text: "Bruttoavance +4 p.p.",
      color: "text-accent"
    },
    {
      icon: AlertCircle,
      text: "Likviditet lavere end forventet – fokus på cashflow",
      color: "text-yellow-500"
    }
  ];

  return (
    <Card className="overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5 pointer-events-none" />
      <div className="absolute top-4 right-4 opacity-10">
        <Bot className="h-32 w-32" />
      </div>
      
      <CardHeader className="relative">
        <div className="flex items-center gap-3">
          <Bot className="h-8 w-8 text-primary" />
          <CardTitle>AI Insights</CardTitle>
        </div>
      </CardHeader>
      
      <CardContent className="relative space-y-6">
        <p className="text-muted-foreground">
          AI genererer månedlige analyser baseret på dine rapporter – kommer i V4.
        </p>
        
        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Eksempel-indsigter:</h4>
          {insights.map((insight, idx) => (
            <div 
              key={idx}
              className="flex items-start gap-3 p-4 rounded-lg bg-card/50 border border-border/50 hover:bg-card transition-all duration-300 hover:scale-[1.02]"
            >
              <insight.icon className={`h-5 w-5 ${insight.color} flex-shrink-0 mt-0.5`} />
              <span className="text-sm">{insight.text}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AIInsightsPlaceholder;
