import { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, CheckCircle2, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Document {
  id: string;
  name_da: string;
  uploaded: boolean;
}

interface DocumentUploadProps {
  document: Document;
  onUpload: (file: File) => Promise<void>;
}

const DocumentUpload = ({ document, onUpload }: DocumentUploadProps) => {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 20MB)
    if (file.size > 20 * 1024 * 1024) {
      toast({
        title: "Fil for stor",
        description: "Filen må max være 20MB",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    try {
      await onUpload(file);
      toast({
        title: "Upload gennemført",
        description: `${document.name_da} er uploadet`,
      });
    } catch (error) {
      toast({
        title: "Upload fejlede",
        description: "Der opstod en fejl. Prøv igen.",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <div className="flex items-center justify-between p-4 rounded-lg border border-border bg-card/50">
      <div className="flex items-center gap-3">
        <FileText className="h-5 w-5 text-muted-foreground" />
        <div>
          <p className="text-sm font-medium text-card-foreground">{document.name_da}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {document.uploaded && (
          <CheckCircle2 className="h-5 w-5 text-[hsl(var(--status-complete))]" />
        )}
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileChange}
          className="hidden"
          accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
        />
        <Button
          size="sm"
          variant={document.uploaded ? "outline" : "default"}
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
        >
          <Upload className="h-4 w-4 mr-2" />
          {uploading ? 'Uploader...' : document.uploaded ? 'Opdater' : 'Upload'}
        </Button>
      </div>
    </div>
  );
};

export default DocumentUpload;
