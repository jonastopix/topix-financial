import { useMemo, useState } from 'react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { toast } from 'sonner';
import { Calendar as CalendarIcon, Zap } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { useTaskManagement } from '@/hooks/useTaskManagement';
import { cn } from '@/lib/utils';

interface QuickTaskSheetProps {
  onSuccess: () => void;
}

const priorityOptions = [
  { value: 'low', label: 'Lav', color: 'bg-muted hover:bg-muted/80' },
  {
    value: 'medium',
    label: 'Mellem',
    color: 'bg-blue-500/20 hover:bg-blue-500/30 text-blue-700 dark:text-blue-300',
  },
  {
    value: 'high',
    label: 'Høj',
    color: 'bg-orange-500/20 hover:bg-orange-500/30 text-orange-700 dark:text-orange-300',
  },
  { value: 'urgent', label: 'Akut', color: 'bg-destructive/20 hover:bg-destructive/30 text-destructive' },
] as const;

export const QuickTaskSheet = ({ onSuccess }: QuickTaskSheetProps) => {
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');
  const [dueDate, setDueDate] = useState<Date | undefined>(undefined);
  const { createTask } = useTaskManagement();

  const dueDateKey = useMemo(() => (dueDate ? format(dueDate, 'yyyy-MM-dd') : ''), [dueDate]);
  const todayKey = useMemo(() => format(new Date(), 'yyyy-MM-dd'), []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      toast.error('Indtast en titel for opgaven');
      return;
    }

    createTask.mutate(
      {
        title: title.trim(),
        priority,
        due_date: dueDate ? format(dueDate, 'yyyy-MM-dd') : null,
        status: 'todo',
        description: null,
        company_id: null,
        assigned_to: null,
      },
      {
        onSuccess: () => {
          toast.success('Opgave oprettet! 🎉', {
            description: 'Du kan berige den senere med flere detaljer.',
          });
          // Reset form
          setTitle('');
          setPriority('medium');
          setDueDate(undefined);
          onSuccess();
        },
        onError: () => {
          toast.error('Kunne ikke oprette opgave');
        },
      },
    );
  };

  // Quick date shortcuts
  const setQuickDate = (days: number) => {
    const date = new Date();
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + days);
    setDueDate(date);
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 pb-8 space-y-6">
      <DrawerHeader className="px-0 pt-0">
        <DrawerTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Hurtig opgave
        </DrawerTitle>
        <DrawerDescription>Notér din idé nu – berig den senere</DrawerDescription>
      </DrawerHeader>

      <div className="space-y-2">
        <Input
          placeholder="Hvad skal du huske?"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          autoFocus
          className="text-lg h-14 px-4"
          autoComplete="off"
        />
      </div>

      <div className="space-y-3">
        <Label className="text-sm text-muted-foreground">Prioritet</Label>
        <div className="grid grid-cols-4 gap-2">
          {priorityOptions.map((p) => (
            <Button
              key={p.value}
              type="button"
              variant="ghost"
              onClick={() => setPriority(p.value)}
              size="sm"
              className={`h-10 ${
                priority === p.value ? `${p.color} ring-2 ring-primary ring-offset-2` : 'bg-muted/50 hover:bg-muted'
              }`}
            >
              {p.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <Label className="text-sm text-muted-foreground flex items-center gap-2">
          <CalendarIcon className="h-4 w-4" />
          Deadline (valgfri)
        </Label>

        {/* Quick date buttons */}
        <div className="flex gap-2 flex-wrap">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setQuickDate(0)}
            className={dueDateKey === todayKey ? 'ring-2 ring-primary' : ''}
          >
            I dag
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => setQuickDate(1)}>
            I morgen
          </Button>
          <Button type="button" variant="outline" size="sm" onClick={() => setQuickDate(7)}>
            Om en uge
          </Button>
          {dueDate && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setDueDate(undefined)}
              className="text-muted-foreground"
            >
              Ryd
            </Button>
          )}
        </div>

        {/* Date picker */}
        <Popover>
          <PopoverTrigger asChild>
            <Button
              type="button"
              variant="outline"
              className={cn(
                'h-12 w-full justify-start text-left font-normal',
                !dueDate && 'text-muted-foreground',
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4 opacity-70" />
              {dueDate ? format(dueDate, 'PPP', { locale: da }) : 'Vælg dato…'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dueDate}
              onSelect={setDueDate}
              initialFocus
              className="pointer-events-auto"
            />
          </PopoverContent>
        </Popover>
      </div>

      <Button type="submit" disabled={!title.trim() || createTask.isPending} className="w-full h-14 text-base font-medium">
        {createTask.isPending ? 'Gemmer...' : 'Gem opgave'}
      </Button>
    </form>
  );
};
