import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAnnouncements } from '@/hooks/useAnnouncements';
import { AlertCircle, CheckCircle, Info, TrendingUp, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AnnouncementBarProps {
  className?: string;
}

const AnnouncementBar = ({ className }: AnnouncementBarProps) => {
  const { data: announcements, isLoading } = useAnnouncements();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);
  const navigate = useNavigate();

  // Rotate announcements every 5 seconds if multiple exist
  useEffect(() => {
    if (!announcements || announcements.length <= 1) return;

    const interval = setInterval(() => {
      setIsVisible(false);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % announcements.length);
        setIsVisible(true);
      }, 300); // Fade out duration
    }, 5000);

    return () => clearInterval(interval);
  }, [announcements]);

  if (isLoading || !announcements || announcements.length === 0) {
    return (
      <div className={cn('hidden lg:flex items-center justify-center px-4 py-2', className)}>
        <span className="text-sm text-muted-foreground">📊 Ingen notifikationer</span>
      </div>
    );
  }

  const currentAnnouncement = announcements[currentIndex];

  const priorityStyles = {
    success: 'bg-accent/10 text-accent-foreground border-accent/20',
    warning: 'bg-yellow-500/10 text-yellow-700 dark:text-yellow-500 border-yellow-500/20',
    error: 'bg-destructive/10 text-destructive border-destructive/20',
    info: 'bg-primary/10 text-primary border-primary/20',
  };

  const priorityIcons = {
    success: CheckCircle,
    warning: AlertCircle,
    error: AlertCircle,
    info: Info,
  };

  const Icon = priorityIcons[currentAnnouncement.priority];

  const handleClick = () => {
    if (currentAnnouncement.link_url) {
      navigate(currentAnnouncement.link_url);
    }
  };

  return (
    <div
      className={cn(
        'hidden lg:flex items-center gap-2 px-4 py-2 rounded-md border cursor-pointer transition-all duration-300 hover:scale-[1.02]',
        priorityStyles[currentAnnouncement.priority],
        !isVisible && 'opacity-0',
        isVisible && 'opacity-100',
        className
      )}
      onClick={handleClick}
    >
      <Icon className="h-4 w-4 flex-shrink-0" />
      <span className="text-sm font-medium flex-1 truncate">
        {currentAnnouncement.message}
      </span>
      {announcements.length > 1 && (
        <span className="text-xs opacity-70 flex-shrink-0">
          {currentIndex + 1}/{announcements.length}
        </span>
      )}
      {currentAnnouncement.link_url && (
        <ChevronRight className="h-4 w-4 flex-shrink-0" />
      )}
    </div>
  );
};

export default AnnouncementBar;
