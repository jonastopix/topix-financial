import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DDDocumentCategory, DDCategoryProgress, DDDocument, useUploadDDDocument, useUpdateCategoryProgress, DDDocumentType } from '@/hooks/useDueDiligence';
import { FileIcon, Upload, CheckCircle2, Clock, Circle, AlertCircle, Trash2, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

type DDCategoryStatus = 'not_started' | 'in_progress' | 'completed' | 'not_applicable';

interface DDCategoryItemProps {
  caseId: string;
  category: DDDocumentCategory;
  progress?: DDCategoryProgress;
  documents: DDDocument[];
}

export function DDCategoryItem({ caseId, category, progress, documents }: DDCategoryItemProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState<DDDocumentType>('other');
  const [notes, setNotes] = useState('');
  const [showExplanationDialog, setShowExplanationDialog] = useState(false);
  const [pendingStatus, setPendingStatus] = useState<DDCategoryStatus | null>(null);
  const [explanation, setExplanation] = useState('');
  const uploadMutation = useUploadDDDocument();
  const updateProgressMutation = useUpdateCategoryProgress();
  const { toast } = useToast();

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 20 * 1024 * 1024) {
        toast({
          title: 'Fil for stor',
          description: 'Filen må ikke være større end 20MB',
          variant: 'destructive',
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setIsUploading(true);
    try {
      await uploadMutation.mutateAsync({
        caseId,
        categoryId: category.id,
        file: selectedFile,
        documentType,
        notes: notes || undefined,
      });
      
      // Reset form
      setSelectedFile(null);
      setNotes('');
      setDocumentType('other');
    } finally {
      setIsUploading(false);
    }
  };

  const handleStatusChange = async (status: DDCategoryStatus) => {
    // If marking as completed or not_applicable without any documents, require explanation
    if ((status === 'completed' || status === 'not_applicable') && documents.length === 0) {
      setPendingStatus(status);
      setShowExplanationDialog(true);
      return;
    }
    
    await updateProgressMutation.mutateAsync({
      caseId,
      categoryId: category.id,
      status,
    });
  };

  const handleConfirmStatusWithExplanation = async () => {
    if (!pendingStatus || !explanation.trim()) return;
    
    await updateProgressMutation.mutateAsync({
      caseId,
      categoryId: category.id,
      status: pendingStatus,
      notes: explanation.trim(),
    });
    
    // Reset dialog state
    setShowExplanationDialog(false);
    setPendingStatus(null);
    setExplanation('');
  };

  const downloadDocument = async (doc: DDDocument) => {
    try {
      const { data, error } = await supabase.storage
        .from('company-documents')
        .download(doc.file_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.file_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: 'Download fejlede',
        description: 'Kunne ikke downloade filen',
        variant: 'destructive',
      });
    }
  };

  const getStatusIcon = () => {
    switch (progress?.status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'in_progress':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'not_applicable':
        return <AlertCircle className="h-4 w-4 text-muted-foreground" />;
      default:
        return <Circle className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = () => {
    switch (progress?.status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-500">Færdig</Badge>;
      case 'in_progress':
        return <Badge variant="secondary">I gang</Badge>;
      case 'not_applicable':
        return <Badge variant="outline">Ikke relevant</Badge>;
      default:
        return <Badge variant="outline">Ikke startet</Badge>;
    }
  };

  return (
    <Card className="bg-muted/30">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 flex-1">
            {getStatusIcon()}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <p className="font-medium text-sm">{category.category_code} - {category.category_name}</p>
                {category.required && (
                  <Badge variant="outline" className="text-xs">Påkrævet</Badge>
                )}
              </div>
              {category.description && (
                <p className="text-sm text-muted-foreground">{category.description}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            {getStatusBadge()}
            <Select
              value={progress?.status || 'not_started'}
              onValueChange={(value) => handleStatusChange(value as any)}
            >
              <SelectTrigger className="w-[140px] h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="not_started">Ikke startet</SelectItem>
                <SelectItem value="in_progress">I gang</SelectItem>
                <SelectItem value="completed">Færdig</SelectItem>
                <SelectItem value="not_applicable">Ikke relevant</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Document list */}
        {documents.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium">Uploadede dokumenter ({documents.length})</p>
            <div className="space-y-2">
              {documents.map(doc => (
                <div key={doc.id} className="flex items-center gap-3 p-3 rounded-lg border bg-card">
                  <FileIcon className="h-4 w-4 text-primary" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{doc.file_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(doc.uploaded_at).toLocaleDateString('da-DK')} • {(doc.file_size / 1024).toFixed(0)} KB
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => downloadDocument(doc)}
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Upload section */}
        <div className="space-y-3 pt-2 border-t">
          <div className="space-y-2">
            <label className="text-sm font-medium">Upload dokument</label>
            <div className="flex gap-2">
              <Input
                type="file"
                onChange={handleFileSelect}
                className="flex-1"
                disabled={isUploading}
              />
              <Select value={documentType} onValueChange={(value) => setDocumentType(value as DDDocumentType)}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="financial">Finansiel</SelectItem>
                  <SelectItem value="legal">Juridisk</SelectItem>
                  <SelectItem value="commercial">Kommerciel</SelectItem>
                  <SelectItem value="technical">Teknisk</SelectItem>
                  <SelectItem value="other">Andet</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {selectedFile && (
            <>
              <Textarea
                placeholder="Valgfri noter om dokumentet..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
              />
              <Button
                onClick={handleUpload}
                disabled={isUploading}
                className="w-full"
              >
                {isUploading ? (
                  <>Uploader...</>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload {selectedFile.name}
                  </>
                )}
              </Button>
            </>
          )}
        </div>

        {/* Explanation Dialog */}
        <Dialog open={showExplanationDialog} onOpenChange={setShowExplanationDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {pendingStatus === 'completed' ? 'Markér som færdig' : 'Markér som ikke relevant'}
              </DialogTitle>
              <DialogDescription>
                Du har ikke uploadet dokumenter til denne kategori. Forklar venligst hvorfor.
              </DialogDescription>
            </DialogHeader>
            <Textarea
              placeholder="Fx: Vi har ingen forsikringer, Dokumentet er under udarbejdelse..."
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              rows={3}
            />
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowExplanationDialog(false);
                  setPendingStatus(null);
                  setExplanation('');
                }}
              >
                Annuller
              </Button>
              <Button 
                onClick={handleConfirmStatusWithExplanation}
                disabled={!explanation.trim()}
              >
                Bekræft
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
