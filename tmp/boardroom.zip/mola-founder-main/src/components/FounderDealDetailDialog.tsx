import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { FounderDeal, useRedeemDeal } from "@/hooks/useFounderDeals";
import { Building2, Copy, ExternalLink, Mail, Calendar, Users, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FounderDealDetailDialogProps {
  deal: FounderDeal | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId?: string;
}

export function FounderDealDetailDialog({ deal, open, onOpenChange, companyId }: FounderDealDetailDialogProps) {
  const { toast } = useToast();
  const redeemMutation = useRedeemDeal();

  if (!deal) return null;

  const getDiscountLabel = () => {
    if (deal.discount_type === 'percentage' && deal.discount_value) {
      return `${deal.discount_value}% rabat`;
    } else if (deal.discount_type === 'fixed_amount' && deal.discount_value) {
      return `${deal.discount_value} kr. rabat`;
    } else if (deal.discount_type === 'trial_extension') {
      return 'Forlænget prøveperiode';
    }
    return 'Special tilbud';
  };

  const copyPromoCode = async () => {
    if (!deal.promo_code) return;
    
    await navigator.clipboard.writeText(deal.promo_code);
    
    if (companyId) {
      await redeemMutation.mutateAsync({
        dealId: deal.id,
        companyId,
      });
    } else {
      toast({
        title: "Kode kopieret",
        description: "Promo koden er kopieret til udklipsholderen.",
      });
    }
  };

  const isExpired = deal.valid_until && new Date(deal.valid_until) < new Date();
  const isFull = deal.max_redemptions && deal.current_redemptions >= deal.max_redemptions;
  const isUnavailable = isExpired || isFull;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <Avatar className="w-12 h-12 border-2 border-primary/10">
              <AvatarImage src={deal.companies?.logo_url || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-primary/20 to-primary/10">
                {deal.companies?.name.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="text-xl font-bold">{deal.title}</div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground font-normal mt-1">
                <Building2 className="w-4 h-4" />
                <span>{deal.companies?.name}</span>
              </div>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <Badge className="bg-gradient-to-r from-accent to-accent-glow text-base py-1.5 px-3">
              {getDiscountLabel()}
            </Badge>
            {deal.categories.map((cat) => (
              <Badge key={cat} variant="outline">
                {cat}
              </Badge>
            ))}
          </div>

          {deal.description && (
            <div>
              <h4 className="font-semibold mb-2">Om tilbuddet</h4>
              <p className="text-muted-foreground">{deal.description}</p>
            </div>
          )}

          {deal.terms && (
            <div className="bg-muted/50 rounded-lg p-4">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                Betingelser
              </h4>
              <p className="text-sm text-muted-foreground">{deal.terms}</p>
            </div>
          )}

          {deal.promo_code && (
            <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg p-6 border border-primary/20">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Promo kode</p>
                  <p className="text-2xl font-mono font-bold tracking-wider">{deal.promo_code}</p>
                </div>
                <Button 
                  onClick={copyPromoCode} 
                  disabled={isUnavailable || redeemMutation.isPending}
                  className="shadow-lg hover:shadow-glow-accent"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  {redeemMutation.isPending ? "Kopierer..." : "Kopier kode"}
                </Button>
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4 text-sm">
            {deal.current_redemptions > 0 && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Users className="w-4 h-4" />
                <span>{deal.current_redemptions} founders har anvendt</span>
              </div>
            )}
            
            {deal.valid_until && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Calendar className="w-4 h-4" />
                <span>Gyldig til {new Date(deal.valid_until).toLocaleDateString('da-DK')}</span>
              </div>
            )}

            {deal.contact_email && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" />
                <a href={`mailto:${deal.contact_email}`} className="hover:text-primary transition-colors">
                  {deal.contact_email}
                </a>
              </div>
            )}

            {deal.product_url && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <ExternalLink className="w-4 h-4" />
                <a 
                  href={deal.product_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="hover:text-primary transition-colors"
                >
                  Besøg website
                </a>
              </div>
            )}
          </div>

          {isUnavailable && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 text-center">
              <p className="text-destructive font-medium">
                {isExpired ? "Dette tilbud er udløbet" : "Dette tilbud er fuldt anvendt"}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
