import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon, Plus, Search } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { CompanyFormData, CompanyStatus } from '@/hooks/useCompanyManagement';
import { useFunds } from '@/hooks/useReturnsData';
import { useCVRLookup } from '@/hooks/useCVRLookup';
import { useRole } from '@/contexts/RoleContext';
import { cn } from '@/lib/utils';

interface CreateCompanyDialogProps {
  onSubmit: (data: CompanyFormData) => void;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function CreateCompanyDialog({ onSubmit, open: controlledOpen, onOpenChange }: CreateCompanyDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = onOpenChange || setInternalOpen;
  const { data: funds } = useFunds();
  const { lookupCVR, isLoading } = useCVRLookup();
  const { isAdmin } = useRole();
  const [formData, setFormData] = useState<CompanyFormData>({
    name: '',
    cvr: '',
    industry: 'other',
    logo_url: '',
    fund_id: '',
    invested_amount_dkk: undefined,
    equity_share_pct: undefined,
    invested_at: '',
    is_active: true,
    status: 'new_investment' as CompanyStatus,
  });
  
  // Separate state for date objects
  const [foundedDate, setFoundedDate] = useState<Date | undefined>(undefined);
  const [foundedDateOpen, setFoundedDateOpen] = useState(false);
  const [investedDate, setInvestedDate] = useState<Date | undefined>(undefined);
  const [investedDateOpen, setInvestedDateOpen] = useState(false);

  const handleCVRLookup = async () => {
    if (!formData.cvr) return;
    const { data } = await lookupCVR(formData.cvr);
    if (data) {
      setFormData({
        ...formData,
        name: data.name,
        founded_date: data.startdate,
        company_type: data.companytype, // This already sets the company type from CVR API
        industry: data.industrydesc || formData.industry,
        address: data.address,
        city: data.city,
        zipcode: data.zipcode,
        phone: data.phone,
        email: data.email,
      });
      // Update date picker if startdate is provided
      if (data.startdate) {
        setFoundedDate(new Date(data.startdate));
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Convert Date objects to ISO strings
    const cleanedData = {
      ...formData,
      invested_at: investedDate ? investedDate.toISOString().split('T')[0] : null,
      founded_date: foundedDate ? foundedDate.toISOString().split('T')[0] : null,
      company_type: formData.company_type || null,
      address: formData.address || null,
      city: formData.city || null,
      zipcode: formData.zipcode || null,
      phone: formData.phone || null,
      email: formData.email || null,
      logo_url: formData.logo_url || null,
      google_drive_url: formData.google_drive_url || null,
      fund_id: formData.fund_id || null,
      invested_amount_dkk: formData.invested_amount_dkk && !isNaN(formData.invested_amount_dkk) 
        ? formData.invested_amount_dkk 
        : null,
      equity_share_pct: formData.equity_share_pct && !isNaN(formData.equity_share_pct)
        ? formData.equity_share_pct
        : null,
    };
    
    onSubmit(cleanedData);
    setOpen(false);
    setFormData({
      name: '',
      cvr: '',
      industry: 'other',
      logo_url: '',
      fund_id: '',
      invested_amount_dkk: undefined,
      equity_share_pct: undefined,
      invested_at: '',
      is_active: true,
      status: 'new_investment' as CompanyStatus,
    });
    setFoundedDate(undefined);
    setInvestedDate(undefined);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Opret Selskab
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Opret Nyt Selskab</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0">
          <div className="flex-1 overflow-y-auto px-1">
            <div className="grid grid-cols-2 gap-4 pb-4">
              <div className="space-y-2">
                <Label htmlFor="name">Navn *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cvr">CVR Nummer</Label>
                <div className="flex gap-2">
                  <Input
                    id="cvr"
                    value={formData.cvr}
                    onChange={(e) => setFormData({ ...formData, cvr: e.target.value })}
                    placeholder="fx 12345678"
                    pattern="\d{8}"
                    maxLength={8}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCVRLookup}
                    disabled={!formData.cvr || !/^\d{8}$/.test(formData.cvr) || isLoading}
                  >
                    <Search className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="founded_date">Stiftelsesdato</Label>
                <Popover modal={true} open={foundedDateOpen} onOpenChange={setFoundedDateOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !foundedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {foundedDate ? format(foundedDate, "dd. MMM yyyy", { locale: da }) : <span>Vælg dato</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 z-50" align="start" side="bottom" sideOffset={5} avoidCollisions={false}>
                    <Calendar
                      mode="single"
                      selected={foundedDate}
                      onSelect={(date) => {
                        setFoundedDate(date);
                        setFoundedDateOpen(false);
                      }}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="company_type">Selskabsform</Label>
                <Input
                  id="company_type"
                  value={formData.company_type || ''}
                  onChange={(e) => setFormData({ ...formData, company_type: e.target.value })}
                  placeholder="fx ApS, A/S"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="industry">Industri</Label>
                <Select
                  value={formData.industry}
                  onValueChange={(value) => setFormData({ ...formData, industry: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="e-commerce">E-commerce</SelectItem>
                    <SelectItem value="saas">SaaS</SelectItem>
                    <SelectItem value="marketplace">Marketplace</SelectItem>
                    <SelectItem value="fintech">Fintech</SelectItem>
                    <SelectItem value="other">Andet</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({ ...formData, status: value as CompanyStatus })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="new_investment">🟡 Ny investering</SelectItem>
                    <SelectItem value="due_diligence">🔵 Due Diligence</SelectItem>
                    <SelectItem value="active">🟢 Aktiv</SelectItem>
                    <SelectItem value="exited">🎯 Solgt</SelectItem>
                    <SelectItem value="bankruptcy">🔴 Konkurs</SelectItem>
                    <SelectItem value="rejected">⚫ Afvist</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="fund">Fond</Label>
                <Select
                  value={formData.fund_id || undefined}
                  onValueChange={(value) => setFormData({ ...formData, fund_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg fond" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {funds?.map((fund) => (
                      <SelectItem key={fund.id} value={fund.id}>
                        {fund.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="invested_amount">Investeret Beløb (DKK)</Label>
                <Input
                  id="invested_amount"
                  type="number"
                  value={formData.invested_amount_dkk ?? ''}
                  onChange={(e) => setFormData({ ...formData, invested_amount_dkk: e.target.value ? parseFloat(e.target.value) : undefined })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="equity_share">Ejerandel (%)</Label>
                <Input
                  id="equity_share"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.equity_share_pct ?? ''}
                  onChange={(e) => setFormData({ ...formData, equity_share_pct: e.target.value ? parseFloat(e.target.value) : undefined })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="invested_at">Investerings Dato</Label>
                <Popover modal={true} open={investedDateOpen} onOpenChange={setInvestedDateOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !investedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {investedDate ? format(investedDate, "dd. MMM yyyy", { locale: da }) : <span>Vælg dato</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 z-50" align="start" side="bottom" sideOffset={5} avoidCollisions={false}>
                    <Calendar
                      mode="single"
                      selected={investedDate}
                      onSelect={(date) => {
                        setInvestedDate(date);
                        setInvestedDateOpen(false);
                      }}
                      initialFocus
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Adresse</Label>
                <Input
                  id="address"
                  value={formData.address || ''}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Vejnavn 1"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">By</Label>
                <Input
                  id="city"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder="København"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="zipcode">Postnummer</Label>
                <Input
                  id="zipcode"
                  value={formData.zipcode || ''}
                  onChange={(e) => setFormData({ ...formData, zipcode: e.target.value })}
                  placeholder="1234"
                  maxLength={4}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Telefon</Label>
                <Input
                  id="phone"
                  value={formData.phone || ''}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="+45 12345678"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email || ''}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="[email protected]"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo_url">Logo URL</Label>
                <Input
                  id="logo_url"
                  value={formData.logo_url}
                  onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                  placeholder="https://..."
                />
              </div>

              {isAdmin && (
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="google_drive_url">Google Drive URL (kun synlig for admins)</Label>
                  <Input
                    id="google_drive_url"
                    value={formData.google_drive_url || ''}
                    onChange={(e) => setFormData({ ...formData, google_drive_url: e.target.value })}
                    placeholder="https://drive.google.com/..."
                  />
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t bg-background">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuller
            </Button>
            <Button type="submit">Opret Selskab</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
