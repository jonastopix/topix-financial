import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

type Props = {
  companyId?: string;
  onSaved?: (reportId: string) => void;
};

function toNumberOrNull(v: string) {
  const t = v.trim();
  if (!t) return null;
  const n = Number(t.replace(/\./g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : null;
}

export default function BoardroomMonthlyReportForm({ companyId, onSaved }: Props) {
  const { toast } = useToast();
  const now = new Date();

  const [year, setYear] = useState(String(now.getFullYear()));
  const [month, setMonth] = useState(String(now.getMonth() + 1));

  const [revenue, setRevenue] = useState('');
  const [grossProfit, setGrossProfit] = useState('');
  const [payroll, setPayroll] = useState('');
  const [otherOpex, setOtherOpex] = useState('');
  const [resultBeforeTax, setResultBeforeTax] = useState('');
  const [notes, setNotes] = useState('');

  const [loading, setLoading] = useState(false);
  const [existingId, setExistingId] = useState<string | null>(null);

  const years = useMemo(() => Array.from({ length: 5 }).map((_, i) => now.getFullYear() - i), [now]);
  const months = useMemo(() => Array.from({ length: 12 }).map((_, i) => i + 1), []);

  const loadExisting = async () => {
    if (!companyId) return;

    const y = Number(year);
    const m = Number(month);

    const { data, error } = await supabase
      .from('monthly_reports')
      .select('id, revenue_dkk, gross_profit_dkk, payroll_dkk, other_opex_dkk, result_before_tax_dkk, note, status')
      .eq('company_id', companyId)
      .eq('period_year', y)
      .eq('period_month', m)
      .maybeSingle();

    if (error) throw error;

    if (!data) {
      setExistingId(null);
      setRevenue('');
      setGrossProfit('');
      setPayroll('');
      setOtherOpex('');
      setResultBeforeTax('');
      setNotes('');
      return;
    }

    setExistingId(data.id);
    setRevenue(data.revenue_dkk?.toString() ?? '');
    setGrossProfit(data.gross_profit_dkk?.toString() ?? '');
    setPayroll(data.payroll_dkk?.toString() ?? '');
    setOtherOpex(data.other_opex_dkk?.toString() ?? '');
    setResultBeforeTax(data.result_before_tax_dkk?.toString() ?? '');
    setNotes(data.note ?? '');
    onSaved?.(data.id);
  };

  useEffect(() => {
    loadExisting().catch(() => {
      // silent
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyId, year, month]);

  const upsert = async (status: 'draft' | 'submitted') => {
    if (!companyId) {
      toast({ title: 'Ingen virksomhed valgt', variant: 'destructive' });
      return;
    }

    const y = Number(year);
    const m = Number(month);
    if (!y || !m) {
      toast({ title: 'Vælg periode', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const payload: any = {
        company_id: companyId,
        period_year: y,
        period_month: m,
        revenue_dkk: toNumberOrNull(revenue),
        gross_profit_dkk: toNumberOrNull(grossProfit),
        payroll_dkk: toNumberOrNull(payroll),
        other_opex_dkk: toNumberOrNull(otherOpex),
        result_before_tax_dkk: toNumberOrNull(resultBeforeTax),
        note: notes?.trim() || null,
        status,
        submitted_at: status === 'submitted' ? new Date().toISOString() : null,
      };

      // Keep legacy required columns from earlier schema as safe fallbacks
      if (payload.revenue_dkk === null) payload.revenue_dkk = 0;
      if (payload.ebitda_dkk === undefined) payload.ebitda_dkk = 0;
      if (payload.cash_dkk === undefined) payload.cash_dkk = 0;
      if (payload.new_customers === undefined) payload.new_customers = 0;

      const { data, error } = await supabase
        .from('monthly_reports')
        .upsert(payload, { onConflict: 'company_id,period_month,period_year' })
        .select('id')
        .single();

      if (error) throw error;

      const id = data.id as string;
      setExistingId(id);
      onSaved?.(id);

      toast({ title: status === 'submitted' ? 'Rapport indsendt' : 'Kladde gemt' });
    } catch (e: any) {
      toast({ title: 'Kunne ikke gemme', description: e?.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Rapportér månedstal</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>År</Label>
            <Select value={year} onValueChange={setYear}>
              <SelectTrigger>
                <SelectValue placeholder="År" />
              </SelectTrigger>
              <SelectContent>
                {years.map((y) => (
                  <SelectItem key={y} value={String(y)}>
                    {y}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Måned</Label>
            <Select value={month} onValueChange={setMonth}>
              <SelectTrigger>
                <SelectValue placeholder="Måned" />
              </SelectTrigger>
              <SelectContent>
                {months.map((m) => (
                  <SelectItem key={m} value={String(m)}>
                    {String(m).padStart(2, '0')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Omsætning (DKK)</Label>
            <Input inputMode="decimal" value={revenue} onChange={(e) => setRevenue(e.target.value)} />
          </div>
          <div>
            <Label>DB / bruttoavance (DKK)</Label>
            <Input inputMode="decimal" value={grossProfit} onChange={(e) => setGrossProfit(e.target.value)} />
          </div>
          <div>
            <Label>Løn (DKK)</Label>
            <Input inputMode="decimal" value={payroll} onChange={(e) => setPayroll(e.target.value)} />
          </div>
          <div>
            <Label>Øvrige kapacitetsomk. (DKK)</Label>
            <Input inputMode="decimal" value={otherOpex} onChange={(e) => setOtherOpex(e.target.value)} />
          </div>
          <div className="md:col-span-2">
            <Label>Resultat før skat (DKK)</Label>
            <Input inputMode="decimal" value={resultBeforeTax} onChange={(e) => setResultBeforeTax(e.target.value)} />
          </div>
        </div>

        <div>
          <Label>Noter (valgfrit)</Label>
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Forklar afvigelser, engangsposter, udfordringer, fokus næste måned." />
        </div>

        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => upsert('draft')} disabled={loading || !companyId}>
            Gem kladde
          </Button>
          <Button onClick={() => upsert('submitted')} disabled={loading || !companyId}>
            Indsend
          </Button>
          {existingId && (
            <div className="text-sm text-muted-foreground flex items-center">
              Rapport-id: {existingId}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
