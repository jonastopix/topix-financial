import { useState } from 'react';
import { Trash2, Plus, ExternalLink, Star } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { useTrustpilotScores, useTrustpilotProfileManagement } from '@/hooks/useTrustpilotScores';
import { TRUSTPILOT_COUNTRIES, getCountryByCode } from '@/lib/trustpilotCountries';
import { cn } from '@/lib/utils';

interface ManageTrustpilotProfilesDialogProps {
  companyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ManageTrustpilotProfilesDialog({
  companyId,
  open,
  onOpenChange,
}: ManageTrustpilotProfilesDialogProps) {
  const { toast } = useToast();
  const { profiles, isLoading } = useTrustpilotScores(companyId);
  const { addProfile, deleteProfile, isAdding, isDeleting } = useTrustpilotProfileManagement(companyId);
  
  const [showAddForm, setShowAddForm] = useState(false);
  const [newCountryCode, setNewCountryCode] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newIsPrimary, setNewIsPrimary] = useState(false);
  const [urlError, setUrlError] = useState('');

  const validateUrl = (url: string): boolean => {
    if (!url) {
      setUrlError('URL er påkrævet');
      return false;
    }
    if (!url.startsWith('https://')) {
      setUrlError('URL skal starte med https://');
      return false;
    }
    if (!url.includes('trustpilot')) {
      setUrlError('URL skal være en Trustpilot-side');
      return false;
    }
    setUrlError('');
    return true;
  };

  const handleAddProfile = async () => {
    if (!newCountryCode) {
      toast({ title: 'Vælg et land', variant: 'destructive' });
      return;
    }
    if (!validateUrl(newUrl)) return;

    const country = getCountryByCode(newCountryCode);
    if (!country) return;

    try {
      await addProfile({
        countryCode: country.code,
        countryName: country.name,
        trustpilotUrl: newUrl,
        isPrimary: newIsPrimary,
      });
      
      toast({ title: 'Profil tilføjet' });
      setShowAddForm(false);
      setNewCountryCode('');
      setNewUrl('');
      setNewIsPrimary(false);
    } catch (error: any) {
      toast({ 
        title: 'Kunne ikke tilføje profil', 
        description: error.message,
        variant: 'destructive' 
      });
    }
  };

  const handleDeleteProfile = async (profileId: string) => {
    try {
      await deleteProfile(profileId);
      toast({ title: 'Profil slettet' });
    } catch (error: any) {
      toast({ 
        title: 'Kunne ikke slette profil', 
        description: error.message,
        variant: 'destructive' 
      });
    }
  };

  const handleCountryChange = (code: string) => {
    setNewCountryCode(code);
    // Auto-fill URL template based on country
    const country = getCountryByCode(code);
    if (country && !newUrl) {
      setNewUrl(`https://${country.domain}/review/`);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Star className="h-5 w-5 text-[#00b67a]" />
            Administrer Trustpilot-profiler
          </DialogTitle>
          <DialogDescription>
            Tilføj Trustpilot-sider for hvert land virksomheden er aktiv i.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Existing profiles */}
          {profiles.length > 0 && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Eksisterende profiler</Label>
              <div className="border rounded-lg divide-y">
                {profiles.map(profile => (
                  <div key={profile.id} className="flex items-center justify-between p-3">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      <span className="text-lg">{profile.countryFlag}</span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{profile.countryName}</span>
                          {profile.isPrimary && (
                            <span className="text-xs bg-primary/10 text-primary px-1.5 py-0.5 rounded">
                              Primær
                            </span>
                          )}
                        </div>
                        <a 
                          href={profile.trustpilotUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-xs text-muted-foreground hover:underline truncate block"
                        >
                          {profile.trustpilotUrl}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => window.open(profile.trustpilotUrl, '_blank')}
                      >
                        <ExternalLink size={14} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleDeleteProfile(profile.id)}
                        disabled={isDeleting}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add new profile form */}
          {showAddForm ? (
            <div className="border rounded-lg p-4 space-y-4">
              <Label className="text-sm font-medium">Tilføj ny profil</Label>
              
              <div className="space-y-2">
                <Label htmlFor="country">Land</Label>
                <Select value={newCountryCode} onValueChange={handleCountryChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg land" />
                  </SelectTrigger>
                  <SelectContent>
                    {TRUSTPILOT_COUNTRIES.map(country => (
                      <SelectItem key={country.code} value={country.code}>
                        <span className="flex items-center gap-2">
                          <span>{country.flag}</span>
                          <span>{country.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="url">Trustpilot URL</Label>
                <Input
                  id="url"
                  placeholder="https://dk.trustpilot.com/review/example.dk"
                  value={newUrl}
                  onChange={(e) => {
                    setNewUrl(e.target.value);
                    if (urlError) validateUrl(e.target.value);
                  }}
                  className={cn(urlError && 'border-destructive')}
                />
                {urlError && (
                  <p className="text-xs text-destructive">{urlError}</p>
                )}
                <p className="text-xs text-muted-foreground">
                  Kopiér URL'en fra virksomhedens Trustpilot-side
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="isPrimary"
                  checked={newIsPrimary}
                  onCheckedChange={(checked) => setNewIsPrimary(!!checked)}
                />
                <Label htmlFor="isPrimary" className="text-sm font-normal cursor-pointer">
                  Markér som primær profil
                </Label>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddForm(false);
                    setNewCountryCode('');
                    setNewUrl('');
                    setNewIsPrimary(false);
                    setUrlError('');
                  }}
                >
                  Annuller
                </Button>
                <Button onClick={handleAddProfile} disabled={isAdding}>
                  {isAdding ? 'Tilføjer...' : 'Tilføj profil'}
                </Button>
              </div>
            </div>
          ) : (
            <Button
              variant="outline"
              onClick={() => setShowAddForm(true)}
              className="w-full"
            >
              <Plus size={14} className="mr-1" />
              Tilføj Trustpilot-profil
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
