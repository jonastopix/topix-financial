import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Calendar, Link2, Info, CheckCircle } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

export function CalendlySettings() {
  const [calendlyLink, setCalendlyLink] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const { data: profile, refetch } = useQuery({
    queryKey: ['profile-calendly'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('profiles')
        .select('calendly_link, full_name')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      
      if (data.calendly_link) {
        setCalendlyLink(data.calendly_link);
      }
      
      return data;
    }
  });

  const handleSave = async () => {
    if (!calendlyLink) {
      toast.error('Indtast venligst et Calendly link');
      return;
    }

    if (!calendlyLink.includes('calendly.com/')) {
      toast.error('Indtast venligst et gyldigt Calendly link');
      return;
    }

    setIsSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('profiles')
        .update({ calendly_link: calendlyLink })
        .eq('id', user.id);

      if (error) throw error;
      
      toast.success('Calendly link gemt');
      refetch();
    } catch (error) {
      console.error('Error saving Calendly link:', error);
      toast.error('Kunne ikke gemme Calendly link');
    } finally {
      setIsSaving(false);
    }
  };

  const webhookUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/calendly-webhook`;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Calendly Integration
        </CardTitle>
        <CardDescription>
          Konfigurer din Calendly integration for automatisk mødeBooking
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="calendly-link">Dit Calendly Booking Link</Label>
          <div className="flex gap-2">
            <Input
              id="calendly-link"
              type="url"
              placeholder="https://calendly.com/dit-navn/30min"
              value={calendlyLink}
              onChange={(e) => setCalendlyLink(e.target.value)}
            />
            <Button onClick={handleSave} disabled={isSaving}>
              <Link2 className="h-4 w-4 mr-2" />
              Gem
            </Button>
          </div>
          {profile?.calendly_link && (
            <p className="text-sm text-green-600 flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Calendly link er konfigureret
            </p>
          )}
        </div>

        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-3 mt-2">
              <p className="font-medium">Webhook Setup (Påkrævet):</p>
              <ol className="list-decimal list-inside space-y-2 text-sm">
                <li>Log ind på <a href="https://calendly.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Calendly.com</a></li>
                <li>Gå til Settings → Webhooks</li>
                <li>Klik "Add Webhook"</li>
                <li className="break-all">
                  <strong>Webhook URL:</strong>
                  <code className="block mt-1 bg-muted p-2 rounded text-xs">
                    {webhookUrl}
                  </code>
                </li>
                <li>
                  <strong>Vælg Events:</strong>
                  <ul className="list-disc list-inside ml-4 mt-1">
                    <li>✅ Invitee Created</li>
                    <li>✅ Invitee Rescheduled</li>
                    <li>✅ Invitee Canceled</li>
                  </ul>
                </li>
                <li>Klik "Save"</li>
              </ol>

              <div className="mt-4 pt-4 border-t">
                <p className="text-sm text-muted-foreground">
                  💡 Når webhooken er sat op, vil systemet automatisk:
                </p>
                <ul className="list-disc list-inside ml-4 text-sm text-muted-foreground">
                  <li>Oprette møder i portalen når founders booker</li>
                  <li>Invitere relevante deltagere automatisk</li>
                  <li>Håndtere reschedules og cancellations</li>
                  <li>Sende calendar invites til alle deltagere</li>
                </ul>
              </div>
            </div>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
