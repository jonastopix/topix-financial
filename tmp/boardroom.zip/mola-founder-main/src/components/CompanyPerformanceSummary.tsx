import { Card } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { formatCurrency, formatPercentage } from '@/lib/formatters';
import { calculateYTD, calculateYOY, getLatestMonth } from '@/lib/metricsCalculations';

interface CompanyPerformanceSummaryProps {
  reports: any[];
}

export function CompanyPerformanceSummary({ reports }: CompanyPerformanceSummaryProps) {
  const currentYear = new Date().getFullYear();
  const ytd = calculateYTD(reports, currentYear);
  const yoy = calculateYOY(reports, currentYear);
  const latestMonth = getLatestMonth(reports);

  if (!reports || reports.length === 0) {
    return null;
  }

  // Calculate KPIs
  const ebitdaMargin = ytd.revenue > 0 ? (ytd.ebitda / ytd.revenue) * 100 : 0;
  
  // Calculate marketing percentage from reports
  const ytdMarketingCost = reports
    .filter(r => r.period_year === currentYear)
    .reduce((sum, r) => sum + (r.marketing_cost_dkk || 0), 0);
  const marketingPct = ytd.revenue > 0 && ytdMarketingCost > 0 ? (ytdMarketingCost / ytd.revenue) * 100 : 0;
  
  // Calculate salary percentage from reports
  const ytdSalaryCost = reports
    .filter(r => r.period_year === currentYear)
    .reduce((sum, r) => sum + (r.salary_cost_dkk || 0), 0);
  const salaryPct = ytd.revenue > 0 && ytdSalaryCost > 0 ? (ytdSalaryCost / ytd.revenue) * 100 : 0;
  
  const yoyGrowth = yoy.revenueGrowth;

  // Helper to get status color for EBITDA margin
  const getMarginStatus = (margin: number) => {
    if (margin >= 10) return { color: 'text-success', bars: 5 };
    if (margin >= 5) return { color: 'text-warning', bars: 3 };
    return { color: 'text-destructive', bars: 1 };
  };

  const marginStatus = getMarginStatus(ebitdaMargin);

  // Helper to get bars for metrics
  const renderBars = (count: number, total: number = 5) => (
    <div className="flex gap-1 mt-1">
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "h-1 w-4 rounded-full",
            i < count ? "bg-current" : "bg-muted"
          )}
        />
      ))}
    </div>
  );

  return (
    <Card className="p-6 glass-card">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">📊 Performance Oversigt</h2>
        <span className="text-muted-foreground">{currentYear}</span>
      </div>

      {/* Main metrics grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* YTD Revenue */}
        <Card className="p-4 border-primary/20 hover-lift">
          <p className="text-sm text-muted-foreground mb-2">YTD Omsætning</p>
          <p className="text-xl lg:text-2xl font-bold mb-2 truncate">{formatCurrency(ytd.revenue)}</p>
          {yoy.revenueGrowth !== 0 && (
            <div className="flex items-center gap-1 text-sm">
              {yoy.revenueGrowth > 0 ? (
                <TrendingUp className="h-4 w-4 text-success" />
              ) : (
                <TrendingDown className="h-4 w-4 text-destructive" />
              )}
              <span className={cn(
                "font-medium",
                yoy.revenueGrowth > 0 ? "text-success" : "text-destructive"
              )}>
                {yoy.revenueGrowth > 0 ? '+' : ''}{formatPercentage(yoy.revenueGrowth, 1)} vs {currentYear - 1}
              </span>
            </div>
          )}
        </Card>

        {/* YTD EBITDA */}
        <Card className="p-4 border-primary/20 hover-lift">
          <p className="text-sm text-muted-foreground mb-2">YTD EBITDA</p>
          <p className="text-xl lg:text-2xl font-bold mb-2 truncate">{formatCurrency(ytd.ebitda)}</p>
          {yoy.ebitdaGrowth !== 0 && (
            <div className="flex items-center gap-1 text-sm">
              {yoy.ebitdaGrowth > 0 ? (
                <TrendingUp className="h-4 w-4 text-success" />
              ) : (
                <TrendingDown className="h-4 w-4 text-destructive" />
              )}
              <span className={cn(
                "font-medium",
                yoy.ebitdaGrowth > 0 ? "text-success" : "text-destructive"
              )}>
                {yoy.ebitdaGrowth > 0 ? '+' : ''}{formatPercentage(yoy.ebitdaGrowth, 1)} vs {currentYear - 1}
              </span>
            </div>
          )}
        </Card>

        {/* Latest Month */}
        <Card className="p-4 border-primary/20 hover-lift">
          <p className="text-sm text-muted-foreground mb-2">Seneste Måned</p>
          {latestMonth.revenue > 0 ? (
            <>
              <p className="text-sm font-medium mb-1">
                {new Date(latestMonth.year, latestMonth.month - 1).toLocaleDateString('da-DK', { month: 'long', year: 'numeric' })}
              </p>
              <p className="text-lg lg:text-xl font-bold truncate">{formatCurrency(latestMonth.revenue)}</p>
              {latestMonth.revenueChange !== 0 && (
                <p className={cn(
                  "text-sm",
                  latestMonth.revenueChange > 0 ? "text-success" : "text-destructive"
                )}>
                  ({latestMonth.revenueChange > 0 ? '+' : ''}{formatPercentage(latestMonth.revenueChange, 1)})
                </p>
              )}
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Ingen data</p>
          )}
        </Card>
      </div>

      {/* KPI Grid */}
      <Card className="p-4 bg-muted/30">
        <h3 className="text-lg font-semibold mb-4">Nøgletal</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* EBITDA Margin */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    <p className="text-sm text-muted-foreground">EBITDA Margin</p>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </div>
                  <p className={cn("text-xl lg:text-2xl font-bold truncate", marginStatus.color)}>
                    {formatPercentage(ebitdaMargin, 1)}
                  </p>
                  <div className={marginStatus.color}>
                    {renderBars(marginStatus.bars)}
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>EBITDA / Omsætning</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Grøn: ≥10% | Gul: 5-10% | Rød: &lt;5%
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Marketing % */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    <p className="text-sm text-muted-foreground">Marketing %</p>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </div>
                  {ytdMarketingCost > 0 ? (
                    <>
                      <p className="text-xl lg:text-2xl font-bold truncate">
                        {formatPercentage(marketingPct, 1)}
                      </p>
                      {renderBars(Math.min(5, Math.ceil(marketingPct / 5)))}
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">Ingen data</p>
                  )}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Marketing omkostninger / Omsætning</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* Løn % */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    <p className="text-sm text-muted-foreground">Løn %</p>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </div>
                  {ytdSalaryCost > 0 ? (
                    <>
                      <p className="text-xl lg:text-2xl font-bold truncate">
                        {formatPercentage(salaryPct, 1)}
                      </p>
                      {renderBars(Math.min(5, Math.ceil(salaryPct / 15)))}
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground">Ingen data</p>
                  )}
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Lønomkostninger / Omsætning</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          {/* YoY Growth */}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="space-y-2">
                  <div className="flex items-center gap-1">
                    <p className="text-sm text-muted-foreground">YoY Vækst</p>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </div>
                  <p className={cn(
                    "text-xl lg:text-2xl font-bold truncate",
                    yoyGrowth > 0 ? "text-success" : yoyGrowth < 0 ? "text-destructive" : ""
                  )}>
                    {yoyGrowth > 0 ? '+' : ''}{formatPercentage(yoyGrowth, 1)}
                  </p>
                  <div className={yoyGrowth > 0 ? "text-success" : "text-muted-foreground"}>
                    {renderBars(Math.min(5, Math.max(1, Math.ceil(Math.abs(yoyGrowth) / 10))))}
                  </div>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                <p>Omsætningsvækst vs. samme periode sidste år</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </Card>
    </Card>
  );
}
