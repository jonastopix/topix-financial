import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useInvitations } from '@/hooks/useInvitations';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface InviteUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function InviteUserDialog({ open, onOpenChange }: InviteUserDialogProps) {
  const { inviteUser, isInviting } = useInvitations();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('');
  const [companyId, setCompanyId] = useState('');
  const [fundId, setFundId] = useState('');
  const [notes, setNotes] = useState('');

  const { data: companies } = useQuery({
    queryKey: ['companies-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  const { data: funds } = useQuery({
    queryKey: ['funds-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    inviteUser({
      email,
      role,
      companyId: companyId || undefined,
      fundId: fundId || undefined,
      notes: notes || undefined,
    }, {
      onSuccess: () => {
        setEmail('');
        setRole('');
        setCompanyId('');
        setFundId('');
        setNotes('');
        onOpenChange(false);
      },
    });
  };

  const roleRequiresCompany = role === 'founder' || role === 'investor';
  const roleRequiresFund = role === 'fund_partner';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Inviter bruger</DialogTitle>
          <DialogDescription>
            Send en invitation til en ny bruger. De vil modtage en email med instruktioner til at sætte deres password.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="bruger@email.dk"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Rolle *</Label>
            <Select value={role} onValueChange={setRole} required>
              <SelectTrigger>
                <SelectValue placeholder="Vælg rolle" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="founder">Founder</SelectItem>
                <SelectItem value="fund_partner">Fund Partner</SelectItem>
                <SelectItem value="investor">Investor</SelectItem>
                <SelectItem value="mola_admin">MOLA Admin</SelectItem>
                <SelectItem value="dd_partner">DD Partner</SelectItem>
                <SelectItem value="external_viewer">External Viewer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {roleRequiresCompany && (
            <div className="space-y-2">
              <Label htmlFor="company">Virksomhed *</Label>
              <Select value={companyId} onValueChange={setCompanyId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Vælg virksomhed" />
                </SelectTrigger>
                <SelectContent>
                  {companies?.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {roleRequiresFund && (
            <div className="space-y-2">
              <Label htmlFor="fund">Fond *</Label>
              <Select value={fundId} onValueChange={setFundId} required>
                <SelectTrigger>
                  <SelectValue placeholder="Vælg fond" />
                </SelectTrigger>
                <SelectContent>
                  {funds?.map((fund) => (
                    <SelectItem key={fund.id} value={fund.id}>
                      {fund.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Notater</Label>
            <Textarea
              id="notes"
              placeholder="Valgfrie notater om invitationen..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isInviting}
            >
              Annuller
            </Button>
            <Button type="submit" disabled={isInviting}>
              {isInviting ? 'Sender...' : 'Send invitation'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}