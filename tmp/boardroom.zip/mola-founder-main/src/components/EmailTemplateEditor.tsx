import { useState, useEffect } from 'react';
import { useEmailTemplate, useEmailTemplateMutations } from '@/hooks/useEmailTemplates';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Save, Eye, Send, X } from 'lucide-react';
import { EmailTemplatePreview } from '@/components/EmailTemplatePreview';
import { SendTestEmailDialog } from '@/components/SendTestEmailDialog';
import { Badge } from '@/components/ui/badge';

interface EmailTemplateEditorProps {
  templateId?: string;
  onClose: () => void;
}

export function EmailTemplateEditor({ templateId, onClose }: EmailTemplateEditorProps) {
  const { data: template } = useEmailTemplate(templateId || '');
  const { updateTemplate, createTemplate } = useEmailTemplateMutations();
  const [showTestDialog, setShowTestDialog] = useState(false);

  const [formData, setFormData] = useState({
    template_key: '',
    template_name: '',
    subject: '',
    html_body: '',
    text_body: '',
    from_name: 'MOLA Portal',
    from_email: 'noreply@founder.molainvest.dk',
    available_variables: [] as string[],
    is_active: true,
  });

  const [newVariable, setNewVariable] = useState('');

  useEffect(() => {
    if (template) {
      setFormData({
        template_key: template.template_key,
        template_name: template.template_name,
        subject: template.subject,
        html_body: template.html_body,
        text_body: template.text_body || '',
        from_name: template.from_name,
        from_email: template.from_email,
        available_variables: template.available_variables,
        is_active: template.is_active,
      });
    }
  }, [template]);

  const handleSave = () => {
    if (templateId) {
      updateTemplate.mutate({ ...formData, id: templateId });
    } else {
      createTemplate.mutate(formData);
    }
    onClose();
  };

  const addVariable = () => {
    if (newVariable && !formData.available_variables.includes(newVariable)) {
      setFormData({
        ...formData,
        available_variables: [...formData.available_variables, newVariable],
      });
      setNewVariable('');
    }
  };

  const removeVariable = (variable: string) => {
    setFormData({
      ...formData,
      available_variables: formData.available_variables.filter(v => v !== variable),
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Label>Aktiv</Label>
          <Switch
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
          />
        </div>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="content">Indhold</TabsTrigger>
          <TabsTrigger value="settings">Indstillinger</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="subject">Emne</Label>
            <Input
              id="subject"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="Email emne..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="html_body">HTML Body</Label>
            <Textarea
              id="html_body"
              value={formData.html_body}
              onChange={(e) => setFormData({ ...formData, html_body: e.target.value })}
              placeholder="HTML email indhold..."
              className="font-mono text-sm min-h-[300px]"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="text_body">Text Body (valgfrit)</Label>
            <Textarea
              id="text_body"
              value={formData.text_body}
              onChange={(e) => setFormData({ ...formData, text_body: e.target.value })}
              placeholder="Plain text fallback..."
              className="min-h-[100px]"
            />
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="template_key">Template Key</Label>
            <Input
              id="template_key"
              value={formData.template_key}
              onChange={(e) => setFormData({ ...formData, template_key: e.target.value })}
              placeholder="template_key"
              disabled={!!templateId}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="template_name">Template Navn</Label>
            <Input
              id="template_name"
              value={formData.template_name}
              onChange={(e) => setFormData({ ...formData, template_name: e.target.value })}
              placeholder="Brugervenligt navn..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="from_name">Fra Navn</Label>
              <Input
                id="from_name"
                value={formData.from_name}
                onChange={(e) => setFormData({ ...formData, from_name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="from_email">Fra Email</Label>
              <Input
                id="from_email"
                value={formData.from_email}
                onChange={(e) => setFormData({ ...formData, from_email: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Tilgængelige Variabler</Label>
            <div className="flex gap-2">
              <Input
                value={newVariable}
                onChange={(e) => setNewVariable(e.target.value)}
                placeholder="variabel_navn"
                onKeyDown={(e) => e.key === 'Enter' && addVariable()}
              />
              <Button onClick={addVariable} type="button">Tilføj</Button>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.available_variables.map((variable) => (
                <Badge
                  key={variable}
                  variant="secondary"
                  className="cursor-pointer"
                  onClick={() => removeVariable(variable)}
                >
                  {`{{${variable}}}`}
                  <X className="w-3 h-3 ml-1" />
                </Badge>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="preview">
          <EmailTemplatePreview
            htmlBody={formData.html_body}
            variables={formData.available_variables}
          />
        </TabsContent>
      </Tabs>

      <div className="flex gap-2 pt-4">
        <Button onClick={handleSave} className="gap-2">
          <Save className="w-4 h-4" />
          Gem Template
        </Button>
        {templateId && (
          <Button variant="outline" onClick={() => setShowTestDialog(true)} className="gap-2">
            <Send className="w-4 h-4" />
            Send Test Email
          </Button>
        )}
      </div>

      {templateId && (
        <SendTestEmailDialog
          open={showTestDialog}
          onOpenChange={setShowTestDialog}
          templateId={templateId}
          templateName={formData.template_name}
        />
      )}
    </div>
  );
}
