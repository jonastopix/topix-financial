import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useCompanyDocuments, DocumentType } from '@/hooks/useCompanyDocuments';
import { useRole } from '@/contexts/RoleContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Upload, FileText } from 'lucide-react';
import DocumentUploadDialog from './DocumentUploadDialog';
import DocumentCard from './DocumentCard';
import DocumentChecklist from './DocumentChecklist';

interface CompanyDocumentsViewProps {
  companyId: string;
}

const CompanyDocumentsView = ({ companyId }: CompanyDocumentsViewProps) => {
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [preselectedDocType, setPreselectedDocType] = useState<DocumentType | undefined>();
  const { documents, isLoading, deleteDocument, downloadDocument } = useCompanyDocuments(companyId);
  const { isAdmin } = useRole();

  // Fetch company to get has_board status
  const { data: company } = useQuery({
    queryKey: ['company-has-board', companyId],
    queryFn: async () => {
      const { data } = await supabase
        .from('companies')
        .select('has_board')
        .eq('id', companyId)
        .single();
      return data;
    },
  });

  const hasBoard = company?.has_board ?? false;

  const handleUploadClick = (docType?: DocumentType) => {
    setPreselectedDocType(docType);
    setUploadDialogOpen(true);
  };

  const documentsByType = documents?.reduce((acc, doc) => {
    if (!acc[doc.document_type]) {
      acc[doc.document_type] = [];
    }
    acc[doc.document_type].push(doc);
    return acc;
  }, {} as Record<DocumentType, typeof documents>);

  // Build document type labels based on whether company has a board
  const documentTypeLabels: Partial<Record<DocumentType, string>> = {
    shareholder_agreement: '📜 Ejeraftale',
    articles_of_association: '📋 Vedtægter',
    annual_report: '📊 Årsrapport',
    ...(hasBoard && { board_minutes: '📝 Bestyrelsesprotokol' }),
    investment_memo: '💼 Investeringsmemo',
    term_sheet: '📄 Term Sheet',
    valuation_report: '💰 Værdiansættelse',
    other: '📎 Andet',
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Dokumenter</h2>
          <p className="text-muted-foreground">
            {documents?.length || 0} dokumenter uploadet
          </p>
        </div>
        {isAdmin && (
          <Button onClick={() => handleUploadClick()}>
            <Upload className="h-4 w-4 mr-2" />
            Upload Dokument
          </Button>
        )}
      </div>

      {isAdmin && (
        <DocumentChecklist 
          companyId={companyId}
          hasBoard={hasBoard}
          onUploadClick={handleUploadClick}
        />
      )}

      {!documents || documents.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FileText className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Ingen dokumenter endnu</p>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Upload din første ejeraftale, vedtægter eller andre vigtige dokumenter.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.entries(documentsByType || {}).filter(([type]) => {
            // Filter out board_minutes if company doesn't have a board
            if (!hasBoard && type === 'board_minutes') return false;
            return true;
          }).map(([type, docs]) => (
            <Card key={type}>
              <CardHeader>
                <CardTitle className="text-lg">
                  {documentTypeLabels[type as DocumentType] || type}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {docs.map((doc) => (
                    <DocumentCard
                      key={doc.id}
                      document={doc}
                      onDownload={() => downloadDocument(doc.file_path, doc.file_name)}
                      onDelete={
                        isAdmin
                          ? () => deleteDocument.mutate(doc.id)
                          : undefined
                      }
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <DocumentUploadDialog
        open={uploadDialogOpen}
        onOpenChange={(open) => {
          setUploadDialogOpen(open);
          if (!open) setPreselectedDocType(undefined);
        }}
        companyId={companyId}
        preselectedDocType={preselectedDocType}
        hasBoard={hasBoard}
      />
    </div>
  );
};

export default CompanyDocumentsView;
