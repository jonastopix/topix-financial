import { CheckCircle2 } from 'lucide-react';
import { OnboardingStep as OnboardingStepType } from '@/config/onboardingSteps';

interface OnboardingStepProps {
  step: OnboardingStepType;
}

export function OnboardingStepContent({ step }: OnboardingStepProps) {
  const isContentArray = Array.isArray(step.content);

  return (
    <div className="space-y-6 text-center">
      <h2 className="text-2xl md:text-3xl font-bold text-foreground leading-tight">
        {step.title}
      </h2>

      {isContentArray ? (
        <div className="space-y-4">
          <ul className="space-y-3 text-left max-w-sm mx-auto">
            {(step.content as string[]).map((item, index) => (
              <li key={index} className="flex items-start gap-3 text-muted-foreground">
                <CheckCircle2 className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-base">{item}</span>
              </li>
            ))}
          </ul>
          {step.footer && (
            <p className="text-base text-foreground font-medium pt-2">
              {step.footer}
            </p>
          )}
        </div>
      ) : (
        <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-md mx-auto">
          {step.content}
        </p>
      )}
    </div>
  );
}
