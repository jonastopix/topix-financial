import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { formatCurrency, formatCompact } from '@/lib/formatters';
import { useIsMobile } from '@/hooks/use-mobile';

interface PortfolioTrendChartProps {
  data: Array<{
    period: string;
    period_year: number;
    period_month: number;
    revenue: number;
    ebitda: number;
    margin: number;
  }>;
}

export function PortfolioTrendChart({ data }: PortfolioTrendChartProps) {
  const isMobile = useIsMobile();
  const chartHeight = isMobile ? 280 : 400;

  if (!data || data.length === 0) {
    return (
      <Card className="p-4 sm:p-6">
        <h3 className="text-lg font-semibold mb-4">Portfolio Udvikling</h3>
        <p className="text-center text-muted-foreground py-8">
          Ingen historiske data tilgængelig
        </p>
      </Card>
    );
  }

  const formatCurrencyValue = (value: number) => {
    const millions = value / 1000000;
    return `${millions.toFixed(1)}M kr`;
  };

  const formatMargin = (value: number) => `${value.toFixed(1)}%`;

  return (
    <Card className="p-4 sm:p-6">
      <h3 className="text-lg font-semibold mb-4">Portfolio Udvikling - Sidste 12 Måneder</h3>
      
      <Tabs defaultValue="revenue" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-3">
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="ebitda">EBITDA</TabsTrigger>
          <TabsTrigger value="margin">Margin</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="mt-6">
          <ResponsiveContainer width="100%" height={chartHeight}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="period" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
              />
              <YAxis 
                tickFormatter={formatCurrencyValue}
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
                width={isMobile ? 50 : 60}
              />
              <Tooltip 
                formatter={(value: number) => [formatCurrency(value, 0), 'Revenue']}
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                name="Revenue"
                dot={{ fill: 'hsl(var(--primary))' }}
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 text-center">
            <div>
              <p className="text-sm text-muted-foreground">Gennemsnit</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(data.reduce((sum, d) => sum + d.revenue, 0) / data.length) : formatCurrency(data.reduce((sum, d) => sum + d.revenue, 0) / data.length, 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Højeste</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(Math.max(...data.map(d => d.revenue))) : formatCurrency(Math.max(...data.map(d => d.revenue)), 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Laveste</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(Math.min(...data.map(d => d.revenue))) : formatCurrency(Math.min(...data.map(d => d.revenue)), 0)}
              </p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="ebitda" className="mt-6">
          <ResponsiveContainer width="100%" height={chartHeight}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="period" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
              />
              <YAxis 
                tickFormatter={formatCurrencyValue}
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
                width={isMobile ? 50 : 60}
              />
              <Tooltip 
                formatter={(value: number) => [formatCurrency(value, 0), 'EBITDA']}
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="ebitda" 
                stroke="hsl(var(--chart-2))" 
                strokeWidth={2}
                name="EBITDA"
                dot={{ fill: 'hsl(var(--chart-2))' }}
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 text-center">
            <div>
              <p className="text-sm text-muted-foreground">Gennemsnit</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(data.reduce((sum, d) => sum + d.ebitda, 0) / data.length) : formatCurrency(data.reduce((sum, d) => sum + d.ebitda, 0) / data.length, 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Højeste</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(Math.max(...data.map(d => d.ebitda))) : formatCurrency(Math.max(...data.map(d => d.ebitda)), 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Laveste</p>
              <p className="text-base sm:text-lg font-semibold truncate">
                {isMobile ? formatCompact(Math.min(...data.map(d => d.ebitda))) : formatCurrency(Math.min(...data.map(d => d.ebitda)), 0)}
              </p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="margin" className="mt-6">
          <ResponsiveContainer width="100%" height={chartHeight}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="period" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
              />
              <YAxis 
                tickFormatter={formatMargin}
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: isMobile ? 10 : 12 }}
                width={isMobile ? 50 : 60}
              />
              <Tooltip 
                formatter={(value: number) => [`${value.toFixed(1)}%`, 'EBITDA Margin']}
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="margin" 
                stroke="hsl(var(--chart-3))" 
                strokeWidth={2}
                name="EBITDA Margin"
                dot={{ fill: 'hsl(var(--chart-3))' }}
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 text-center">
            <div>
              <p className="text-sm text-muted-foreground">Gennemsnit</p>
              <p className="text-base sm:text-lg font-semibold">
                {(data.reduce((sum, d) => sum + d.margin, 0) / data.length).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Højeste</p>
              <p className="text-base sm:text-lg font-semibold">
                {Math.max(...data.map(d => d.margin)).toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Laveste</p>
              <p className="text-base sm:text-lg font-semibold">
                {Math.min(...data.map(d => d.margin)).toFixed(1)}%
              </p>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
