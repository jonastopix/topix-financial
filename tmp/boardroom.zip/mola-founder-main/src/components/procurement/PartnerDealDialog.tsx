import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useUpsertPartnerDeal } from "@/hooks/useProcurementAdmin";

interface PartnerDealDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  deal?: any;
}

export const PartnerDealDialog = ({ open, onOpenChange, deal }: PartnerDealDialogProps) => {
  const [formData, setFormData] = useState({
    category: '',
    vendor: '',
    plan_name: '',
    mola_price: '',
    list_price: '',
    unit: '',
    terms: '',
    contact_email: '',
    activation_url: '',
    is_active: true,
  });

  const upsertDeal = useUpsertPartnerDeal();

  useEffect(() => {
    if (deal) {
      setFormData({
        category: deal.category,
        vendor: deal.vendor,
        plan_name: deal.plan_name,
        mola_price: deal.mola_price.toString(),
        list_price: deal.list_price.toString(),
        unit: deal.unit,
        terms: deal.terms,
        contact_email: deal.contact_email,
        activation_url: deal.activation_url || '',
        is_active: deal.is_active,
      });
    } else {
      setFormData({
        category: '',
        vendor: '',
        plan_name: '',
        mola_price: '',
        list_price: '',
        unit: '',
        terms: '',
        contact_email: '',
        activation_url: '',
        is_active: true,
      });
    }
  }, [deal, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const dealData: any = {
      ...formData,
      mola_price: parseFloat(formData.mola_price),
      list_price: parseFloat(formData.list_price),
      activation_url: formData.activation_url || null,
    };

    if (deal?.id) {
      dealData.id = deal.id;
    }

    await upsertDeal.mutateAsync(dealData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{deal ? 'Rediger Partneraftale' : 'Ny Partneraftale'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="category">Kategori *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Vælg kategori" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="shipping">Fragt</SelectItem>
                  <SelectItem value="payment">Betaling</SelectItem>
                  <SelectItem value="saas">SaaS</SelectItem>
                  <SelectItem value="tele">Tele</SelectItem>
                  <SelectItem value="energy">Energi</SelectItem>
                  <SelectItem value="insurance">Forsikring</SelectItem>
                  <SelectItem value="packaging">Emballage</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="vendor">Leverandør *</Label>
              <Input
                id="vendor"
                value={formData.vendor}
                onChange={(e) => setFormData({ ...formData, vendor: e.target.value })}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="plan_name">Plan navn *</Label>
            <Input
              id="plan_name"
              value={formData.plan_name}
              onChange={(e) => setFormData({ ...formData, plan_name: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="mola_price">MOLA pris *</Label>
              <Input
                id="mola_price"
                type="number"
                step="0.01"
                value={formData.mola_price}
                onChange={(e) => setFormData({ ...formData, mola_price: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="list_price">Listepris *</Label>
              <Input
                id="list_price"
                type="number"
                step="0.01"
                value={formData.list_price}
                onChange={(e) => setFormData({ ...formData, list_price: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="unit">Enhed *</Label>
              <Input
                id="unit"
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                placeholder="kr/pakke, % af tx"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="terms">Vilkår *</Label>
            <Textarea
              id="terms"
              value={formData.terms}
              onChange={(e) => setFormData({ ...formData, terms: e.target.value })}
              rows={3}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="contact_email">Kontakt email *</Label>
              <Input
                id="contact_email"
                type="email"
                value={formData.contact_email}
                onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                required
              />
            </div>

            <div>
              <Label htmlFor="activation_url">Aktiverings URL</Label>
              <Input
                id="activation_url"
                type="url"
                value={formData.activation_url}
                onChange={(e) => setFormData({ ...formData, activation_url: e.target.value })}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="is_active"
              checked={formData.is_active}
              onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
              className="h-4 w-4"
            />
            <Label htmlFor="is_active" className="cursor-pointer">Aktiv</Label>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={upsertDeal.isPending}>
              {upsertDeal.isPending ? 'Gemmer...' : 'Gem'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};