import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQueryClient } from "@tanstack/react-query";
import { Upload } from "lucide-react";

interface CSVImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  entity: 'partner_deals' | 'company_prices' | 'procurement_adoptions';
}

export const CSVImportDialog = ({ open, onOpenChange, entity }: CSVImportDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const lines = text.split('\n');
      const headers = lines[0].split(',').map(h => h.trim());
      
      const data = lines.slice(1, 6).filter(line => line.trim()).map(line => {
        const values = line.split(',');
        const row: any = {};
        headers.forEach((header, i) => {
          row[header] = values[i]?.trim() || '';
        });
        return row;
      });
      
      setPreview(data);
    };
    reader.readAsText(selectedFile);
  };

  const handleImport = async () => {
    if (!file) return;

    setIsImporting(true);
    
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const text = event.target?.result as string;
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim());
        
        const data = lines.slice(1).filter(line => line.trim()).map(line => {
          const values = line.split(',');
          const row: any = {};
          headers.forEach((header, i) => {
            row[header] = values[i]?.trim() || '';
          });
          return row;
        });

        // Transform data based on entity
        const transformedData = data.map(row => {
          if (entity === 'partner_deals') {
            return {
              category: row.category,
              vendor: row.vendor,
              plan_name: row.plan_name,
              mola_price: parseFloat(row.mola_price),
              list_price: parseFloat(row.list_price),
              unit: row.unit,
              terms: row.terms,
              contact_email: row.contact_email,
              activation_url: row.activation_url || null,
              is_active: row.is_active === 'true' || row.is_active === '1',
            };
          } else if (entity === 'company_prices') {
            return {
              company_id: row.company_id,
              category: row.category,
              subcategory: row.subcategory,
              value_numeric: parseFloat(row.value_numeric),
              unit: row.unit,
              sample_volume_monthly: row.sample_volume_monthly ? parseFloat(row.sample_volume_monthly) : null,
            };
          }
          return row;
        });

        const { error } = await supabase
          .from(entity)
          .insert(transformedData);

        if (error) throw error;

        toast({
          title: "Import succesfuld",
          description: `${data.length} rækker importeret.`,
        });

        queryClient.invalidateQueries({ queryKey: [`${entity}-admin`] });
        onOpenChange(false);
      };
      reader.readAsText(file);
    } catch (error) {
      toast({
        title: "Import fejlede",
        description: "Kunne ikke importere data. Tjek CSV format.",
        variant: "destructive",
      });
      console.error('Import error:', error);
    } finally {
      setIsImporting(false);
    }
  };

  const entityLabels = {
    partner_deals: 'Partneraftaler',
    company_prices: 'Selskabspriser',
    procurement_adoptions: 'Adoptioner',
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Importer {entityLabels[entity]} fra CSV</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="csv-file">Vælg CSV fil</Label>
            <div className="mt-2">
              <label
                htmlFor="csv-file"
                className="flex items-center justify-center gap-2 px-4 py-8 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
              >
                <Upload className="w-6 h-6" />
                <span>{file ? file.name : 'Klik for at vælge fil'}</span>
              </label>
              <input
                id="csv-file"
                type="file"
                accept=".csv"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>
          </div>

          {preview.length > 0 && (
            <div>
              <h3 className="font-semibold mb-2">Preview (første 5 rækker)</h3>
              <div className="border rounded-lg overflow-auto max-h-64">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {Object.keys(preview[0]).map(key => (
                        <TableHead key={key}>{key}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.map((row, i) => (
                      <TableRow key={i}>
                        {Object.values(row).map((value: any, j) => (
                          <TableCell key={j}>{value}</TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button onClick={handleImport} disabled={!file || isImporting}>
            {isImporting ? 'Importerer...' : 'Importer'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};