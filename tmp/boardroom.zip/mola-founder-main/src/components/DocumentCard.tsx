import { CompanyDocument } from '@/hooks/useCompanyDocuments';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, Trash2, FileText, File, Image, Table } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface DocumentCardProps {
  document: CompanyDocument;
  onDownload: () => void;
  onDelete?: () => void;
}

const getDocumentIcon = (mimeType: string) => {
  if (mimeType.includes('pdf')) return FileText;
  if (mimeType.includes('word') || mimeType.includes('document')) return FileText;
  if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return Table;
  if (mimeType.includes('image')) return Image;
  return File;
};

const DocumentCard = ({ document, onDownload, onDelete }: DocumentCardProps) => {
  const Icon = getDocumentIcon(document.mime_type);

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-lg bg-muted">
            <Icon className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate" title={document.file_name}>
              {document.file_name}
            </p>
            <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
              <span>{(document.file_size / 1024).toFixed(0)} KB</span>
              <span>•</span>
              <span>
                {format(new Date(document.uploaded_at), 'd. MMM yyyy', {
                  locale: da,
                })}
              </span>
            </div>
            {document.version > 1 && (
              <span className="text-xs text-muted-foreground">
                v{document.version}
              </span>
            )}
            {document.notes && (
              <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                {document.notes}
              </p>
            )}
          </div>
        </div>
        <div className="flex gap-2 mt-4">
          <Button
            variant="outline"
            size="sm"
            onClick={onDownload}
            className="flex-1"
          >
            <Download className="h-3 w-3 mr-1" />
            Download
          </Button>
          {onDelete && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onDelete}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DocumentCard;
