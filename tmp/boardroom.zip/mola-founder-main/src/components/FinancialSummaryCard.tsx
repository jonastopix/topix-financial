import { Card } from '@/components/ui/card';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatPercentage } from '@/lib/formatters';

interface FinancialSummaryCardProps {
  title: string;
  value: string;
  change?: number;
  icon: 'revenue' | 'ebitda' | 'cash' | 'growth';
  className?: string;
}

const iconMap = {
  revenue: DollarSign,
  ebitda: Activity,
  cash: DollarSign,
  growth: TrendingUp,
};

export function FinancialSummaryCard({ title, value, change, icon, className }: FinancialSummaryCardProps) {
  const Icon = iconMap[icon];
  const hasChange = typeof change === 'number';
  const isPositive = change && change >= 0;

  return (
    <Card className={cn("p-6 glass-card hover-lift", className)}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <div className="p-2 rounded-lg bg-primary/10">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </div>
      <p className="text-3xl font-bold mb-2">{value}</p>
      {hasChange && (
        <div className="flex items-center gap-2">
          {isPositive ? (
            <TrendingUp className="h-4 w-4 text-success" />
          ) : (
            <TrendingDown className="h-4 w-4 text-destructive" />
          )}
            <span className={cn(
              "text-sm font-medium",
              isPositive ? 'text-success' : 'text-destructive'
            )}>
              {change > 0 ? '+' : ''}{formatPercentage(change, 1)}
            </span>
        </div>
      )}
    </Card>
  );
}
