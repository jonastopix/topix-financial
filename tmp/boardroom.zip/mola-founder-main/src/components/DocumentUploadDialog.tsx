import { useState, useEffect } from 'react';
import { useCompanyDocuments, DocumentType } from '@/hooks/useCompanyDocuments';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Upload } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

interface DocumentUploadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
  preselectedDocType?: DocumentType;
  hasBoard?: boolean;
}

const DocumentUploadDialog = ({
  open,
  onOpenChange,
  companyId,
  preselectedDocType,
  hasBoard = true,
}: DocumentUploadDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState<DocumentType>(preselectedDocType || 'other');
  const [notes, setNotes] = useState('');
  const { uploadDocument } = useCompanyDocuments(companyId);

  // Update document type when preselected type changes
  useEffect(() => {
    if (preselectedDocType) {
      setDocumentType(preselectedDocType);
    }
  }, [preselectedDocType]);

  const allDocumentTypeOptions: { value: DocumentType; label: string }[] = [
    { value: 'shareholder_agreement', label: 'Ejeraftale' },
    { value: 'articles_of_association', label: 'Vedtægter' },
    { value: 'annual_report', label: 'Årsrapport' },
    { value: 'board_minutes', label: 'Bestyrelsesprotokol' },
    { value: 'investment_memo', label: 'Investeringsmemo' },
    { value: 'term_sheet', label: 'Term Sheet' },
    { value: 'valuation_report', label: 'Værdiansættelse' },
    { value: 'other', label: 'Andet' },
  ];

  // Filter out board_minutes if company doesn't have a board
  const documentTypeOptions = hasBoard 
    ? allDocumentTypeOptions 
    : allDocumentTypeOptions.filter(opt => opt.value !== 'board_minutes');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async () => {
    if (!file) return;

    await uploadDocument.mutateAsync({
      file,
      companyId,
      documentType,
      notes: notes || undefined,
    });

    // Reset form
    setFile(null);
    setDocumentType('other');
    setNotes('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Upload Dokument</DialogTitle>
          <DialogDescription>
            Upload et nyt dokument til selskabet
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="file">Fil</Label>
            <div className="mt-2">
              <input
                id="file"
                type="file"
                onChange={handleFileChange}
                className="block w-full text-sm text-foreground file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-primary-foreground hover:file:bg-primary/90"
              />
            </div>
            {file && (
              <p className="text-sm text-muted-foreground mt-2">
                {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
              </p>
            )}
          </div>

          <div>
            <Label htmlFor="document-type">Dokumenttype</Label>
            <Select
              value={documentType}
              onValueChange={(value) => setDocumentType(value as DocumentType)}
            >
              <SelectTrigger id="document-type" className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {documentTypeOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="notes">Noter (valgfrit)</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Tilføj noter om dokumentet..."
              className="mt-2"
              rows={3}
            />
          </div>

          {uploadDocument.isPending && (
            <div className="space-y-2">
              <Label>Uploader...</Label>
              <Progress value={50} />
            </div>
          )}

          <div className="flex gap-3 justify-end pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={uploadDocument.isPending}
            >
              Annuller
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!file || uploadDocument.isPending}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentUploadDialog;
