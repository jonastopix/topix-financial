import { useState, useEffect } from 'react';
import { useCompanyContacts } from '@/hooks/useCompanyContacts';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';

interface AddContactDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
  editingContact?: any;
}

const AddContactDialog = ({
  open,
  onOpenChange,
  companyId,
  editingContact,
}: AddContactDialogProps) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [isPrimary, setIsPrimary] = useState(false);

  const { createContact, updateContact } = useCompanyContacts(companyId);

  useEffect(() => {
    if (editingContact) {
      setName(editingContact.name || '');
      setRole(editingContact.role || '');
      setEmail(editingContact.email || '');
      setPhone(editingContact.phone || '');
      setNotes(editingContact.notes || '');
      setIsPrimary(editingContact.is_primary || false);
    } else {
      resetForm();
    }
  }, [editingContact]);

  const resetForm = () => {
    setName('');
    setRole('');
    setEmail('');
    setPhone('');
    setNotes('');
    setIsPrimary(false);
  };

  const handleSubmit = async () => {
    if (!name || !role) return;

    const contactData = {
      company_id: companyId,
      name,
      role,
      email: email || undefined,
      phone: phone || undefined,
      notes: notes || undefined,
      is_primary: isPrimary,
    };

    if (editingContact) {
      await updateContact.mutateAsync({
        contactId: editingContact.id,
        updates: contactData,
      });
    } else {
      await createContact.mutateAsync(contactData);
    }

    resetForm();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {editingContact ? 'Rediger Kontakt' : 'Tilføj Kontakt'}
          </DialogTitle>
          <DialogDescription>
            {editingContact
              ? 'Opdater kontaktinformation'
              : 'Tilføj en ny kontaktperson til selskabet'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Navn *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="John Doe"
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="role">Rolle *</Label>
            <Input
              id="role"
              value={role}
              onChange={(e) => setRole(e.target.value)}
              placeholder="CEO, CFO, Board Member..."
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="john@example.com"
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="phone">Telefon</Label>
            <Input
              id="phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+45 12 34 56 78"
              className="mt-2"
            />
          </div>

          <div>
            <Label htmlFor="notes">Noter</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Yderligere information..."
              className="mt-2"
              rows={3}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="primary"
              checked={isPrimary}
              onCheckedChange={(checked) => setIsPrimary(checked as boolean)}
            />
            <Label htmlFor="primary" className="cursor-pointer">
              Primær kontakt
            </Label>
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={createContact.isPending || updateContact.isPending}
            >
              Annuller
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={
                !name ||
                !role ||
                createContact.isPending ||
                updateContact.isPending
              }
            >
              {editingContact ? 'Opdater' : 'Tilføj'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddContactDialog;
