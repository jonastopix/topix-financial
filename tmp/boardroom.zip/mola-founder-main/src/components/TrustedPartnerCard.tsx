import { Building2, User, Mail, Phone, Smartphone, Globe, Linkedin, Star, CheckCheck, Pencil } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useState } from 'react';
import { TrustedPartner } from '@/hooks/useTrustedPartners';
import { PartnerRatingStars } from '@/components/PartnerRatingStars';
import { PartnerRatingStats } from '@/hooks/usePartnerRatings';

interface TrustedPartnerCardProps {
  partner: TrustedPartner;
  ratingStats?: PartnerRatingStats;
  onEdit?: () => void;
}

export const TrustedPartnerCard = ({ partner, ratingStats, onEdit }: TrustedPartnerCardProps) => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = async (value: string, field: string) => {
    try {
      await navigator.clipboard.writeText(value);
      setCopiedField(field);
      setTimeout(() => setCopiedField(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 border-border/50 hover:border-primary/30 relative">
      <CardContent className="p-5">
        <div className="space-y-4">
          {/* Edit button */}
          {onEdit && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-3 right-3 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={onEdit}
            >
              <Pencil className="h-4 w-4" />
            </Button>
          )}

          {/* Header with Logo and Badge */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              {partner.logo_url ? (
                <img
                  src={partner.logo_url}
                  alt={partner.company_name}
                  className="w-12 h-12 rounded-lg object-contain bg-muted p-1"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
              )}
              <div className="min-w-0">
                <h3 className="font-semibold text-foreground">{partner.company_name}</h3>
                {partner.category && (
                  <p className="text-xs text-muted-foreground">{partner.category.name}</p>
                )}
                <div className="mt-1">
                  <PartnerRatingStars
                    partnerId={partner.id}
                    averageRating={ratingStats?.average_rating ?? 0}
                    ratingCount={ratingStats?.rating_count ?? 0}
                    userRating={ratingStats?.user_rating ?? null}
                  />
                </div>
              </div>
            </div>
            {partner.is_mola_recommended && (
              <Badge variant="secondary" className="bg-amber-500/10 text-amber-600 border-amber-500/30 flex items-center gap-1 mr-8">
                <Star className="h-3 w-3 fill-current" />
                MOLA Anbefalet
              </Badge>
            )}
          </div>

          {/* Contact Person */}
          {(partner.contact_name || partner.contact_title) && (
            <div className="flex items-center gap-2 text-sm">
              <User className="h-4 w-4 text-muted-foreground" />
              <span className="text-foreground">
                {partner.contact_name}
                {partner.contact_title && (
                  <span className="text-muted-foreground"> · {partner.contact_title}</span>
                )}
              </span>
            </div>
          )}

          {/* Description */}
          {partner.description && (
            <p className="text-sm text-muted-foreground line-clamp-3">
              {partner.description}
            </p>
          )}

          {/* Contact Actions */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-border/50">
            {partner.email && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-muted-foreground hover:text-primary"
                    onClick={() => handleCopy(partner.email!, 'email')}
                  >
                    {copiedField === 'email' ? (
                      <CheckCheck className="h-4 w-4 text-green-500" />
                    ) : (
                      <Mail className="h-4 w-4" />
                    )}
                    <span className="ml-1 text-xs max-w-[120px] truncate">{partner.email}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Klik for at kopiere</TooltipContent>
              </Tooltip>
            )}

            {partner.phone && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-muted-foreground hover:text-primary"
                    onClick={() => handleCopy(partner.phone!, 'phone')}
                  >
                    {copiedField === 'phone' ? (
                      <CheckCheck className="h-4 w-4 text-green-500" />
                    ) : (
                      <Phone className="h-4 w-4" />
                    )}
                    <span className="ml-1 text-xs">{partner.phone}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Klik for at kopiere fastnet</TooltipContent>
              </Tooltip>
            )}

            {partner.mobile_phone && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-muted-foreground hover:text-primary"
                    onClick={() => handleCopy(partner.mobile_phone!, 'mobile')}
                  >
                    {copiedField === 'mobile' ? (
                      <CheckCheck className="h-4 w-4 text-green-500" />
                    ) : (
                      <Smartphone className="h-4 w-4" />
                    )}
                    <span className="ml-1 text-xs">{partner.mobile_phone}</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Klik for at kopiere mobil</TooltipContent>
              </Tooltip>
            )}

            {partner.website && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-muted-foreground hover:text-primary"
                    asChild
                  >
                    <a href={partner.website} target="_blank" rel="noopener noreferrer">
                      <Globe className="h-4 w-4" />
                      <span className="ml-1 text-xs">Website</span>
                    </a>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Åbn website</TooltipContent>
              </Tooltip>
            )}

            {partner.linkedin_url && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2 text-muted-foreground hover:text-primary"
                    asChild
                  >
                    <a href={partner.linkedin_url} target="_blank" rel="noopener noreferrer">
                      <Linkedin className="h-4 w-4" />
                      <span className="ml-1 text-xs">LinkedIn</span>
                    </a>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Åbn LinkedIn</TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
