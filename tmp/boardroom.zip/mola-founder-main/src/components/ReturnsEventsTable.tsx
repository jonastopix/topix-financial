import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface ReturnsEventsTableProps {
  limit?: number;
}

export function ReturnsEventsTable({ limit = 5 }: ReturnsEventsTableProps) {
  const { data: events, isLoading } = useQuery({
    queryKey: ['returns-events', limit],
    queryFn: async () => {
      // Get dividends
      const { data: dividendsData, error: dividendsError } = await supabase
        .from('dividends')
        .select(`
          id,
          amount_dkk,
          declared_date,
          companies (
            name
          )
        `)
        .order('declared_date', { ascending: false })
        .limit(limit);

      if (dividendsError) throw dividendsError;

      // Get exits
      const { data: exitsData, error: exitsError } = await supabase
        .from('exits')
        .select(`
          id,
          gross_sale_amount_dkk,
          transaction_costs_dkk,
          closing_date,
          companies (
            name
          )
        `)
        .order('closing_date', { ascending: false })
        .limit(limit);

      if (exitsError) throw exitsError;

      // Transform to common format
      const dividendEvents = (dividendsData || []).map(d => ({
        id: d.id,
        type: 'dividend' as const,
        date: d.declared_date,
        company: d.companies?.name || 'Unknown',
        amount: d.amount_dkk || 0,
      }));

      const exitEvents = (exitsData || []).map(e => ({
        id: e.id,
        type: 'exit' as const,
        date: e.closing_date,
        company: e.companies?.name || 'Unknown',
        amount: (e.gross_sale_amount_dkk || 0) - (e.transaction_costs_dkk || 0),
      }));

      // Combine and sort by date
      const allEvents = [...dividendEvents, ...exitEvents]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, limit);

      return allEvents;
    },
  });

  if (isLoading) {
    return <p className="text-muted-foreground text-sm">Indlæser events...</p>;
  }

  if (!events || events.length === 0) {
    return <p className="text-muted-foreground text-sm">Ingen events fundet</p>;
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Dato</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Selskab</TableHead>
          <TableHead className="text-right">Beløb</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {events.map((event) => (
          <TableRow key={`${event.type}-${event.id}`}>
            <TableCell className="font-medium">
              {format(new Date(event.date), 'dd MMM yyyy', { locale: da })}
            </TableCell>
            <TableCell>
              <Badge variant={event.type === 'exit' ? 'default' : 'secondary'}>
                {event.type === 'exit' ? 'Exit' : 'Udbytte'}
              </Badge>
            </TableCell>
            <TableCell>{event.company}</TableCell>
            <TableCell className="text-right font-medium">
              {formatCurrency(event.amount)}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
