import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { Badge } from '@/components/ui/badge';
import { 
  Calculator, 
  DollarSign, 
  Percent, 
  Package, 
  Truck, 
  CreditCard,
  Save,
  RotateCcw,
  Info,
  TrendingUp
} from 'lucide-react';
import { useROASCalculations, ROASCalculationInput } from '@/hooks/useROASCalculations';
import { cn } from '@/lib/utils';

interface ROASCalculatorProps {
  companyId: string | undefined;
}

interface CalculatorInputs {
  averageOrderValue: string;
  inputMode: 'cogs' | 'margin';
  costOfGoods: string;
  marginPercentage: string;
  shippingCost: string;
  packagingCost: string;
  fulfillmentCost: string;
  otherCost: string;
  paymentFeePercentage: string;
  paymentFeeFixed: string;
  returnRatePercentage: string;
  notes: string;
}

const initialInputs: CalculatorInputs = {
  averageOrderValue: '',
  inputMode: 'cogs',
  costOfGoods: '',
  marginPercentage: '',
  shippingCost: '',
  packagingCost: '',
  fulfillmentCost: '',
  otherCost: '',
  paymentFeePercentage: '',
  paymentFeeFixed: '',
  returnRatePercentage: '',
  notes: '',
};

export function ROASCalculator({ companyId }: ROASCalculatorProps) {
  const [inputs, setInputs] = useState<CalculatorInputs>(initialInputs);
  const { saveCalculation } = useROASCalculations(companyId);

  const parseNumber = (value: string): number => {
    const parsed = parseFloat(value.replace(',', '.'));
    return isNaN(parsed) ? 0 : parsed;
  };

  const results = useMemo(() => {
    const aov = parseNumber(inputs.averageOrderValue);
    
    if (aov <= 0) {
      return { contributionMargin: 0, breakevenROAS: 0, cogs: 0, otherExpenses: 0, paymentFee: 0, returnLoss: 0, effectiveAOV: 0 };
    }

    // Calculate return rate impact
    const returnRate = parseNumber(inputs.returnRatePercentage);
    const returnLoss = aov * (returnRate / 100);
    const effectiveAOV = aov - returnLoss;

    // Calculate COGS based on input mode (based on effective AOV after returns)
    let cogs: number;
    if (inputs.inputMode === 'cogs') {
      cogs = parseNumber(inputs.costOfGoods) * (1 - returnRate / 100); // Only pay COGS on non-returned orders
    } else {
      const marginPct = parseNumber(inputs.marginPercentage);
      cogs = effectiveAOV * (1 - marginPct / 100);
    }

    // Sum of other expenses (scaled by return rate - only apply to non-returned orders)
    const otherExpenses = 
      (parseNumber(inputs.shippingCost) +
      parseNumber(inputs.packagingCost) +
      parseNumber(inputs.fulfillmentCost) +
      parseNumber(inputs.otherCost)) * (1 - returnRate / 100);

    // Payment fee (based on original AOV - you pay fees even on returned orders)
    const paymentFee = 
      (aov * parseNumber(inputs.paymentFeePercentage) / 100) +
      parseNumber(inputs.paymentFeeFixed);

    // Contribution margin (før ads) - based on effective revenue
    const contributionMargin = effectiveAOV - cogs - otherExpenses - paymentFee;

    // Breakeven ROAS - still based on original AOV (what you pay per order in ads)
    const breakevenROAS = contributionMargin > 0 ? aov / contributionMargin : 0;

    return { contributionMargin, breakevenROAS, cogs, otherExpenses, paymentFee, returnLoss, effectiveAOV };
  }, [inputs]);

  const handleInputChange = (field: keyof CalculatorInputs, value: string) => {
    setInputs(prev => ({ ...prev, [field]: value }));
  };

  const handleReset = () => {
    setInputs(initialInputs);
  };

  const handleSave = () => {
    if (!companyId) return;
    
    const returnRateValue = parseNumber(inputs.returnRatePercentage);
    
    const calculation: ROASCalculationInput = {
      average_order_value: parseNumber(inputs.averageOrderValue),
      cost_of_goods: inputs.inputMode === 'cogs' ? parseNumber(inputs.costOfGoods) : null,
      margin_percentage: inputs.inputMode === 'margin' ? parseNumber(inputs.marginPercentage) : null,
      input_mode: inputs.inputMode,
      shipping_cost: parseNumber(inputs.shippingCost),
      packaging_cost: parseNumber(inputs.packagingCost),
      fulfillment_cost: parseNumber(inputs.fulfillmentCost),
      other_cost: parseNumber(inputs.otherCost),
      payment_fee_percentage: parseNumber(inputs.paymentFeePercentage),
      payment_fee_fixed: parseNumber(inputs.paymentFeeFixed),
      contribution_margin: results.contributionMargin,
      breakeven_roas: results.breakevenROAS,
      return_rate_percentage: returnRateValue > 0 ? returnRateValue : null,
      notes: inputs.notes || undefined,
    };

    saveCalculation.mutate(calculation);
  };

  const isPositiveMargin = results.contributionMargin > 0;
  const hasValidAOV = parseNumber(inputs.averageOrderValue) > 0;

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Input Section */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            Indtast dine data
          </CardTitle>
          <CardDescription>
            Udfyld felterne for at beregne din breakeven ROAS
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* AOV */}
          <div className="space-y-2">
            <Label htmlFor="aov" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-muted-foreground" />
              Gennemsnitlig ordreværdi (ekskl. moms)
            </Label>
            <div className="relative">
              <Input
                id="aov"
                type="text"
                inputMode="decimal"
                placeholder="0"
                value={inputs.averageOrderValue}
                onChange={(e) => handleInputChange('averageOrderValue', e.target.value)}
                className="pr-10"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                kr.
              </span>
            </div>
          </div>

          {/* COGS / Margin Toggle */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Package className="h-4 w-4 text-muted-foreground" />
              Vareforbrug
            </Label>
            <Tabs 
              value={inputs.inputMode} 
              onValueChange={(v) => handleInputChange('inputMode', v as 'cogs' | 'margin')}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="cogs">Vareforbrug (kr.)</TabsTrigger>
                <TabsTrigger value="margin">Dækningsgrad (%)</TabsTrigger>
              </TabsList>
            </Tabs>
            
            {inputs.inputMode === 'cogs' ? (
              <div className="relative">
                <Input
                  type="text"
                  inputMode="decimal"
                  placeholder="0"
                  value={inputs.costOfGoods}
                  onChange={(e) => handleInputChange('costOfGoods', e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                  kr.
                </span>
              </div>
            ) : (
              <div className="relative">
                <Input
                  type="text"
                  inputMode="decimal"
                  placeholder="0"
                  value={inputs.marginPercentage}
                  onChange={(e) => handleInputChange('marginPercentage', e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                  %
                </span>
              </div>
            )}
          </div>

          {/* Other Expenses */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <Truck className="h-4 w-4 text-muted-foreground" />
              Øvrige omkostninger pr. ordre
            </Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Fragt</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.shippingCost}
                    onChange={(e) => handleInputChange('shippingCost', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    kr.
                  </span>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Emballage</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.packagingCost}
                    onChange={(e) => handleInputChange('packagingCost', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    kr.
                  </span>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Fulfillment/pluk & pak</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.fulfillmentCost}
                    onChange={(e) => handleInputChange('fulfillmentCost', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    kr.
                  </span>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Andet</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.otherCost}
                    onChange={(e) => handleInputChange('otherCost', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    kr.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Payment Fees */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-muted-foreground" />
              Betalingsgebyr
            </Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Procentgebyr</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.paymentFeePercentage}
                    onChange={(e) => handleInputChange('paymentFeePercentage', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    %
                  </span>
                </div>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Fast gebyr</Label>
                <div className="relative">
                  <Input
                    type="text"
                    inputMode="decimal"
                    placeholder="0"
                    value={inputs.paymentFeeFixed}
                    onChange={(e) => handleInputChange('paymentFeeFixed', e.target.value)}
                    className="pr-10"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                    kr.
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Return Rate */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Percent className="h-4 w-4 text-muted-foreground" />
              Retur-rate
              <Tooltip>
                <TooltipTrigger asChild>
                  <Info className="h-3.5 w-3.5 text-muted-foreground cursor-help" />
                </TooltipTrigger>
                <TooltipContent className="max-w-xs">
                  <p>Andel af ordrer der returneres. Påvirker din effektive omsætning og dermed breakeven ROAS.</p>
                </TooltipContent>
              </Tooltip>
            </Label>
            <div className="relative">
              <Input
                type="text"
                inputMode="decimal"
                placeholder="0"
                value={inputs.returnRatePercentage}
                onChange={(e) => handleInputChange('returnRatePercentage', e.target.value)}
                className="pr-10"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm">
                %
              </span>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label htmlFor="notes">Noter (valgfrit)</Label>
            <Textarea
              id="notes"
              placeholder="Tilføj noter til denne beregning..."
              value={inputs.notes}
              onChange={(e) => handleInputChange('notes', e.target.value)}
              className="resize-none"
              rows={2}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={handleReset}
              className="flex-1"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Nulstil
            </Button>
            <Button
              onClick={handleSave}
              disabled={!hasValidAOV || !companyId || saveCalculation.isPending}
              className="flex-1"
            >
              <Save className="h-4 w-4 mr-2" />
              Gem beregning
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results Section */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Resultat
          </CardTitle>
          <CardDescription>
            Din breakeven ROAS baseret på de indtastede data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Breakeven ROAS */}
          <div className="text-center py-8 space-y-2">
            <p className="text-sm text-muted-foreground">Breakeven ROAS</p>
            <p className={cn(
              "text-6xl font-bold tabular-nums",
              hasValidAOV && isPositiveMargin ? "text-primary" : "text-destructive"
            )}>
              {hasValidAOV && results.breakevenROAS > 0 
                ? results.breakevenROAS.toFixed(2) 
                : '—'}
            </p>
            <p className="text-sm text-muted-foreground">
              {hasValidAOV && results.breakevenROAS > 0 && (
                <>For hver 1 kr. du bruger på ads, skal du tjene {results.breakevenROAS.toFixed(2)} kr. tilbage</>
              )}
            </p>
          </div>

          {/* Contribution Margin */}
          <div className="bg-muted/50 rounded-lg p-4 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Contribution margin (før ads)</span>
              <span className={cn(
                "text-lg font-semibold tabular-nums",
                isPositiveMargin ? "text-primary" : "text-destructive"
              )}>
                {hasValidAOV 
                  ? `${results.contributionMargin.toFixed(2)} kr.`
                  : '— kr.'}
              </span>
            </div>

            {hasValidAOV && (
              <>
                <div className="h-px bg-border" />
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-muted-foreground">
                    <span>Ordreværdi (AOV)</span>
                    <span>{parseNumber(inputs.averageOrderValue).toFixed(2)} kr.</span>
                  </div>
                  {results.returnLoss > 0 && (
                    <div className="flex justify-between text-orange-600 dark:text-orange-400">
                      <span>− Tab fra returneringer ({parseNumber(inputs.returnRatePercentage).toFixed(1)}%)</span>
                      <span>{results.returnLoss.toFixed(2)} kr.</span>
                    </div>
                  )}
                  {results.returnLoss > 0 && (
                    <div className="flex justify-between text-muted-foreground font-medium">
                      <span>= Effektiv AOV</span>
                      <span>{results.effectiveAOV.toFixed(2)} kr.</span>
                    </div>
                  )}
                  <div className="flex justify-between text-muted-foreground">
                    <span>− Vareforbrug</span>
                    <span>{results.cogs.toFixed(2)} kr.</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>− Øvrige omkostninger</span>
                    <span>{results.otherExpenses.toFixed(2)} kr.</span>
                  </div>
                  <div className="flex justify-between text-muted-foreground">
                    <span>− Betalingsgebyr</span>
                    <span>{results.paymentFee.toFixed(2)} kr.</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Formula */}
          <div className="flex items-start gap-2 p-3 bg-muted/30 rounded-lg">
            <Info className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
            <p className="text-xs text-muted-foreground">
              <strong>Formel:</strong> Breakeven ROAS = AOV ÷ Contribution margin (før ads)
            </p>
          </div>

          {/* Warning for negative margin */}
          {hasValidAOV && !isPositiveMargin && (
            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
              <p className="text-sm text-destructive">
                ⚠️ Negativ contribution margin betyder, at du taber penge på hver ordre – selv uden ads.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
