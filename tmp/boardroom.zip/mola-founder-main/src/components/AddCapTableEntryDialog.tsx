import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useCapTableMutations } from '@/hooks/useCompanyCapTable';
import { Checkbox } from '@/components/ui/checkbox';

interface AddCapTableEntryDialogProps {
  companyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddCapTableEntryDialog({ companyId, open, onOpenChange }: AddCapTableEntryDialogProps) {
  const { addEntry } = useCapTableMutations();
  const [formData, setFormData] = useState({
    owner_name: '',
    owner_email: '',
    owner_cvr: '',
    owner_type: 'person' as 'person' | 'company' | 'fund' | 'other',
    ownership_pct: 0,
    shares: null as number | null,
    share_class: '',
    acquired_date: '',
    notes: '',
  });
  const [inviteAsInvestor, setInviteAsInvestor] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    addEntry.mutate(
      {
        company_id: companyId,
        owner_name: formData.owner_name,
        owner_email: formData.owner_email || null,
        owner_cvr: formData.owner_cvr || null,
        owner_type: formData.owner_type,
        ownership_pct: formData.ownership_pct,
        shares: formData.shares,
        share_class: formData.share_class || null,
        acquired_date: formData.acquired_date || null,
        notes: formData.notes || null,
        user_id: null,
        invited_at: null,
        invitation_status: null,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
          setFormData({
            owner_name: '',
            owner_email: '',
            owner_cvr: '',
            owner_type: 'person',
            ownership_pct: 0,
            shares: null,
            share_class: '',
            acquired_date: '',
            notes: '',
          });
          setInviteAsInvestor(false);
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Tilføj ejer til cap table</DialogTitle>
          <DialogDescription>
            Registrer en ny ejer i kapital tabellen
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="owner_name">Ejer navn *</Label>
              <Input
                id="owner_name"
                value={formData.owner_name}
                onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner_type">Ejer type *</Label>
              <Select
                value={formData.owner_type}
                onValueChange={(value: any) => setFormData({ ...formData, owner_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="person">Person</SelectItem>
                  <SelectItem value="company">Virksomhed</SelectItem>
                  <SelectItem value="fund">Fond</SelectItem>
                  <SelectItem value="other">Andet</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="owner_email">Email</Label>
              <Input
                id="owner_email"
                type="email"
                value={formData.owner_email}
                onChange={(e) => setFormData({ ...formData, owner_email: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Påkrævet for at invitere som investor
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="owner_cvr">CVR nummer</Label>
              <Input
                id="owner_cvr"
                value={formData.owner_cvr}
                onChange={(e) => setFormData({ ...formData, owner_cvr: e.target.value })}
                maxLength={8}
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ownership_pct">Ejerandel % *</Label>
              <Input
                id="ownership_pct"
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={formData.ownership_pct}
                onChange={(e) => setFormData({ ...formData, ownership_pct: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="shares">Antal aktier</Label>
              <Input
                id="shares"
                type="number"
                value={formData.shares || ''}
                onChange={(e) => setFormData({ ...formData, shares: e.target.value ? parseInt(e.target.value) : null })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="share_class">Aktieklasse</Label>
              <Input
                id="share_class"
                value={formData.share_class}
                onChange={(e) => setFormData({ ...formData, share_class: e.target.value })}
                placeholder="A, B, etc."
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="acquired_date">Erhvervelsesdato</Label>
            <Input
              id="acquired_date"
              type="date"
              value={formData.acquired_date}
              onChange={(e) => setFormData({ ...formData, acquired_date: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Noter</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          {formData.owner_email && (
            <div className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
              <Checkbox
                id="invite"
                checked={inviteAsInvestor}
                onCheckedChange={(checked) => setInviteAsInvestor(checked as boolean)}
              />
              <label
                htmlFor="invite"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Inviter som investor efter oprettelse
              </label>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={addEntry.isPending}>
              {addEntry.isPending ? 'Tilføjer...' : 'Tilføj ejer'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
