import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface ResourceCardProps {
  title: string;
  icon: LucideIcon;
  description: string;
  category: 'legal' | 'finance' | 'hr' | 'marketing';
}

const ResourceCard = ({ title, icon: Icon, description, category }: ResourceCardProps) => {
  const categoryColors = {
    legal: 'from-blue-500/20 to-blue-600/20 hover:from-blue-500/30 hover:to-blue-600/30',
    finance: 'from-green-500/20 to-green-600/20 hover:from-green-500/30 hover:to-green-600/30',
    hr: 'from-purple-500/20 to-purple-600/20 hover:from-purple-500/30 hover:to-purple-600/30',
    marketing: 'from-orange-500/20 to-orange-600/20 hover:from-orange-500/30 hover:to-orange-600/30'
  };

  const iconColors = {
    legal: 'text-blue-400',
    finance: 'text-green-400',
    hr: 'text-purple-400',
    marketing: 'text-orange-400'
  };

  return (
    <Card className={`bg-gradient-to-br ${categoryColors[category]} border-border/50 hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer`}>
      <CardContent className="p-6 space-y-4">
        <div className={`w-12 h-12 rounded-lg bg-background/50 flex items-center justify-center`}>
          <Icon className={`h-6 w-6 ${iconColors[category]}`} />
        </div>
        <div>
          <h3 className="font-semibold mb-2">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ResourceCard;
