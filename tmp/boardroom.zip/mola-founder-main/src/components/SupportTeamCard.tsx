import * as LucideIcons from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useSupportContacts } from '@/hooks/useSupportContacts';
import { toast } from '@/hooks/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const SupportTeamCard = () => {
  const { data: contacts, isLoading } = useSupportContacts();

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Kopieret!",
      description: `${type} blev kopieret til udklipsholder`,
    });
  };

  const getIcon = (iconName: string) => {
    const Icon = (LucideIcons as any)[iconName] || LucideIcons.User;
    return Icon;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>MOLA Team</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-lg bg-card/50 animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>MOLA Team</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          {contacts?.map((member) => {
            const Icon = getIcon(member.icon_name);
            return (
              <div 
                key={member.id}
                className="flex items-start justify-between gap-4 p-4 rounded-lg bg-card/50 border border-border/50 hover:bg-card transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <Avatar className="w-12 h-12 flex-shrink-0">
                    <AvatarImage src={member.avatar_url || undefined} />
                    <AvatarFallback className="bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-semibold">{member.name}</h4>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                  </div>
                </div>
                <div className="flex flex-col gap-1 text-sm text-right">
                  {member.email && (
                    <button
                      onClick={() => copyToClipboard(member.email!, "Email")}
                      className="hover:text-primary transition-colors flex items-center justify-end gap-1 group"
                    >
                      <LucideIcons.Mail className="h-3 w-3" />
                      <span className="group-hover:underline">{member.email}</span>
                    </button>
                  )}
                {member.phone && (
                    <button
                      onClick={() => copyToClipboard(member.phone!, "Telefon")}
                      className="hover:text-primary transition-colors flex items-center justify-end gap-1 group"
                    >
                      <LucideIcons.Phone className="h-3 w-3" />
                      <span className="group-hover:underline">{member.phone}</span>
                    </button>
                  )}
                  {member.linkedin_url && (
                    <a
                      href={member.linkedin_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary transition-colors flex items-center justify-end gap-1 group"
                    >
                      <LucideIcons.Linkedin className="h-3 w-3" />
                      <span className="group-hover:underline">LinkedIn</span>
                    </a>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <a
          href="https://app.slack.com/client/T04MYSLDJSW/D06GBLAH3AS"
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-primary hover:bg-primary/90 flex items-center justify-center cursor-pointer shadow-lg transition-all duration-300 hover:scale-110"
          title="Chat på Slack"
        >
          <LucideIcons.Slack className="h-6 w-6 text-primary-foreground" />
        </a>
      </CardContent>
    </Card>
  );
};

export default SupportTeamCard;
