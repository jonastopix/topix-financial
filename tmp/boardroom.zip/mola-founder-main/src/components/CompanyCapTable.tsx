import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Pencil, Trash2, Mail, Plus, AlertTriangle, CheckCircle, FileUp } from 'lucide-react';
import { useCapTable, useCapTableStats, useCapTableMutations, type CapTableEntry } from '@/hooks/useCompanyCapTable';
import { useState } from 'react';
import { AddCapTableEntryDialog } from './AddCapTableEntryDialog';
import { EditCapTableEntryDialog } from './EditCapTableEntryDialog';
import { InviteInvestorDialog } from './InviteInvestorDialog';
import { ImportEjerbogDialog } from './ImportEjerbogDialog';
import { useRole } from '@/contexts/RoleContext';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';

interface CompanyCapTableProps {
  companyId: string;
}

export function CompanyCapTable({ companyId }: CompanyCapTableProps) {
  const { data: entries, isLoading } = useCapTable(companyId);
  const { totalOwnership, isValid, entriesCount } = useCapTableStats(companyId);
  const { deleteEntry } = useCapTableMutations();
  const { isAdmin } = useRole();

  const { data: company } = useQuery({
    queryKey: ['company-ejerbog-date', companyId],
    queryFn: async () => {
      const { data } = await supabase
        .from('companies')
        .select('ejerbog_updated_at')
        .eq('id', companyId)
        .single();
      return data;
    }
  });

  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [editingEntry, setEditingEntry] = useState<CapTableEntry | null>(null);
  const [invitingEntry, setInvitingEntry] = useState<CapTableEntry | null>(null);

  const getOwnerTypeBadge = (type: string) => {
    const variants = {
      person: 'default',
      company: 'secondary',
      fund: 'outline',
      other: 'secondary',
    } as const;

    return <Badge variant={variants[type as keyof typeof variants]}>{type}</Badge>;
  };

  const getInvitationStatusBadge = (status: string | null, hasUser: boolean) => {
    if (!hasUser) return null;
    
    if (status === 'accepted') {
      return <Badge variant="default" className="ml-2"><CheckCircle className="h-3 w-3 mr-1" />Accepteret</Badge>;
    }
    if (status === 'pending') {
      return <Badge variant="outline" className="ml-2"><Mail className="h-3 w-3 mr-1" />Afventer</Badge>;
    }
    return null;
  };

  const handleDelete = (entry: CapTableEntry) => {
    if (confirm(`Er du sikker på at du vil slette ${entry.owner_name} fra cap table?`)) {
      deleteEntry.mutate({ id: entry.id, companyId });
    }
  };

  if (isLoading) {
    return <div>Indlæser cap table...</div>;
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Kapitaltabel (Cap Table)</CardTitle>
              <CardDescription>
                {entriesCount} ejere registreret • Total ejerandel: {totalOwnership.toFixed(2)}%
                {company?.ejerbog_updated_at && (
                  <> • Ejerbog: {new Date(company.ejerbog_updated_at).toLocaleDateString('da-DK')}</>
                )}
              </CardDescription>
            </div>
            {isAdmin && (
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setShowImportDialog(true)}>
                  <FileUp className="h-4 w-4 mr-2" />
                  Importér ejerbog
                </Button>
                <Button onClick={() => setShowAddDialog(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Tilføj ejer
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {!isValid && (
            <div className="mb-4 p-3 bg-warning/10 border border-warning/20 rounded-lg flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-warning mt-0.5" />
              <div>
                <p className="font-medium text-warning">Ejerskab summerer ikke til 100%</p>
                <p className="text-sm text-muted-foreground">
                  Nuværende total: {totalOwnership.toFixed(2)}% 
                  {totalOwnership > 100 ? ' (overallokeret)' : ' (underallokeret)'}
                </p>
              </div>
            </div>
          )}

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ejer</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>CVR</TableHead>
                <TableHead className="text-right">Ejerandel</TableHead>
                <TableHead className="text-right">Aktier</TableHead>
                <TableHead>Klasse</TableHead>
                <TableHead>Erhvervet</TableHead>
                {isAdmin && <TableHead className="text-right">Handlinger</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {!entries || entries.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center text-muted-foreground">
                    Ingen ejere registreret endnu. Tilføj ejere for at oprette cap table.
                  </TableCell>
                </TableRow>
              ) : (
                entries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell className="font-medium">
                      {entry.owner_name}
                      {getInvitationStatusBadge(entry.invitation_status, !!entry.user_id)}
                    </TableCell>
                    <TableCell>{getOwnerTypeBadge(entry.owner_type)}</TableCell>
                    <TableCell className="text-muted-foreground">{entry.owner_email || '-'}</TableCell>
                    <TableCell className="text-muted-foreground">{entry.owner_cvr || '-'}</TableCell>
                    <TableCell className="text-right font-medium">{entry.ownership_pct}%</TableCell>
                    <TableCell className="text-right">{entry.shares?.toLocaleString() || '-'}</TableCell>
                    <TableCell>{entry.share_class || '-'}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {entry.acquired_date ? new Date(entry.acquired_date).toLocaleDateString('da-DK') : '-'}
                    </TableCell>
                    {isAdmin && (
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {entry.owner_email && !entry.user_id && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setInvitingEntry(entry)}
                              title="Inviter som investor"
                            >
                              <Mail className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingEntry(entry)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(entry)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
              {entries && entries.length > 0 && (
                <TableRow className="font-bold bg-muted/50">
                  <TableCell colSpan={4}>Total</TableCell>
                  <TableCell className="text-right">{totalOwnership.toFixed(2)}%</TableCell>
                  <TableCell colSpan={isAdmin ? 4 : 3}></TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <AddCapTableEntryDialog
        companyId={companyId}
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
      />

      <ImportEjerbogDialog
        companyId={companyId}
        open={showImportDialog}
        onOpenChange={setShowImportDialog}
      />

      {editingEntry && (
        <EditCapTableEntryDialog
          entry={editingEntry}
          open={!!editingEntry}
          onOpenChange={(open) => !open && setEditingEntry(null)}
        />
      )}

      {invitingEntry && (
        <InviteInvestorDialog
          entry={invitingEntry}
          companyId={companyId}
          open={!!invitingEntry}
          onOpenChange={(open) => !open && setInvitingEntry(null)}
        />
      )}
    </div>
  );
}
