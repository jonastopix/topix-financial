import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileText, X } from 'lucide-react';
import { useUploadDDDocument, DDDocumentType } from '@/hooks/useDueDiligence';

interface DDDocumentUploadProps {
  caseId: string;
}

export function DDDocumentUpload({ caseId }: DDDocumentUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [documentType, setDocumentType] = useState<DDDocumentType>('financial');
  const [notes, setNotes] = useState('');
  const uploadMutation = useUploadDDDocument();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      if (selectedFile.size > 20 * 1024 * 1024) {
        alert('Filen må max være 20MB');
        return;
      }
      setFile(selectedFile);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    await uploadMutation.mutateAsync({
      caseId,
      file,
      documentType,
      notes,
    });

    // Reset form
    setFile(null);
    setNotes('');
    setDocumentType('financial');
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Upload dokument</h3>
      
      <div className="space-y-4">
        <div>
          <Label htmlFor="document-type">Dokument type</Label>
          <Select value={documentType} onValueChange={(v) => setDocumentType(v as DDDocumentType)}>
            <SelectTrigger id="document-type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="financial">Finansiel</SelectItem>
              <SelectItem value="legal">Juridisk</SelectItem>
              <SelectItem value="commercial">Kommerciel</SelectItem>
              <SelectItem value="technical">Teknisk</SelectItem>
              <SelectItem value="other">Andet</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="file-upload">Vælg fil</Label>
          <div className="mt-2">
            {file ? (
              <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-muted">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm flex-1 truncate">{file.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFile(null)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ) : (
              <label
                htmlFor="file-upload"
                className="flex items-center justify-center gap-2 p-6 rounded-lg border-2 border-dashed border-border hover:border-primary cursor-pointer transition-colors"
              >
                <Upload className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">
                  Klik for at vælge fil (max 20MB)
                </span>
                <Input
                  id="file-upload"
                  type="file"
                  className="hidden"
                  onChange={handleFileChange}
                  accept=".pdf,.doc,.docx,.xls,.xlsx,.png,.jpg,.jpeg"
                />
              </label>
            )}
          </div>
        </div>

        <div>
          <Label htmlFor="notes">Noter (valgfrit)</Label>
          <Textarea
            id="notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Tilføj noter om dokumentet..."
            rows={3}
          />
        </div>

        <Button
          onClick={handleUpload}
          disabled={!file || uploadMutation.isPending}
          className="w-full"
        >
          <Upload className="h-4 w-4 mr-2" />
          {uploadMutation.isPending ? 'Uploader...' : 'Upload dokument'}
        </Button>
      </div>
    </Card>
  );
}
