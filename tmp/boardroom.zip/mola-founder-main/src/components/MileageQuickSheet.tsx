import { useState, useEffect, useCallback } from 'react';
import { format, subDays, endOfMonth } from 'date-fns';
import { da } from 'date-fns/locale';
import { Home, Building2, MapPin, CalendarIcon, Loader2, RefreshCw, RotateCcw } from 'lucide-react';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import {
  Drawer,
  DrawerContent,
  DrawerDescription,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useIsMobile } from '@/hooks/use-mobile';
import { useMileageSettings, useMileageMutations } from '@/hooks/useMileage';
import { useDistanceCalculation } from '@/hooks/useDistanceCalculation';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { MileageSettingsDialog } from './MileageSettingsDialog';

interface MileageQuickSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type FromAddressType = 'private' | 'office' | 'manual';
type DateQuickOption = 'today' | 'yesterday' | 'other';

export function MileageQuickSheet({ open, onOpenChange }: MileageQuickSheetProps) {
  const isMobile = useIsMobile();
  const { data: settings } = useMileageSettings();
  const { createEntry } = useMileageMutations();
  const { calculateDistance, isCalculating, error: distanceError, clearError } = useDistanceCalculation();
  const [showSettings, setShowSettings] = useState(false);
  const [distanceAutoCalculated, setDistanceAutoCalculated] = useState(false);
  
  // Form state
  const [fromAddressType, setFromAddressType] = useState<FromAddressType>('private');
  const [manualFromAddress, setManualFromAddress] = useState('');
  const [toCompanyId, setToCompanyId] = useState<string>('');
  const [manualToAddress, setManualToAddress] = useState('');
  const [purpose, setPurpose] = useState('');
  const [distanceKm, setDistanceKm] = useState('');
  const [payingEntityId, setPayingEntityId] = useState<string>('');
  const [payingEntityType, setPayingEntityType] = useState<'fund' | 'company'>('fund');
  const [dateOption, setDateOption] = useState<DateQuickOption>('today');
  const [customDate, setCustomDate] = useState<string>(format(new Date(), 'yyyy-MM-dd'));
  const [isReturnTrip, setIsReturnTrip] = useState(false);
  
  // Fetch all companies for dropdowns
  const { data: companies = [] } = useQuery({
    queryKey: ['companies-for-mileage'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, address, zipcode, city')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Fetch all funds for paying entity dropdown
  const { data: funds = [] } = useQuery({
    queryKey: ['funds-for-mileage'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Set default paying fund when settings load
  useEffect(() => {
    if (settings?.default_paying_fund_id && !payingEntityId) {
      setPayingEntityId(settings.default_paying_fund_id);
      setPayingEntityType('fund');
    }
  }, [settings?.default_paying_fund_id]);
  
  // Check if settings are configured
  const needsSettings = !settings?.employee_name || !settings?.private_address;
  
  // Get the actual addresses
  const getFromAddress = (): string => {
    if (fromAddressType === 'private') {
      return settings?.private_address || '';
    } else if (fromAddressType === 'office') {
      return settings?.office_address || '';
    }
    return manualFromAddress;
  };
  
  const getToAddress = (): string => {
    if (toCompanyId && toCompanyId !== 'manual') {
      const company = companies.find(c => c.id === toCompanyId);
      if (company) {
        const parts = [company.address, company.zipcode, company.city].filter(Boolean);
        return parts.join(', ');
      }
    }
    return manualToAddress;
  };
  
  const getTripDate = (): string => {
    if (dateOption === 'today') {
      return format(new Date(), 'yyyy-MM-dd');
    } else if (dateOption === 'yesterday') {
      return format(subDays(new Date(), 1), 'yyyy-MM-dd');
    }
    return customDate;
  };

  // Auto-calculate distance when both addresses are available
  const triggerDistanceCalculation = useCallback(async () => {
    const from = getFromAddress();
    const to = getToAddress();
    
    if (from && to) {
      clearError();
      const result = await calculateDistance(from, to);
      if (result) {
        setDistanceKm(result.distance_km.toString());
        setDistanceAutoCalculated(true);
      }
    }
  }, [calculateDistance, clearError, fromAddressType, manualFromAddress, toCompanyId, manualToAddress, settings, companies]);

  // Trigger calculation when addresses change
  useEffect(() => {
    const from = getFromAddress();
    const to = getToAddress();
    
    if (from && to) {
      // Debounce the calculation
      const timer = setTimeout(() => {
        triggerDistanceCalculation();
      }, 500);
      return () => clearTimeout(timer);
    } else {
      setDistanceAutoCalculated(false);
    }
  }, [triggerDistanceCalculation]);

  // Reset auto-calculated flag when user manually changes distance
  const handleDistanceChange = (value: string) => {
    setDistanceKm(value);
    setDistanceAutoCalculated(false);
  };
  
  // Calculate actual distance (doubled if return trip)
  const getActualDistance = (): number => {
    const baseDistance = parseFloat(distanceKm) || 0;
    return isReturnTrip ? baseDistance * 2 : baseDistance;
  };
  
  const handleSubmit = async () => {
    if (!payingEntityId || !purpose || !distanceKm) {
      return;
    }
    
    const fromAddress = getFromAddress();
    const toAddress = getToAddress();
    
    if (!fromAddress || !toAddress) {
      return;
    }
    
    const actualDistance = getActualDistance();
    
    await createEntry.mutateAsync({
      paying_company_id: payingEntityType === 'company' ? payingEntityId : null,
      paying_fund_id: payingEntityType === 'fund' ? payingEntityId : null,
      trip_date: getTripDate(),
      from_address_type: fromAddressType,
      from_address: fromAddress,
      to_company_id: toCompanyId && toCompanyId !== 'manual' ? toCompanyId : null,
      to_address: toAddress,
      purpose: isReturnTrip ? `${purpose} (tur/retur)` : purpose,
      distance_km: actualDistance,
      rate_per_km: 3.94,
    });
    
    // Reset form but keep default paying entity
    setFromAddressType('private');
    setManualFromAddress('');
    setToCompanyId('');
    setManualToAddress('');
    setPurpose('');
    setDistanceKm('');
    setDistanceAutoCalculated(false);
    setDateOption('today');
    setIsReturnTrip(false);
    // Restore default paying fund
    if (settings?.default_paying_fund_id) {
      setPayingEntityId(settings.default_paying_fund_id);
      setPayingEntityType('fund');
    }
    onOpenChange(false);
  };
  
  const formContent = (
    <div className="space-y-6 p-4">
      {needsSettings ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground mb-4">
            Du skal først konfigurere dine kørselsindstillinger
          </p>
          <Button onClick={() => setShowSettings(true)}>
            Konfigurer indstillinger
          </Button>
        </div>
      ) : (
        <>
          {/* FROM ADDRESS */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Fra</Label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                type="button"
                variant={fromAddressType === 'private' ? 'default' : 'outline'}
                className="h-14 flex-col gap-1"
                onClick={() => setFromAddressType('private')}
              >
                <Home className="h-5 w-5" />
                <span className="text-xs">Privat</span>
              </Button>
              <Button
                type="button"
                variant={fromAddressType === 'office' ? 'default' : 'outline'}
                className="h-14 flex-col gap-1"
                onClick={() => setFromAddressType('office')}
                disabled={!settings?.office_address}
              >
                <Building2 className="h-5 w-5" />
                <span className="text-xs">Kontor</span>
              </Button>
              <Button
                type="button"
                variant={fromAddressType === 'manual' ? 'default' : 'outline'}
                className="h-14 flex-col gap-1"
                onClick={() => setFromAddressType('manual')}
              >
                <MapPin className="h-5 w-5" />
                <span className="text-xs">Anden</span>
              </Button>
            </div>
            {fromAddressType === 'manual' && (
              <Input
                placeholder="Indtast adresse..."
                value={manualFromAddress}
                onChange={(e) => setManualFromAddress(e.target.value)}
                className="h-12"
              />
            )}
            {fromAddressType !== 'manual' && (
              <p className="text-sm text-muted-foreground truncate">
                {getFromAddress()}
              </p>
            )}
          </div>
          
          {/* TO ADDRESS */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Til</Label>
            <Select value={toCompanyId} onValueChange={setToCompanyId}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Vælg virksomhed eller anden adresse" />
              </SelectTrigger>
              <SelectContent>
                {companies.map((company) => (
                  <SelectItem key={company.id} value={company.id}>
                    {company.name}
                  </SelectItem>
                ))}
                <SelectItem value="manual">Anden adresse...</SelectItem>
              </SelectContent>
            </Select>
            {toCompanyId === 'manual' && (
              <Input
                placeholder="Indtast destination adresse..."
                value={manualToAddress}
                onChange={(e) => setManualToAddress(e.target.value)}
                className="h-12"
              />
            )}
            {toCompanyId && toCompanyId !== 'manual' && (
              <p className="text-sm text-muted-foreground truncate">
                {getToAddress()}
              </p>
            )}
          </div>
          
          {/* PURPOSE */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Formål</Label>
            <Input
              placeholder="F.eks. Kundemøde, Bestyrelsesmøde..."
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="h-12"
            />
          </div>
          
          {/* DISTANCE */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">Afstand (km)</Label>
              {isCalculating && (
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  Beregner...
                </span>
              )}
            </div>
            <div className="relative">
              <Input
                type="number"
                step="0.1"
                placeholder="0.0"
                value={distanceKm}
                onChange={(e) => handleDistanceChange(e.target.value)}
                className="h-12 text-lg pr-10"
              />
              {getFromAddress() && getToAddress() && !isCalculating && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-8 w-8 p-0"
                  onClick={triggerDistanceCalculation}
                  title="Genberegn afstand"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              )}
            </div>
            {distanceAutoCalculated && !isCalculating && (
              <p className="text-xs text-muted-foreground">
                ✓ Automatisk beregnet køreafstand – kan justeres
              </p>
            )}
            {distanceError && (
              <p className="text-xs text-destructive">
                Kunne ikke beregne afstand: {distanceError}
              </p>
            )}
          </div>
          
          {/* RETURN TRIP */}
          <div className="flex items-center space-x-3 p-4 rounded-lg border bg-muted/50">
            <Checkbox
              id="return-trip"
              checked={isReturnTrip}
              onCheckedChange={(checked) => setIsReturnTrip(checked === true)}
            />
            <div className="flex-1">
              <Label htmlFor="return-trip" className="text-base font-medium cursor-pointer flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Tur/retur
              </Label>
              <p className="text-xs text-muted-foreground">
                {isReturnTrip 
                  ? `${distanceKm ? (parseFloat(distanceKm) * 2).toFixed(1) : '0'} km i alt (${distanceKm || '0'} km × 2)`
                  : 'Afstanden fordobles automatisk'}
              </p>
            </div>
          </div>
          
          {/* PAYING ENTITY (Fund or Company) */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Betales af</Label>
            <Select 
              value={payingEntityId} 
              onValueChange={(value) => {
                const fund = funds.find(f => f.id === value);
                const company = companies.find(c => c.id === value);
                if (fund) {
                  setPayingEntityId(value);
                  setPayingEntityType('fund');
                } else if (company) {
                  setPayingEntityId(value);
                  setPayingEntityType('company');
                }
              }}
            >
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Vælg fund eller virksomhed" />
              </SelectTrigger>
              <SelectContent>
                {funds.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">Funds</div>
                    {funds.map((fund) => (
                      <SelectItem key={fund.id} value={fund.id}>
                        {fund.name}
                        {settings?.default_paying_fund_id === fund.id && (
                          <span className="ml-2 text-xs text-muted-foreground">(Standard)</span>
                        )}
                      </SelectItem>
                    ))}
                  </>
                )}
                {companies.length > 0 && (
                  <>
                    <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">Virksomheder</div>
                    {companies.map((company) => (
                      <SelectItem key={company.id} value={company.id}>
                        {company.name}
                      </SelectItem>
                    ))}
                  </>
                )}
              </SelectContent>
            </Select>
          </div>
          
          {/* DATE */}
          <div className="space-y-3">
            <Label className="text-base font-medium">Dato</Label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                type="button"
                variant={dateOption === 'today' ? 'default' : 'outline'}
                className="h-12"
                onClick={() => {
                  setDateOption('today');
                  setCustomDate(format(new Date(), 'yyyy-MM-dd'));
                }}
              >
                I dag
              </Button>
              <Button
                type="button"
                variant={dateOption === 'yesterday' ? 'default' : 'outline'}
                className="h-12"
                onClick={() => {
                  setDateOption('yesterday');
                  setCustomDate(format(subDays(new Date(), 1), 'yyyy-MM-dd'));
                }}
              >
                I går
              </Button>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant={dateOption === 'other' ? 'default' : 'outline'}
                    className="h-12"
                  >
                    <CalendarIcon className="h-4 w-4" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="center">
                  <Calendar
                    mode="single"
                    selected={customDate ? new Date(customDate) : new Date()}
                    onSelect={(date) => {
                      if (date) {
                        setCustomDate(format(date, 'yyyy-MM-dd'));
                        setDateOption('other');
                      }
                    }}
                    disabled={(date) => date > endOfMonth(new Date())}
                    locale={da}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            <p className="text-sm text-muted-foreground">
              Valgt: {format(
                dateOption === 'today' 
                  ? new Date() 
                  : dateOption === 'yesterday' 
                    ? subDays(new Date(), 1) 
                    : new Date(customDate),
                'EEEE d. MMMM yyyy',
                { locale: da }
              )}
            </p>
          </div>
          
          {/* SUBMIT */}
          <Button
            onClick={handleSubmit}
            disabled={!payingEntityId || !purpose || !distanceKm || !getFromAddress() || !getToAddress() || createEntry.isPending}
            className="w-full h-14 text-lg"
          >
            {createEntry.isPending ? 'Gemmer...' : 'Registrer kørsel'}
          </Button>
          
          {/* Settings link */}
          <div className="text-center pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSettings(true)}
            >
              Rediger adresser og indstillinger
            </Button>
          </div>
        </>
      )}
      
      <MileageSettingsDialog 
        open={showSettings} 
        onOpenChange={setShowSettings} 
      />
    </div>
  );
  
  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="max-h-[90vh]">
          <DrawerHeader>
            <DrawerTitle>Registrer kørsel</DrawerTitle>
            <DrawerDescription>
              SKAT-sats 2026: 3,94 kr/km
            </DrawerDescription>
          </DrawerHeader>
          <div className="overflow-y-auto">
            {formContent}
          </div>
        </DrawerContent>
      </Drawer>
    );
  }
  
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Registrer kørsel</SheetTitle>
          <SheetDescription>
            SKAT-sats 2026: 3,94 kr/km
          </SheetDescription>
        </SheetHeader>
        {formContent}
      </SheetContent>
    </Sheet>
  );
}
