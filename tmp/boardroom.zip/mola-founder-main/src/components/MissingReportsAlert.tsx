import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

interface MissingReportsAlertProps {
  companyName?: string;
  lastReportMonth?: number;
  lastReportYear?: number;
}

export const MissingReportsAlert = ({ 
  companyName, 
  lastReportMonth,
  lastReportYear 
}: MissingReportsAlertProps) => {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1; // 0-indexed
  const currentDay = now.getDate();

  // Calculate expected report month (previous month)
  let expectedMonth = currentMonth - 1;
  let expectedYear = currentYear;
  
  if (expectedMonth === 0) {
    expectedMonth = 12;
    expectedYear = currentYear - 1;
  }

  // Check if we're past the 20th of current month (deadline for previous month's report)
  const isPastDeadline = currentDay > 20;

  // If we have no reports or the last report is older than expected
  const isMissing = !lastReportMonth || !lastReportYear || 
    (lastReportYear < expectedYear) || 
    (lastReportYear === expectedYear && lastReportMonth < expectedMonth);

  // Only show alert if past deadline and report is missing
  if (!isPastDeadline || !isMissing) {
    return null;
  }

  const monthNames = [
    'januar', 'februar', 'marts', 'april', 'maj', 'juni',
    'juli', 'august', 'september', 'oktober', 'november', 'december'
  ];

  const expectedMonthName = monthNames[expectedMonth - 1];

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Manglende månedsrapport</AlertTitle>
      <AlertDescription>
        {companyName ? `${companyName} har` : 'Der er'} ikke uploadet månedsrapport for {expectedMonthName} {expectedYear}.
        Rapporten skulle have været indsendt senest den 20. {monthNames[currentMonth - 1]}.
      </AlertDescription>
    </Alert>
  );
};
