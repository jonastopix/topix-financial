import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBoardMembers } from '@/hooks/useBoardMembers';

interface AddBoardMemberDialogProps {
  companyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddBoardMemberDialog({ companyId, open, onOpenChange }: AddBoardMemberDialogProps) {
  const { createMember } = useBoardMembers(companyId);
  const [formData, setFormData] = useState({
    name: '',
    role: 'member' as 'chairman' | 'member' | 'alternate',
    email: '',
    phone: '',
    appointed_date: new Date().toISOString().split('T')[0],
    term_end_date: '',
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    await createMember.mutateAsync({
      company_id: companyId,
      ...formData,
      email: formData.email || undefined,
      phone: formData.phone || undefined,
      term_end_date: formData.term_end_date || undefined,
      notes: formData.notes || undefined,
    });

    setFormData({
      name: '',
      role: 'member',
      email: '',
      phone: '',
      appointed_date: new Date().toISOString().split('T')[0],
      term_end_date: '',
      notes: '',
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Tilføj bestyrelsesmedlem</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Navn *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
            />
          </div>

          <div>
            <Label htmlFor="role">Rolle *</Label>
            <Select
              value={formData.role}
              onValueChange={(value: any) => setFormData({ ...formData, role: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="chairman">Formand</SelectItem>
                <SelectItem value="member">Medlem</SelectItem>
                <SelectItem value="alternate">Suppleant</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="phone">Telefon</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="appointed_date">Tiltrådt dato *</Label>
            <Input
              id="appointed_date"
              type="date"
              value={formData.appointed_date}
              onChange={(e) => setFormData({ ...formData, appointed_date: e.target.value })}
              required
            />
          </div>

          <div>
            <Label htmlFor="term_end_date">Valgperiode udløber</Label>
            <Input
              id="term_end_date"
              type="date"
              value={formData.term_end_date}
              onChange={(e) => setFormData({ ...formData, term_end_date: e.target.value })}
            />
          </div>

          <div>
            <Label htmlFor="notes">Noter</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={createMember.isPending}>
              {createMember.isPending ? 'Gemmer...' : 'Gem'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
