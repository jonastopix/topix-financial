import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Trophy } from 'lucide-react';
import { calculateScorecard, calculateHealthIndex } from '@/lib/metricsCalculations';

interface TopCompaniesLeaderboardProps {
  fundFilter?: string;
  limit?: number;
}

export function TopCompaniesLeaderboard({ fundFilter, limit = 5 }: TopCompaniesLeaderboardProps) {
  const currentYear = new Date().getFullYear();

  const { data: topCompanies, isLoading } = useQuery({
    queryKey: ['top-companies-leaderboard', fundFilter, limit, currentYear],
    queryFn: async () => {
      // Get companies
      let companiesQuery = supabase
        .from('companies')
        .select('id, name, fund_id')
        .eq('is_active', true);

      if (fundFilter && fundFilter !== 'all') {
        companiesQuery = companiesQuery.eq('fund_id', fundFilter);
      }

      const { data: companies, error: companiesError } = await companiesQuery;
      if (companiesError) throw companiesError;

      const companyIds = companies?.map(c => c.id) || [];

      // Get monthly reports
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', companyIds);
      if (reportsError) throw reportsError;

      // Get NPS responses
      const { data: npsData, error: npsError } = await supabase
        .from('nps_responses')
        .select('*')
        .in('company_id', companyIds);
      if (npsError) throw npsError;

      // Calculate health for each company
      const companiesWithHealth = companies?.map(company => {
        const companyReports = reports?.filter(r => r.company_id === company.id) || [];
        const companyNPS = npsData?.filter(n => n.company_id === company.id) || [];
        
        const scorecard = calculateScorecard(companyReports, companyNPS, currentYear);
        const healthIndex = calculateHealthIndex(
          scorecard.financial,
          scorecard.growth,
          scorecard.transparency,
          scorecard.relationship
        );

        return {
          ...company,
          healthIndex,
          scorecard,
        };
      }) || [];

      // Sort by health index and take top N
      return companiesWithHealth
        .sort((a, b) => b.healthIndex - a.healthIndex)
        .slice(0, limit);
    },
  });

  if (isLoading) {
    return <p className="text-muted-foreground text-sm">Indlæser leaderboard...</p>;
  }

  if (!topCompanies || topCompanies.length === 0) {
    return <p className="text-muted-foreground text-sm">Ingen data tilgængelig</p>;
  }

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getHealthBadge = (score: number) => {
    if (score >= 80) return { variant: 'default' as const, label: 'Sund' };
    if (score >= 50) return { variant: 'secondary' as const, label: 'Stabil' };
    return { variant: 'destructive' as const, label: 'Risiko' };
  };

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-12">Rank</TableHead>
          <TableHead>Selskab</TableHead>
          <TableHead className="text-center">Health Index</TableHead>
          <TableHead className="text-center">Status</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {topCompanies.map((company, index) => {
          const badge = getHealthBadge(company.healthIndex);
          return (
            <TableRow key={company.id}>
              <TableCell className="font-medium">
                {index === 0 && <Trophy className="h-5 w-5 text-yellow-500 inline mr-1" />}
                #{index + 1}
              </TableCell>
              <TableCell className="font-medium">{company.name}</TableCell>
              <TableCell className="text-center">
                <span className={`text-2xl font-bold ${getHealthColor(company.healthIndex)}`}>
                  {Math.round(company.healthIndex)}
                </span>
              </TableCell>
              <TableCell className="text-center">
                <Badge variant={badge.variant}>{badge.label}</Badge>
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}
