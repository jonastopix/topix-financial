import { useState } from 'react';
import { useTaskManagement } from '@/hooks/useTaskManagement';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { format, isAfter, isBefore, addDays } from 'date-fns';
import { da } from 'date-fns/locale';
import { CheckCircle2, Calendar, AlertCircle, ArrowRight, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import CreateTaskDialog from '@/components/CreateTaskDialog';
import TaskDetailsDialog from '@/components/TaskDetailsDialog';
import type { Task } from '@/hooks/useTaskManagement';

const MyTasksWidget = () => {
  const { tasks, isLoading, updateTask } = useTaskManagement();
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);

  const myTasks = tasks?.filter(t => t.status !== 'done' && t.status !== 'cancelled') || [];
  
  // Sort by priority first (urgent > high > medium > low), then by due date
  const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 };
  const sortedTasks = [...myTasks].sort((a, b) => {
    const priorityA = priorityOrder[a.priority as keyof typeof priorityOrder] ?? 4;
    const priorityB = priorityOrder[b.priority as keyof typeof priorityOrder] ?? 4;
    if (priorityA !== priorityB) return priorityA - priorityB;
    
    // Then by due date
    if (a.due_date && b.due_date) {
      return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
    }
    if (a.due_date) return -1;
    if (b.due_date) return 1;
    return 0;
  });

  const urgentTasks = sortedTasks.filter(t => {
    if (!t.due_date) return false;
    const dueDate = new Date(t.due_date);
    const today = new Date();
    return isBefore(dueDate, addDays(today, 3));
  });

  const handleQuickComplete = (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    updateTask.mutate({ id: taskId, status: 'done' });
  };

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setIsDetailsOpen(true);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-destructive text-destructive-foreground';
      case 'high': return 'bg-orange-500 text-white';
      case 'medium': return 'bg-yellow-500 text-white';
      case 'low': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'Akut';
      case 'high': return 'Høj';
      case 'medium': return 'Mellem';
      case 'low': return 'Lav';
      default: return priority;
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return '?';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-32" />
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

  // Hide widget completely if no active tasks
  if (myTasks.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Mine opgaver</CardTitle>
            <CreateTaskDialog 
              trigger={
                <Button variant="outline" size="sm">
                  <Plus className="h-4 w-4 mr-1" />
                  Ny opgave
                </Button>
              }
            />
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-sm text-center py-4">
            Ingen aktive opgaver
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="text-lg">Mine opgaver</CardTitle>
            <div className="flex items-center gap-2">
              <CreateTaskDialog 
                trigger={
                  <Button variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Ny
                  </Button>
                }
              />
              <Link to="/tasks">
                <Button variant="ghost" size="sm">
                  Se alle
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {urgentTasks.length > 0 && (
            <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-3 mb-3">
              <div className="flex items-center gap-2 text-destructive font-medium text-sm">
                <AlertCircle className="h-4 w-4" />
                {urgentTasks.length} opgave{urgentTasks.length > 1 ? 'r' : ''} med snart deadline
              </div>
            </div>
          )}

          {sortedTasks.slice(0, 6).map((task) => {
            const isOverdue = task.due_date && isBefore(new Date(task.due_date), new Date());
            const isDueSoon = task.due_date && 
              isAfter(new Date(task.due_date), new Date()) && 
              isBefore(new Date(task.due_date), addDays(new Date(), 3));

            return (
              <div
                key={task.id}
                onClick={() => handleTaskClick(task)}
                className={cn(
                  'flex items-center gap-3 p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors cursor-pointer group',
                  isOverdue && 'border-destructive',
                  isDueSoon && 'border-yellow-500'
                )}
              >
                {/* Quick complete checkbox */}
                <Checkbox
                  checked={false}
                  onClick={(e) => handleQuickComplete(task.id, e)}
                  className="opacity-60 group-hover:opacity-100 transition-opacity"
                />

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm truncate">{task.title}</p>
                    {task.priority && task.priority !== 'medium' && (
                      <Badge className={cn('text-xs shrink-0', getPriorityColor(task.priority))}>
                        {getPriorityLabel(task.priority)}
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    {task.due_date && (
                      <div className={cn(
                        'flex items-center gap-1 text-xs',
                        isOverdue && 'text-destructive font-medium',
                        isDueSoon && 'text-yellow-600 font-medium'
                      )}>
                        <Calendar className="h-3 w-3" />
                        {format(new Date(task.due_date), 'dd MMM', { locale: da })}
                      </div>
                    )}
                    
                    {task.company && (
                      <span className="text-xs text-muted-foreground truncate max-w-[100px]">
                        {task.company.name}
                      </span>
                    )}
                  </div>
                </div>

                {/* Assigned user avatar */}
                {task.assigned_profile && (
                  <Avatar className="h-7 w-7 shrink-0">
                    <AvatarFallback className="text-xs bg-primary/10 text-primary">
                      {getInitials(task.assigned_profile.full_name)}
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            );
          })}

          {sortedTasks.length > 6 && (
            <Link to="/tasks" className="block">
              <p className="text-center text-sm text-muted-foreground pt-2 hover:text-primary transition-colors">
                +{sortedTasks.length - 6} flere opgaver
              </p>
            </Link>
          )}
        </CardContent>
      </Card>

      {/* Task details dialog */}
      {selectedTask && (
        <TaskDetailsDialog
          task={selectedTask}
          open={isDetailsOpen}
          onOpenChange={(open) => {
            setIsDetailsOpen(open);
            if (!open) setSelectedTask(null);
          }}
        />
      )}
    </>
  );
};

export default MyTasksWidget;
