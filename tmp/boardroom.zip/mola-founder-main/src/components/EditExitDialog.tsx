import { useState, useMemo, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useExitMutations } from '@/hooks/useExitMutations';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Info } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';
import { formatDKK } from '@/lib/returnsCalculations';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { Exit } from '@/lib/returnsCalculations';

interface EditExitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  exit: Exit;
}

export function EditExitDialog({ 
  open, 
  onOpenChange, 
  exit,
}: EditExitDialogProps) {
  const { updateExit } = useExitMutations();
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [closingDate, setClosingDate] = useState<Date>();
  const [grossSaleAmount, setGrossSaleAmount] = useState('');
  const [ownershipPct, setOwnershipPct] = useState('');
  const [transactionCosts, setTransactionCosts] = useState('');
  const [retainedShares, setRetainedShares] = useState('');
  const [earnoutPossible, setEarnoutPossible] = useState(false);
  const [earnoutAmount, setEarnoutAmount] = useState('');
  const [note, setNote] = useState('');

  // Initialize form with exit data when dialog opens
  useEffect(() => {
    if (open && exit) {
      setClosingDate(parseISO(exit.closing_date));
      setGrossSaleAmount(exit.gross_sale_amount_dkk.toString());
      setOwnershipPct(exit.mola_ownership_pct_at_exit.toString());
      setTransactionCosts((exit.transaction_costs_dkk || 0).toString());
      setRetainedShares((exit.retained_shares_pct || 0).toString());
      setEarnoutPossible(exit.earnout_possible || false);
      setEarnoutAmount((exit.earnout_amount_potential_dkk || '').toString());
      setNote(exit.note || '');
    }
  }, [open, exit]);

  // Calculate preview of realized proceeds
  const previewCalculation = useMemo(() => {
    const gross = parseFloat(grossSaleAmount) || 0;
    const ownership = parseFloat(ownershipPct) || 0;
    const costs = parseFloat(transactionCosts) || 0;
    
    const molaShare = gross * (ownership / 100);
    const netProceeds = molaShare - costs;
    
    return {
      molaShare,
      netProceeds,
      isLoss: netProceeds < 0,
      hasValues: gross > 0 && ownership > 0
    };
  }, [grossSaleAmount, ownershipPct, transactionCosts]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!closingDate || !grossSaleAmount || !ownershipPct) {
      return;
    }

    await updateExit.mutateAsync({
      id: exit.id,
      closing_date: format(closingDate, 'yyyy-MM-dd'),
      gross_sale_amount_dkk: parseFloat(grossSaleAmount),
      mola_ownership_pct_at_exit: parseFloat(ownershipPct),
      transaction_costs_dkk: parseFloat(transactionCosts),
      retained_shares_pct: parseFloat(retainedShares),
      earnout_possible: earnoutPossible,
      earnout_amount_potential_dkk: earnoutPossible && earnoutAmount ? parseFloat(earnoutAmount) : undefined,
      note: note || undefined,
    });

    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Rediger Exit</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Rediger exit-detaljerne. Ændringer vil påvirke alle beregninger for denne investering.
            </AlertDescription>
          </Alert>
          
          <div className="space-y-2">
            <Label htmlFor="closing_date">Closing Date *</Label>
            <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !closingDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {closingDate ? format(closingDate, 'dd MMM yyyy') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 z-50">
                <Calendar
                  mode="single"
                  selected={closingDate}
                  onSelect={(date) => {
                    setClosingDate(date);
                    setDatePickerOpen(false);
                  }}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="gross_sale">Gross Sale Amount (DKK) *</Label>
            <Input
              id="gross_sale"
              type="number"
              step="0.01"
              placeholder="5000000"
              value={grossSaleAmount}
              onChange={(e) => setGrossSaleAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ownership">MOLA Ownership % at Exit *</Label>
            <Input
              id="ownership"
              type="number"
              step="0.01"
              placeholder="15.00"
              value={ownershipPct}
              onChange={(e) => setOwnershipPct(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="transaction_costs">Transaction Costs (DKK)</Label>
            <Input
              id="transaction_costs"
              type="number"
              step="0.01"
              placeholder="0"
              value={transactionCosts}
              onChange={(e) => setTransactionCosts(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="retained_shares">Retained Shares %</Label>
            <Input
              id="retained_shares"
              type="number"
              step="0.01"
              placeholder="0"
              value={retainedShares}
              onChange={(e) => setRetainedShares(e.target.value)}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="earnout"
              checked={earnoutPossible}
              onCheckedChange={(checked) => setEarnoutPossible(checked as boolean)}
            />
            <Label htmlFor="earnout" className="text-sm font-normal cursor-pointer">
              Earnout Possible
            </Label>
          </div>

          {earnoutPossible && (
            <div className="space-y-2">
              <Label htmlFor="earnout_amount">Earnout Amount Potential (DKK)</Label>
              <Input
                id="earnout_amount"
                type="number"
                step="0.01"
                placeholder="500000"
                value={earnoutAmount}
                onChange={(e) => setEarnoutAmount(e.target.value)}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="note">Note (Optional)</Label>
            <Textarea
              id="note"
              placeholder="Additional information about this exit..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
            />
          </div>

          {previewCalculation.hasValues && (
            <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-2">
              <div className="font-semibold text-sm text-muted-foreground">Preview af Beregning</div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Samlet salgsbeløb:</span>
                  <span className="font-medium">{formatDKK(parseFloat(grossSaleAmount) || 0)}</span>
                </div>
                <div className="flex justify-between">
                  <span>MOLA's andel ({ownershipPct}%):</span>
                  <span className="font-medium">{formatDKK(previewCalculation.molaShare)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Transaktionsomkostninger:</span>
                  <span className="font-medium">-{formatDKK(parseFloat(transactionCosts) || 0)}</span>
                </div>
                <div className="h-px bg-border my-2" />
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Estimeret Realized Proceeds:</span>
                  <span className={cn(
                    "font-bold text-base",
                    previewCalculation.isLoss ? "text-destructive" : "text-primary"
                  )}>
                    {formatDKK(previewCalculation.netProceeds)}
                  </span>
                </div>
                {previewCalculation.isLoss && (
                  <div className="text-xs text-destructive mt-1">
                    ⚠️ Dette exit vil resultere i et tab
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button 
              type="submit" 
              disabled={!closingDate || !grossSaleAmount || !ownershipPct || updateExit.isPending}
            >
              {updateExit.isPending ? 'Gemmer...' : 'Gem ændringer'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
