import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Search } from 'lucide-react';
import { useCVRLookup } from '@/hooks/useCVRLookup';

interface Fund {
  id: string;
  name: string;
  cvr: string;
  inception_date?: string;
  target_size_dkk?: number;
}

interface EditFundDialogProps {
  fund: Fund | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdate: (fund: { 
    id: string; 
    name: string; 
    cvr: string; 
    inception_date?: string; 
    target_size_dkk?: number;
    company_type?: string;
    address?: string;
    city?: string;
    zipcode?: string;
  }) => void;
}

export function EditFundDialog({ fund, open, onOpenChange, onUpdate }: EditFundDialogProps) {
  const [name, setName] = useState('');
  const [cvr, setCvr] = useState('');
  const [inceptionDate, setInceptionDate] = useState('');
  const [targetSize, setTargetSize] = useState('');
  const [companyType, setCompanyType] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [zipcode, setZipcode] = useState('');
  const { lookupCVR, isLoading } = useCVRLookup();

  const handleCVRLookup = async () => {
    const { data } = await lookupCVR(cvr);
    if (data) {
      setName(data.name);
      setInceptionDate(data.startdate);
      setCompanyType(data.companytype);
      setAddress(data.address);
      setCity(data.city);
      setZipcode(data.zipcode);
    }
  };

  useEffect(() => {
    if (fund) {
      setName(fund.name);
      setCvr(fund.cvr);
      setInceptionDate(fund.inception_date || '');
      setTargetSize(fund.target_size_dkk?.toString() || '');
      setCompanyType((fund as any).company_type || '');
      setAddress((fund as any).address || '');
      setCity((fund as any).city || '');
      setZipcode((fund as any).zipcode || '');
    }
  }, [fund]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fund) return;
    
    onUpdate({
      id: fund.id,
      name,
      cvr,
      inception_date: inceptionDate || undefined,
      target_size_dkk: targetSize ? parseFloat(targetSize) : undefined,
      company_type: companyType || undefined,
      address: address || undefined,
      city: city || undefined,
      zipcode: zipcode || undefined,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Rediger Fond</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="editName">Fond Navn</Label>
            <Input
              id="editName"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="fx MOLA Fund I"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editCvr">CVR Nummer</Label>
            <div className="flex gap-2">
              <Input
                id="editCvr"
                type="text"
                value={cvr}
                onChange={(e) => setCvr(e.target.value)}
                placeholder="fx 12345678"
                pattern="\d{8}"
                maxLength={8}
                required
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleCVRLookup}
                disabled={!cvr || !/^\d{8}$/.test(cvr) || isLoading}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="editInceptionDate">Stiftelsesdato (valgfri)</Label>
            <Input
              id="editInceptionDate"
              type="date"
              value={inceptionDate}
              onChange={(e) => setInceptionDate(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editTargetSize">Target Størrelse DKK (valgfri)</Label>
            <Input
              id="editTargetSize"
              type="number"
              min="0"
              step="1000"
              value={targetSize}
              onChange={(e) => setTargetSize(e.target.value)}
              placeholder="10000000"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editCompanyType">Selskabsform (valgfri)</Label>
            <Input
              id="editCompanyType"
              value={companyType}
              onChange={(e) => setCompanyType(e.target.value)}
              placeholder="fx ApS, A/S"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editAddress">Adresse (valgfri)</Label>
            <Input
              id="editAddress"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Vejnavn 1"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editCity">By (valgfri)</Label>
            <Input
              id="editCity"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="København"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="editZipcode">Postnummer (valgfri)</Label>
            <Input
              id="editZipcode"
              value={zipcode}
              onChange={(e) => setZipcode(e.target.value)}
              placeholder="1234"
              maxLength={4}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit">Gem</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
