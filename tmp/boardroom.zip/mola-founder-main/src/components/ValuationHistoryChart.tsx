import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { formatCurrency } from '@/lib/formatters';
import { format } from 'date-fns';
import { Target, BarChart3, Edit3, TrendingUp } from 'lucide-react';

interface Valuation {
  id: string;
  as_of_date: string;
  post_money_valuation_dkk: number;
  source: string;
}

interface ValuationHistoryChartProps {
  valuations: Valuation[];
  companyName: string;
}

export function ValuationHistoryChart({ valuations, companyName }: ValuationHistoryChartProps) {
  if (!valuations || valuations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Valuation History - {companyName}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No valuation history available for this company
          </p>
        </CardContent>
      </Card>
    );
  }

  // Sort valuations by date
  const sortedValuations = [...valuations].sort((a, b) => 
    new Date(a.as_of_date).getTime() - new Date(b.as_of_date).getTime()
  );

  // Categorize valuations by source type
  const categorizedData = sortedValuations.map(v => {
    const isFundingRound = v.source.includes('Funding Round');
    const isMarketBased = v.source.includes('Market-based') || v.source.includes('Auto-calculated');
    
    return {
      date: format(new Date(v.as_of_date), 'MMM yyyy'),
      fullDate: v.as_of_date,
      source: v.source,
      fundingRound: isFundingRound ? v.post_money_valuation_dkk : null,
      marketBased: isMarketBased ? v.post_money_valuation_dkk : null,
      manual: (!isFundingRound && !isMarketBased) ? v.post_money_valuation_dkk : null,
      total: v.post_money_valuation_dkk,
    };
  });

  // Calculate stats
  const latestValuation = sortedValuations[sortedValuations.length - 1];
  const firstValuation = sortedValuations[0];
  const totalGrowth = latestValuation.post_money_valuation_dkk - firstValuation.post_money_valuation_dkk;
  const growthPercentage = (totalGrowth / firstValuation.post_money_valuation_dkk) * 100;

  const fundingRoundCount = sortedValuations.filter(v => v.source.includes('Funding Round')).length;
  const marketBasedCount = sortedValuations.filter(v => 
    v.source.includes('Market-based') || v.source.includes('Auto-calculated')
  ).length;
  const manualCount = sortedValuations.filter(v => 
    !v.source.includes('Funding Round') && 
    !v.source.includes('Market-based') && 
    !v.source.includes('Auto-calculated')
  ).length;

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border rounded-lg p-3 shadow-lg">
          <p className="font-semibold mb-2">{data.date}</p>
          {payload.map((entry: any, index: number) => {
            if (entry.value !== null) {
              return (
                <p key={index} className="text-sm" style={{ color: entry.color }}>
                  {entry.name}: {formatCurrency(entry.value, 0)}
                </p>
              );
            }
            return null;
          })}
          <p className="text-xs text-muted-foreground mt-2 border-t pt-2">
            {data.source}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Valuation History - {companyName}
        </CardTitle>
        <CardDescription>
          Historical valuation tracking from funding rounds and market-based calculations
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Latest Valuation</p>
            <p className="text-2xl font-bold">{formatCurrency(latestValuation.post_money_valuation_dkk, 0)}</p>
            <p className="text-xs text-muted-foreground mt-1">{format(new Date(latestValuation.as_of_date), 'dd MMM yyyy')}</p>
          </div>
          <div className="p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Total Growth</p>
            <p className="text-2xl font-bold">{formatCurrency(totalGrowth, 0)}</p>
            <p className={`text-xs mt-1 ${growthPercentage >= 0 ? 'text-primary' : 'text-destructive'}`}>
              {growthPercentage >= 0 ? '+' : ''}{growthPercentage.toFixed(1)}%
            </p>
          </div>
          <div className="p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground">Data Points</p>
            <p className="text-2xl font-bold">{sortedValuations.length}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {format(new Date(firstValuation.as_of_date), 'MMM yyyy')} - {format(new Date(latestValuation.as_of_date), 'MMM yyyy')}
            </p>
          </div>
          <div className="p-4 border rounded-lg">
            <p className="text-sm text-muted-foreground mb-2">Sources</p>
            <div className="space-y-1">
              {fundingRoundCount > 0 && (
                <Badge variant="secondary" className="flex items-center gap-1 w-fit">
                  <Target className="h-3 w-3" />
                  {fundingRoundCount}
                </Badge>
              )}
              {marketBasedCount > 0 && (
                <Badge variant="outline" className="flex items-center gap-1 w-fit">
                  <BarChart3 className="h-3 w-3" />
                  {marketBasedCount}
                </Badge>
              )}
              {manualCount > 0 && (
                <Badge variant="default" className="flex items-center gap-1 w-fit">
                  <Edit3 className="h-3 w-3" />
                  {manualCount}
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Chart */}
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={categorizedData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="date" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
                tickFormatter={(value) => `${(value / 1000000).toFixed(0)}M`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: '20px' }}
                iconType="line"
              />
              <Line 
                type="monotone" 
                dataKey="fundingRound" 
                stroke="hsl(var(--primary))" 
                strokeWidth={3}
                name="Funding Round"
                connectNulls={false}
                dot={{ fill: 'hsl(var(--primary))', r: 6 }}
              />
              <Line 
                type="monotone" 
                dataKey="marketBased" 
                stroke="hsl(var(--chart-2))" 
                strokeWidth={2}
                strokeDasharray="5 5"
                name="Market-based"
                connectNulls={false}
                dot={{ fill: 'hsl(var(--chart-2))', r: 4 }}
              />
              <Line 
                type="monotone" 
                dataKey="manual" 
                stroke="hsl(var(--chart-3))" 
                strokeWidth={2}
                name="Manual Entry"
                connectNulls={false}
                dot={{ fill: 'hsl(var(--chart-3))', r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Timeline */}
        <div className="space-y-2">
          <h3 className="font-semibold text-sm">Timeline</h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto">
            {sortedValuations.reverse().map((valuation) => {
              const isFundingRound = valuation.source.includes('Funding Round');
              const isMarketBased = valuation.source.includes('Market-based') || valuation.source.includes('Auto-calculated');
              
              return (
                <div key={valuation.id} className="flex items-center gap-3 p-3 border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-shrink-0">
                    {isFundingRound ? (
                      <div className="h-3 w-3 rounded-full bg-primary" />
                    ) : isMarketBased ? (
                      <div className="h-3 w-3 rounded-full border-2 border-chart-2" />
                    ) : (
                      <div className="h-3 w-3 rounded-full bg-chart-3" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <div className="flex items-center justify-between">
                      <p className="font-medium">{formatCurrency(valuation.post_money_valuation_dkk, 0)}</p>
                      <p className="text-sm text-muted-foreground">{format(new Date(valuation.as_of_date), 'dd MMM yyyy')}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">{valuation.source}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
