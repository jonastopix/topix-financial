import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { MoreVertical, Check, X, Download, Eye } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useDataRequestManagement } from '@/hooks/useDataAccessRequests';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export function DataAccessRequestsTable() {
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string>('');
  const [rejectionReason, setRejectionReason] = useState('');

  const { data: requests, isLoading } = useQuery({
    queryKey: ['admin-data-access-requests'],
    queryFn: async () => {
      // Get requests
      const { data: requestsData, error: requestsError } = await supabase
        .from('data_access_requests')
        .select('*')
        .order('requested_at', { ascending: false });
      
      if (requestsError) throw requestsError;

      // Get user profiles for each request
      const userIds = requestsData.map(r => r.user_id);
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name')
        .in('id', userIds);
      
      if (profilesError) throw profilesError;

      // Merge data
      const enrichedRequests = requestsData.map(request => ({
        ...request,
        user_profile: profiles?.find(p => p.id === request.user_id)
      }));
      
      return enrichedRequests;
    }
  });

  const { approveRequest, rejectRequest, generateDataFile } = useDataRequestManagement();

  const handleApprove = (requestId: string) => {
    approveRequest.mutate(requestId);
  };

  const handleRejectClick = (requestId: string) => {
    setSelectedRequestId(requestId);
    setRejectDialogOpen(true);
  };

  const handleRejectConfirm = () => {
    if (rejectionReason.trim()) {
      rejectRequest.mutate({ requestId: selectedRequestId, reason: rejectionReason });
      setRejectDialogOpen(false);
      setRejectionReason('');
    }
  };

  const handleGenerateData = (requestId: string) => {
    generateDataFile.mutate(requestId);
  };

  const formatRequestType = (type: string) => {
    const types = {
      personal_data: 'Personlige oplysninger',
      company_data: 'Virksomhedsdata',
      full_export: 'Fuld export'
    };
    return types[type as keyof typeof types] || type;
  };

  const formatStatus = (status: string) => {
    const statuses = {
      pending: 'Afventer',
      approved: 'Godkendt',
      rejected: 'Afvist',
      completed: 'Færdig'
    };
    return statuses[status as keyof typeof statuses] || status;
  };

  const getStatusVariant = (status: string) => {
    const variants = {
      pending: 'outline' as const,
      approved: 'default' as const,
      rejected: 'destructive' as const,
      completed: 'default' as const
    };
    return variants[status as keyof typeof variants] || 'outline' as const;
  };

  if (isLoading) {
    return <div>Indlæser...</div>;
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Data Anmodninger</CardTitle>
          <CardDescription>
            Administrer bruger anmodninger om data export
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto w-full max-w-full">
            <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Bruger</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Anmodet</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Handlinger</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {requests?.map((request) => (
                <TableRow key={request.id}>
                  <TableCell>
                    <div className="font-medium">{request.user_profile?.full_name || 'Ukendt'}</div>
                  </TableCell>
                  <TableCell>{formatRequestType(request.request_type)}</TableCell>
                  <TableCell>{format(new Date(request.requested_at), 'dd/MM/yyyy HH:mm')}</TableCell>
                  <TableCell>
                    <Badge variant={getStatusVariant(request.status)}>
                      {formatStatus(request.status)}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {request.status === 'pending' && (
                          <>
                            <DropdownMenuItem onClick={() => handleApprove(request.id)}>
                              <Check className="mr-2 h-4 w-4" />
                              Godkend
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleRejectClick(request.id)}>
                              <X className="mr-2 h-4 w-4" />
                              Afvis
                            </DropdownMenuItem>
                          </>
                        )}
                        {request.status === 'approved' && (
                          <DropdownMenuItem onClick={() => handleGenerateData(request.id)}>
                            <Download className="mr-2 h-4 w-4" />
                            Generer Data Fil
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Afvis Anmodning</DialogTitle>
            <DialogDescription>
              Angiv en begrundelse for afvisning af data anmodningen
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Begrundelse</Label>
              <Textarea
                placeholder="Skriv hvorfor anmodningen afvises..."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialogOpen(false)}>
              Annuller
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleRejectConfirm}
              disabled={!rejectionReason.trim()}
            >
              Afvis Anmodning
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
