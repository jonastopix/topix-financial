import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Upload, X, CheckCircle2, Download } from 'lucide-react';
import { useRole } from '@/contexts/RoleContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import * as XLSX from 'xlsx';

const MONTH_NAME_TO_NUMBER: Record<string, number> = {
  'januar': 1, 'februar': 2, 'marts': 3, 'april': 4,
  'maj': 5, 'juni': 6, 'juli': 7, 'august': 8,
  'september': 9, 'oktober': 10, 'november': 11, 'december': 12
};

const getMonthNumber = (monthName: string): number | undefined => {
  const normalized = monthName?.toLowerCase().trim();
  return MONTH_NAME_TO_NUMBER[normalized];
};

interface MonthlyReportImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId?: string;
  onImportComplete: () => void;
}

interface ParsedRow {
  period_month: number;
  period_year: number;
  revenue_dkk: number;
  budget_revenue_dkk: number;
  ebitda_dkk: number;
  budget_ebitda_dkk: number;
  marketing_cost_dkk: number;
  budget_marketing_cost_dkk: number;
  salary_cost_dkk?: number;
  budget_salary_cost_dkk?: number;
}

interface ImportResult {
  newMonths: Array<{ month: number; year: number }>;
  updatedMonths: Array<{ month: number; year: number }>;
  totalRevenue: number;
  totalEbitda: number;
  totalMarketing: number;
}

const MonthlyReportImportDialog = ({ 
  open, 
  onOpenChange, 
  companyId: founderCompanyId,
  onImportComplete 
}: MonthlyReportImportDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<ParsedRow[]>([]);
  const [importing, setImporting] = useState(false);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string>('');
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [budgetOnlyMode, setBudgetOnlyMode] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const { toast } = useToast();
  const { isAdmin } = useRole();

  const { data: companies } = useQuery({
    queryKey: ['all-companies-for-import'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      return data;
    },
    enabled: isAdmin && open,
  });

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    setFile(selectedFile);

    const isExcel = selectedFile.name.endsWith('.xlsx') || selectedFile.name.endsWith('.xls');

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        if (isExcel) {
          // Parse Excel file (Monday.com format)
          const data = event.target?.result;
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 }) as any[][];
          
          if (jsonData.length < 2) {
            toast({
              title: 'Fejl',
              description: 'Excel filen skal indeholde overskrifter og mindst én række data',
              variant: 'destructive',
            });
            return;
          }

          // Monday.com format has title rows before headers - find the row with "Name" column
          let headerRowIndex = -1;
          for (let i = 0; i < Math.min(10, jsonData.length); i++) {
            const row = jsonData[i] as string[];
            if (row && row.some(cell => cell?.toString().toLowerCase().trim() === 'name')) {
              headerRowIndex = i;
              break;
            }
          }

          if (headerRowIndex === -1) {
            toast({
              title: 'Fejl',
              description: 'Kunne ikke finde header-rækken med "Name" kolonnen i Excel-filen',
              variant: 'destructive',
            });
            return;
          }

          const headers = (jsonData[headerRowIndex] as string[]).map(h => h?.toLowerCase().trim());
          const dataRows = jsonData.slice(headerRowIndex + 1).filter(row => Array.isArray(row) && row.length > 0);
          
          console.log('Found header row at index:', headerRowIndex);
          console.log('Excel headers:', headers);
          console.log('First few data rows:', dataRows.slice(0, 3));
          
          // Find column indices - matching exact Monday.com export format
          const nameIndex = headers.findIndex(h => h === 'name' || h.includes('navn'));
          const revenueIndex = headers.findIndex(h => h === 'omsætning');
          const budgetRevenueIndex = headers.findIndex(h => h === 'budget omsætning');
          const marketingIndex = headers.findIndex(h => h === 'marketing omk.');
          const budgetMarketingIndex = headers.findIndex(h => h === 'budget marketing');
          const salaryIndex = headers.findIndex(h => h === 'løn omk.' || h === 'lønomkostninger');
          const budgetSalaryIndex = headers.findIndex(h => h === 'budget løn');
          const ebitdaIndex = headers.findIndex(h => h === 'resultat før skat');
          const budgetEbitdaIndex = headers.findIndex(h => h === 'budget resultat før skat');
          
          console.log('Column indices:', { nameIndex, revenueIndex, budgetRevenueIndex, marketingIndex, budgetMarketingIndex, ebitdaIndex, budgetEbitdaIndex });
          
          const parsed: ParsedRow[] = [];
          
          for (const row of dataRows.slice(0, 5)) { // Preview first 5
            console.log('Row:', row);
            console.log('Name column value:', row[nameIndex]);
            console.log('Name column type:', typeof row[nameIndex]);
            
            if (!row[nameIndex]) {
              console.log('Skipping row - no name value');
              continue;
            }
            
            const monthName = String(row[nameIndex]).trim();
            const month = getMonthNumber(monthName);
            
            console.log('Processing:', { 
              monthName, 
              monthNameLower: monthName.toLowerCase(),
              month, 
              revenue: row[revenueIndex],
              ebitda: row[ebitdaIndex]
            });
            
            if (!month) {
              console.log('Skipping row - month not recognized:', monthName);
              continue;
            }
            
            parsed.push({
              period_month: month,
              period_year: selectedYear,
              revenue_dkk: parseFloat(row[revenueIndex]) || 0,
              budget_revenue_dkk: parseFloat(row[budgetRevenueIndex]) || 0,
              ebitda_dkk: parseFloat(row[ebitdaIndex]) || 0,
              budget_ebitda_dkk: parseFloat(row[budgetEbitdaIndex]) || 0,
              marketing_cost_dkk: parseFloat(row[marketingIndex]) || 0,
              budget_marketing_cost_dkk: parseFloat(row[budgetMarketingIndex]) || 0,
              salary_cost_dkk: salaryIndex >= 0 ? parseFloat(row[salaryIndex]) || undefined : undefined,
              budget_salary_cost_dkk: budgetSalaryIndex >= 0 ? parseFloat(row[budgetSalaryIndex]) || 0 : 0,
            });
          }
          
          console.log('Parsed preview:', parsed);
          
          if (parsed.length === 0) {
            toast({
              title: 'Ingen data fundet',
              description: 'Kunne ikke finde gyldige månedsnavne i Excel-filen. Tjek at "Name" kolonnen indeholder danske månedsnavne (januar, februar, osv.)',
              variant: 'destructive',
            });
          }
          
          setPreview(parsed);
        } else {
          // Parse CSV file (original format)
          const text = event.target?.result as string;
          const rows = text.split('\n').filter(row => row.trim());
          
          if (rows.length < 2) {
            toast({
              title: 'Fejl',
              description: 'CSV filen skal indeholde overskrifter og mindst én række data',
              variant: 'destructive',
            });
            return;
          }

          const headers = rows[0].split(',').map(h => h.trim().toLowerCase());
          const dataRows = rows.slice(1, 6); // Preview first 5 rows

          const parsed: ParsedRow[] = [];
          
          for (const row of dataRows) {
            const values = row.split(',').map(v => v.trim());
            
            const monthIndex = headers.findIndex(h => h.includes('måned') || h === 'month');
            const yearIndex = headers.findIndex(h => h.includes('år') || h === 'year');
            const revenueIndex = headers.findIndex(h => 
              (h.includes('omsætning') || h.includes('revenue')) && !h.includes('budget')
            );
            const budgetRevenueIndex = headers.findIndex(h => 
              (h.includes('omsætning') || h.includes('revenue')) && h.includes('budget')
            );
            const ebitdaIndex = headers.findIndex(h => 
              (h.includes('resultat') || h.includes('ebitda')) && !h.includes('budget')
            );
            const budgetEbitdaIndex = headers.findIndex(h => 
              (h.includes('resultat') || h.includes('ebitda')) && h.includes('budget')
            );
            const marketingIndex = headers.findIndex(h => 
              h.includes('marketing') && !h.includes('budget')
            );
            const budgetMarketingIndex = headers.findIndex(h => 
              h.includes('marketing') && h.includes('budget')
            );

            if (monthIndex === -1 || yearIndex === -1) {
              toast({
                title: 'Fejl',
                description: 'CSV filen skal indeholde kolonner for Måned og År',
                variant: 'destructive',
              });
              return;
            }

            const salaryIndex = headers.findIndex(h => 
              (h.includes('løn') || h.includes('salary')) && !h.includes('budget')
            );
            const budgetSalaryIndex = headers.findIndex(h => 
              (h.includes('løn') || h.includes('salary')) && h.includes('budget')
            );

            parsed.push({
              period_month: parseInt(values[monthIndex]),
              period_year: parseInt(values[yearIndex]),
              revenue_dkk: parseFloat(values[revenueIndex]) || 0,
              budget_revenue_dkk: parseFloat(values[budgetRevenueIndex]) || 0,
              ebitda_dkk: parseFloat(values[ebitdaIndex]) || 0,
              budget_ebitda_dkk: parseFloat(values[budgetEbitdaIndex]) || 0,
              marketing_cost_dkk: parseFloat(values[marketingIndex]) || 0,
              budget_marketing_cost_dkk: parseFloat(values[budgetMarketingIndex]) || 0,
              salary_cost_dkk: salaryIndex >= 0 ? parseFloat(values[salaryIndex]) || undefined : undefined,
              budget_salary_cost_dkk: budgetSalaryIndex >= 0 ? parseFloat(values[budgetSalaryIndex]) || 0 : 0,
            });
          }

          setPreview(parsed);
        }
      } catch (error) {
        console.error('Parse error:', error);
        toast({
          title: 'Fejl',
          description: 'Kunne ikke læse filen. Tjek at formatet er korrekt.',
          variant: 'destructive',
        });
      }
    };

    if (isExcel) {
      reader.readAsArrayBuffer(selectedFile);
    } else {
      reader.readAsText(selectedFile);
    }
  };

  const handleImport = async () => {
    if (!file) return;

    const targetCompanyId = isAdmin ? selectedCompanyId : founderCompanyId;
    
    if (!targetCompanyId) {
      toast({
        title: 'Fejl',
        description: 'Vælg venligst et selskab',
        variant: 'destructive',
      });
      return;
    }

    setImporting(true);

    try {
      const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        try {
          const records: any[] = [];

          if (isExcel) {
            // Parse Excel file (Monday.com format)
            const data = event.target?.result;
            const workbook = XLSX.read(data, { type: 'array' });
            const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
            const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 }) as any[][];
            
            // Find header row with "Name" column
            let headerRowIndex = -1;
            for (let i = 0; i < Math.min(10, jsonData.length); i++) {
              const row = jsonData[i] as string[];
              if (row && row.some(cell => cell?.toString().toLowerCase().trim() === 'name')) {
                headerRowIndex = i;
                break;
              }
            }

            if (headerRowIndex === -1) {
              throw new Error('Kunne ikke finde header-rækken med "Name" kolonnen');
            }

            const headers = (jsonData[headerRowIndex] as string[]).map(h => h?.toLowerCase().trim());
            const dataRows = jsonData.slice(headerRowIndex + 1).filter(row => Array.isArray(row) && row.length > 0);
            
            // Match exact Monday.com export format
            const nameIndex = headers.findIndex(h => h === 'name' || h.includes('navn'));
            const revenueIndex = headers.findIndex(h => h === 'omsætning');
            const budgetRevenueIndex = headers.findIndex(h => h === 'budget omsætning');
            const marketingIndex = headers.findIndex(h => h === 'marketing omk.');
            const budgetMarketingIndex = headers.findIndex(h => h === 'budget marketing');
            const salaryIndex = headers.findIndex(h => h === 'løn omk.' || h === 'lønomkostninger');
            const budgetSalaryIndex = headers.findIndex(h => h === 'budget løn');
            const ebitdaIndex = headers.findIndex(h => h === 'resultat før skat');
            const budgetEbitdaIndex = headers.findIndex(h => h === 'budget resultat før skat');
            
            for (const row of dataRows) {
              if (!row[nameIndex]) continue;
              
              const monthName = row[nameIndex] as string;
              const month = getMonthNumber(monthName);
              
              if (!month || month < 1 || month > 12) continue;
              
              records.push({
                company_id: targetCompanyId,
                period_month: month,
                period_year: selectedYear,
                revenue_dkk: budgetOnlyMode ? null : (parseFloat(row[revenueIndex]) || null),
                budget_revenue_dkk: parseFloat(row[budgetRevenueIndex]) || 0,
                ebitda_dkk: budgetOnlyMode ? null : (parseFloat(row[ebitdaIndex]) || null),
                budget_ebitda_dkk: parseFloat(row[budgetEbitdaIndex]) || 0,
                marketing_cost_dkk: budgetOnlyMode ? null : (parseFloat(row[marketingIndex]) || 0),
                budget_marketing_cost_dkk: parseFloat(row[budgetMarketingIndex]) || 0,
                salary_cost_dkk: budgetOnlyMode ? null : (salaryIndex >= 0 ? parseFloat(row[salaryIndex]) || null : null),
                budget_salary_cost_dkk: budgetSalaryIndex >= 0 ? parseFloat(row[budgetSalaryIndex]) || 0 : 0,
                cash_dkk: budgetOnlyMode ? null : 0,
                new_customers: budgetOnlyMode ? null : 0,
              });
            }
          } else {
            // Parse CSV file (original format)
            const text = event.target?.result as string;
            const rows = text.split('\n').filter(row => row.trim());
            const headers = rows[0].split(',').map(h => h.trim().toLowerCase());
            const dataRows = rows.slice(1);

            for (const row of dataRows) {
              const values = row.split(',').map(v => v.trim());
              
              const monthIndex = headers.findIndex(h => h.includes('måned') || h === 'month');
              const yearIndex = headers.findIndex(h => h.includes('år') || h === 'year');
              const revenueIndex = headers.findIndex(h => 
                (h.includes('omsætning') || h.includes('revenue')) && !h.includes('budget')
              );
              const budgetRevenueIndex = headers.findIndex(h => 
                (h.includes('omsætning') || h.includes('revenue')) && h.includes('budget')
              );
              const ebitdaIndex = headers.findIndex(h => 
                (h.includes('resultat') || h.includes('ebitda')) && !h.includes('budget')
              );
              const budgetEbitdaIndex = headers.findIndex(h => 
                (h.includes('resultat') || h.includes('ebitda')) && h.includes('budget')
              );
              const marketingIndex = headers.findIndex(h => 
                h.includes('marketing') && !h.includes('budget')
              );
              const budgetMarketingIndex = headers.findIndex(h => 
                h.includes('marketing') && h.includes('budget')
              );
              const salaryIndex = headers.findIndex(h => 
                (h.includes('løn') || h.includes('salary')) && !h.includes('budget')
              );
              const budgetSalaryIndex = headers.findIndex(h => 
                (h.includes('løn') || h.includes('salary')) && h.includes('budget')
              );

              const month = parseInt(values[monthIndex]);
              const year = parseInt(values[yearIndex]);

              if (month < 1 || month > 12 || year < 2000 || year > 2100) {
                continue;
              }

              records.push({
                company_id: targetCompanyId,
                period_month: month,
                period_year: year,
                revenue_dkk: budgetOnlyMode ? null : (parseFloat(values[revenueIndex]) || null),
                budget_revenue_dkk: parseFloat(values[budgetRevenueIndex]) || 0,
                ebitda_dkk: budgetOnlyMode ? null : (parseFloat(values[ebitdaIndex]) || null),
                budget_ebitda_dkk: parseFloat(values[budgetEbitdaIndex]) || 0,
                marketing_cost_dkk: budgetOnlyMode ? null : (parseFloat(values[marketingIndex]) || 0),
                budget_marketing_cost_dkk: parseFloat(values[budgetMarketingIndex]) || 0,
                salary_cost_dkk: budgetOnlyMode ? null : (salaryIndex >= 0 ? parseFloat(values[salaryIndex]) || null : null),
                budget_salary_cost_dkk: budgetSalaryIndex >= 0 ? parseFloat(values[budgetSalaryIndex]) || 0 : 0,
                cash_dkk: budgetOnlyMode ? null : 0,
                new_customers: budgetOnlyMode ? null : 0,
              });
            }
          }

          // Check which months already exist
          const { data: existingReports } = await supabase
            .from('monthly_reports')
            .select('period_month, period_year')
            .eq('company_id', targetCompanyId)
            .in('period_month', records.map(r => r.period_month))
            .eq('period_year', selectedYear);

          const existingSet = new Set(
            existingReports?.map(r => `${r.period_year}-${r.period_month}`) || []
          );

          const newMonths: Array<{ month: number; year: number }> = [];
          const updatedMonths: Array<{ month: number; year: number }> = [];

          records.forEach(record => {
            const key = `${record.period_year}-${record.period_month}`;
            if (existingSet.has(key)) {
              updatedMonths.push({ month: record.period_month, year: record.period_year });
            } else {
              newMonths.push({ month: record.period_month, year: record.period_year });
            }
          });

          const { error } = await supabase
            .from('monthly_reports')
            .upsert(records, {
              onConflict: 'company_id,period_year,period_month',
            });

          if (error) throw error;

          // Calculate totals
          const totalRevenue = records.reduce((sum, r) => sum + r.revenue_dkk, 0);
          const totalEbitda = records.reduce((sum, r) => sum + r.ebitda_dkk, 0);
          const totalMarketing = records.reduce((sum, r) => sum + r.marketing_cost_dkk, 0);

          setImportResult({
            newMonths,
            updatedMonths,
            totalRevenue,
            totalEbitda,
            totalMarketing,
          });
          
          setShowConfirmation(true);
          onImportComplete();
        } catch (error) {
          console.error('Import error:', error);
          throw error;
        }
      };

      if (isExcel) {
        reader.readAsArrayBuffer(file);
      } else {
        reader.readAsText(file);
      }
    } catch (error) {
      console.error('Import error:', error);
      toast({
        title: 'Fejl',
        description: 'Der opstod en fejl under importen',
        variant: 'destructive',
      });
    } finally {
      setImporting(false);
    }

    onImportComplete();
  };

  const handleDownloadTemplate = () => {
    const months = [
      'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni',
      'Juli', 'August', 'September', 'Oktober', 'November', 'December'
    ];

    const templateData = months.map((month, index) => ({
      'Måned': month,
      'År': selectedYear,
      'Budget Omsætning': '',
      'Budget EBITDA': '',
      'Budget Marketing': '',
      'Budget Løn': ''
    }));

    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Budget');
    XLSX.writeFile(wb, `budget_template_${selectedYear}.xlsx`);
    
    toast({
      title: "Template downloadet",
      description: `Budget template for ${selectedYear} er downloadet. Udfyld Excel-filen og upload den igen.`,
    });
  };

  const handleClose = () => {
    setFile(null);
    setPreview([]);
    setSelectedCompanyId('');
    setShowConfirmation(false);
    setImportResult(null);
    onOpenChange(false);
  };

  const getMonthName = (month: number): string => {
    const months = ['Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni', 
                    'Juli', 'August', 'September', 'Oktober', 'November', 'December'];
    return months[month - 1] || '';
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {showConfirmation ? 'Import gennemført!' : 'Importér månedlige tal fra Excel/CSV'}
          </DialogTitle>
        </DialogHeader>

        {showConfirmation && importResult ? (
          <div className="space-y-6 py-4">
            <div className="flex flex-col items-center justify-center gap-4">
              <div className="relative">
                <CheckCircle2 className="h-16 w-16 text-green-500" />
                <div className="absolute inset-0 animate-ping">
                  <CheckCircle2 className="h-16 w-16 text-green-500 opacity-20" />
                </div>
              </div>
              <p className="text-lg font-medium text-center">
                {importResult.newMonths.length + importResult.updatedMonths.length} måneder importeret
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {importResult.newMonths.length > 0 && (
                <div className="border rounded-lg p-4 bg-green-50 dark:bg-green-950/20">
                  <h3 className="font-semibold text-green-700 dark:text-green-400 mb-2 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Nye måneder ({importResult.newMonths.length})
                  </h3>
                  <ul className="space-y-1 text-sm">
                    {importResult.newMonths.map((m, i) => (
                      <li key={i} className="text-green-600 dark:text-green-500">
                        {getMonthName(m.month)} {m.year}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {importResult.updatedMonths.length > 0 && (
                <div className="border rounded-lg p-4 bg-yellow-50 dark:bg-yellow-950/20">
                  <h3 className="font-semibold text-yellow-700 dark:text-yellow-400 mb-2 flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4" />
                    Opdaterede måneder ({importResult.updatedMonths.length})
                  </h3>
                  <ul className="space-y-1 text-sm">
                    {importResult.updatedMonths.map((m, i) => (
                      <li key={i} className="text-yellow-600 dark:text-yellow-500">
                        {getMonthName(m.month)} {m.year}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="border rounded-lg p-4 bg-muted/50">
              <h3 className="font-semibold mb-3">Importerede totaler</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Total omsætning</p>
                  <p className="text-2xl font-bold text-foreground">
                    {importResult.totalRevenue.toLocaleString('da-DK')} kr.
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Total resultat</p>
                  <p className="text-2xl font-bold text-foreground">
                    {importResult.totalEbitda.toLocaleString('da-DK')} kr.
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Total marketing</p>
                  <p className="text-2xl font-bold text-foreground">
                    {importResult.totalMarketing.toLocaleString('da-DK')} kr.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-center">
              <Button onClick={handleClose} size="lg">
                Luk
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
          {isAdmin && (
            <div className="space-y-2">
              <Label>Vælg selskab</Label>
              <Select value={selectedCompanyId} onValueChange={setSelectedCompanyId}>
                <SelectTrigger>
                  <SelectValue placeholder="Vælg selskab" />
                </SelectTrigger>
                <SelectContent>
                  {companies?.map((company) => (
                    <SelectItem key={company.id} value={company.id}>
                      {company.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
            <input
              type="checkbox"
              id="budgetOnlyMode"
              checked={budgetOnlyMode}
              onChange={(e) => setBudgetOnlyMode(e.target.checked)}
              className="h-4 w-4 rounded border-border"
            />
            <div className="flex-1">
              <Label htmlFor="budgetOnlyMode" className="cursor-pointer text-sm font-medium">
                Importér budget for hele året
              </Label>
              <p className="text-xs text-muted-foreground mt-1">
                Upload budget-tal for alle 12 måneder. Du kan senere udfylde faktiske tal måned for måned.
              </p>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Vælg år (for Excel import)</Label>
            <Select value={selectedYear.toString()} onValueChange={(val) => setSelectedYear(parseInt(val))}>
              <SelectTrigger>
                <SelectValue placeholder="Vælg år" />
              </SelectTrigger>
              <SelectContent>
                {Array.from({ length: 11 }, (_, i) => new Date().getFullYear() - 5 + i).map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <Label>Upload fil</Label>
                <p className="text-xs text-muted-foreground mt-1">
                  Upload budget for hele året eller månedlige rapporter
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleDownloadTemplate}
              >
                <Download className="h-4 w-4 mr-2" />
                Download Template
              </Button>
            </div>
            <div className="flex gap-2">
              <Input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileChange}
                className="flex-1"
              />
              {file && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setFile(null);
                    setPreview([]);
                  }}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            <p className="text-sm text-muted-foreground">
              <strong>Monday.com Excel:</strong> Name (måned), Omsætning, Budget omsætning, Resultat før skat, Budget resultat før skat, Marketing omk., Budget marketing<br/>
              <strong>CSV format:</strong> Måned, År, Omsætning, Omsætning Budget, Resultat før skat, Resultat før skat Budget, Marketing Omkostning, Marketing Omkostning Budget
            </p>
          </div>

          {preview.length > 0 && (
            <div className="space-y-2">
              <Label>Preview (første 5 rækker)</Label>
              <div className="border rounded-lg overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-muted">
                    <tr>
                      <th className="p-2 text-left">Måned</th>
                      <th className="p-2 text-left">År</th>
                      <th className="p-2 text-right">Omsætning</th>
                      <th className="p-2 text-right">Budget</th>
                      <th className="p-2 text-right">Resultat</th>
                      <th className="p-2 text-right">Budget</th>
                      <th className="p-2 text-right">Marketing</th>
                      <th className="p-2 text-right">Budget</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, index) => (
                      <tr key={index} className="border-t">
                        <td className="p-2">{row.period_month}</td>
                        <td className="p-2">{row.period_year}</td>
                        <td className="p-2 text-right">{row.revenue_dkk.toLocaleString()}</td>
                        <td className="p-2 text-right">{row.budget_revenue_dkk.toLocaleString()}</td>
                        <td className="p-2 text-right">{row.ebitda_dkk.toLocaleString()}</td>
                        <td className="p-2 text-right">{row.budget_ebitda_dkk.toLocaleString()}</td>
                        <td className="p-2 text-right">{row.marketing_cost_dkk.toLocaleString()}</td>
                        <td className="p-2 text-right">{row.budget_marketing_cost_dkk.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={handleClose}>
                Annuller
              </Button>
              <Button
                onClick={handleImport}
                disabled={!file || preview.length === 0 || importing || (isAdmin && !selectedCompanyId)}
              >
                <Upload className="h-4 w-4 mr-2" />
                {importing ? 'Importerer...' : `Importér ${file ? 'alle rækker' : ''}`}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default MonthlyReportImportDialog;