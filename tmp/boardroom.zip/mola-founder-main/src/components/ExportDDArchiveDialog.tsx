import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Download, FileArchive, AlertTriangle, Loader2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ExportDDArchiveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  caseId: string;
  documentCount: number;
  totalSize: number;
  companyName: string;
}

export function ExportDDArchiveDialog({
  open,
  onOpenChange,
  caseId,
  documentCount,
  totalSize,
  companyName,
}: ExportDDArchiveDialogProps) {
  const [deleteFiles, setDeleteFiles] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const { toast } = useToast();

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke("export-dd-archive", {
        body: {
          caseId,
          deleteFilesFromPortal: deleteFiles,
        },
      });

      if (error) throw error;

      setDownloadUrl(data.archive_url);
      setExportComplete(true);

      toast({
        title: "DD arkiv eksporteret",
        description: `${documentCount} dokumenter blev eksporteret${deleteFiles ? " og slettet fra portalen" : ""}.`,
      });
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "Eksport fejlede",
        description: error.message || "Der opstod en fejl under eksport af DD arkivet.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = () => {
    if (downloadUrl) {
      window.open(downloadUrl, "_blank");
    }
  };

  const handleClose = () => {
    setExportComplete(false);
    setDownloadUrl(null);
    setDeleteFiles(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        {!exportComplete ? (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileArchive className="h-5 w-5" />
                Eksporter DD Arkiv
              </DialogTitle>
              <DialogDescription>
                Generer og download et komplet arkiv af alle due diligence dokumenter for {companyName}.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Antal dokumenter:</span>
                  <span className="font-medium">{documentCount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Total størrelse:</span>
                  <span className="font-medium">{formatFileSize(totalSize)}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="delete-files"
                    checked={deleteFiles}
                    onCheckedChange={(checked) => setDeleteFiles(checked as boolean)}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="delete-files" className="cursor-pointer font-medium">
                      Slet filer fra portal efter eksport
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Frigør plads i portalen. Metadata bevares i databasen.
                    </p>
                  </div>
                </div>
              </div>

              {deleteFiles && (
                <Alert variant="destructive">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Advarsel:</strong> Filer vil blive permanent slettet fra portalen. 
                    Sørg for at gemme det downloadede arkiv sikkert.
                  </AlertDescription>
                </Alert>
              )}

              <Alert>
                <AlertDescription className="text-sm">
                  Download linket er gyldigt i 7 dage. Arkivet indeholder alle dokumenter 
                  organiseret efter kategori samt en manifest fil med metadata.
                </AlertDescription>
              </Alert>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleClose} disabled={isExporting}>
                Annuller
              </Button>
              <Button onClick={handleExport} disabled={isExporting}>
                {isExporting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Eksporterer...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Eksporter Arkiv
                  </>
                )}
              </Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-green-600">
                <CheckCircle2 className="h-5 w-5" />
                Eksport Gennemført
              </DialogTitle>
              <DialogDescription>
                DD arkivet er blevet genereret og er klar til download.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="font-medium text-green-600">✓ Eksporteret</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Dokumenter:</span>
                  <span className="font-medium">{documentCount}</span>
                </div>
                {deleteFiles && (
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Filer slettet:</span>
                    <span className="font-medium text-orange-600">✓ Ja</span>
                  </div>
                )}
              </div>

              <Alert>
                <AlertDescription className="text-sm">
                  Download linket udløber om 7 dage. Gem arkivet sikkert på jeres 
                  Google Drive eller lokalt filsystem.
                </AlertDescription>
              </Alert>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>
                Luk
              </Button>
              <Button onClick={handleDownload}>
                <Download className="mr-2 h-4 w-4" />
                Download Arkiv
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
