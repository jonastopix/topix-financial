import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { usePortfolioPendingPR } from '@/hooks/usePortfolioPendingPR';
import { useNavigate } from 'react-router-dom';
import { Newspaper, Clock, ArrowRight, CheckCheck } from 'lucide-react';

export default function PendingPRAlertWidget() {
  const { totalPending, articlesByCompany, isLoading, approveAll, isApprovingAll } = usePortfolioPendingPR();
  const navigate = useNavigate();

  // Don't show if loading or no pending articles
  if (isLoading || totalPending === 0) {
    return null;
  }

  const companyCount = Object.keys(articlesByCompany).length;

  return (
    <Card className="p-4 border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/20">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center shrink-0">
            <Newspaper className="h-5 w-5 text-amber-600 dark:text-amber-400" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold">PR-artikler afventer godkendelse</h3>
              <Badge variant="secondary" className="bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-200">
                <Clock className="h-3 w-3 mr-1" />
                {totalPending}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              {totalPending} artikel{totalPending !== 1 ? 'er' : ''} fra {companyCount} selskab{companyCount !== 1 ? 'er' : ''} venter på review
            </p>
          </div>
        </div>
        <div className="flex gap-2 sm:shrink-0">
          <Button
            variant="outline"
            size="sm"
            onClick={() => approveAll()}
            disabled={isApprovingAll}
            className="bg-white dark:bg-background"
          >
            <CheckCheck className="h-4 w-4 mr-1" />
            Godkend alle
          </Button>
          <Button
            size="sm"
            onClick={() => navigate('/portfolio/pr')}
          >
            Gennemgå
            <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
