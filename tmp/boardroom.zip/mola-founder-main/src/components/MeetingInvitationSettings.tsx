import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Users, UserCheck, Building } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface MeetingInvitationSettingsProps {
  companyId: string;
  autoInviteResponsiblePartner?: boolean;
  autoInviteCoinvestors?: boolean;
  autoInviteDdPartners?: boolean;
  responsiblePartnerId?: string;
}

export function MeetingInvitationSettings({
  companyId,
  autoInviteResponsiblePartner = true,
  autoInviteCoinvestors = false,
  autoInviteDdPartners = false,
  responsiblePartnerId
}: MeetingInvitationSettingsProps) {
  const [inviteResponsible, setInviteResponsible] = useState(autoInviteResponsiblePartner);
  const [inviteCoinvestors, setInviteCoinvestors] = useState(autoInviteCoinvestors);
  const [inviteDdPartners, setInviteDdPartners] = useState(autoInviteDdPartners);

  // Get responsible partner info
  const { data: responsiblePartner } = useQuery({
    queryKey: ['partner', responsiblePartnerId],
    queryFn: async () => {
      if (!responsiblePartnerId) return null;
      const { data } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', responsiblePartnerId)
        .single();
      return data;
    },
    enabled: !!responsiblePartnerId
  });

  // Count co-investors
  const { data: coinvestorsCount } = useQuery({
    queryKey: ['coinvestors-count', companyId],
    queryFn: async () => {
      const { count } = await supabase
        .from('company_cap_table')
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId)
        .not('user_id', 'is', null);
      return count || 0;
    }
  });

  // Count DD partners
  const { data: ddPartnersCount } = useQuery({
    queryKey: ['dd-partners-count', companyId],
    queryFn: async () => {
      const { count } = await supabase
        .from('dd_partner_assignments')
        .select('*', { count: 'exact', head: true })
        .eq('company_id', companyId);
      return count || 0;
    }
  });

  const handleToggle = async (field: string, value: boolean) => {
    try {
      const { error } = await supabase
        .from('companies')
        .update({ [field]: value })
        .eq('id', companyId);

      if (error) throw error;
      toast.success('Invitation indstillinger opdateret');
    } catch (error) {
      console.error('Error updating invitation settings:', error);
      toast.error('Kunne ikke opdatere indstillinger');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5" />
          Automatiske Møde Invitationer
        </CardTitle>
        <CardDescription>
          Vælg hvem der automatisk skal inviteres når møde bookes via Calendly
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Responsible Partner */}
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <UserCheck className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="invite-partner" className="cursor-pointer">
                Ansvarlig Fund Partner
              </Label>
            </div>
            {responsiblePartner && (
              <p className="text-sm text-muted-foreground">
                {responsiblePartner.full_name}
              </p>
            )}
            {!responsiblePartnerId && (
              <p className="text-sm text-muted-foreground">
                Ingen ansvarlig partner tildelt
              </p>
            )}
          </div>
          <Switch
            id="invite-partner"
            checked={inviteResponsible}
            onCheckedChange={(checked) => {
              setInviteResponsible(checked);
              handleToggle('auto_invite_responsible_partner', checked);
            }}
            disabled={!responsiblePartnerId}
          />
        </div>

        {/* Co-investors */}
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <Building className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="invite-coinvestors" className="cursor-pointer">
                Med-investorer
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-sm text-muted-foreground">
                {coinvestorsCount || 0} medejere i cap table
              </p>
              {coinvestorsCount > 0 && (
                <Badge variant="secondary">{coinvestorsCount}</Badge>
              )}
            </div>
          </div>
          <Switch
            id="invite-coinvestors"
            checked={inviteCoinvestors}
            onCheckedChange={(checked) => {
              setInviteCoinvestors(checked);
              handleToggle('auto_invite_coinvestors', checked);
            }}
            disabled={!coinvestorsCount || coinvestorsCount === 0}
          />
        </div>

        {/* DD Partners */}
        <div className="flex items-center justify-between rounded-lg border p-4">
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-muted-foreground" />
              <Label htmlFor="invite-dd-partners" className="cursor-pointer">
                DD Partners
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-sm text-muted-foreground">
                {ddPartnersCount || 0} DD partners tildelt
              </p>
              {ddPartnersCount > 0 && (
                <Badge variant="secondary">{ddPartnersCount}</Badge>
              )}
            </div>
          </div>
          <Switch
            id="invite-dd-partners"
            checked={inviteDdPartners}
            onCheckedChange={(checked) => {
              setInviteDdPartners(checked);
              handleToggle('auto_invite_dd_partners', checked);
            }}
            disabled={!ddPartnersCount || ddPartnersCount === 0}
          />
        </div>

        <div className="rounded-lg bg-muted/50 p-4 text-sm text-muted-foreground">
          <p>
            💡 Disse personer vil automatisk modtage en kalender invitation når en founder booker møde via Calendly.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
