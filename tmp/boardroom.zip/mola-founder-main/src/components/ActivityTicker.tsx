import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { formatDistanceToNow } from 'date-fns';
import { da } from 'date-fns/locale';
import { RealtimeChannel } from '@supabase/supabase-js';
import { useActivityTickerNews } from '@/hooks/useActivityTickerNews';

interface ActivityEvent {
  id: string;
  event_type?: string;
  event_message: string;
  event_icon: string | null;
  created_at: string;
}

export function ActivityTicker() {
  const [realtimeEvents, setRealtimeEvents] = useState<ActivityEvent[]>([]);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);
  const { data: dynamicNews, isLoading } = useActivityTickerNews();

  useEffect(() => {
    // Fetch initial events from portfolio_activity_events (if any)
    const fetchInitialEvents = async () => {
      const { data, error } = await supabase
        .from('portfolio_activity_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Error fetching activity events:', error);
        return;
      }

      if (data) {
        setRealtimeEvents(data);
      }
    };

    fetchInitialEvents();

    // Set up realtime subscription for new events
    const activityChannel = supabase
      .channel('activity-ticker')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'portfolio_activity_events',
        },
        (payload) => {
          const newEvent = payload.new as ActivityEvent;
          setRealtimeEvents((prev) => [newEvent, ...prev.slice(0, 9)]);
        }
      )
      .subscribe();

    setChannel(activityChannel);

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, []);

  // Combine real-time events with dynamic news
  const allEvents: ActivityEvent[] = [
    ...realtimeEvents,
    ...(dynamicNews || []).map(news => ({
      id: news.id,
      event_message: news.message,
      event_icon: news.icon,
      created_at: news.created_at,
    })),
  ];

  // Don't render if loading or no events
  if (isLoading || allEvents.length === 0) {
    return null;
  }

  // Duplicate events for seamless loop
  const duplicatedEvents = [...allEvents, ...allEvents];

  return (
    <div className="relative overflow-hidden bg-primary/10 border-y border-primary/20 py-2">
      <div className="marquee-container">
        <div className="marquee-content">
          {duplicatedEvents.map((event, index) => (
            <div
              key={`${event.id}-${index}`}
              className="inline-flex items-center gap-3 px-6 whitespace-nowrap"
            >
              <span className="text-xl" role="img" aria-label="event icon">
                {event.event_icon || '📌'}
              </span>
              <span className="text-sm font-medium text-foreground">
                {event.event_message}
              </span>
              {event.event_type && (
                <span className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(event.created_at), {
                    addSuffix: true,
                    locale: da,
                  })}
                </span>
              )}
              <span className="text-muted-foreground/50">•</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
