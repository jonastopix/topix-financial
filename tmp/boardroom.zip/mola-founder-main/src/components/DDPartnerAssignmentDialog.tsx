import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAvailableDDPartners } from '@/hooks/useDDPartnerAssignments';
import { Loader2 } from 'lucide-react';

interface DDPartnerAssignmentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
  onAssign: (args: { userId: string; notes?: string; specialization: 'economic' | 'legal' }) => void;
}

export function DDPartnerAssignmentDialog({
  open,
  onOpenChange,
  companyId,
  onAssign,
}: DDPartnerAssignmentDialogProps) {
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [specialization, setSpecialization] = useState<'economic' | 'legal'>('economic');
  const { data: availablePartners, isLoading } = useAvailableDDPartners();

  const handleAssign = () => {
    if (!selectedUserId) return;
    
    onAssign({ userId: selectedUserId, notes: notes || undefined, specialization });
    setSelectedUserId('');
    setNotes('');
    setSpecialization('economic');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle>Tildel DD Partner</DialogTitle>
          <DialogDescription>
            Vælg en DD partner der skal have adgang til denne virksomhed
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="partner">DD Partner</Label>
            {isLoading ? (
              <div className="flex items-center justify-center py-4">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                <SelectTrigger id="partner">
                  <SelectValue placeholder="Vælg DD partner" />
                </SelectTrigger>
                <SelectContent>
                  {availablePartners?.map((partner) => (
                    <SelectItem key={partner.id} value={partner.id}>
                      {partner.full_name} {partner.company_name && `(${partner.company_name})`}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="specialization">Specialisering</Label>
            <Select value={specialization} onValueChange={(value: 'economic' | 'legal') => setSpecialization(value)}>
              <SelectTrigger id="specialization">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="economic">Økonomisk DD</SelectItem>
                <SelectItem value="legal">Legal DD</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Noter (valgfrit)</Label>
            <Textarea
              id="notes"
              placeholder="Tilføj noter om hvorfor denne partner er tildelt..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button onClick={handleAssign} disabled={!selectedUserId} variant="gradient">
            Tildel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
