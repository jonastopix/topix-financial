import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { 
  DollarSign, 
  TrendingUp, 
  Megaphone,
  Briefcase,
  Users, 
  Clock,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  TrendingDown,
  Minus
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import ConfettiCelebration from './ConfettiCelebration';

interface TokenizedMonthlyReportFormProps {
  token: string;
  tokenData: any;
  companyData: any;
  onSubmitSuccess: () => void;
}

interface FormData {
  revenue: string;
  budgetRevenue: string;
  ebitda: string;
  budgetEbitda: string;
  marketingCost: string;
  budgetMarketingCost: string;
  salaryCost: string;
  liquidity: string;
  newCustomers: string;
  comments: string;
}

const TokenizedMonthlyReportForm = ({ 
  token, 
  tokenData, 
  companyData,
  onSubmitSuccess 
}: TokenizedMonthlyReportFormProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<FormData>({
    revenue: '',
    budgetRevenue: '',
    ebitda: '',
    budgetEbitda: '',
    marketingCost: '',
    budgetMarketingCost: '',
    salaryCost: '',
    liquidity: '',
    newCustomers: '',
    comments: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [lastMonthData, setLastMonthData] = useState<any>(null);
  const { toast } = useToast();

  // Fetch existing report or budget for this period
  useEffect(() => {
    const fetchExistingData = async () => {
      if (!companyData?.id || !tokenData) return;
      
      // Check for existing report/budget for this exact period
      const { data: existingReport } = await supabase
        .from('monthly_reports')
        .select('*')
        .eq('company_id', companyData.id)
        .eq('period_month', tokenData.period_month)
        .eq('period_year', tokenData.period_year)
        .maybeSingle();
      
      if (existingReport) {
        // Pre-fill budget fields if this is a budget-only record
        if (existingReport.revenue_dkk === null && existingReport.budget_revenue_dkk !== null) {
          setFormData(prev => ({
            ...prev,
            budgetRevenue: existingReport.budget_revenue_dkk?.toString() || '',
            budgetEbitda: existingReport.budget_ebitda_dkk?.toString() || '',
            budgetMarketingCost: existingReport.budget_marketing_cost_dkk?.toString() || '',
          }));
          setLastMonthData(existingReport);
        }
      } else {
        // Fetch last month's data for reference
        const { data: lastMonth } = await supabase
          .from('monthly_reports')
          .select('*')
          .eq('company_id', companyData.id)
          .order('period_year', { ascending: false })
          .order('period_month', { ascending: false })
          .limit(1)
          .maybeSingle();
        
        if (lastMonth) {
          setLastMonthData(lastMonth);
          setFormData(prev => ({
            ...prev,
            budgetRevenue: lastMonth.budget_revenue_dkk?.toString() || '',
            budgetEbitda: lastMonth.budget_ebitda_dkk?.toString() || '',
            budgetMarketingCost: lastMonth.budget_marketing_cost_dkk?.toString() || '',
          }));
        }
      }
    };
    fetchExistingData();
  }, [companyData?.id, tokenData]);

  const monthNames = [
    'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni',
    'Juli', 'August', 'September', 'Oktober', 'November', 'December'
  ];

  const steps = [
    {
      title: 'Omsætning',
      description: 'Hvordan gik det med salget?',
      icon: DollarSign,
      fields: ['revenue', 'budgetRevenue'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Resultat',
      description: 'Hvad var jeres bundlinje?',
      icon: TrendingUp,
      fields: ['ebitda', 'budgetEbitda'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Marketing',
      description: 'Hvor meget brugte I på marketing?',
      icon: Megaphone,
      fields: ['marketingCost', 'budgetMarketingCost'],
      estimatedTime: '15 sek'
    },
    {
      title: 'Løn',
      description: 'Hvad var jeres lønudgifter?',
      icon: Briefcase,
      fields: ['salaryCost'],
      estimatedTime: '15 sek'
    },
    {
      title: 'Vækst & Likviditet',
      description: 'Nye kunder og cash position',
      icon: Users,
      fields: ['liquidity', 'newCustomers'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Kommentarer',
      description: 'Har du noget at tilføje? (valgfrit)',
      icon: Sparkles,
      fields: ['comments'],
      estimatedTime: '30 sek'
    },
  ];

  const totalSteps = steps.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const updateField = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isStepValid = () => {
    const currentFields = steps[currentStep].fields;
    
    // Comments step is optional
    if (currentStep === 4) return true;
    
    return currentFields.every(field => {
      const value = formData[field as keyof FormData];
      // Budget fields are optional
      if (field.includes('budget')) return true;
      return value && value.trim() !== '';
    });
  };

  const handleNext = () => {
    if (currentStep < totalSteps - 1 && isStepValid()) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!isStepValid()) {
      toast({
        title: "Udfyld alle felter",
        description: "Sørg for at alle påkrævede felter er udfyldt",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      // Upsert the monthly report (handles both new and budget updates)
      const { error: reportError } = await supabase
        .from('monthly_reports')
        .upsert({
          company_id: companyData.id,
          period_month: tokenData.period_month,
          period_year: tokenData.period_year,
          revenue_dkk: parseFloat(formData.revenue),
          budget_revenue_dkk: formData.budgetRevenue ? parseFloat(formData.budgetRevenue) : null,
          ebitda_dkk: parseFloat(formData.ebitda),
          budget_ebitda_dkk: formData.budgetEbitda ? parseFloat(formData.budgetEbitda) : null,
          marketing_cost_dkk: parseFloat(formData.marketingCost),
          budget_marketing_cost_dkk: formData.budgetMarketingCost ? parseFloat(formData.budgetMarketingCost) : null,
          salary_cost_dkk: formData.salaryCost ? parseFloat(formData.salaryCost) : null,
          cash_dkk: parseFloat(formData.liquidity),
          new_customers: parseInt(formData.newCustomers),
          note: formData.comments || null,
        }, {
          onConflict: 'company_id,period_month,period_year',
          ignoreDuplicates: false
        });

      if (reportError) throw reportError;

      // Mark token as used
      const { error: tokenError } = await supabase
        .from('monthly_report_tokens')
        .update({ 
          status: 'used',
          used_at: new Date().toISOString()
        })
        .eq('token', token);

      if (tokenError) throw tokenError;

      // Trigger milestone detection
      try {
        await supabase.functions.invoke('detect-milestones', {
          body: { companyId: companyData.id }
        });
      } catch (err) {
        console.error('Milestone detection failed:', err);
      }

      // Trigger valuation calculation
      try {
        await supabase.functions.invoke('calculate-valuation', {
          body: { companyId: companyData.id }
        });
      } catch (err) {
        console.error('Valuation calculation failed:', err);
      }

      setShowCelebration(true);
      
      setTimeout(() => {
        setShowCelebration(false);
        onSubmitSuccess();
      }, 3000);

    } catch (error: any) {
      console.error('Error submitting report:', error);
      toast({
        title: "Fejl",
        description: error.message || "Der opstod en fejl ved indsendelse af rapporten",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const renderInstantFeedback = (field: 'revenue' | 'ebitda' | 'marketingCost', budgetField: string) => {
    const actual = parseFloat(formData[field]);
    const budget = parseFloat(formData[budgetField as keyof FormData]);

    if (!actual || !budget) return null;

    const diff = actual - budget;
    const percentage = ((diff / budget) * 100).toFixed(1);
    const isPositive = diff > 0;
    const isNeutral = Math.abs(diff) < budget * 0.02; // Within 2%

    let Icon = Minus;
    let colorClass = 'text-muted-foreground';
    let message = 'På budget';

    if (!isNeutral) {
      Icon = isPositive ? TrendingUp : TrendingDown;
      if (field === 'marketingCost') {
        // For costs, lower is better
        colorClass = isPositive ? 'text-destructive' : 'text-success';
        message = isPositive ? 'Over budget' : 'Under budget';
      } else {
        // For revenue/EBITDA, higher is better
        colorClass = isPositive ? 'text-success' : 'text-destructive';
        message = isPositive ? 'Over budget' : 'Under budget';
      }
    }

    return (
      <div className={cn("flex items-center gap-2 mt-2 text-sm font-medium", colorClass)}>
        <Icon className="h-4 w-4" />
        <span>{message}: {Math.abs(parseFloat(percentage))}%</span>
      </div>
    );
  };

  const renderStepContent = () => {
    const step = steps[currentStep];
    const StepIcon = step.icon;

    return (
      <div className="space-y-6 animate-in fade-in-50 duration-300">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-primary/10 rounded-lg">
            <StepIcon className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">{step.title}</h2>
            <p className="text-muted-foreground">{step.description}</p>
          </div>
        </div>

        {currentStep === 0 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="revenue">Omsætning (DKK) *</Label>
              <Input
                id="revenue"
                type="number"
                placeholder="f.eks. 500000"
                value={formData.revenue}
                onChange={(e) => updateField('revenue', e.target.value)}
                className="text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetRevenue">Budget omsætning (DKK)</Label>
              <Input
                id="budgetRevenue"
                type="number"
                placeholder="f.eks. 450000"
                value={formData.budgetRevenue}
                onChange={(e) => updateField('budgetRevenue', e.target.value)}
                className="text-lg"
              />
              {renderInstantFeedback('revenue', 'budgetRevenue')}
            </div>
          </div>
        )}

        {currentStep === 1 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ebitda">EBITDA (DKK) *</Label>
              <Input
                id="ebitda"
                type="number"
                placeholder="f.eks. 100000"
                value={formData.ebitda}
                onChange={(e) => updateField('ebitda', e.target.value)}
                className="text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetEbitda">Budget EBITDA (DKK)</Label>
              <Input
                id="budgetEbitda"
                type="number"
                placeholder="f.eks. 90000"
                value={formData.budgetEbitda}
                onChange={(e) => updateField('budgetEbitda', e.target.value)}
                className="text-lg"
              />
              {renderInstantFeedback('ebitda', 'budgetEbitda')}
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="marketingCost">Marketingomkostninger (DKK) *</Label>
              <Input
                id="marketingCost"
                type="number"
                placeholder="f.eks. 50000"
                value={formData.marketingCost}
                onChange={(e) => updateField('marketingCost', e.target.value)}
                className="text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetMarketingCost">Budget marketing (DKK)</Label>
              <Input
                id="budgetMarketingCost"
                type="number"
                placeholder="f.eks. 60000"
                value={formData.budgetMarketingCost}
                onChange={(e) => updateField('budgetMarketingCost', e.target.value)}
                className="text-lg"
              />
              {renderInstantFeedback('marketingCost', 'budgetMarketingCost')}
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="salaryCost">Lønomkostninger (DKK) - valgfrit</Label>
              <Input
                id="salaryCost"
                type="number"
                placeholder="f.eks. 150000"
                value={formData.salaryCost}
                onChange={(e) => updateField('salaryCost', e.target.value)}
                className="text-lg"
              />
            </div>
          </div>
        )}

        {currentStep === 4 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="liquidity">Likviditet (DKK) *</Label>
              <Input
                id="liquidity"
                type="number"
                placeholder="f.eks. 200000"
                value={formData.liquidity}
                onChange={(e) => updateField('liquidity', e.target.value)}
                className="text-lg"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newCustomers">Nye kunder *</Label>
              <Input
                id="newCustomers"
                type="number"
                placeholder="f.eks. 12"
                value={formData.newCustomers}
                onChange={(e) => updateField('newCustomers', e.target.value)}
                className="text-lg"
              />
            </div>
          </div>
        )}

        {currentStep === 5 && (
          <div className="space-y-2">
            <Label htmlFor="comments">Kommentarer og opdateringer</Label>
            <Textarea
              id="comments"
              placeholder="Del gerne særlige events, udfordringer eller milepæle fra måneden..."
              value={formData.comments}
              onChange={(e) => updateField('comments', e.target.value)}
              className="min-h-32 text-lg"
            />
            <p className="text-sm text-muted-foreground">Dette felt er valgfrit</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <>
      {showCelebration && <ConfettiCelebration show={showCelebration} />}
      
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        {/* Header */}
        <div className="mb-8 text-center">
          {companyData.logo_url && (
            <img 
              src={companyData.logo_url} 
              alt={companyData.name}
              className="h-16 w-auto mx-auto mb-4 object-contain"
            />
          )}
          <h1 className="text-3xl font-bold mb-2">Månedsrapport</h1>
          <p className="text-muted-foreground">
            {monthNames[tokenData.period_month - 1]} {tokenData.period_year}
          </p>
        </div>

        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">
              Trin {currentStep + 1} af {totalSteps}
            </span>
            <span className="text-sm text-muted-foreground">
              {steps[currentStep].estimatedTime}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Form Card */}
        <Card className="p-6 mb-6">
          {renderStepContent()}
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between gap-4">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 0 || submitting}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Tilbage
          </Button>

          {currentStep < totalSteps - 1 ? (
            <Button
              onClick={handleNext}
              disabled={!isStepValid() || submitting}
              className="gap-2"
            >
              Næste
              <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={submitting}
              className="gap-2"
            >
              {submitting ? (
                <>
                  <Clock className="h-4 w-4 animate-spin" />
                  Indsender...
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  Indsend rapport
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </>
  );
};

export default TokenizedMonthlyReportForm;
