import { Card } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Cell } from 'recharts';
import { formatDKK } from '@/lib/returnsCalculations';
import { formatCompact } from '@/lib/formatters';
import type { CashFlow } from '@/lib/returnsCalculations';
import { format } from 'date-fns';

interface CashFlowChartProps {
  cashFlows: CashFlow[];
}

export function CashFlowChart({ cashFlows }: CashFlowChartProps) {
  const chartData = cashFlows.map((cf) => ({
    date: format(new Date(cf.date), 'MMM yyyy'),
    amount: cf.amount,
    type: cf.type,
    description: cf.description,
  }));

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-background border border-border p-3 rounded-lg shadow-lg">
          <p className="font-medium">{data.date}</p>
          <p className="text-sm text-muted-foreground">{data.description}</p>
          <p className={`font-bold ${data.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
            {formatDKK(Math.abs(data.amount))}
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Cash Flow Timeline</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 12 }}
            className="text-muted-foreground"
          />
          <YAxis 
            tickFormatter={(value) => formatCompact(value, 1)}
            tick={{ fontSize: 12 }}
            className="text-muted-foreground"
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={0} stroke="hsl(var(--border))" />
          <Bar 
            dataKey="amount" 
            radius={[4, 4, 0, 0]}
          >
            {chartData.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={entry.amount > 0 ? 'hsl(var(--chart-2))' : 'hsl(var(--chart-1))'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex items-center justify-center gap-6 mt-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded" style={{ backgroundColor: 'hsl(var(--chart-1))' }} />
          <span className="text-muted-foreground">Investments</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded" style={{ backgroundColor: 'hsl(var(--chart-2))' }} />
          <span className="text-muted-foreground">Distributions</span>
        </div>
      </div>
    </Card>
  );
}
