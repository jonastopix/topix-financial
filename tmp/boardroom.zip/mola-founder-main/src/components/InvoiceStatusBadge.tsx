import { Badge } from "@/components/ui/badge";

interface InvoiceStatusBadgeProps {
  status: string;
}

export function InvoiceStatusBadge({ status }: InvoiceStatusBadgeProps) {
  const statusConfig = {
    pending: { label: "Afventer", variant: "secondary" as const },
    paid: { label: "Betalt", variant: "default" as const },
    overdue: { label: "Forfalden", variant: "destructive" as const },
    cancelled: { label: "Annulleret", variant: "outline" as const },
  };

  const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

  return <Badge variant={config.variant}>{config.label}</Badge>;
}
