import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useDDPartnerAssignments } from '@/hooks/useDDPartnerAssignments';
import { DDPartnerAssignmentDialog } from './DDPartnerAssignmentDialog';
import { UserPlus, X, FileCheck, Mail, Building2 } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface DDPartnerTeamCardProps {
  companyId: string;
}

export function DDPartnerTeamCard({ companyId }: DDPartnerTeamCardProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [removeDialogOpen, setRemoveDialogOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<string | null>(null);
  
  const { assignments, isLoading, assignDDPartner, removeDDPartner, approveDDPartner, rejectDDPartner } = useDDPartnerAssignments(companyId);

  const handleRemove = (assignmentId: string) => {
    setSelectedAssignment(assignmentId);
    setRemoveDialogOpen(true);
  };

  const confirmRemove = () => {
    if (selectedAssignment) {
      removeDDPartner(selectedAssignment);
      setSelectedAssignment(null);
      setRemoveDialogOpen(false);
    }
  };

  return (
    <>
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <FileCheck className="h-5 w-5" />
                DD Partner Team
              </CardTitle>
              <CardDescription>
                Due diligence partnere der har adgang til dette selskab
              </CardDescription>
            </div>
            <Button onClick={() => setDialogOpen(true)} size="sm" variant="outline">
              <UserPlus className="h-4 w-4 mr-2" />
              Tildel DD Partner
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Indlæser...</p>
          ) : assignments.length === 0 ? (
            <div className="text-center py-8">
              <FileCheck className="h-12 w-12 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm text-muted-foreground">
                Ingen DD partnere tildelt endnu
              </p>
              <Button 
                onClick={() => setDialogOpen(true)} 
                variant="ghost" 
                size="sm"
                className="mt-3"
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Tildel første partner
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {assignments.map((assignment: any) => (
                <div
                  key={assignment.id}
                  className="flex items-start justify-between p-4 rounded-lg border border-border/50 hover:bg-accent/5 transition-colors"
                >
                  <div className="flex-1 space-y-2">
                     <div className="flex items-center gap-2">
                      <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                        <FileCheck className="h-4 w-4 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">
                            {assignment.profiles?.full_name || 'Ukendt navn'}
                          </p>
                          <Badge variant={assignment.specialization === 'economic' ? 'default' : 'secondary'} className="text-xs">
                            {assignment.specialization === 'economic' ? 'Økonomisk' : 'Legal'}
                          </Badge>
                        </div>
                        {assignment.profiles?.company_name && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Building2 className="h-3 w-3" />
                            {assignment.profiles.company_name}
                          </p>
                        )}
                      </div>
                    </div>
                    
                    {assignment.notes && (
                      <p className="text-sm text-muted-foreground pl-10">
                        {assignment.notes}
                      </p>
                    )}
                    
                    <div className="flex items-center gap-2 pl-10 text-xs text-muted-foreground">
                      <span>
                        Tildelt: {new Date(assignment.assigned_at).toLocaleDateString('da-DK')}
                      </span>
                      {assignment.approved_at && (
                        <span className="text-green-600">
                          • Godkendt: {new Date(assignment.approved_at).toLocaleDateString('da-DK')}
                        </span>
                      )}
                    </div>
                    
                    {assignment.approval_status === 'pending' && (
                      <div className="flex gap-2 pl-10 mt-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => approveDDPartner({ assignmentId: assignment.id })}
                          className="text-green-600 hover:text-green-700 hover:bg-green-50"
                        >
                          <FileCheck className="h-3 w-3 mr-1" />
                          Godkend {assignment.specialization === 'economic' ? 'Økonomisk' : 'Legal'} DD
                        </Button>
                      </div>
                    )}
                    
                    {assignment.approval_status === 'approved' && (
                      <div className="pl-10 mt-2">
                        <Badge variant="default" className="bg-green-600">
                          ✓ Godkendt
                        </Badge>
                      </div>
                    )}
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemove(assignment.id)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <DDPartnerAssignmentDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        companyId={companyId}
        onAssign={assignDDPartner}
      />

      <AlertDialog open={removeDialogOpen} onOpenChange={setRemoveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fjern DD Partner?</AlertDialogTitle>
            <AlertDialogDescription>
              Er du sikker på at du vil fjerne denne DD partner fra virksomheden? 
              De vil ikke længere have adgang til virksomhedsdata.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuller</AlertDialogCancel>
            <AlertDialogAction onClick={confirmRemove} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Fjern
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
