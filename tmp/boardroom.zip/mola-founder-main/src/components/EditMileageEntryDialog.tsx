import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { Pencil, MapPin, Building2, Car, RotateCcw, Calculator } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { cn } from '@/lib/utils';
import { MileageEntry, useMileageSettings } from '@/hooks/useMileage';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface EditMileageEntryDialogProps {
  entry: MileageEntry | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface EditFormData {
  paying_company_id: string;
  trip_date: Date;
  from_address_type: 'private' | 'office' | 'manual';
  from_address: string;
  to_company_id: string;
  to_address: string;
  purpose: string;
  distance_km: number;
  is_round_trip: boolean;
}

export function EditMileageEntryDialog({ entry, open, onOpenChange }: EditMileageEntryDialogProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { data: settings } = useMileageSettings();
  const [isCalculating, setIsCalculating] = useState(false);

  const form = useForm<EditFormData>({
    defaultValues: {
      paying_company_id: '',
      trip_date: new Date(),
      from_address_type: 'private',
      from_address: '',
      to_company_id: '',
      to_address: '',
      purpose: '',
      distance_km: 0,
      is_round_trip: false,
    },
  });

  // Load companies for dropdowns
  const { data: companies = [] } = useQuery({
    queryKey: ['companies-for-mileage'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, address, city, zipcode')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Reset form when entry changes
  useEffect(() => {
    if (entry && open) {
      form.reset({
        paying_company_id: entry.paying_company_id,
        trip_date: new Date(entry.trip_date),
        from_address_type: entry.from_address_type,
        from_address: entry.from_address,
        to_company_id: entry.to_company_id || '',
        to_address: entry.to_address,
        purpose: entry.purpose,
        distance_km: entry.distance_km,
        is_round_trip: false, // We don't store this, so default to false
      });
    }
  }, [entry, open, form]);

  // Update from_address when type changes
  const fromAddressType = form.watch('from_address_type');
  useEffect(() => {
    if (fromAddressType === 'private' && settings?.private_address) {
      form.setValue('from_address', settings.private_address);
    } else if (fromAddressType === 'office' && settings?.office_address) {
      form.setValue('from_address', settings.office_address);
    } else if (fromAddressType === 'manual') {
      form.setValue('from_address', '');
    }
  }, [fromAddressType, settings, form]);

  // Update to_address when company is selected
  const toCompanyId = form.watch('to_company_id');
  useEffect(() => {
    if (toCompanyId) {
      const company = companies.find(c => c.id === toCompanyId);
      if (company) {
        const fullAddress = [company.address, company.zipcode, company.city]
          .filter(Boolean)
          .join(', ');
        form.setValue('to_address', fullAddress || '');
      }
    }
  }, [toCompanyId, companies, form]);

  const updateMutation = useMutation({
    mutationFn: async (data: EditFormData) => {
      if (!entry) throw new Error('No entry to update');
      
      const distanceToSave = data.is_round_trip ? data.distance_km * 2 : data.distance_km;
      const ratePerKm = settings?.high_rate_per_km || 3.94;
      
      const { error } = await supabase
        .from('mileage_entries')
        .update({
          paying_company_id: data.paying_company_id,
          trip_date: format(data.trip_date, 'yyyy-MM-dd'),
          from_address_type: data.from_address_type,
          from_address: data.from_address,
          to_company_id: data.to_company_id || null,
          to_address: data.to_address,
          purpose: data.purpose,
          distance_km: distanceToSave,
          rate_per_km: ratePerKm,
        })
        .eq('id', entry.id)
        .eq('is_submitted', false);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mileage-entries'] });
      toast.success('Kørsel opdateret');
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error('Kunne ikke opdatere kørsel: ' + error.message);
    },
  });

  const calculateDistance = async () => {
    const fromAddress = form.getValues('from_address');
    const toAddress = form.getValues('to_address');
    
    if (!fromAddress || !toAddress) {
      toast.error('Udfyld både fra- og til-adresse');
      return;
    }
    
    setIsCalculating(true);
    try {
      const { data, error } = await supabase.functions.invoke('calculate-distance', {
        body: { origin: fromAddress, destination: toAddress },
      });
      
      if (error) throw error;
      if (data?.distance_km) {
        form.setValue('distance_km', Math.round(data.distance_km * 10) / 10);
        toast.success(`Afstand beregnet: ${data.distance_km.toFixed(1)} km`);
      }
    } catch (error) {
      toast.error('Kunne ikke beregne afstand');
    } finally {
      setIsCalculating(false);
    }
  };

  const onSubmit = (data: EditFormData) => {
    updateMutation.mutate(data);
  };

  if (!entry) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pencil className="h-5 w-5" />
            Redigér kørselsregistrering
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Dato */}
            <FormField
              control={form.control}
              name="trip_date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Dato</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? format(field.value, 'PPP', { locale: da }) : 'Vælg dato'}
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        locale={da}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Fra-adresse */}
            <div className="space-y-2">
              <Label>Fra-adresse</Label>
              <FormField
                control={form.control}
                name="from_address_type"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="private">
                        <span className="flex items-center gap-2">
                          <MapPin className="h-4 w-4" />
                          Privat adresse
                        </span>
                      </SelectItem>
                      {settings?.office_address && (
                        <SelectItem value="office">
                          <span className="flex items-center gap-2">
                            <Building2 className="h-4 w-4" />
                            Kontoradresse
                          </span>
                        </SelectItem>
                      )}
                      <SelectItem value="manual">
                        <span className="flex items-center gap-2">
                          <Car className="h-4 w-4" />
                          Anden adresse
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
              <FormField
                control={form.control}
                name="from_address"
                render={({ field }) => (
                  <Input
                    {...field}
                    placeholder="Indtast adresse"
                    disabled={fromAddressType !== 'manual'}
                  />
                )}
              />
            </div>

            {/* Til-adresse */}
            <div className="space-y-2">
              <Label>Til-adresse</Label>
              <FormField
                control={form.control}
                name="to_company_id"
                render={({ field }) => (
                <Select value={field.value || "manual"} onValueChange={(val) => field.onChange(val === "manual" ? "" : val)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Vælg virksomhed (valgfrit)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manual">Manuel adresse</SelectItem>
                      {companies.map((company) => (
                        <SelectItem key={company.id} value={company.id}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              <FormField
                control={form.control}
                name="to_address"
                render={({ field }) => (
                  <Input {...field} placeholder="Indtast til-adresse" />
                )}
              />
            </div>

            {/* Formål */}
            <FormField
              control={form.control}
              name="purpose"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Formål</FormLabel>
                  <FormControl>
                    <Textarea {...field} placeholder="Beskriv formålet med kørslen" rows={2} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Afstand */}
            <div className="space-y-2">
              <Label>Afstand (km)</Label>
              <div className="flex gap-2">
                <FormField
                  control={form.control}
                  name="distance_km"
                  render={({ field }) => (
                    <Input
                      type="number"
                      step="0.1"
                      min="0"
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                      className="flex-1"
                    />
                  )}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={calculateDistance}
                  disabled={isCalculating}
                >
                  {isCalculating ? (
                    <RotateCcw className="h-4 w-4 animate-spin" />
                  ) : (
                    <Calculator className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {/* Tur/retur */}
            <FormField
              control={form.control}
              name="is_round_trip"
              render={({ field }) => (
                <FormItem className="flex items-center justify-between rounded-lg border p-3">
                  <div>
                    <FormLabel className="font-normal">Tur/retur</FormLabel>
                    <p className="text-sm text-muted-foreground">
                      Fordobler afstanden automatisk
                    </p>
                  </div>
                  <FormControl>
                    <Switch checked={field.value} onCheckedChange={field.onChange} />
                  </FormControl>
                </FormItem>
              )}
            />

            {/* Betales af */}
            <FormField
              control={form.control}
              name="paying_company_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Betales af</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg virksomhed" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {companies.map((company) => (
                        <SelectItem key={company.id} value={company.id}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Handlinger */}
            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Annuller
              </Button>
              <Button type="submit" disabled={updateMutation.isPending}>
                {updateMutation.isPending ? 'Gemmer...' : 'Gem ændringer'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
