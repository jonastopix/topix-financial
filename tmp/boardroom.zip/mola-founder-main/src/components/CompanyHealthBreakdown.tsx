import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { DollarSign, BarChart, Zap, Heart, Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface CompanyHealthBreakdownProps {
  healthIndex: number;
  financialScore: number;
  growthScore: number;
  transparencyScore: number;
  relationshipScore: number;
}

export function CompanyHealthBreakdown({
  healthIndex,
  financialScore,
  growthScore,
  transparencyScore,
  relationshipScore,
}: CompanyHealthBreakdownProps) {
  const getHealthStatus = (score: number) => {
    if (score >= 80) return { label: 'Sund', color: 'text-green-500', bg: 'bg-green-500' };
    if (score >= 50) return { label: 'Stabil', color: 'text-yellow-500', bg: 'bg-yellow-500' };
    return { label: 'Risiko', color: 'text-red-500', bg: 'bg-red-500' };
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const status = getHealthStatus(healthIndex);

  const metrics = [
    {
      label: 'Financial Health',
      score: financialScore,
      icon: DollarSign,
      weight: '40%',
      description: 'YTD vækst, EBITDA-margin og cash position',
    },
    {
      label: 'Growth Momentum',
      score: growthScore,
      icon: BarChart,
      weight: '30%',
      description: 'YOY omsætningsvækst og kundeoptagelse',
    },
    {
      label: 'Transparency',
      score: transparencyScore,
      icon: Zap,
      weight: '20%',
      description: 'Rapporteringskonsistens og fuldstændighed',
    },
    {
      label: 'Relationship',
      score: relationshipScore,
      icon: Heart,
      weight: '10%',
      description: 'NPS score og samarbejde kvalitet',
    },
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold">Company Health Index</h3>
        <div className={`flex items-center gap-2 ${status.color}`}>
          <span className="text-2xl lg:text-3xl font-bold">{Math.round(healthIndex)}</span>
          <div className="text-sm">
            <div className="font-semibold">{status.label}</div>
            <div className="text-muted-foreground">/ 100</div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {metrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <div key={metric.label} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">{metric.label}</span>
                  <span className="text-xs text-muted-foreground">({metric.weight})</span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="h-3 w-3 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="text-xs max-w-xs">{metric.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                <span className={`text-sm font-semibold ${getScoreColor(metric.score)}`}>
                  {Math.round(metric.score)}%
                </span>
              </div>
              <Progress 
                value={metric.score} 
                className="h-2"
              />
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-6 border-t">
        <div className="grid grid-cols-3 gap-4 text-center text-sm">
          <div>
            <div className="text-green-500 font-semibold">80-100</div>
            <div className="text-muted-foreground">Sund</div>
          </div>
          <div>
            <div className="text-yellow-500 font-semibold">50-79</div>
            <div className="text-muted-foreground">Stabil</div>
          </div>
          <div>
            <div className="text-red-500 font-semibold">0-49</div>
            <div className="text-muted-foreground">Risiko</div>
          </div>
        </div>
      </div>
    </Card>
  );
}
