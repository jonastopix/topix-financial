import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';

interface AddFundOwnershipDialogProps {
  fundId: string;
  onAdd: (ownership: { fund_id: string; owner_name: string; owner_type: 'person' | 'company' | 'fund'; ownership_pct: number }) => void;
}

export function AddFundOwnershipDialog({ fundId, onAdd }: AddFundOwnershipDialogProps) {
  const [open, setOpen] = useState(false);
  const [ownerName, setOwnerName] = useState('');
  const [ownerType, setOwnerType] = useState<'person' | 'company' | 'fund'>('company');
  const [ownershipPct, setOwnershipPct] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({
      fund_id: fundId,
      owner_name: ownerName,
      owner_type: ownerType,
      ownership_pct: parseFloat(ownershipPct),
    });
    setOwnerName('');
    setOwnershipPct('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Tilføj Ejer
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Tilføj Ejer til Fond</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ownerName">Ejer Navn</Label>
            <Input
              id="ownerName"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              placeholder="fx Mola Invest ApS"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ownerType">Type</Label>
            <Select value={ownerType} onValueChange={(value: any) => setOwnerType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="person">Person</SelectItem>
                <SelectItem value="company">Selskab</SelectItem>
                <SelectItem value="fund">Fond</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="ownershipPct">Ejerandel (%)</Label>
            <Input
              id="ownershipPct"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value={ownershipPct}
              onChange={(e) => setOwnershipPct(e.target.value)}
              placeholder="50"
              required
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuller
            </Button>
            <Button type="submit">Tilføj</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
