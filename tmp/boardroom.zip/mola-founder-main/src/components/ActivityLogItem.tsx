import { ActivityLog } from '@/hooks/useCompanyActivityLog';
import { Card, CardContent } from '@/components/ui/card';
import {
  CheckCircle2,
  CheckCircle,
  Upload,
  UserPlus,
  FileText,
  Edit,
  Trash2,
  Activity,
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { da } from 'date-fns/locale';

interface ActivityLogItemProps {
  activity: ActivityLog;
}

const getActivityIcon = (activityType: string) => {
  const icons: Record<string, any> = {
    task_created: CheckCircle2,
    task_status_changed: CheckCircle,
    task_completed: CheckCircle,
    document_uploaded: Upload,
    document_deleted: Trash2,
    contact_added: UserPlus,
    contact_updated: Edit,
    contact_deleted: Trash2,
    report_submitted: FileText,
  };
  return icons[activityType] || Activity;
};

const getActivityColor = (activityType: string) => {
  if (activityType.includes('created') || activityType.includes('added')) {
    return 'text-green-500';
  }
  if (activityType.includes('deleted')) {
    return 'text-red-500';
  }
  if (activityType.includes('updated') || activityType.includes('changed')) {
    return 'text-blue-500';
  }
  return 'text-muted-foreground';
};

const ActivityLogItem = ({ activity }: ActivityLogItemProps) => {
  const Icon = getActivityIcon(activity.activity_type);
  const colorClass = getActivityColor(activity.activity_type);

  return (
    <Card className="relative ml-12">
      <div
        className={`absolute -left-6 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-background border-2 border-border ${colorClass}`}
      >
        <Icon className="h-4 w-4" />
      </div>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <p className="font-medium">{activity.description}</p>
            {activity.metadata && (
              <div className="mt-2 text-sm text-muted-foreground">
                {activity.metadata.task_title && (
                  <p>Opgave: {activity.metadata.task_title}</p>
                )}
                {activity.metadata.file_name && (
                  <p>Fil: {activity.metadata.file_name}</p>
                )}
                {activity.metadata.contact_name && (
                  <p>Kontakt: {activity.metadata.contact_name}</p>
                )}
              </div>
            )}
          </div>
          <span className="text-xs text-muted-foreground whitespace-nowrap">
            {formatDistanceToNow(new Date(activity.created_at), {
              addSuffix: true,
              locale: da,
            })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
};

export default ActivityLogItem;
