import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatCompact } from '@/lib/formatters';

interface MonthlyReport {
  period_month: number;
  period_year: number;
  revenue_dkk: number;
  ebitda_dkk: number;
}

interface MonthlyReportChartsProps {
  reports: MonthlyReport[];
}

const MonthlyReportCharts = ({ reports }: MonthlyReportChartsProps) => {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];

  const revenueData = reports
    .slice(0, 12)
    .reverse()
    .map(r => ({
      month: `${monthNames[r.period_month - 1]} ${r.period_year}`,
      value: Number(r.revenue_dkk) / 1000,
    }));

  const ebitdaData = reports
    .slice(0, 12)
    .reverse()
    .map(r => ({
      month: `${monthNames[r.period_month - 1]} ${r.period_year}`,
      value: Number(r.ebitda_dkk) / 1000,
    }));

  return (
    <Card className="p-6">
      <h3 className="text-xl font-semibold mb-6">Historisk Udvikling</h3>
      <Tabs defaultValue="revenue" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="revenue">Omsætning over tid</TabsTrigger>
          <TabsTrigger value="ebitda">EBITDA-trend</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="h-[300px] mt-6">
          {revenueData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="month" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `${value}k`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                  formatter={(value: number) => [`${formatCompact(value * 1000, 0)} kr.`, 'Omsætning']}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={3}
                  dot={{ fill: 'hsl(var(--primary))', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              Ingen data endnu
            </div>
          )}
        </TabsContent>

        <TabsContent value="ebitda" className="h-[300px] mt-6">
          {ebitdaData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ebitdaData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="month" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                  tickFormatter={(value) => `${value}k`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                  labelStyle={{ color: 'hsl(var(--foreground))' }}
                  formatter={(value: number) => [`${formatCompact(value * 1000, 0)} kr.`, 'EBITDA']}
                />
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="hsl(var(--accent))" 
                  strokeWidth={3}
                  dot={{ fill: 'hsl(var(--accent))', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              Ingen data endnu
            </div>
          )}
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default MonthlyReportCharts;