import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatDistanceToNow } from 'date-fns';
import { da } from 'date-fns/locale';
import { RealtimeChannel } from '@supabase/supabase-js';

interface ActivityEvent {
  id: string;
  event_type: string;
  event_message: string;
  event_icon: string | null;
  created_at: string;
}

export function PortfolioActivityFeed() {
  const [events, setEvents] = useState<ActivityEvent[]>([]);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);

  useEffect(() => {
    // Fetch initial events
    const fetchInitialEvents = async () => {
      const { data, error } = await supabase
        .from('portfolio_activity_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) {
        console.error('Error fetching activity events:', error);
        return;
      }

      if (data) {
        setEvents(data);
      }
    };

    fetchInitialEvents();

    // Set up realtime subscription
    const activityChannel = supabase
      .channel('portfolio-activity')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'portfolio_activity_events',
        },
        (payload) => {
          console.log('New activity event:', payload);
          const newEvent = payload.new as ActivityEvent;
          setEvents((prev) => [newEvent, ...prev.slice(0, 9)]);
        }
      )
      .subscribe();

    setChannel(activityChannel);

    return () => {
      if (channel) {
        supabase.removeChannel(channel);
      }
    };
  }, []);

  if (events.length === 0) {
    return (
      <Card className="bg-card border-border h-full">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <span className="text-xl">🔔</span>
            Portfolio Aktivitet
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <span className="text-4xl mb-3">📭</span>
            <p className="text-muted-foreground">
              Ingen aktivitet at vise endnu
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Aktivitet vises når founders indsender rapporter eller opnår milepæle
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border h-full">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <span className="text-xl">🔔</span>
          Portfolio Aktivitet
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {events.map((event, index) => (
            <div
              key={event.id}
              className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors animate-in fade-in slide-in-from-left-2"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-2xl" role="img" aria-label="event icon">
                {event.event_icon || '📌'}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-foreground">{event.event_message}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatDistanceToNow(new Date(event.created_at), {
                    addSuffix: true,
                    locale: da,
                  })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
