import { useState, useMemo } from 'react';
import { useTaskManagement, Task } from '@/hooks/useTaskManagement';
import { useRole } from '@/contexts/RoleContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Plus, ListTodo, Search, Filter, ArrowUpDown } from 'lucide-react';
import TasksTable from './TasksTable';
import TaskMobileRow from './TaskMobileRow';
import TaskDetailsDialog from './TaskDetailsDialog';
import CreateTaskDialog from './CreateTaskDialog';

interface CompanyTasksViewProps {
  companyId: string;
}

const CompanyTasksView = ({ companyId }: CompanyTasksViewProps) => {
  const { tasks, isLoading, updateTask } = useTaskManagement();
  const { isAdmin, activeRole } = useRole();
  const isMobile = useIsMobile();
  const canCreateTasks = isAdmin || activeRole === 'fund_partner';

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('open');
  const [sortBy, setSortBy] = useState('due_date');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  // Filter tasks for this company
  const companyTasks = tasks?.filter((task) => task.company_id === companyId);

  // Filter and sort tasks
  const filteredTasks = useMemo(() => {
    let result = companyTasks || [];

    // Search
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (task) =>
          task.title.toLowerCase().includes(query) ||
          task.description?.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (statusFilter === 'open') {
      result = result.filter((task) => task.status !== 'done');
    } else if (statusFilter !== 'all') {
      result = result.filter((task) => task.status === statusFilter);
    }

    // Sorting
    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'due_date':
          if (!a.due_date && !b.due_date) return 0;
          if (!a.due_date) return 1;
          if (!b.due_date) return -1;
          return new Date(a.due_date).getTime() - new Date(b.due_date).getTime();
        case 'priority':
          const priorityOrder: Record<string, number> = { urgent: 0, high: 1, medium: 2, low: 3 };
          return (priorityOrder[a.priority] ?? 4) - (priorityOrder[b.priority] ?? 4);
        case 'created_at':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case 'title':
          return a.title.localeCompare(b.title, 'da');
        default:
          return 0;
      }
    });

    return result;
  }, [companyTasks, searchQuery, statusFilter, sortBy]);

  // Statistics
  const stats = {
    open: companyTasks?.filter((t) => t.status !== 'done').length || 0,
    overdue:
      companyTasks?.filter(
        (t) =>
          t.due_date &&
          new Date(t.due_date) < new Date() &&
          t.status !== 'done'
      ).length || 0,
    completedThisMonth:
      companyTasks?.filter((t) => {
        if (!t.completed_at) return false;
        const completed = new Date(t.completed_at);
        const now = new Date();
        return (
          completed.getMonth() === now.getMonth() &&
          completed.getFullYear() === now.getFullYear()
        );
      }).length || 0,
  };

  const handleTaskClick = (task: Task) => {
    setSelectedTask(task);
    setShowDetails(true);
  };

  const handleToggleStatus = (task: Task) => {
    const newStatus = task.status === 'done' ? 'todo' : 'done';
    updateTask.mutate({ id: task.id, status: newStatus });
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Opgaver</h2>
          <p className="text-muted-foreground">
            {companyTasks?.length || 0} opgaver totalt
          </p>
        </div>
        {canCreateTasks && (
          <CreateTaskDialog
            companyId={companyId}
            trigger={
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Opret Opgave
              </Button>
            }
          />
        )}
      </div>

      {/* Statistics */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold">{stats.open}</div>
            <p className="text-sm text-muted-foreground">Åbne opgaver</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-destructive">{stats.overdue}</div>
            <p className="text-sm text-muted-foreground">Overskredet deadline</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="text-2xl font-bold text-green-600 dark:text-green-400">
              {stats.completedThisMonth}
            </div>
            <p className="text-sm text-muted-foreground">Afsluttet denne måned</p>
          </CardContent>
        </Card>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px] max-w-[280px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Søg i opgaver..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-9"
          />
        </div>

        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[140px] h-9">
            <Filter className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="open">Åbne opgaver</SelectItem>
            <SelectItem value="all">Alle opgaver</SelectItem>
            <SelectItem value="todo">Afventer</SelectItem>
            <SelectItem value="in_progress">I gang</SelectItem>
            <SelectItem value="done">Færdige</SelectItem>
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[140px] h-9">
            <ArrowUpDown className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="due_date">Deadline</SelectItem>
            <SelectItem value="priority">Prioritet</SelectItem>
            <SelectItem value="created_at">Oprettet</SelectItem>
            <SelectItem value="title">Titel</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Tasks list */}
      {filteredTasks.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ListTodo className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Ingen opgaver</p>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              {companyTasks?.length
                ? 'Ingen opgaver matcher dine filtre'
                : 'Opret den første opgave for dette selskab.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Desktop: Table */}
          <div className="hidden md:block">
            <TasksTable tasks={filteredTasks} />
          </div>

          {/* Mobile: List */}
          <div className="md:hidden space-y-2">
            {filteredTasks.map((task) => (
              <TaskMobileRow
                key={task.id}
                task={task}
                onToggleStatus={() => handleToggleStatus(task)}
                onClick={() => handleTaskClick(task)}
              />
            ))}
          </div>
        </>
      )}

      {/* Task Details Dialog */}
      {selectedTask && (
        <TaskDetailsDialog
          task={selectedTask}
          open={showDetails}
          onOpenChange={(open) => {
            setShowDetails(open);
            if (!open) setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
};

export default CompanyTasksView;
