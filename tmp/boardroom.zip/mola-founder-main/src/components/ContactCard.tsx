import { CompanyContact } from '@/hooks/useCompanyContacts';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Mail, Phone, Edit, Trash2 } from 'lucide-react';

interface ContactCardProps {
  contact: CompanyContact;
  onEdit?: () => void;
  onDelete?: () => void;
}

const ContactCard = ({ contact, onEdit, onDelete }: ContactCardProps) => {
  const initials = contact.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <Avatar className="h-12 w-12">
            <AvatarFallback className="bg-primary text-primary-foreground">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold truncate">{contact.name}</p>
                <p className="text-sm text-muted-foreground">{contact.role}</p>
              </div>
              {contact.is_primary && (
                <Badge variant="secondary" className="shrink-0">
                  Primær
                </Badge>
              )}
            </div>

            <div className="space-y-2 mt-4">
              {contact.email && (
                <a
                  href={`mailto:${contact.email}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Mail className="h-3 w-3" />
                  <span className="truncate">{contact.email}</span>
                </a>
              )}
              {contact.phone && (
                <a
                  href={`tel:${contact.phone}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <Phone className="h-3 w-3" />
                  <span>{contact.phone}</span>
                </a>
              )}
            </div>

            {contact.notes && (
              <p className="text-xs text-muted-foreground mt-3 line-clamp-2">
                {contact.notes}
              </p>
            )}

            {(onEdit || onDelete) && (
              <div className="flex gap-2 mt-4">
                {onEdit && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={onEdit}
                    className="flex-1"
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    Rediger
                  </Button>
                )}
                {onDelete && (
                  <Button variant="ghost" size="sm" onClick={onDelete}>
                    <Trash2 className="h-3 w-3" />
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ContactCard;
