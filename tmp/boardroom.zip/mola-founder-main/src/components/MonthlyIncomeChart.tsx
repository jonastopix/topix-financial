import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { formatCurrency } from "@/lib/formatters";

interface MonthlyIncomeChartProps {
  data: Array<{ month: string; faktura: number; løn: number; anden: number }>;
  year: number;
}

export function MonthlyIncomeChart({ data, year }: MonthlyIncomeChartProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Månedlig Indkomst {year}</h3>
      <ResponsiveContainer width="100%" height={350}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis tickFormatter={(value) => formatCurrency(value)} />
          <Tooltip formatter={(value) => formatCurrency(value as number)} />
          <Legend />
          <Bar dataKey="faktura" fill="hsl(var(--primary))" name="Fakturaer" />
          <Bar dataKey="løn" fill="hsl(var(--secondary))" name="Løn" />
          <Bar dataKey="anden" fill="hsl(var(--accent))" name="Anden" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
