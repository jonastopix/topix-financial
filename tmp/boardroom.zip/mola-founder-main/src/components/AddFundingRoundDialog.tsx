import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, TrendingUp, AlertTriangle, RotateCcw, Users, Info } from 'lucide-react';
import { FundingRoundInput } from '@/hooks/useFundingRounds';
import { useFunds } from '@/hooks/useReturnsData';

interface AddFundingRoundDialogProps {
  companyId: string;
  onAdd: (data: FundingRoundInput) => void;
  editData?: FundingRoundInput & { id: string };
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

const ROUND_TYPES = [
  { value: 'seed', label: 'Seed' },
  { value: 'series_a', label: 'Series A' },
  { value: 'series_b', label: 'Series B' },
  { value: 'series_c', label: 'Series C' },
  { value: 'follow_on', label: 'Follow-on' },
  { value: 'bridge', label: 'Bridge' },
  { value: 'secondary', label: 'Secondary (Old Shares)' },
];

export function AddFundingRoundDialog({ companyId, onAdd, editData, open: controlledOpen, onOpenChange: controlledOnOpenChange }: AddFundingRoundDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = controlledOnOpenChange || setInternalOpen;

  const { data: funds } = useFunds();
  
  const [formData, setFormData] = useState<FundingRoundInput>({
    company_id: companyId,
    round_name: '',
    round_type: 'follow_on',
    invested_amount_dkk: 0,
    equity_acquired_pct: 0,
    invested_at: new Date().toISOString().split('T')[0],
    pre_money_valuation_dkk: undefined,
    post_money_valuation_dkk: undefined,
    fund_id: undefined,
    note: '',
    seller_name: '',
    is_secondary: false,
  });

  const isSecondary = formData.round_type === 'secondary';

  const [showValuationWarning, setShowValuationWarning] = useState(false);

  useEffect(() => {
    if (editData) {
      setFormData(editData);
    }
  }, [editData]);

  // Validate valuations match calculations
  useEffect(() => {
    const { invested_amount_dkk, equity_acquired_pct, pre_money_valuation_dkk, post_money_valuation_dkk } = formData;
    
    if (invested_amount_dkk > 0 && equity_acquired_pct > 0 && post_money_valuation_dkk) {
      const equityDecimal = equity_acquired_pct / 100;
      const calculatedPostMoney = invested_amount_dkk / equityDecimal;
      
      // Check if user-entered valuation deviates significantly (>1%) from calculated
      const deviationPct = Math.abs((post_money_valuation_dkk - calculatedPostMoney) / calculatedPostMoney) * 100;
      setShowValuationWarning(deviationPct > 1);
    } else {
      setShowValuationWarning(false);
    }
  }, [formData.invested_amount_dkk, formData.equity_acquired_pct, formData.post_money_valuation_dkk]);

  // Recalculate valuations based on invested amount and equity
  const handleRecalculateValuations = () => {
    const { invested_amount_dkk, equity_acquired_pct } = formData;
    
    if (invested_amount_dkk > 0 && equity_acquired_pct > 0) {
      const equityDecimal = equity_acquired_pct / 100;
      const calculatedPostMoney = invested_amount_dkk / equityDecimal;
      const calculatedPreMoney = calculatedPostMoney - invested_amount_dkk;
      
      setFormData(prev => ({
        ...prev,
        pre_money_valuation_dkk: Math.round(calculatedPreMoney),
        post_money_valuation_dkk: Math.round(calculatedPostMoney),
      }));
      setShowValuationWarning(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd(formData);
    setOpen(false);
    
    // Reset form
    setFormData({
      company_id: companyId,
      round_name: '',
      round_type: 'follow_on',
      invested_amount_dkk: 0,
      equity_acquired_pct: 0,
      invested_at: new Date().toISOString().split('T')[0],
      pre_money_valuation_dkk: undefined,
      post_money_valuation_dkk: undefined,
      fund_id: undefined,
      note: '',
      seller_name: '',
      is_secondary: false,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Tilføj Funding Round
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            {editData ? 'Rediger Funding Round' : 'Tilføj Funding Round'}
          </DialogTitle>
          <DialogDescription>
            Registrer en ny investering, follow-up financing eller køb af old shares
          </DialogDescription>
        </DialogHeader>

        {isSecondary && (
          <Alert className="bg-blue-50 border-blue-200 dark:bg-blue-950/30 dark:border-blue-800">
            <Info className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <AlertDescription className="text-blue-800 dark:text-blue-200">
              <strong>Sekundær transaktion:</strong> Køb af eksisterende aktier fra en eksisterende aktionær. 
              Pengene går til sælger, ikke til selskabet. Der udstedes ingen nye aktier.
            </AlertDescription>
          </Alert>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="round_name">Round Navn *</Label>
              <Input
                id="round_name"
                value={formData.round_name}
                onChange={(e) => setFormData({ ...formData, round_name: e.target.value })}
                placeholder="f.eks. Follow-on Q1 2024"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="round_type">Round Type *</Label>
              <Select
                value={formData.round_type}
                onValueChange={(value) => setFormData({ 
                  ...formData, 
                  round_type: value,
                  is_secondary: value === 'secondary',
                  seller_name: value === 'secondary' ? formData.seller_name : '',
                })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROUND_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {isSecondary && (
            <div className="space-y-2">
              <Label htmlFor="seller_name" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Sælgers Navn *
              </Label>
              <Input
                id="seller_name"
                value={formData.seller_name || ''}
                onChange={(e) => setFormData({ ...formData, seller_name: e.target.value })}
                placeholder="Navn på sælger af aktierne"
                required={isSecondary}
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="invested_at">Investerings Dato *</Label>
              <Input
                id="invested_at"
                type="date"
                value={formData.invested_at}
                onChange={(e) => setFormData({ ...formData, invested_at: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fund_id">Fond</Label>
              <Select
                value={formData.fund_id || ''}
                onValueChange={(value) => setFormData({ ...formData, fund_id: value || undefined })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Vælg fond" />
                </SelectTrigger>
                <SelectContent>
                  {funds?.map((fund) => (
                    <SelectItem key={fund.id} value={fund.id}>
                      {fund.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="invested_amount">
                {isSecondary ? 'Købspris (DKK) *' : 'Investeret Beløb (DKK) *'}
              </Label>
              <Input
                id="invested_amount"
                type="number"
                step="0.01"
                value={formData.invested_amount_dkk}
                onChange={(e) => setFormData({ ...formData, invested_amount_dkk: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="equity_acquired">Ejerandel Erhvervet (%) *</Label>
              <Input
                id="equity_acquired"
                type="number"
                step="0.01"
                value={formData.equity_acquired_pct}
                onChange={(e) => setFormData({ ...formData, equity_acquired_pct: parseFloat(e.target.value) || 0 })}
                required
              />
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>Valuations</Label>
              {formData.invested_amount_dkk > 0 && formData.equity_acquired_pct > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleRecalculateValuations}
                  className="h-8"
                >
                  <RotateCcw className="h-3 w-3 mr-1" />
                  Genberegn
                </Button>
              )}
            </div>
            
            {showValuationWarning && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  De indtastede valuations matcher ikke beregningen baseret på investeret beløb og ejerandel. 
                  Klik "Genberegn" for at rette dette.
                </AlertDescription>
              </Alert>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="pre_money">Pre-money Valuation (DKK)</Label>
                <Input
                  id="pre_money"
                  type="number"
                  step="0.01"
                  value={formData.pre_money_valuation_dkk || ''}
                  onChange={(e) => setFormData({ ...formData, pre_money_valuation_dkk: parseFloat(e.target.value) || undefined })}
                  placeholder="Auto-beregnes"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="post_money">Post-money Valuation (DKK)</Label>
                <Input
                  id="post_money"
                  type="number"
                  step="0.01"
                  value={formData.post_money_valuation_dkk || ''}
                  onChange={(e) => setFormData({ ...formData, post_money_valuation_dkk: parseFloat(e.target.value) || undefined })}
                  placeholder="Auto-beregnes"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="note">Noter</Label>
            <Textarea
              id="note"
              value={formData.note || ''}
              onChange={(e) => setFormData({ ...formData, note: e.target.value })}
              placeholder="Ekstra information om denne investering..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuller
            </Button>
            <Button type="submit">
              {editData ? 'Gem Ændringer' : 'Tilføj Round'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
