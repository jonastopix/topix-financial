import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, FileText } from "lucide-react";
import { format } from "date-fns";
import { da } from "date-fns/locale";

interface MonthlyReport {
  period_month: number;
  period_year: number;
  revenue_dkk: number | null;
  budget_revenue_dkk: number | null;
}

interface BudgetOverviewCardProps {
  reports: MonthlyReport[];
  currentYear?: number;
  onReportClick: (month: number) => void;
}

const DANISH_MONTHS = [
  "Januar", "Februar", "Marts", "April", "Maj", "Juni",
  "Juli", "August", "September", "Oktober", "November", "December"
];

export function BudgetOverviewCard({ reports, currentYear = new Date().getFullYear(), onReportClick }: BudgetOverviewCardProps) {
  const monthsData = DANISH_MONTHS.map((monthName, index) => {
    const month = index + 1;
    const report = reports.find(r => r.period_month === month && r.period_year === currentYear);
    
    const hasBudget = report && report.budget_revenue_dkk !== null && report.budget_revenue_dkk > 0;
    // A month is only "reported" if revenue_dkk is not null AND greater than 0
    // This distinguishes actual reports from budget placeholders with 0 values
    const hasActual = report && report.revenue_dkk !== null && report.revenue_dkk > 0;
    
    return {
      month,
      monthName,
      hasBudget,
      hasActual,
      status: hasActual ? 'reported' : hasBudget ? 'budget-only' : 'missing'
    };
  });

  const budgetCount = monthsData.filter(m => m.hasBudget).length;
  const reportedCount = monthsData.filter(m => m.hasActual).length;
  const nextMonth = monthsData.find(m => m.status === 'budget-only');

  return (
    <Card>
      <CardHeader>
        <CardTitle>Budget Oversigt {currentYear}</CardTitle>
        <CardDescription>
          {budgetCount} måneder med budget • {reportedCount} måneder rapporteret
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {monthsData.map(({ month, monthName, status }) => (
            <button
              key={month}
              onClick={() => onReportClick(month)}
              className="flex flex-col items-center p-3 rounded-lg border transition-all hover:border-primary hover:bg-accent"
            >
              {status === 'reported' ? (
                <CheckCircle2 className="h-5 w-5 text-success mb-1" />
              ) : status === 'budget-only' ? (
                <FileText className="h-5 w-5 text-warning mb-1" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground mb-1" />
              )}
              <span className="text-xs font-medium">{monthName.slice(0, 3)}</span>
              <span className="text-xs text-muted-foreground">
                {status === 'reported' ? 'Rapporteret' : status === 'budget-only' ? 'Budget' : 'Mangler'}
              </span>
            </button>
          ))}
        </div>

        {nextMonth && (
          <div className="pt-4 border-t">
            <Button 
              onClick={() => onReportClick(nextMonth.month)}
              className="w-full"
            >
              Rapportér {nextMonth.monthName}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
