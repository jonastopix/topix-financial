import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { usePortfolioRankings } from '@/hooks/usePortfolioRankings';
import { TrendingUp, DollarSign, Target, Percent, Users } from 'lucide-react';
import { formatCurrency, formatNumber } from '@/lib/formatters';

interface MyRankingWidgetProps {
  companyId?: string;
}

export function MyRankingWidget({ companyId }: MyRankingWidgetProps) {
  const { data: rankings, isLoading } = usePortfolioRankings(companyId);

  if (isLoading) {
    return (
      <Card className="min-h-[450px]">
        <CardHeader>
          <CardTitle className="text-lg">Min Position i Porteføljen</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3 flex-1">
                <Skeleton className="h-10 w-10 rounded-lg" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Skeleton className="h-8 w-20 rounded-full" />
                <Skeleton className="h-4 w-16" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!rankings || rankings.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Min Position i Porteføljen</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Ingen data tilgængelig endnu</p>
        </CardContent>
      </Card>
    );
  }

  // Get latest rankings for each metric
  const latestRankings = rankings.reduce((acc, ranking) => {
    if (!acc[ranking.metric_type] || 
        new Date(ranking.calculated_at) > new Date(acc[ranking.metric_type].calculated_at)) {
      acc[ranking.metric_type] = ranking;
    }
    return acc;
  }, {} as Record<string, typeof rankings[0]>);

  const metrics = [
    {
      type: 'ytd_revenue',
      label: 'Omsætning YTD',
      icon: DollarSign,
      format: (value: number) => formatCurrency(value),
      color: 'text-blue-600',
    },
    {
      type: 'latest_month_revenue',
      label: 'Seneste Måneds Omsætning',
      icon: Target,
      format: (value: number) => formatCurrency(value),
      color: 'text-green-600',
    },
    {
      type: 'growth_rate',
      label: 'Vækstrate (MoM)',
      icon: TrendingUp,
      format: (value: number) => `${formatNumber(value, 1)}%`,
      color: 'text-purple-600',
    },
    {
      type: 'ebitda_margin',
      label: 'EBITDA Margin',
      icon: Percent,
      format: (value: number) => `${formatNumber(value, 1)}%`,
      color: 'text-orange-600',
    },
    {
      type: 'customer_count',
      label: 'Nye Kunder',
      icon: Users,
      format: (value: number) => formatNumber(value),
      color: 'text-indigo-600',
    },
  ];

  const getRankBadgeColor = (percentile: number) => {
    if (percentile >= 75) return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    if (percentile >= 50) return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    if (percentile >= 25) return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="text-lg">Min Position i Porteføljen</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {metrics.map(metric => {
          const ranking = latestRankings[metric.type];
          if (!ranking) return null;

          const Icon = metric.icon;

          return (
            <div key={metric.type} className="flex items-center justify-between p-3 rounded-lg border">
              <div className="flex items-center gap-3 flex-1">
                <div className={`p-2 rounded-lg ${metric.color} bg-opacity-10`}>
                  <Icon className={`h-5 w-5 ${metric.color}`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{metric.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {metric.format(ranking.metric_value)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getRankBadgeColor(ranking.percentile)}`}>
                  #{ranking.rank} af {ranking.total_companies}
                </div>
                <div className="text-sm text-muted-foreground">
                  Top {Math.round(100 - ranking.percentile)}%
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}