import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { cn } from '@/lib/utils';

export type PeriodType = 'ytd' | 'last12' | 'custom';

interface PeriodSelectorProps {
  selectedPeriod: PeriodType;
  onPeriodChange: (period: PeriodType) => void;
  customStartDate: Date | undefined;
  customEndDate: Date | undefined;
  onCustomStartDateChange: (date: Date | undefined) => void;
  onCustomEndDateChange: (date: Date | undefined) => void;
  currentYear: number;
}

export function PeriodSelector({
  selectedPeriod,
  onPeriodChange,
  customStartDate,
  customEndDate,
  onCustomStartDateChange,
  onCustomEndDateChange,
  currentYear,
}: PeriodSelectorProps) {
  const [startDateOpen, setStartDateOpen] = useState(false);
  const [endDateOpen, setEndDateOpen] = useState(false);

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold mb-3">Vælg periode</h3>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedPeriod === 'ytd' ? 'default' : 'outline'}
              onClick={() => onPeriodChange('ytd')}
            >
              YTD {currentYear}
            </Button>
            <Button
              variant={selectedPeriod === 'last12' ? 'default' : 'outline'}
              onClick={() => onPeriodChange('last12')}
            >
              Sidste 12 mdr
            </Button>
            <Button
              variant={selectedPeriod === 'custom' ? 'default' : 'outline'}
              onClick={() => onPeriodChange('custom')}
            >
              Custom periode
            </Button>
          </div>
        </div>

        {selectedPeriod === 'custom' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
            <div className="space-y-2">
              <label className="text-sm font-medium">Start dato</label>
              <Popover open={startDateOpen} onOpenChange={setStartDateOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !customStartDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {customStartDate ? (
                      format(customStartDate, 'PPP', { locale: da })
                    ) : (
                      <span>Vælg start dato</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={customStartDate}
                    onSelect={(date) => {
                      onCustomStartDateChange(date);
                      setStartDateOpen(false);
                    }}
                    disabled={(date) => date > new Date()}
                    initialFocus
                    className={cn('p-3 pointer-events-auto')}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Slut dato</label>
              <Popover open={endDateOpen} onOpenChange={setEndDateOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !customEndDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {customEndDate ? (
                      format(customEndDate, 'PPP', { locale: da })
                    ) : (
                      <span>Vælg slut dato</span>
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={customEndDate}
                    onSelect={(date) => {
                      onCustomEndDateChange(date);
                      setEndDateOpen(false);
                    }}
                    disabled={(date) => 
                      date > new Date() || (customStartDate ? date < customStartDate : false)
                    }
                    initialFocus
                    className={cn('p-3 pointer-events-auto')}
                  />
                </PopoverContent>
              </Popover>
            </div>

            {customStartDate && customEndDate && (
              <div className="col-span-full">
                <p className="text-sm text-muted-foreground">
                  Valgt periode: {format(customStartDate, 'dd MMM yyyy', { locale: da })} - {format(customEndDate, 'dd MMM yyyy', { locale: da })}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
