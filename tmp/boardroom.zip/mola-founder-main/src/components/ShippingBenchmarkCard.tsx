import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Truck, Package, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useCompanyPrices, usePortfolioBenchmarks } from '@/hooks/useProcurementData';
import { Skeleton } from '@/components/ui/skeleton';

interface ShippingBenchmarkCardProps {
  companyId?: string;
}

export function ShippingBenchmarkCard({ companyId }: ShippingBenchmarkCardProps) {
  const navigate = useNavigate();
  const { data: companyPrices, isLoading: pricesLoading } = useCompanyPrices(companyId);
  const { data: homeBenchmarks } = usePortfolioBenchmarks('shipping', 'home_delivery');
  const { data: pickupBenchmarks } = usePortfolioBenchmarks('shipping', 'pickup_point');

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('da-DK', {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value) + ' kr';
  };

  const shippingPrices = companyPrices?.filter(p => p.category === 'shipping' && !p.archived);
  const homePrice = shippingPrices?.find(p => p.subcategory === 'home_delivery');
  const pickupPrice = shippingPrices?.find(p => p.subcategory === 'pickup_point');

  const getComparisonBadge = (companyValue: number, portfolioAvg: number | null) => {
    if (!portfolioAvg) return null;
    
    const diffPct = ((companyValue - portfolioAvg) / portfolioAvg) * 100;
    
    if (diffPct < 0) {
      return (
        <Badge variant="success" className="text-xs">
          Under snit
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive" className="text-xs">
          Over snit
        </Badge>
      );
    }
  };

  if (pricesLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Shipping Benchmark</h2>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => navigate('/procurement/benchmarks')}
        >
          Se fuldt Benchmark & Deals
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Hjemmelevering</p>
                {homePrice ? (
                  <>
                    <p className="text-2xl font-bold">
                      {formatCurrency(Number(homePrice.value_numeric))}
                    </p>
                    {homeBenchmarks?.median && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Snit: {formatCurrency(homeBenchmarks.median)}
                      </p>
                    )}
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground mt-1">Ingen data</p>
                )}
              </div>
            </div>
            {homePrice && homeBenchmarks?.median && (
              <div>
                {getComparisonBadge(Number(homePrice.value_numeric), homeBenchmarks.median)}
              </div>
            )}
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-success/10">
                <Package className="h-6 w-6 text-success" />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pakkeshop</p>
                {pickupPrice ? (
                  <>
                    <p className="text-2xl font-bold">
                      {formatCurrency(Number(pickupPrice.value_numeric))}
                    </p>
                    {pickupBenchmarks?.median && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Snit: {formatCurrency(pickupBenchmarks.median)}
                      </p>
                    )}
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground mt-1">Ingen data</p>
                )}
              </div>
            </div>
            {pickupPrice && pickupBenchmarks?.median && (
              <div>
                {getComparisonBadge(Number(pickupPrice.value_numeric), pickupBenchmarks.median)}
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
