import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { DDChecklistTemplate, DDChecklistProgress } from '@/hooks/useDueDiligence';

interface DDChecklistItemProps {
  template: DDChecklistTemplate;
  progress?: DDChecklistProgress;
  onToggle: (completed: boolean) => void;
}

export function DDChecklistItem({ template, progress, onToggle }: DDChecklistItemProps) {
  const isCompleted = progress?.completed || false;

  return (
    <div className="flex items-start gap-3 p-4 rounded-lg border border-border hover:bg-accent/50 transition-colors">
      <Checkbox
        id={`checklist-${template.id}`}
        checked={isCompleted}
        onCheckedChange={onToggle}
        className="mt-1"
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <label
            htmlFor={`checklist-${template.id}`}
            className={`text-sm font-medium cursor-pointer ${
              isCompleted ? 'line-through text-muted-foreground' : ''
            }`}
          >
            {template.item_name}
          </label>
          {template.required && (
            <Badge variant="outline" className="text-xs">
              Påkrævet
            </Badge>
          )}
        </div>
        {template.description && (
          <p className="text-sm text-muted-foreground">{template.description}</p>
        )}
        {progress?.completed_at && (
          <p className="text-xs text-muted-foreground mt-2">
            Afsluttet {new Date(progress.completed_at).toLocaleDateString('da-DK')}
          </p>
        )}
      </div>
    </div>
  );
}
