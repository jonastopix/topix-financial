import { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { useExitMutations } from '@/hooks/useExitMutations';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Info } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { formatDKK } from '@/lib/returnsCalculations';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface RecordExitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
  fundId: string;
  currentOwnershipPct: number;
}

export function RecordExitDialog({ 
  open, 
  onOpenChange, 
  companyId, 
  fundId,
  currentOwnershipPct 
}: RecordExitDialogProps) {
  const { createExit } = useExitMutations();
  const [closingDate, setClosingDate] = useState<Date>();
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [grossSaleAmount, setGrossSaleAmount] = useState('');
  const [ownershipPct, setOwnershipPct] = useState(currentOwnershipPct.toString());
  const [transactionCosts, setTransactionCosts] = useState('0');
  const [retainedShares, setRetainedShares] = useState('0');
  const [earnoutPossible, setEarnoutPossible] = useState(false);
  const [earnoutAmount, setEarnoutAmount] = useState('');
  const [note, setNote] = useState('');

  // Calculate preview of realized proceeds
  const previewCalculation = useMemo(() => {
    const gross = parseFloat(grossSaleAmount) || 0;
    const ownership = parseFloat(ownershipPct) || 0;
    const costs = parseFloat(transactionCosts) || 0;
    
    const molaShare = gross * (ownership / 100);
    const netProceeds = molaShare - costs;
    
    return {
      molaShare,
      netProceeds,
      isLoss: netProceeds < 0,
      hasValues: gross > 0 && ownership > 0
    };
  }, [grossSaleAmount, ownershipPct, transactionCosts]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!closingDate || !grossSaleAmount || !ownershipPct) {
      return;
    }

    try {
      await createExit.mutateAsync({
        company_id: companyId,
        fund_id: fundId,
        closing_date: format(closingDate, 'yyyy-MM-dd'),
        gross_sale_amount_dkk: parseFloat(grossSaleAmount),
        mola_ownership_pct_at_exit: parseFloat(ownershipPct),
        transaction_costs_dkk: parseFloat(transactionCosts),
        retained_shares_pct: parseFloat(retainedShares),
        earnout_possible: earnoutPossible,
        earnout_amount_potential_dkk: earnoutPossible && earnoutAmount ? parseFloat(earnoutAmount) : undefined,
        note: note || undefined,
      });

      // Reset form
      setClosingDate(undefined);
      setGrossSaleAmount('');
      setOwnershipPct(currentOwnershipPct.toString());
      setTransactionCosts('0');
      setRetainedShares('0');
      setEarnoutPossible(false);
      setEarnoutAmount('');
      setNote('');
      onOpenChange(false);
    } catch (error: any) {
      // Check if it's a unique constraint violation
      if (error?.message?.includes('exits_company_id_unique') || error?.code === '23505') {
        // Error toast is already shown by the mutation hook, but we can add specific handling if needed
        console.error('Exit already exists for this company');
      }
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Record Exit</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Indtast det faktiske salgsbeløb og ejerskabsprocent ved exit. Systemet håndterer både gevinster og tab korrekt.
              Hvis salgsværdien er lavere end den oprindelige investering, vil dit realized proceeds være negativt.
            </AlertDescription>
          </Alert>
          <div className="space-y-2">
            <Label htmlFor="closing_date">Closing Date *</Label>
            <Popover open={datePickerOpen} onOpenChange={setDatePickerOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !closingDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {closingDate ? format(closingDate, 'dd MMM yyyy') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 z-50">
                <Calendar
                  mode="single"
                  selected={closingDate}
                  onSelect={(date) => {
                    setClosingDate(date);
                    setDatePickerOpen(false);
                  }}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="gross_sale">Gross Sale Amount (DKK) *</Label>
            <Input
              id="gross_sale"
              type="number"
              step="0.01"
              placeholder="5000000"
              value={grossSaleAmount}
              onChange={(e) => setGrossSaleAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ownership">MOLA Ownership % at Exit *</Label>
            <Input
              id="ownership"
              type="number"
              step="0.01"
              placeholder="15.00"
              value={ownershipPct}
              onChange={(e) => setOwnershipPct(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="transaction_costs">Transaction Costs (DKK)</Label>
            <Input
              id="transaction_costs"
              type="number"
              step="0.01"
              placeholder="0"
              value={transactionCosts}
              onChange={(e) => setTransactionCosts(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="retained_shares">Retained Shares %</Label>
            <Input
              id="retained_shares"
              type="number"
              step="0.01"
              placeholder="0"
              value={retainedShares}
              onChange={(e) => setRetainedShares(e.target.value)}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="earnout"
              checked={earnoutPossible}
              onCheckedChange={(checked) => setEarnoutPossible(checked as boolean)}
            />
            <Label htmlFor="earnout" className="text-sm font-normal cursor-pointer">
              Earnout Possible
            </Label>
          </div>

          {earnoutPossible && (
            <div className="space-y-2">
              <Label htmlFor="earnout_amount">Earnout Amount Potential (DKK)</Label>
              <Input
                id="earnout_amount"
                type="number"
                step="0.01"
                placeholder="500000"
                value={earnoutAmount}
                onChange={(e) => setEarnoutAmount(e.target.value)}
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="note">Note (Optional)</Label>
            <Textarea
              id="note"
              placeholder="Additional information about this exit..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
            />
          </div>

          {previewCalculation.hasValues && (
            <div className="rounded-lg border border-border bg-muted/50 p-4 space-y-2">
              <div className="font-semibold text-sm text-muted-foreground">Preview af Beregning</div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span>Samlet salgsbeløb:</span>
                  <span className="font-medium">{formatDKK(parseFloat(grossSaleAmount) || 0)}</span>
                </div>
                <div className="flex justify-between">
                  <span>MOLA's andel ({ownershipPct}%):</span>
                  <span className="font-medium">{formatDKK(previewCalculation.molaShare)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Transaktionsomkostninger:</span>
                  <span className="font-medium">-{formatDKK(parseFloat(transactionCosts) || 0)}</span>
                </div>
                <div className="h-px bg-border my-2" />
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Estimeret Realized Proceeds:</span>
                  <span className={cn(
                    "font-bold text-base",
                    previewCalculation.isLoss ? "text-destructive" : "text-primary"
                  )}>
                    {formatDKK(previewCalculation.netProceeds)}
                  </span>
                </div>
                {previewCalculation.isLoss && (
                  <div className="text-xs text-destructive mt-1">
                    ⚠️ Dette exit vil resultere i et tab
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!closingDate || !grossSaleAmount || !ownershipPct || createExit.isPending}
            >
              {createExit.isPending ? 'Recording...' : 'Record Exit'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
