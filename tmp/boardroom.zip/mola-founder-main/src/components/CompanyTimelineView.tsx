import { useState } from 'react';
import { useCompanyActivityLog } from '@/hooks/useCompanyActivityLog';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Activity } from 'lucide-react';
import ActivityLogItem from './ActivityLogItem';
import { format, isToday, isYesterday, isThisWeek } from 'date-fns';
import { da } from 'date-fns/locale';

interface CompanyTimelineViewProps {
  companyId: string;
}

const CompanyTimelineView = ({ companyId }: CompanyTimelineViewProps) => {
  const [activityTypeFilter, setActivityTypeFilter] = useState<string>('all');
  const { data: activities, isLoading } = useCompanyActivityLog(
    companyId,
    activityTypeFilter === 'all' ? undefined : activityTypeFilter
  );

  const groupedActivities = activities?.reduce((acc, activity) => {
    const activityDate = new Date(activity.created_at);
    let group = format(activityDate, 'd. MMMM yyyy', { locale: da });

    if (isToday(activityDate)) {
      group = 'I dag';
    } else if (isYesterday(activityDate)) {
      group = 'I går';
    } else if (isThisWeek(activityDate)) {
      group = 'Denne uge';
    }

    if (!acc[group]) {
      acc[group] = [];
    }
    acc[group].push(activity);
    return acc;
  }, {} as Record<string, typeof activities>);

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Timeline</h2>
          <p className="text-muted-foreground">
            {activities?.length || 0} aktiviteter
          </p>
        </div>
        <Select value={activityTypeFilter} onValueChange={setActivityTypeFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle typer</SelectItem>
            <SelectItem value="task_created">Opgaver oprettet</SelectItem>
            <SelectItem value="task_status_changed">Opgaver opdateret</SelectItem>
            <SelectItem value="document_uploaded">Dokumenter uploadet</SelectItem>
            <SelectItem value="document_deleted">Dokumenter slettet</SelectItem>
            <SelectItem value="contact_added">Kontakter tilføjet</SelectItem>
            <SelectItem value="contact_updated">Kontakter opdateret</SelectItem>
            <SelectItem value="contact_deleted">Kontakter slettet</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!activities || activities.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Activity className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Ingen aktiviteter endnu</p>
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Aktiviteter vil blive logget automatisk når der sker handlinger i systemet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedActivities || {}).map(([group, groupActivities]) => (
            <div key={group} className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
                {group}
              </h3>
              <div className="space-y-3 relative before:absolute before:left-6 before:top-0 before:bottom-0 before:w-px before:bg-border">
                {groupActivities.map((activity) => (
                  <ActivityLogItem key={activity.id} activity={activity} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default CompanyTimelineView;
