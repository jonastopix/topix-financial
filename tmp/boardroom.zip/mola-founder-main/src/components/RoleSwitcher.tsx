import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, User, FileCheck, Briefcase, TrendingUp } from 'lucide-react';
import { useRole } from '@/contexts/RoleContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface RoleSwitcherProps {
  fullWidth?: boolean;
}

const RoleSwitcher = ({ fullWidth = false }: RoleSwitcherProps) => {
  const { activeRole, availableRoles, switchRole } = useRole();

  if (availableRoles.length <= 1) return null;

  const roleConfig: Record<string, { label: string; icon: typeof User; variant: 'default' | 'secondary' | 'outline' }> = {
    founder: {
      label: 'Founder',
      icon: User,
      variant: 'default' as const,
    },
    mola_admin: {
      label: 'MOLA Admin',
      icon: Shield,
      variant: 'secondary' as const,
    },
    dd_partner: {
      label: 'DD Partner',
      icon: FileCheck,
      variant: 'outline' as const,
    },
    fund_partner: {
      label: 'Fund Partner',
      icon: Briefcase,
      variant: 'outline' as const,
    },
    investor: {
      label: 'Investor',
      icon: TrendingUp,
      variant: 'outline' as const,
    },
  };

  const currentConfig = roleConfig[activeRole] || roleConfig.founder;
  const CurrentIcon = currentConfig.icon;

  if (fullWidth) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="w-full h-11 justify-start gap-2">
            <CurrentIcon className="h-4 w-4" />
            <span>{currentConfig.label}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-full z-[100] bg-popover">
          {availableRoles.map((role) => {
            const config = roleConfig[role];
            const Icon = config.icon;
            return (
              <DropdownMenuItem
                key={role}
                onClick={() => switchRole(role)}
                className="gap-2"
              >
                <Icon className="h-4 w-4" />
                {config.label}
                {role === activeRole && (
                  <Badge variant="default" className="ml-auto">
                    Aktiv
                  </Badge>
                )}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="gap-0 sm:gap-2">
          <CurrentIcon className="h-4 w-4" />
          <span className="hidden sm:inline ml-2">{currentConfig.label}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="z-[100] bg-popover">
        {availableRoles.map((role) => {
          const config = roleConfig[role];
          const Icon = config.icon;
          return (
            <DropdownMenuItem
              key={role}
              onClick={() => switchRole(role)}
              className="gap-2"
            >
              <Icon className="h-4 w-4" />
              {config.label}
              {role === activeRole && (
                <Badge variant="default" className="ml-auto">
                  Aktiv
                </Badge>
              )}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default RoleSwitcher;