import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Search } from 'lucide-react';
import { useCVRLookup } from '@/hooks/useCVRLookup';

interface CreateFundDialogProps {
  onCreate: (fund: { 
    name: string; 
    cvr: string; 
    inception_date?: string; 
    target_size_dkk?: number;
    company_type?: string;
    address?: string;
    city?: string;
    zipcode?: string;
  }) => void;
}

export function CreateFundDialog({ onCreate }: CreateFundDialogProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [cvr, setCvr] = useState('');
  const [inceptionDate, setInceptionDate] = useState('');
  const [targetSize, setTargetSize] = useState('');
  const [companyType, setCompanyType] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [zipcode, setZipcode] = useState('');
  const { lookupCVR, isLoading } = useCVRLookup();

  const handleCVRLookup = async () => {
    const { data } = await lookupCVR(cvr);
    if (data) {
      setName(data.name);
      setInceptionDate(data.startdate);
      setCompanyType(data.companytype);
      setAddress(data.address);
      setCity(data.city);
      setZipcode(data.zipcode);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreate({
      name,
      cvr,
      inception_date: inceptionDate || undefined,
      target_size_dkk: targetSize ? parseFloat(targetSize) : undefined,
      company_type: companyType || undefined,
      address: address || undefined,
      city: city || undefined,
      zipcode: zipcode || undefined,
    });
    setName('');
    setCvr('');
    setInceptionDate('');
    setTargetSize('');
    setCompanyType('');
    setAddress('');
    setCity('');
    setZipcode('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Opret Fond
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Opret Ny Fond</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Fond Navn</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="fx MOLA Fund I"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="cvr">CVR Nummer</Label>
            <div className="flex gap-2">
              <Input
                id="cvr"
                type="text"
                value={cvr}
                onChange={(e) => setCvr(e.target.value)}
                placeholder="fx 12345678"
                pattern="\d{8}"
                maxLength={8}
                required
              />
              <Button
                type="button"
                variant="outline"
                onClick={handleCVRLookup}
                disabled={!cvr || !/^\d{8}$/.test(cvr) || isLoading}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="inceptionDate">Stiftelsesdato (valgfri)</Label>
            <Input
              id="inceptionDate"
              type="date"
              value={inceptionDate}
              onChange={(e) => setInceptionDate(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetSize">Target Størrelse DKK (valgfri)</Label>
            <Input
              id="targetSize"
              type="number"
              min="0"
              step="1000"
              value={targetSize}
              onChange={(e) => setTargetSize(e.target.value)}
              placeholder="10000000"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyType">Selskabsform (valgfri)</Label>
            <Input
              id="companyType"
              value={companyType}
              onChange={(e) => setCompanyType(e.target.value)}
              placeholder="fx ApS, A/S"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Adresse (valgfri)</Label>
            <Input
              id="address"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Vejnavn 1"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="city">By (valgfri)</Label>
            <Input
              id="city"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="København"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="zipcode">Postnummer (valgfri)</Label>
            <Input
              id="zipcode"
              value={zipcode}
              onChange={(e) => setZipcode(e.target.value)}
              placeholder="1234"
              maxLength={4}
            />
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Annuller
            </Button>
            <Button type="submit">Opret</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
