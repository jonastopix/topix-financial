import { Badge } from '@/components/ui/badge';
import { DDStatus } from '@/hooks/useDueDiligence';

interface DDStatusBadgeProps {
  status: DDStatus;
}

export function DDStatusBadge({ status }: DDStatusBadgeProps) {
  const statusConfig = {
    not_started: {
      label: 'Ikke startet',
      variant: 'secondary' as const,
      className: '',
    },
    in_progress: {
      label: 'I gang',
      variant: 'default' as const,
      className: '',
    },
    pending_review: {
      label: 'Afventer gennemgang',
      variant: 'outline' as const,
      className: '',
    },
    approved: {
      label: 'Godkendt',
      variant: 'default' as const,
      className: 'bg-green-600 hover:bg-green-700',
    },
    rejected: {
      label: 'Afvist',
      variant: 'destructive' as const,
      className: '',
    },
  };

  const config = statusConfig[status];

  return (
    <Badge variant={config.variant} className={config.className}>
      {config.label}
    </Badge>
  );
}
