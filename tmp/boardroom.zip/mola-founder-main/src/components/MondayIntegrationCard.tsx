import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useMondayIntegration } from '@/hooks/useMondayIntegration';
import { ExternalLink, Loader2, Check, X, RefreshCw, Unplug, Pause, Plug, Settings2, AlertCircle, Webhook } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface MondayBoard {
  id: string;
  name: string;
  columns?: MondayColumn[];
}

interface MondayColumn {
  id: string;
  title: string;
  type: string;
}

export const MondayIntegrationCard = () => {
  const {
    config,
    isLoadingConfig,
    isConnected,
    isActive,
    hasWebhook,
    validateAndFetchBoards,
    selectBoard,
    fetchColumns,
    fetchBoardsWithSavedToken,
    saveColumnMapping,
    toggleSync,
    disconnect,
    recreateWebhook,
  } = useMondayIntegration();

  const [apiToken, setApiToken] = useState('');
  const [boards, setBoards] = useState<MondayBoard[]>([]);
  const [selectedBoardId, setSelectedBoardId] = useState<string>('');
  const [showSetup, setShowSetup] = useState(false);
  const [showColumnMapping, setShowColumnMapping] = useState(false);
  const [columns, setColumns] = useState<MondayColumn[]>([]);
  const [useNewToken, setUseNewToken] = useState(false);
  const [isLoadingSavedToken, setIsLoadingSavedToken] = useState(false);
  
  // Column mapping state
  const [statusColumnId, setStatusColumnId] = useState<string>('');
  const [dateColumnId, setDateColumnId] = useState<string>('');
  const [companyColumnId, setCompanyColumnId] = useState<string>('');
  const [linkColumnId, setLinkColumnId] = useState<string>('');
  const [assigneeColumnId, setAssigneeColumnId] = useState<string>('');

  // Initialize column mapping from config
  useEffect(() => {
    if (config) {
      setStatusColumnId(config.status_column_id || '');
      setDateColumnId(config.date_column_id || '');
      setCompanyColumnId(config.company_column_id || '');
      setLinkColumnId(config.link_column_id || '');
      setAssigneeColumnId(config.assignee_column_id || '');
    }
  }, [config]);

  const handleValidateToken = async () => {
    const result = await validateAndFetchBoards.mutateAsync(apiToken);
    if (result) {
      setBoards(result);
    }
  };

  const handleSelectBoard = async () => {
    if (selectedBoardId) {
      const result = await selectBoard.mutateAsync(selectedBoardId);
      if (result?.columns) {
        setColumns(result.columns);
        setShowColumnMapping(true);
      }
      setShowSetup(false);
      setApiToken('');
      setBoards([]);
    }
  };

  const handleFetchColumns = async () => {
    const result = await fetchColumns.mutateAsync();
    if (result) {
      setColumns(result);
      setShowColumnMapping(true);
    }
  };

  const handleSaveColumnMapping = async () => {
    await saveColumnMapping.mutateAsync({
      status_column_id: statusColumnId || null,
      date_column_id: dateColumnId || null,
      company_column_id: companyColumnId || null,
      link_column_id: linkColumnId || null,
      assignee_column_id: assigneeColumnId || null,
    });
    setShowColumnMapping(false);
  };

  const handleToggleSync = async (checked: boolean) => {
    await toggleSync.mutateAsync(checked);
  };

  const handleDisconnect = async () => {
    await disconnect.mutateAsync();
    setShowSetup(false);
    setApiToken('');
    setBoards([]);
    setSelectedBoardId('');
    setColumns([]);
    setShowColumnMapping(false);
    setUseNewToken(false);
  };

  const handleChangeBoardClick = async () => {
    setIsLoadingSavedToken(true);
    try {
      const result = await fetchBoardsWithSavedToken.mutateAsync();
      setBoards(result);
      setShowSetup(true);
      setUseNewToken(false);
    } catch (error) {
      if (error instanceof Error && error.message === 'TOKEN_EXPIRED') {
        setShowSetup(true);
        setUseNewToken(true);
      }
    } finally {
      setIsLoadingSavedToken(false);
    }
  };

  // Filter columns by type
  const statusColumns = columns.filter(c => c.type === 'color' || c.type === 'status');
  const dateColumns = columns.filter(c => c.type === 'date');
  const textColumns = columns.filter(c => c.type === 'text');
  const linkColumns = columns.filter(c => c.type === 'link');
  const personColumns = columns.filter(c => c.type === 'people' || c.type === 'multiple-person');

  if (isLoadingConfig) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-32 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center",
              isConnected && isActive 
                ? "bg-green-500/10" 
                : isConnected 
                  ? "bg-yellow-500/10" 
                  : "bg-muted"
            )}>
              {isConnected && isActive ? (
                <RefreshCw className="h-5 w-5 text-green-500" />
              ) : isConnected ? (
                <Pause className="h-5 w-5 text-yellow-500" />
              ) : (
                <Plug className="h-5 w-5 text-muted-foreground" />
              )}
            </div>
            <div>
              <CardTitle className="text-lg">Monday.com</CardTitle>
              <CardDescription>Synkroniser opgaver med Monday</CardDescription>
            </div>
          </div>
          {isConnected && (
            <Badge variant={isActive ? 'default' : 'secondary'}>
              {isActive ? 'Aktiv' : 'Inaktiv'}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {isConnected ? (
          <>
            <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
              <div className="space-y-1">
                <p className="text-sm font-medium">Board: {config?.board_name}</p>
                {config?.last_sync_at && (
                  <p className="text-xs text-muted-foreground">
                    Sidst synkroniseret: {format(new Date(config.last_sync_at), 'PPp', { locale: da })}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="sync-toggle" className="text-sm">Synkronisering</Label>
                <Switch
                  id="sync-toggle"
                  checked={isActive}
                  onCheckedChange={handleToggleSync}
                  disabled={toggleSync.isPending}
                />
              </div>
            </div>

            {/* Column mapping summary */}
            <div className="p-4 rounded-lg border bg-card space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium">Kolonne-mapping</h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleFetchColumns}
                  disabled={fetchColumns.isPending}
                >
                  {fetchColumns.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Settings2 className="h-4 w-4" />
                  )}
                  <span className="ml-2">Rediger</span>
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                <div>Status: {config?.status_column_id ? '✓' : '–'}</div>
                <div>Deadline: {config?.date_column_id ? '✓' : '–'}</div>
                <div>Selskab: {config?.company_column_id ? '✓' : '–'}</div>
                <div>Ansvarlig: {config?.assignee_column_id ? '✓' : '–'}</div>
                <div>Link: {config?.link_column_id ? '✓' : '–'}</div>
              </div>
            </div>

            {/* Column mapping editor */}
            {showColumnMapping && columns.length > 0 && (
              <div className="space-y-4 p-4 border rounded-lg">
                <h4 className="font-medium">Vælg kolonne-mapping</h4>
                <p className="text-sm text-muted-foreground">
                  Map felterne fra platformen til dine Monday.com kolonner.
                </p>
                
                <Separator />

                <div className="grid gap-4">
                  {/* Status column */}
                  <div className="space-y-2">
                    <Label>Status-kolonne (påkrævet)</Label>
                    <Select value={statusColumnId || "__none__"} onValueChange={(val) => setStatusColumnId(val === "__none__" ? "" : val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg status-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Vælg en kolonne...</SelectItem>
                        {statusColumns.filter(col => col.id && col.id.trim() !== '').map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Date column */}
                  <div className="space-y-2">
                    <Label>Deadline-kolonne (valgfri)</Label>
                    <Select value={dateColumnId || "__none__"} onValueChange={(val) => setDateColumnId(val === "__none__" ? "" : val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg dato-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Ingen</SelectItem>
                        {dateColumns.filter(col => col.id && col.id.trim() !== '').map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Company column */}
                  <div className="space-y-2">
                    <Label>Selskabs-kolonne (valgfri)</Label>
                    <Select value={companyColumnId || "__none__"} onValueChange={(val) => setCompanyColumnId(val === "__none__" ? "" : val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg tekst-kolonne til selskab" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Ingen</SelectItem>
                        {textColumns.filter(col => col.id && col.id.trim() !== '').map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Assignee column (People type) */}
                  <div className="space-y-2">
                    <Label>Person-kolonne (valgfri)</Label>
                    <Select value={assigneeColumnId || "__none__"} onValueChange={(val) => setAssigneeColumnId(val === "__none__" ? "" : val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg person-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Ingen</SelectItem>
                        {personColumns.filter(col => col.id && col.id.trim() !== '').map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {config?.monday_user_name && (
                      <p className="text-xs text-muted-foreground">
                        Opgaver tildeles automatisk til: <span className="font-medium">{config.monday_user_name}</span>
                      </p>
                    )}
                  </div>

                  {/* Link column */}
                  <div className="space-y-2">
                    <Label>Link-kolonne (valgfri)</Label>
                    <Select value={linkColumnId || "__none__"} onValueChange={(val) => setLinkColumnId(val === "__none__" ? "" : val)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg link-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="__none__">Ingen</SelectItem>
                        {linkColumns.filter(col => col.id && col.id.trim() !== '').map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Tilføjer et direkte link til opgaven i platformen
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={handleSaveColumnMapping}
                    disabled={!statusColumnId || saveColumnMapping.isPending}
                  >
                    {saveColumnMapping.isPending ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Check className="h-4 w-4 mr-2" />
                    )}
                    Gem mapping
                  </Button>
                  <Button variant="ghost" onClick={() => setShowColumnMapping(false)}>
                    <X className="h-4 w-4 mr-2" />
                    Annuller
                  </Button>
                </div>
              </div>
            )}

            {/* Webhook status warning */}
            {isActive && !hasWebhook && (
              <Alert variant="destructive" className="border-yellow-500 bg-yellow-50 dark:bg-yellow-950/20">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800 dark:text-yellow-200">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm">Webhook ikke konfigureret – synkronisering fra Monday.com er ikke aktiv</span>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => recreateWebhook.mutate()}
                      disabled={recreateWebhook.isPending}
                      className="shrink-0"
                    >
                      {recreateWebhook.isPending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Webhook className="h-4 w-4 mr-2" />
                      )}
                      Opret webhook
                    </Button>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Token saved status */}
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Check className="h-3 w-3 text-green-500" />
              API-token gemt sikkert
              {hasWebhook && (
                <>
                  <span className="mx-1">•</span>
                  <Check className="h-3 w-3 text-green-500" />
                  Webhook aktiv
                </>
              )}
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleChangeBoardClick}
                disabled={isLoadingSavedToken}
              >
                {isLoadingSavedToken ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4 mr-2" />
                )}
                Skift board
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleDisconnect}
                disabled={disconnect.isPending}
              >
                <Unplug className="h-4 w-4 mr-2" />
                Afbryd
              </Button>
            </div>

            {showSetup && (
              <div className="space-y-4 p-4 border rounded-lg">
                {/* Show saved token status */}
                {!useNewToken && boards.length > 0 && (
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200 dark:bg-green-950/20 dark:border-green-900">
                    <p className="text-sm text-green-800 dark:text-green-200 flex items-center gap-2">
                      <Check className="h-4 w-4" />
                      Bruger din gemte API-token
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      className="p-0 h-auto text-xs text-green-700 dark:text-green-300"
                      onClick={() => {
                        setUseNewToken(true);
                        setBoards([]);
                      }}
                    >
                      Brug ny token i stedet
                    </Button>
                  </div>
                )}

                {/* New token input - show if needed */}
                {useNewToken && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="api-token">Ny API Token</Label>
                      <Input
                        id="api-token"
                        type="password"
                        placeholder="Indsæt din Monday API token"
                        value={apiToken}
                        onChange={(e) => setApiToken(e.target.value)}
                      />
                    </div>
                    <Button 
                      onClick={handleValidateToken}
                      disabled={!apiToken || validateAndFetchBoards.isPending}
                    >
                      {validateAndFetchBoards.isPending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4 mr-2" />
                      )}
                      Valider token
                    </Button>
                  </>
                )}

                {boards.length > 0 && (
                  <div className="space-y-2">
                    <Label>Vælg board</Label>
                    <Select value={selectedBoardId} onValueChange={setSelectedBoardId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg et board" />
                      </SelectTrigger>
                      <SelectContent>
                        {boards.map((board) => (
                          <SelectItem key={board.id} value={board.id}>
                            {board.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button 
                      onClick={handleSelectBoard}
                      disabled={!selectedBoardId || selectBoard.isPending}
                    >
                      {selectBoard.isPending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : null}
                      Gem board
                    </Button>
                  </div>
                )}

                <Button variant="ghost" size="sm" onClick={() => {
                  setShowSetup(false);
                  setUseNewToken(false);
                  setBoards([]);
                }}>
                  <X className="h-4 w-4 mr-2" />
                  Annuller
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Forbind din Monday.com konto for at synkronisere opgaver automatisk.
            </p>

            <div className="space-y-2">
              <Label htmlFor="api-token">API Token</Label>
              <Input
                id="api-token"
                type="password"
                placeholder="Indsæt din Monday API token"
                value={apiToken}
                onChange={(e) => setApiToken(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Find din token på{' '}
                <a 
                  href="https://monday.com/developers/v2/apps/manage/tokens" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline inline-flex items-center gap-1"
                >
                  monday.com/developers
                  <ExternalLink className="h-3 w-3" />
                </a>
              </p>
            </div>

            <Button 
              onClick={handleValidateToken}
              disabled={!apiToken || validateAndFetchBoards.isPending}
            >
              {validateAndFetchBoards.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Check className="h-4 w-4 mr-2" />
              )}
              Valider og fortsæt
            </Button>

            {boards.length > 0 && (
              <div className="space-y-2 p-4 border rounded-lg bg-muted/50">
                <Label>Vælg board til synkronisering</Label>
                <Select value={selectedBoardId} onValueChange={setSelectedBoardId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Vælg et board" />
                  </SelectTrigger>
                  <SelectContent>
                    {boards.map((board) => (
                      <SelectItem key={board.id} value={board.id}>
                        {board.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button 
                  onClick={handleSelectBoard}
                  disabled={!selectedBoardId || selectBoard.isPending}
                  className="w-full"
                >
                  {selectBoard.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : null}
                  Vælg board og fortsæt
                </Button>
              </div>
            )}

            {/* Column mapping after board selection for new setup */}
            {showColumnMapping && columns.length > 0 && (
              <div className="space-y-4 p-4 border rounded-lg">
                <h4 className="font-medium">Vælg kolonne-mapping</h4>
                <p className="text-sm text-muted-foreground">
                  Map felterne fra platformen til dine Monday.com kolonner.
                </p>
                
                <Separator />

                <div className="grid gap-4">
                  <div className="space-y-2">
                    <Label>Status-kolonne (påkrævet)</Label>
                    <Select value={statusColumnId} onValueChange={setStatusColumnId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg status-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        {statusColumns.map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Deadline-kolonne (valgfri)</Label>
                    <Select value={dateColumnId} onValueChange={setDateColumnId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg dato-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Ingen</SelectItem>
                        {dateColumns.map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Selskabs-kolonne (valgfri)</Label>
                    <Select value={companyColumnId} onValueChange={setCompanyColumnId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg tekst-kolonne til selskab" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Ingen</SelectItem>
                        {textColumns.map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Ansvarlig-kolonne (valgfri)</Label>
                    <Select value={assigneeColumnId} onValueChange={setAssigneeColumnId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg tekst-kolonne til ansvarlig" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Ingen</SelectItem>
                        {textColumns.map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Link-kolonne (valgfri)</Label>
                    <Select value={linkColumnId} onValueChange={setLinkColumnId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Vælg link-kolonne" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Ingen</SelectItem>
                        {linkColumns.map((col) => (
                          <SelectItem key={col.id} value={col.id}>
                            {col.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Tilføjer et direkte link til opgaven i platformen
                    </p>
                  </div>
                </div>

                <Button 
                  onClick={handleSaveColumnMapping}
                  disabled={!statusColumnId || saveColumnMapping.isPending}
                  className="w-full"
                >
                  {saveColumnMapping.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Check className="h-4 w-4 mr-2" />
                  )}
                  Aktiver integration
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
