import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Heart, Sparkles } from 'lucide-react';

interface NPSPromptBannerProps {
  companyId: string;
  onSubmit: () => void;
}

const NPSPromptBanner = ({ companyId, onSubmit }: NPSPromptBannerProps) => {
  const [score, setScore] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { toast } = useToast();

  const now = new Date();
  const quarter = Math.floor(now.getMonth() / 3) + 1;
  const year = now.getFullYear();

  const handleSubmit = async () => {
    if (score === null) {
      toast({
        title: 'Vælg en score',
        description: 'Vælg venligst en score fra 0-10',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);

    const { error } = await supabase.from('nps_responses').insert({
      company_id: companyId,
      score,
      comment: comment || null,
      period_quarter: quarter,
      period_year: year,
    });

    setSubmitting(false);

    if (error) {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke gemme din feedback',
        variant: 'destructive',
      });
      return;
    }

    toast({
      title: 'Tak for dit svar! 🙏',
      description: 'Din NPS-score er blevet gemt',
    });

    setScore(null);
    setComment('');
    onSubmit();
  };

  const getScoreColor = (num: number) => {
    if (num <= 6) return 'bg-destructive text-destructive-foreground';
    if (num <= 8) return 'bg-yellow-500 text-white';
    return 'bg-green-500 text-white';
  };

  const getScoreHoverColor = (num: number) => {
    if (num <= 6) return 'hover:bg-destructive/80';
    if (num <= 8) return 'hover:bg-yellow-500/80';
    return 'hover:bg-green-500/80';
  };

  return (
    <Card className="relative overflow-hidden border-2 border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-background p-6 md:p-8 animate-fade-in">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-primary/10 rounded-full blur-2xl translate-y-1/2 -translate-x-1/2" />
      
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="relative">
            <Heart className="h-8 w-8 text-pink-500 animate-pulse" fill="currentColor" />
            <Sparkles className="h-4 w-4 text-yellow-400 absolute -top-1 -right-1" />
          </div>
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-foreground">
              MOLA Relationship Pulse
            </h2>
            <p className="text-sm text-muted-foreground">
              Q{quarter} {year} • Dit kvartalsvise NPS-feedback afventer
            </p>
          </div>
        </div>

        {/* Description */}
        <p className="text-muted-foreground mb-6 max-w-2xl">
          Hvor sandsynligt er det, at du vil anbefale MOLA til andre founders? Din feedback hjælper os med at forbedre vores service.
        </p>

        {/* Score selection */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2 text-xs md:text-sm text-muted-foreground px-1">
            <span>Usandsynligt</span>
            <span>Meget sandsynligt</span>
          </div>
          <div className="grid grid-cols-11 gap-1 md:gap-2">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
              <Button
                key={num}
                variant={score === num ? 'default' : 'outline'}
                onClick={() => setScore(num)}
                className={`aspect-square p-0 text-sm md:text-base font-semibold transition-all duration-200 ${
                  score === num 
                    ? `${getScoreColor(num)} scale-110 shadow-lg ring-2 ring-offset-2 ring-primary/50` 
                    : `hover:scale-105 ${getScoreHoverColor(num)}`
                }`}
              >
                {num}
              </Button>
            ))}
          </div>
        </div>

        {/* Comment and submit */}
        <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-end">
          <div className="flex-1">
            <Textarea
              placeholder="Kommentar (valgfri) - Del gerne dine tanker om samarbejdet"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="resize-none bg-background/50"
              rows={2}
            />
          </div>
          <Button 
            onClick={handleSubmit} 
            disabled={submitting || score === null}
            size="lg"
            className="md:px-8 bg-primary hover:bg-primary/90 shadow-lg"
          >
            {submitting ? 'Sender...' : 'Send Feedback'}
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default NPSPromptBanner;
