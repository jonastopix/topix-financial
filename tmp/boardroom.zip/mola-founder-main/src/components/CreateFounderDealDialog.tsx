import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useCreateFounderDeal } from "@/hooks/useFounderDeals";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

interface CreateFounderDealDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
}

const CATEGORY_OPTIONS = [
  { value: "saas", label: "SaaS & Tools" },
  { value: "marketing", label: "Marketing" },
  { value: "shipping", label: "Fragt & Levering" },
  { value: "payment", label: "Betaling" },
  { value: "tech", label: "Tech & Development" },
  { value: "design", label: "Design & Creative" },
  { value: "other", label: "Andet" },
];

export function CreateFounderDealDialog({ open, onOpenChange, companyId }: CreateFounderDealDialogProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [discountType, setDiscountType] = useState<"percentage" | "fixed_amount" | "trial_extension" | "other">("percentage");
  const [discountValue, setDiscountValue] = useState("");
  const [promoCode, setPromoCode] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [terms, setTerms] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [productUrl, setProductUrl] = useState("");
  const [maxRedemptions, setMaxRedemptions] = useState("");
  const [validUntil, setValidUntil] = useState("");

  const createMutation = useCreateFounderDeal();

  const handleAddCategory = (category: string) => {
    if (!selectedCategories.includes(category)) {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const handleRemoveCategory = (category: string) => {
    setSelectedCategories(selectedCategories.filter(c => c !== category));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    await createMutation.mutateAsync({
      company_id: companyId,
      title,
      description: description || null,
      discount_type: discountType,
      discount_value: discountValue ? parseFloat(discountValue) : null,
      promo_code: promoCode || null,
      categories: selectedCategories,
      terms: terms || null,
      contact_email: contactEmail || null,
      product_url: productUrl || null,
      max_redemptions: maxRedemptions ? parseInt(maxRedemptions) : null,
      valid_from: new Date().toISOString().split('T')[0],
      valid_until: validUntil || null,
      is_active: true,
    });

    // Reset form
    setTitle("");
    setDescription("");
    setDiscountValue("");
    setPromoCode("");
    setSelectedCategories([]);
    setTerms("");
    setContactEmail("");
    setProductUrl("");
    setMaxRedemptions("");
    setValidUntil("");
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Opret Founder Deal</DialogTitle>
          <DialogDescription>
            Del dit produkt eller service med andre founders i MOLA-porteføljen
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Titel *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="F.eks. '20% rabat på vores SaaS platform'"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Beskrivelse</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Beskriv dit produkt/service og hvad deal'et indeholder"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="discountType">Rabat Type *</Label>
              <Select value={discountType} onValueChange={(value: any) => setDiscountType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Procent</SelectItem>
                  <SelectItem value="fixed_amount">Fast beløb</SelectItem>
                  <SelectItem value="trial_extension">Forlænget prøveperiode</SelectItem>
                  <SelectItem value="other">Andet</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="discountValue">Værdi</Label>
              <Input
                id="discountValue"
                type="number"
                value={discountValue}
                onChange={(e) => setDiscountValue(e.target.value)}
                placeholder={discountType === 'percentage' ? '20' : '500'}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="promoCode">Promo Kode</Label>
            <Input
              id="promoCode"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="MOLA2024"
            />
          </div>

          <div className="space-y-2">
            <Label>Kategorier *</Label>
            <Select onValueChange={handleAddCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Vælg kategorier" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORY_OPTIONS.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex flex-wrap gap-2 mt-2">
              {selectedCategories.map((cat) => (
                <Badge key={cat} variant="secondary" className="gap-1">
                  {CATEGORY_OPTIONS.find(c => c.value === cat)?.label}
                  <button
                    type="button"
                    onClick={() => handleRemoveCategory(cat)}
                    className="hover:text-destructive"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="terms">Betingelser</Label>
            <Textarea
              id="terms"
              value={terms}
              onChange={(e) => setTerms(e.target.value)}
              placeholder="F.eks. 'Gælder kun første 3 måneder' eller 'Max 1 per virksomhed'"
              rows={2}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="contactEmail">Kontakt Email</Label>
              <Input
                id="contactEmail"
                type="email"
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                placeholder="kontakt@dinvirksomhed.dk"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="productUrl">Produkt URL</Label>
              <Input
                id="productUrl"
                type="url"
                value={productUrl}
                onChange={(e) => setProductUrl(e.target.value)}
                placeholder="https://dinvirksomhed.dk"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxRedemptions">Max Antal (valgfrit)</Label>
              <Input
                id="maxRedemptions"
                type="number"
                value={maxRedemptions}
                onChange={(e) => setMaxRedemptions(e.target.value)}
                placeholder="Ubegrænset"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="validUntil">Udløber (valgfrit)</Label>
              <Input
                id="validUntil"
                type="date"
                value={validUntil}
                onChange={(e) => setValidUntil(e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Annuller
            </Button>
            <Button type="submit" disabled={createMutation.isPending}>
              {createMutation.isPending ? "Opretter..." : "Opret Deal"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
