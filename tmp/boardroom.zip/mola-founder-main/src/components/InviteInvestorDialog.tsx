import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Mail, Building2, Percent } from 'lucide-react';
import { useInviteInvestor } from '@/hooks/useInviteInvestor';
import { type CapTableEntry } from '@/hooks/useCompanyCapTable';

interface InviteInvestorDialogProps {
  entry: CapTableEntry;
  companyId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function InviteInvestorDialog({ entry, companyId, open, onOpenChange }: InviteInvestorDialogProps) {
  const inviteInvestor = useInviteInvestor();

  const handleInvite = () => {
    if (!entry.owner_email) {
      return;
    }

    inviteInvestor.mutate(
      {
        capTableEntryId: entry.id,
        email: entry.owner_email,
        companyId,
      },
      {
        onSuccess: () => {
          onOpenChange(false);
        },
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Inviter investor</DialogTitle>
          <DialogDescription>
            Send invitation til {entry.owner_name} for at give adgang til investor portalen
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Investor</p>
              <p className="text-sm text-muted-foreground">{entry.owner_name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <Mail className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Email</p>
              <p className="text-sm text-muted-foreground">{entry.owner_email}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
            <Percent className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">Ejerandel</p>
              <p className="text-sm text-muted-foreground">{entry.ownership_pct}%</p>
            </div>
          </div>

          <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <p className="text-sm font-medium mb-2">Investor får adgang til:</p>
            <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
              <li>View-only finansielle data</li>
              <li>Registrere møder</li>
              <li>Læse eksisterende møder</li>
              <li>Tilføje private noter</li>
            </ul>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Annuller
          </Button>
          <Button onClick={handleInvite} disabled={inviteInvestor.isPending}>
            {inviteInvestor.isPending ? 'Sender invitation...' : 'Send invitation'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
