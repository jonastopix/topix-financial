import { Users, Eye } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useOnlinePresence } from '@/hooks/useOnlinePresence';
import { motion, AnimatePresence } from 'framer-motion';

export function OnlineUsersIndicator() {
  const { onlineUsers, totalOnline } = useOnlinePresence();

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'mola_admin': return 'Admin';
      case 'founder': return 'Founder';
      case 'fund_partner': return 'Fund Partner';
      default: return role;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'mola_admin': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300';
      case 'founder': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300';
      case 'fund_partner': return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const sortedUsers = [...onlineUsers].sort((a, b) => {
    const roleOrder = { mola_admin: 0, founder: 1, fund_partner: 2 };
    return (roleOrder[a.role as keyof typeof roleOrder] || 3) - (roleOrder[b.role as keyof typeof roleOrder] || 3);
  });

  return (
    <Popover>
      <PopoverTrigger asChild>
        <button className="relative flex items-center gap-2 px-3 py-1.5 rounded-md hover:bg-accent transition-colors">
          <Users className="h-4 w-4 text-muted-foreground" />
          <Badge variant="secondary" className="gap-1.5">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            {totalOnline === 0 ? '1' : totalOnline}
          </Badge>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4" align="end">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-semibold text-sm">Online Brugere</h4>
            <Badge variant="outline" className="gap-1.5">
              <span className="h-2 w-2 rounded-full bg-green-500"></span>
              {totalOnline} aktive
            </Badge>
          </div>
          
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {totalOnline === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                <p className="text-sm">Kun dig online i øjeblikket</p>
              </div>
            ) : (
              <AnimatePresence mode="popLayout">
                {sortedUsers.map((user) => (
                  <motion.div 
                    key={user.user_id}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    layout
                    className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors"
                  >
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="text-xs bg-primary/10 text-primary">
                        {getInitials(user.full_name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium truncate">{user.full_name}</p>
                        <span className="h-1.5 w-1.5 rounded-full bg-green-500 flex-shrink-0"></span>
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <Badge 
                          variant="secondary" 
                          className={`text-xs px-1.5 py-0 ${getRoleBadgeColor(user.role)}`}
                        >
                          {getRoleLabel(user.role)}
                        </Badge>
                      </div>
                      {/* Show current page */}
                      {user.current_page_label && (
                        <motion.div 
                          key={user.current_page}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex items-center gap-1 mt-1"
                        >
                          <Eye className="h-3 w-3 text-muted-foreground" />
                          <p className="text-xs text-muted-foreground truncate">
                            {user.current_page_label}
                          </p>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            )}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}
