import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { usePortfolioAggregates } from '@/hooks/usePortfolioAggregates';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown, Minus, BarChart3, Percent, Building2 } from 'lucide-react';
import { useMemo } from 'react';

export function PortfolioPulseWidget() {
  const { data: aggregates, isLoading } = usePortfolioAggregates();

  const trendDisplay = useMemo(() => {
    if (!aggregates) return null;
    
    switch (aggregates.portfolioTrend) {
      case 'up':
        return {
          icon: <TrendingUp className="h-5 w-5 text-green-500" />,
          text: 'Stigende',
          color: 'text-green-500'
        };
      case 'down':
        return {
          icon: <TrendingDown className="h-5 w-5 text-red-500" />,
          text: 'Faldende',
          color: 'text-red-500'
        };
      default:
        return {
          icon: <Minus className="h-5 w-5 text-muted-foreground" />,
          text: 'Stabil',
          color: 'text-muted-foreground'
        };
    }
  }, [aggregates]);

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Portfolio Puls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!aggregates || !trendDisplay) {
    return null;
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Portfolio Puls
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Portfolio Trend */}
          <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-muted-foreground">Portfolio Trend</p>
              {trendDisplay.icon}
            </div>
            <div className="flex-1 flex items-center">
              <p className={`text-2xl lg:text-3xl font-bold truncate ${trendDisplay.color}`}>
                {trendDisplay.text}
              </p>
            </div>
            <div className="h-5"></div>
          </Card>

          {/* Marketing % */}
          <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-muted-foreground">Gns. Marketing %</p>
              <Percent className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 flex items-center">
              <p className="text-2xl lg:text-3xl font-bold truncate">
                {aggregates.avgMarketingPct !== null ? `${aggregates.avgMarketingPct.toFixed(1)}%` : 'N/A'}
              </p>
            </div>
            <div className="h-5">
              <p className="text-xs text-muted-foreground">på tværs af portfolio</p>
            </div>
          </Card>

          {/* EBITDA Margin */}
          <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-muted-foreground">Gns. EBITDA Margin</p>
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 flex items-center">
              <p className="text-2xl lg:text-3xl font-bold truncate">
                {aggregates.avgEbitdaMargin !== null ? `${aggregates.avgEbitdaMargin.toFixed(1)}%` : 'N/A'}
              </p>
            </div>
            <div className="h-5">
              <p className="text-xs text-muted-foreground">på tværs af portfolio</p>
            </div>
          </Card>

          {/* Profitable Companies */}
          <Card className="p-4 min-h-[120px] flex flex-col overflow-hidden min-w-0">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-muted-foreground">Profitable Selskaber</p>
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1 flex items-center">
              <p className="text-2xl lg:text-3xl font-bold truncate">
                {aggregates.profitableCompanies} af {aggregates.totalActiveCompanies}
              </p>
            </div>
            <div className="h-5">
              <p className="text-xs text-muted-foreground">
                {aggregates.totalActiveCompanies > 0
                  ? `${((aggregates.profitableCompanies / aggregates.totalActiveCompanies) * 100).toFixed(0)}% af portfolio`
                  : 'Ingen data'}
              </p>
            </div>
          </Card>
        </div>
      </CardContent>
    </Card>
  );
}
