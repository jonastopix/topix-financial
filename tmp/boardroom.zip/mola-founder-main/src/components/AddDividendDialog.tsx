import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useDividendMutations } from '@/hooks/useDividendMutations';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface AddDividendDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companyId: string;
  fundId: string;
}

export function AddDividendDialog({ open, onOpenChange, companyId, fundId }: AddDividendDialogProps) {
  const { createDividend } = useDividendMutations();
  const [declaredDate, setDeclaredDate] = useState<Date>();
  const [declaredDateOpen, setDeclaredDateOpen] = useState(false);
  const [paidDate, setPaidDate] = useState<Date>();
  const [paidDateOpen, setPaidDateOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!declaredDate || !paidDate || !amount) {
      return;
    }

    await createDividend.mutateAsync({
      company_id: companyId,
      fund_id: fundId,
      declared_date: format(declaredDate, 'yyyy-MM-dd'),
      paid_date: format(paidDate, 'yyyy-MM-dd'),
      amount_dkk: parseFloat(amount),
      note: note || undefined,
    });

    // Reset form
    setDeclaredDate(undefined);
    setPaidDate(undefined);
    setAmount('');
    setNote('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Dividend</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="declared_date">Declared Date *</Label>
            <Popover open={declaredDateOpen} onOpenChange={setDeclaredDateOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !declaredDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {declaredDate ? format(declaredDate, 'dd MMM yyyy') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 z-50">
                <Calendar
                  mode="single"
                  selected={declaredDate}
                  onSelect={(date) => {
                    setDeclaredDate(date);
                    setDeclaredDateOpen(false);
                  }}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="paid_date">Paid Date *</Label>
            <Popover open={paidDateOpen} onOpenChange={setPaidDateOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    'w-full justify-start text-left font-normal',
                    !paidDate && 'text-muted-foreground'
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {paidDate ? format(paidDate, 'dd MMM yyyy') : 'Pick a date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 z-50">
                <Calendar
                  mode="single"
                  selected={paidDate}
                  onSelect={(date) => {
                    setPaidDate(date);
                    setPaidDateOpen(false);
                  }}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount">Amount (DKK) *</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="100000"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="note">Note (Optional)</Label>
            <Textarea
              id="note"
              placeholder="Additional information about this dividend..."
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!declaredDate || !paidDate || !amount || createDividend.isPending}
            >
              {createDividend.isPending ? 'Saving...' : 'Add Dividend'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
