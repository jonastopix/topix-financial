import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';

type AIFeedback = {
  id: string;
  report_id: string;
  summary: string;
  key_observations: string[];
  recommendations: string[];
  slack_line: string;
  created_at: string;
};

export function BoardroomAIFeedbackCard({ reportId }: { reportId?: string }) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<AIFeedback | null>(null);

  const load = async () => {
    if (!reportId) return;
    const { data, error } = await supabase
      .from('ai_feedback')
      .select('*')
      .eq('report_id', reportId)
      .maybeSingle();
    if (error) throw error;
    setFeedback(data as any);
  };

  useEffect(() => {
    load().catch(() => {
      // silent
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reportId]);

  const generate = async () => {
    if (!reportId) return;
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('boardroom-generate-feedback', {
        body: { report_id: reportId },
      });
      if (error) throw error;
      await load();
      toast({ title: 'AI feedback opdateret' });
    } catch (e: any) {
      toast({
        title: 'Kunne ikke generere AI feedback',
        description: e?.message ?? 'Ukendt fejl',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle>AI feedback</CardTitle>
        <Button onClick={generate} disabled={!reportId || loading}>
          {feedback ? 'Opdatér' : 'Generér'}
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {!reportId && <div className="text-sm text-muted-foreground">Gem rapporten først.</div>}

        {reportId && !feedback && (
          <div className="text-sm text-muted-foreground">
            Ingen AI feedback endnu. Tryk “Generér” når tallene er indtastet.
          </div>
        )}

        {feedback && (
          <>
            <div className="text-sm leading-relaxed">{feedback.summary}</div>
            <Separator />

            <div>
              <div className="text-sm font-medium mb-2">Vigtigste observationer</div>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                {(feedback.key_observations || []).slice(0, 3).map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>

            <div>
              <div className="text-sm font-medium mb-2">Anbefalinger (næste skridt)</div>
              <ul className="list-disc pl-5 space-y-1 text-sm">
                {(feedback.recommendations || []).slice(0, 4).map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>

            <Separator />
            <div>
              <div className="text-sm font-medium mb-2">Slack-linje</div>
              <div className="text-sm font-mono bg-muted rounded-md p-3">{feedback.slack_line}</div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
