import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  AlertTriangle, 
  AlertCircle, 
  Info,
  TrendingDown,
  Clock,
  FileText,
  DollarSign,
  Users
} from 'lucide-react';
import { calculateScorecard, calculateHealthIndex, calculateYTD, calculateYOY } from '@/lib/metricsCalculations';
import { useNavigate } from 'react-router-dom';

type AlertSeverity = 'critical' | 'warning' | 'info';

interface Alert {
  id: string;
  severity: AlertSeverity;
  title: string;
  description: string;
  companyId: string;
  companyName: string;
  category: 'health' | 'financial' | 'reporting' | 'growth';
  actionUrl?: string;
}

export function RiskAlertsWidget() {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  const { data: alerts, isLoading } = useQuery({
    queryKey: ['risk-alerts', currentYear, currentMonth],
    queryFn: async () => {
      const alerts: Alert[] = [];

      // Get all active companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true);
      
      if (companiesError) throw companiesError;

      // Get monthly reports
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', companies?.map(c => c.id) || []);
      
      if (reportsError) throw reportsError;

      // Get NPS responses
      const { data: npsData, error: npsError } = await supabase
        .from('nps_responses')
        .select('*')
        .in('company_id', companies?.map(c => c.id) || []);
      
      if (npsError) throw npsError;

      companies?.forEach(company => {
        const companyReports = reports?.filter(r => r.company_id === company.id) || [];
        const companyNPS = npsData?.filter(n => n.company_id === company.id) || [];
        
        // Check for missing monthly report
        const hasCurrentMonthReport = companyReports.some(
          r => r.period_month === currentMonth && r.period_year === currentYear
        );
        
        if (!hasCurrentMonthReport && currentMonth > 1) {
          alerts.push({
            id: `missing-report-${company.id}`,
            severity: 'warning',
            title: 'Manglende månedlig rapport',
            description: `${company.name} har ikke indrapporteret for ${currentMonth}/${currentYear}`,
            companyId: company.id,
            companyName: company.name,
            category: 'reporting',
            actionUrl: `/company/${company.id}`,
          });
        }

        // Calculate health metrics
        if (companyReports.length > 0) {
          const scorecard = calculateScorecard(companyReports, companyNPS, currentYear);
          const healthIndex = calculateHealthIndex(
            scorecard.financial,
            scorecard.growth,
            scorecard.transparency,
            scorecard.relationship
          );

          // Critical health alert
          if (healthIndex < 50) {
            alerts.push({
              id: `critical-health-${company.id}`,
              severity: 'critical',
              title: 'Kritisk health index',
              description: `${company.name} har health index på ${Math.round(healthIndex)} - kræver handling`,
              companyId: company.id,
              companyName: company.name,
              category: 'health',
              actionUrl: `/company/${company.id}`,
            });
          }

          // Financial performance alerts
          const ytd = calculateYTD(companyReports, currentYear);
          if (ytd.ebitda < 0 && companyReports.length >= 3) {
            alerts.push({
              id: `negative-ebitda-${company.id}`,
              severity: 'warning',
              title: 'Negativ EBITDA YTD',
              description: `${company.name} har negativ EBITDA på ${Math.round(ytd.ebitda).toLocaleString('da-DK')} DKK`,
              companyId: company.id,
              companyName: company.name,
              category: 'financial',
              actionUrl: `/company/${company.id}`,
            });
          }

          // Growth alerts
          const yoy = calculateYOY(companyReports, currentYear);
          if (yoy.revenueGrowth < -10 && companyReports.length >= 12) {
            alerts.push({
              id: `declining-revenue-${company.id}`,
              severity: 'warning',
              title: 'Faldende omsætning',
              description: `${company.name} har YOY omsætningsfald på ${Math.abs(yoy.revenueGrowth).toFixed(1)}%`,
              companyId: company.id,
              companyName: company.name,
              category: 'growth',
              actionUrl: `/company/${company.id}`,
            });
          }

          // Low cash alert
          if (ytd.cash < 100000 && ytd.cash > 0) {
            alerts.push({
              id: `low-cash-${company.id}`,
              severity: 'critical',
              title: 'Lav likviditet',
              description: `${company.name} har kun ${Math.round(ytd.cash).toLocaleString('da-DK')} DKK i likviditet`,
              companyId: company.id,
              companyName: company.name,
              category: 'financial',
              actionUrl: `/company/${company.id}`,
            });
          }
        }

        // Transparency alerts
        const recentReports = companyReports
          .filter(r => r.period_year === currentYear || (r.period_year === currentYear - 1 && r.period_month >= currentMonth))
          .slice(-3);
        
        if (recentReports.length < 3 && companyReports.length > 0) {
          alerts.push({
            id: `inconsistent-reporting-${company.id}`,
            severity: 'info',
            title: 'Inkonsistent rapportering',
            description: `${company.name} har kun ${recentReports.length} af de sidste 3 måneder rapporteret`,
            companyId: company.id,
            companyName: company.name,
            category: 'reporting',
            actionUrl: `/company/${company.id}`,
          });
        }
      });

      // Sort alerts by severity
      const severityOrder = { critical: 0, warning: 1, info: 2 };
      return alerts.sort((a, b) => severityOrder[a.severity] - severityOrder[b.severity]);
    },
  });

  if (isLoading || !alerts) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Risk Alerts</h2>
        </div>
        <p className="text-muted-foreground">Indlæser...</p>
      </Card>
    );
  }

  const criticalAlerts = alerts.filter(a => a.severity === 'critical');
  const warningAlerts = alerts.filter(a => a.severity === 'warning');
  const infoAlerts = alerts.filter(a => a.severity === 'info');

  const getSeverityIcon = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      case 'info':
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  const getSeverityBadge = (severity: AlertSeverity) => {
    switch (severity) {
      case 'critical':
        return <Badge variant="destructive">Kritisk</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Advarsel</Badge>;
      case 'info':
        return <Badge variant="secondary">Info</Badge>;
    }
  };

  const getCategoryIcon = (category: Alert['category']) => {
    switch (category) {
      case 'health':
        return <AlertTriangle className="h-4 w-4" />;
      case 'financial':
        return <DollarSign className="h-4 w-4" />;
      case 'reporting':
        return <FileText className="h-4 w-4" />;
      case 'growth':
        return <TrendingDown className="h-4 w-4" />;
    }
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Risk Alerts</h2>
        </div>
        <div className="flex items-center gap-2">
          {criticalAlerts.length > 0 && (
            <Badge variant="destructive">{criticalAlerts.length} kritiske</Badge>
          )}
          {warningAlerts.length > 0 && (
            <Badge className="bg-yellow-500">{warningAlerts.length} advarsler</Badge>
          )}
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="text-center py-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-500/10 mb-4">
            <Users className="h-8 w-8 text-green-500" />
          </div>
          <p className="font-semibold text-lg">Ingen aktive alerts</p>
          <p className="text-muted-foreground text-sm">Portfolio ser godt ud!</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {alerts.slice(0, 10).map(alert => (
            <div
              key={alert.id}
              className="p-4 rounded-lg border transition-colors hover:bg-muted/50 cursor-pointer"
              onClick={() => alert.actionUrl && navigate(alert.actionUrl)}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {getSeverityIcon(alert.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    {getSeverityBadge(alert.severity)}
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      {getCategoryIcon(alert.category)}
                      <span className="capitalize">{alert.category}</span>
                    </div>
                  </div>
                  <p className="font-semibold text-sm">{alert.title}</p>
                  <p className="text-sm text-muted-foreground">{alert.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {alerts.length > 10 && (
        <div className="mt-4 pt-4 border-t text-center">
          <p className="text-sm text-muted-foreground">
            Viser 10 af {alerts.length} alerts
          </p>
        </div>
      )}
    </Card>
  );
}
