import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  DollarSign, 
  TrendingUp, 
  Droplet, 
  Users, 
  Target, 
  Megaphone,
  Briefcase,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Sparkles,
  Clock
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import ConfettiCelebration from './ConfettiCelebration';

interface MonthlyReportFormProps {
  companyId?: string;
  onSubmit: () => void;
  initialMonth?: number | null;
}

interface FormData {
  month: string;
  year: string;
  revenue: string;
  budgetRevenue: string;
  ebitda: string;
  budgetEbitda: string;
  marketingCost: string;
  budgetMarketingCost: string;
  salaryCost: string;
  liquidity: string;
  newCustomers: string;
  comments: string;
}

const SmartMonthlyReportForm = ({ companyId, onSubmit, initialMonth }: MonthlyReportFormProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<FormData>({
    month: '',
    year: new Date().getFullYear().toString(),
    revenue: '',
    budgetRevenue: '',
    ebitda: '',
    budgetEbitda: '',
    marketingCost: '',
    budgetMarketingCost: '',
    salaryCost: '',
    liquidity: '',
    newCustomers: '',
    comments: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [lastMonthData, setLastMonthData] = useState<any>(null);
  const [existingReport, setExistingReport] = useState<any>(null);
  const { toast } = useToast();

  // Update selected month when initialMonth prop changes
  useEffect(() => {
    if (initialMonth !== null && initialMonth !== undefined) {
      setFormData(prev => ({ ...prev, month: initialMonth.toString() }));
    }
  }, [initialMonth]);

  // Fetch last month's data for smart pre-fill
  const fetchLastMonth = async () => {
    if (!companyId) return;
    
    const { data } = await supabase
      .from('monthly_reports')
      .select('*')
      .eq('company_id', companyId)
      .gt('revenue_dkk', 0) // Only get reports with actual data
      .order('period_year', { ascending: false })
      .order('period_month', { ascending: false })
      .limit(1)
      .single();
    
    if (data) {
      setLastMonthData(data);
    }
  };

  useEffect(() => {
    fetchLastMonth();
  }, [companyId]);

  // Check if report exists for selected period
  useEffect(() => {
    const checkExistingReport = async () => {
      if (!companyId || !formData.month || !formData.year) {
        setExistingReport(null);
        return;
      }
      
      const { data } = await supabase
        .from('monthly_reports')
        .select('*')
        .eq('company_id', companyId)
        .eq('period_month', parseInt(formData.month))
        .eq('period_year', parseInt(formData.year))
        .maybeSingle();
      
      // Check if this is a budget-only record (revenue_dkk IS NULL but budget exists)
      if (data && data.revenue_dkk === null && data.budget_revenue_dkk !== null) {
        // Pre-fill form with budget data for update
        setFormData(prev => ({
          ...prev,
          budgetRevenue: data.budget_revenue_dkk?.toString() || '',
          budgetEbitda: data.budget_ebitda_dkk?.toString() || '',
          budgetMarketingCost: data.budget_marketing_cost_dkk?.toString() || '',
        }));
        setExistingReport(data);
      } else if (data && data.revenue_dkk !== null && Number(data.revenue_dkk) > 0) {
        // Actual report exists (not just budget) - block submission
        setExistingReport(data);
      } else {
        setExistingReport(null);
      }
    };
    checkExistingReport();
  }, [companyId, formData.month, formData.year]);

  const steps = [
    {
      title: 'Vælg periode',
      description: 'Hvilken måned rapporterer du?',
      icon: Clock,
      fields: ['month', 'year'],
      estimatedTime: '10 sek'
    },
    {
      title: 'Omsætning',
      description: 'Hvordan gik det med salget?',
      icon: DollarSign,
      fields: ['revenue', 'budgetRevenue'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Resultat',
      description: 'Hvad var jeres bundlinje?',
      icon: TrendingUp,
      fields: ['ebitda', 'budgetEbitda'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Marketing',
      description: 'Hvor meget brugte I på marketing?',
      icon: Megaphone,
      fields: ['marketingCost', 'budgetMarketingCost'],
      estimatedTime: '15 sek'
    },
    {
      title: 'Løn',
      description: 'Hvad var jeres lønudgifter?',
      icon: Briefcase,
      fields: ['salaryCost'],
      estimatedTime: '15 sek'
    },
    {
      title: 'Vækst & Likviditet',
      description: 'Nye kunder og cash position',
      icon: Users,
      fields: ['liquidity', 'newCustomers'],
      estimatedTime: '20 sek'
    },
    {
      title: 'Kommentarer',
      description: 'Har du noget at tilføje? (valgfrit)',
      icon: Sparkles,
      fields: ['comments'],
      estimatedTime: '30 sek'
    },
  ];

  const totalSteps = steps.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const updateField = (field: keyof FormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isStepValid = () => {
    const currentFields = steps[currentStep].fields;
    
    // Comments step is optional
    if (currentStep === 5) return true;
    
    // Check if actual report already exists (not just budget - revenue must be > 0)
    if (currentStep === 0 && existingReport && existingReport.revenue_dkk !== null && Number(existingReport.revenue_dkk) > 0) return false;
    
    return currentFields.every(field => {
      const value = formData[field as keyof FormData];
      // Budget fields are optional
      if (field.includes('budget')) return true;
      return value && value.trim() !== '';
    });
  };

  const handleNext = () => {
    if (!isStepValid()) {
      if (currentStep === 0 && existingReport) {
        toast({
          title: "Rapport eksisterer allerede",
          description: "Der findes allerede en rapport for denne måned/år. Vælg venligst en anden periode.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Udfyld venligst alle felter",
          description: "Du skal udfylde de påkrævede felter før du kan fortsætte.",
          variant: "destructive",
        });
      }
      return;
    }
    
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    if (!companyId) return;
    
    setSubmitting(true);

    const reportData = {
      company_id: companyId,
      period_month: parseInt(formData.month),
      period_year: parseInt(formData.year),
      revenue_dkk: parseFloat(formData.revenue),
      budget_revenue_dkk: formData.budgetRevenue ? parseFloat(formData.budgetRevenue) : null,
      ebitda_dkk: parseFloat(formData.ebitda),
      budget_ebitda_dkk: formData.budgetEbitda ? parseFloat(formData.budgetEbitda) : null,
      marketing_cost_dkk: formData.marketingCost ? parseFloat(formData.marketingCost) : null,
      budget_marketing_cost_dkk: formData.budgetMarketingCost ? parseFloat(formData.budgetMarketingCost) : null,
      salary_cost_dkk: formData.salaryCost ? parseFloat(formData.salaryCost) : null,
      cash_dkk: parseFloat(formData.liquidity),
      new_customers: parseInt(formData.newCustomers),
      note: formData.comments || null,
    };

    // Use upsert to handle both new records and budget updates
    const { data: newReport, error } = await supabase
      .from('monthly_reports')
      .upsert(reportData, {
        onConflict: 'company_id,period_month,period_year',
        ignoreDuplicates: false
      })
      .select()
      .single();

    setSubmitting(false);

    if (error) {
      toast({
        title: "Fejl",
        description: "Kunne ikke gemme rapporten",
        variant: "destructive",
      });
      return;
    }

    // Trigger celebration
    setShowCelebration(true);

    // Trigger milestone detection
    if (newReport?.id) {
      try {
        await supabase.functions.invoke('detect-milestones', {
          body: { reportId: newReport.id }
        });
      } catch (error) {
        console.error('Failed to detect milestones:', error);
      }
    }

    // Trigger auto-calculation of valuation
    try {
      await supabase.functions.invoke('calculate-valuation', {
        body: { company_id: companyId }
      });
    } catch (error) {
      console.error('Failed to trigger valuation:', error);
    }

    // Reset after celebration
    setTimeout(() => {
      setShowCelebration(false);
        setFormData({
          month: '',
          year: new Date().getFullYear().toString(),
          revenue: '',
          budgetRevenue: '',
          ebitda: '',
          budgetEbitda: '',
          marketingCost: '',
          budgetMarketingCost: '',
          salaryCost: '',
          liquidity: '',
          newCustomers: '',
          comments: '',
        });
      setCurrentStep(0);
      fetchLastMonth(); // Refresh last month data
      onSubmit();
    }, 3000);
  };

  const StepIcon = steps[currentStep].icon;

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="month">Måned</Label>
                <Select value={formData.month} onValueChange={(value) => updateField('month', value)}>
                  <SelectTrigger className="text-lg">
                    <SelectValue placeholder="Vælg måned" />
                  </SelectTrigger>
                  <SelectContent className="bg-card">
                    <SelectItem value="1">Januar</SelectItem>
                    <SelectItem value="2">Februar</SelectItem>
                    <SelectItem value="3">Marts</SelectItem>
                    <SelectItem value="4">April</SelectItem>
                    <SelectItem value="5">Maj</SelectItem>
                    <SelectItem value="6">Juni</SelectItem>
                    <SelectItem value="7">Juli</SelectItem>
                    <SelectItem value="8">August</SelectItem>
                    <SelectItem value="9">September</SelectItem>
                    <SelectItem value="10">Oktober</SelectItem>
                    <SelectItem value="11">November</SelectItem>
                    <SelectItem value="12">December</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="year">År</Label>
                <Select value={formData.year} onValueChange={(value) => updateField('year', value)}>
                  <SelectTrigger className="text-lg">
                    <SelectValue placeholder="Vælg år" />
                  </SelectTrigger>
                  <SelectContent className="bg-card">
                    <SelectItem value="2020">2020</SelectItem>
                    <SelectItem value="2021">2021</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                    <SelectItem value="2026">2026</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {lastMonthData && (
              <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
                <p className="text-sm text-accent flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Sidste rapport var for {lastMonthData.period_month}/{lastMonthData.period_year}
                </p>
              </div>
            )}
            {existingReport && existingReport.revenue_dkk === null && (
              <div className="p-3 bg-accent/10 border border-accent/20 rounded-lg">
                <p className="text-sm text-accent font-medium flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Budget findes for denne måned - udfyld faktiske tal
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Budget: {existingReport.budget_revenue_dkk?.toLocaleString('da-DK')} kr.
                </p>
              </div>
            )}
            {existingReport && existingReport.revenue_dkk !== null && (
              <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                <p className="text-sm text-destructive font-medium">
                  ⚠️ Der findes allerede en rapport for denne måned/år
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Vælg en anden måned eller kontakt support for at opdatere eksisterende rapport
                </p>
              </div>
            )}
          </div>
        );

      case 1:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="revenue" className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-accent" />
                Omsætning (kr.)
              </Label>
              <Input
                id="revenue"
                type="number"
                placeholder={lastMonthData ? `Sidst: ${lastMonthData.revenue_dkk.toLocaleString('da-DK')} kr.` : '1200000'}
                value={formData.revenue}
                onChange={(e) => updateField('revenue', e.target.value)}
                className="text-lg"
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetRevenue" className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                Omsætning Budget (kr.) - valgfrit
              </Label>
              <Input
                id="budgetRevenue"
                type="number"
                placeholder={lastMonthData?.budget_revenue_dkk ? `Sidst: ${lastMonthData.budget_revenue_dkk.toLocaleString('da-DK')} kr.` : '1100000'}
                value={formData.budgetRevenue}
                onChange={(e) => updateField('budgetRevenue', e.target.value)}
                className="text-lg"
              />
            </div>
            {formData.revenue && formData.budgetRevenue && (
              <InstantFeedback
                actual={parseFloat(formData.revenue)}
                budget={parseFloat(formData.budgetRevenue)}
                label="omsætning"
              />
            )}
          </div>
        );

      case 2:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="ebitda" className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-accent" />
                Resultat før skat (kr.)
              </Label>
              <Input
                id="ebitda"
                type="number"
                placeholder={lastMonthData ? `Sidst: ${lastMonthData.ebitda_dkk.toLocaleString('da-DK')} kr.` : '180000'}
                value={formData.ebitda}
                onChange={(e) => updateField('ebitda', e.target.value)}
                className="text-lg"
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetEbitda" className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                Resultat før skat Budget (kr.) - valgfrit
              </Label>
              <Input
                id="budgetEbitda"
                type="number"
                placeholder={lastMonthData?.budget_ebitda_dkk ? `Sidst: ${lastMonthData.budget_ebitda_dkk.toLocaleString('da-DK')} kr.` : '150000'}
                value={formData.budgetEbitda}
                onChange={(e) => updateField('budgetEbitda', e.target.value)}
                className="text-lg"
              />
            </div>
            {formData.ebitda && formData.budgetEbitda && (
              <InstantFeedback
                actual={parseFloat(formData.ebitda)}
                budget={parseFloat(formData.budgetEbitda)}
                label="resultat"
              />
            )}
          </div>
        );

      case 3:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="marketingCost" className="flex items-center gap-2">
                <Megaphone className="h-4 w-4 text-accent" />
                Marketing omkostninger (kr.) - valgfrit
              </Label>
              <Input
                id="marketingCost"
                type="number"
                placeholder={lastMonthData?.marketing_cost_dkk ? `Sidst: ${lastMonthData.marketing_cost_dkk.toLocaleString('da-DK')} kr.` : '120000'}
                value={formData.marketingCost}
                onChange={(e) => updateField('marketingCost', e.target.value)}
                className="text-lg"
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="budgetMarketingCost" className="flex items-center gap-2">
                <Target className="h-4 w-4 text-muted-foreground" />
                Marketing omkostninger Budget (kr.) - valgfrit
              </Label>
              <Input
                id="budgetMarketingCost"
                type="number"
                placeholder={lastMonthData?.budget_marketing_cost_dkk ? `Sidst: ${lastMonthData.budget_marketing_cost_dkk.toLocaleString('da-DK')} kr.` : '100000'}
                value={formData.budgetMarketingCost}
                onChange={(e) => updateField('budgetMarketingCost', e.target.value)}
                className="text-lg"
              />
            </div>
            {formData.marketingCost && formData.budgetMarketingCost && (
              <InstantFeedback
                actual={parseFloat(formData.marketingCost)}
                budget={parseFloat(formData.budgetMarketingCost)}
                label="marketing"
                inverse
              />
            )}
          </div>
        );

      case 4:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="salaryCost" className="flex items-center gap-2">
                <Briefcase className="h-4 w-4 text-accent" />
                Lønomkostninger (kr.) - valgfrit
              </Label>
              <Input
                id="salaryCost"
                type="number"
                placeholder={lastMonthData?.salary_cost_dkk ? `Sidst: ${lastMonthData.salary_cost_dkk.toLocaleString('da-DK')} kr.` : '150000'}
                value={formData.salaryCost}
                onChange={(e) => updateField('salaryCost', e.target.value)}
                className="text-lg"
                autoFocus
              />
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="liquidity" className="flex items-center gap-2">
                <Droplet className="h-4 w-4 text-accent" />
                Likvid beholdning (kr.)
              </Label>
              <Input
                id="liquidity"
                type="number"
                placeholder={lastMonthData ? `Sidst: ${lastMonthData.cash_dkk.toLocaleString('da-DK')} kr.` : '1150000'}
                value={formData.liquidity}
                onChange={(e) => updateField('liquidity', e.target.value)}
                className="text-lg"
                autoFocus
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newCustomers" className="flex items-center gap-2">
                <Users className="h-4 w-4 text-accent" />
                Nye kunder
              </Label>
              <Input
                id="newCustomers"
                type="number"
                placeholder={lastMonthData ? `Sidst: ${lastMonthData.new_customers}` : '63'}
                value={formData.newCustomers}
                onChange={(e) => updateField('newCustomers', e.target.value)}
                className="text-lg"
              />
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-4 animate-fade-up">
            <div className="space-y-2">
              <Label htmlFor="comments">Kommentarer (valgfrit)</Label>
              <Textarea
                id="comments"
                placeholder="Har du noget særligt at tilføje om denne måned? Fx særlige events, udfordringer eller succeser..."
                value={formData.comments}
                onChange={(e) => updateField('comments', e.target.value)}
                rows={4}
                className="text-base"
                autoFocus
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Card className="p-6 glass-card">
        {/* Progress Bar */}
        <div className="mb-6 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">
              Step {currentStep + 1} af {totalSteps}
            </span>
            <span className="text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" />
              ~{steps[currentStep].estimatedTime}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Header */}
        <div className="mb-6 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-3">
            <StepIcon className="h-6 w-6 text-accent" />
          </div>
          <h2 className="text-2xl font-bold mb-1">{steps[currentStep].title}</h2>
          <p className="text-muted-foreground">{steps[currentStep].description}</p>
        </div>

        {/* Step Content */}
        {renderStepContent()}

        {/* Navigation */}
        <div className="flex gap-3 mt-6">
          {currentStep > 0 && (
            <Button
              variant="outline"
              onClick={handleBack}
              className="flex-1"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Tilbage
            </Button>
          )}
          {currentStep < totalSteps - 1 ? (
            <Button
              onClick={handleNext}
              className="flex-1"
              disabled={!isStepValid()}
            >
              Næste
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              className="flex-1 gradient-success"
              disabled={submitting}
            >
              {submitting ? (
                'Gemmer...'
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  Gem rapport
                </>
              )}
            </Button>
          )}
        </div>

        {/* Completed Steps Indicator */}
        <div className="flex gap-1 mt-4 justify-center">
          {Array.from({ length: totalSteps }).map((_, idx) => (
            <div
              key={idx}
              className={cn(
                "h-1.5 rounded-full transition-all duration-300",
                idx < currentStep ? "w-8 bg-accent" : 
                idx === currentStep ? "w-12 bg-accent" : 
                "w-6 bg-muted"
              )}
            />
          ))}
        </div>
      </Card>

      <ConfettiCelebration show={showCelebration} />
    </>
  );
};

interface InstantFeedbackProps {
  actual: number;
  budget: number;
  label: string;
  inverse?: boolean;
}

const InstantFeedback = ({ actual, budget, label, inverse = false }: InstantFeedbackProps) => {
  const diff = actual - budget;
  const diffPercent = ((diff / budget) * 100).toFixed(1);
  const isGood = inverse ? diff < 0 : diff > 0;
  
  return (
    <div className={cn(
      "p-3 rounded-lg border animate-scale-in",
      isGood ? "bg-success/10 border-success/20" : "bg-warning/10 border-warning/20"
    )}>
      <div className="flex items-center gap-2">
        {isGood ? (
          <TrendingUp className="h-4 w-4 text-success" />
        ) : (
          <TrendingUp className="h-4 w-4 text-warning rotate-180" />
        )}
        <p className={cn(
          "text-sm font-medium",
          isGood ? "text-success" : "text-warning"
        )}>
          {isGood ? '🎉 Godt arbejde!' : '⚠️ Under budget'}
        </p>
      </div>
      <p className="text-sm text-muted-foreground mt-1">
        {label.charAt(0).toUpperCase() + label.slice(1)} er{' '}
        <span className="font-medium">
          {Math.abs(parseFloat(diffPercent))}% {isGood ? 'over' : 'under'}
        </span>{' '}
        budget ({Math.abs(diff).toLocaleString('da-DK')} kr.)
      </p>
    </div>
  );
};

export default SmartMonthlyReportForm;
