import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { format } from 'date-fns';

const valuationSchema = z.object({
  company_id: z.string().min(1, 'Company is required'),
  as_of_date: z.string().min(1, 'Date is required'),
  post_money_valuation_dkk: z.coerce.number().positive('Valuation must be positive'),
  source: z.string().min(1, 'Source is required'),
});

type ValuationFormData = z.infer<typeof valuationSchema>;

interface AddValuationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  companies: Array<{ id: string; name: string }>;
  defaultCompanyId?: string;
}

export function AddValuationDialog({
  open,
  onOpenChange,
  companies,
  defaultCompanyId,
}: AddValuationDialogProps) {
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<ValuationFormData>({
    resolver: zodResolver(valuationSchema),
    defaultValues: {
      company_id: defaultCompanyId || '',
      as_of_date: format(new Date(), 'yyyy-MM-dd'),
      post_money_valuation_dkk: 0,
      source: 'Manual Entry',
    },
  });

  const addValuationMutation = useMutation({
    mutationFn: async (data: ValuationFormData) => {
      const { error } = await supabase.from('valuations').insert([{
        company_id: data.company_id,
        as_of_date: data.as_of_date,
        post_money_valuation_dkk: data.post_money_valuation_dkk,
        source: data.source,
      }]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['valuations'] });
      queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
      queryClient.invalidateQueries({ queryKey: ['company-returns'] });
      queryClient.invalidateQueries({ queryKey: ['portfolio-metrics'] });
      toast.success('Valuation added successfully');
      form.reset();
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast.error('Failed to add valuation: ' + error.message);
    },
  });

  const onSubmit = async (data: ValuationFormData) => {
    setIsSubmitting(true);
    try {
      await addValuationMutation.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Add Valuation</DialogTitle>
          <DialogDescription>
            Add a new valuation for a portfolio company
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="company_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Company</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select company" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {companies.map((company) => (
                        <SelectItem key={company.id} value={company.id}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="as_of_date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Valuation Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="post_money_valuation_dkk"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Post-Money Valuation (DKK)</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="1"
                      placeholder="10000000"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="source"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Source</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Manual Entry">Manual Entry</SelectItem>
                      <SelectItem value="Funding Round">Funding Round</SelectItem>
                      <SelectItem value="Market Valuation">Market Valuation</SelectItem>
                      <SelectItem value="Internal Assessment">Internal Assessment</SelectItem>
                      <SelectItem value="External Appraisal">External Appraisal</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Add Valuation
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
