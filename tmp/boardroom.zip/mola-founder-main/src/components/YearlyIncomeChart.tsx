import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { formatCurrency } from "@/lib/formatters";

interface YearlyIncomeChartProps {
  data: Array<{ year: number; total: number }>;
}

export function YearlyIncomeChart({ data }: YearlyIncomeChartProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold mb-4">Årlig Indkomst Trend</h3>
      <ResponsiveContainer width="100%" height={350}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="year" />
          <YAxis tickFormatter={(value) => formatCurrency(value)} />
          <Tooltip formatter={(value) => formatCurrency(value as number)} />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="total" 
            stroke="hsl(var(--primary))" 
            strokeWidth={2}
            name="Total Indkomst" 
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
