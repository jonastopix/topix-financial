import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { OnboardingStepContent } from '@/components/OnboardingStep';
import { useOnboarding } from '@/hooks/useOnboarding';
import { useRole } from '@/contexts/RoleContext';
import { useAuth } from '@/contexts/AuthContext';
import {
  getOnboardingStepsForRole,
  getNewStepsForRole,
  needsOnboarding,
  isFirstTimeOnboarding,
  OnboardingStep,
} from '@/config/onboardingSteps';

export function OnboardingModal() {
  const { user } = useAuth();
  const { activeRole } = useRole();
  const { progress, isLoading, markStepComplete, completeOnboarding, dismissWhatsNew, ensureProgressExists } = useOnboarding();
  
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [steps, setSteps] = useState<OnboardingStep[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isWhatsNew, setIsWhatsNew] = useState(false);
  const [direction, setDirection] = useState(1);
  const hasInitialized = useRef(false);

  // Determine if we should show onboarding
  useEffect(() => {
    if (!user || isLoading) return;
    
    // Reset hasInitialized when progress is null (after reset)
    if (!progress) {
      hasInitialized.current = false;
    }
    
    // Skip if already initialized and modal is open
    if (hasInitialized.current && isOpen) return;

    const roleConfig = getOnboardingStepsForRole(activeRole as any);
    if (!roleConfig) {
      setIsOpen(false);
      return;
    }

    const versionSeen = progress?.version_seen ?? 0;
    const shouldShow = needsOnboarding(activeRole as any, versionSeen);

    if (!shouldShow) {
      setIsOpen(false);
      return;
    }

    // Check if dismissed recently (within 24 hours)
    if (progress?.dismissed_at) {
      const dismissedAt = new Date(progress.dismissed_at);
      const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      if (dismissedAt > dayAgo) {
        setIsOpen(false);
        return;
      }
    }

    const isFirstTime = isFirstTimeOnboarding(versionSeen);
    setIsWhatsNew(!isFirstTime);

    // Get appropriate steps - only on first initialization
    if (!hasInitialized.current) {
      if (isFirstTime) {
        setSteps(roleConfig.steps);
      } else {
        const newSteps = getNewStepsForRole(activeRole as any, versionSeen);
        setSteps(newSteps);
      }
      setCurrentStepIndex(0);
      hasInitialized.current = true;
    }

    setIsOpen(true);
    
    // Ensure progress record exists
    ensureProgressExists();
  }, [user, isLoading, progress, activeRole, isOpen]);

  const currentStep = steps[currentStepIndex];
  const isLastStep = currentStepIndex === steps.length - 1;
  const roleConfig = getOnboardingStepsForRole(activeRole as any);

  const handleNext = useCallback(async () => {
    if (!currentStep || !roleConfig) return;

    // Mark current step as complete
    await markStepComplete(currentStep.id);

    if (isLastStep) {
      // Complete onboarding
      await completeOnboarding(roleConfig.currentVersion);
      hasInitialized.current = false;
      setIsOpen(false);
    } else {
      setDirection(1);
      setCurrentStepIndex(prev => prev + 1);
    }
  }, [currentStep, isLastStep, roleConfig, markStepComplete, completeOnboarding]);

  const handleDismiss = useCallback(async () => {
    await dismissWhatsNew();
    hasInitialized.current = false;
    setIsOpen(false);
  }, [dismissWhatsNew]);

  if (!isOpen || !currentStep || isLoading) return null;

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 50 : -50,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction > 0 ? -50 : 50,
      opacity: 0,
    }),
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
      />

      {/* Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ type: 'spring', duration: 0.5 }}
        className="relative z-10 w-full max-w-lg mx-4"
      >
        <div className="bg-background border border-border rounded-2xl shadow-2xl overflow-hidden">
          {/* Progress indicator */}
          <div className="flex justify-center gap-2 pt-8 pb-2">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`h-2 w-2 rounded-full transition-all duration-300 ${
                  index === currentStepIndex
                    ? 'bg-primary w-6'
                    : index < currentStepIndex
                    ? 'bg-primary/60'
                    : 'bg-muted'
                }`}
              />
            ))}
          </div>

          {/* Content */}
          <div className="px-8 py-8 md:px-12 md:py-10 min-h-[280px] flex flex-col justify-center">
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={currentStep.id}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3, ease: 'easeInOut' }}
              >
                <OnboardingStepContent step={currentStep} />
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Actions */}
          <div className="px-8 pb-8 md:px-12 md:pb-10 flex flex-col gap-3">
            <Button
              onClick={handleNext}
              size="lg"
              className="w-full text-base font-medium"
              variant={currentStep.ctaVariant === 'primary' || isLastStep ? 'default' : 'outline'}
            >
              {currentStep.cta}
            </Button>

            {/* Show "Se senere" option for What's New */}
            {isWhatsNew && (
              <Button
                onClick={handleDismiss}
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground"
              >
                Se senere
              </Button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
