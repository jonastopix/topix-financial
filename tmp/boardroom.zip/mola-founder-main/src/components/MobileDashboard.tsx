import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import { MobileQuickActions } from './MobileQuickActions';
import { ActivityShortcutDialog } from './ActivityShortcutDialog';
import { QuickTaskSheet } from './QuickTaskSheet';
import { MileageQuickSheet } from './MileageQuickSheet';
import { 
  ChevronRight, 
  Calendar, 
  CheckCircle2, 
  Clock,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Task {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_date: string | null;
}

interface Activity {
  id: string;
  activity_type: string;
  description: string;
  created_at: string;
  companies?: { name: string } | null;
}

interface Meeting {
  id: string;
  title: string;
  meeting_date: string;
  companies?: { name: string } | null;
}

export const MobileDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isAdmin, activeRole } = useRole();
  
  const [activityOpen, setActivityOpen] = useState(false);
  const [taskOpen, setTaskOpen] = useState(false);
  const [mileageOpen, setMileageOpen] = useState(false);

  // Fetch user profile for name
  const { data: profile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const isFounder = activeRole === 'founder';
  const greeting = getGreeting();
  const firstName = profile?.full_name?.split(' ')[0] || 'der';

  // Fetch today's tasks (due today or overdue)
  const { data: tasks = [] } = useQuery({
    queryKey: ['mobile-dashboard-tasks', user?.id],
    queryFn: async () => {
      const today = format(new Date(), 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('tasks')
        .select('id, title, status, priority, due_date')
        .eq('assigned_to', user!.id)
        .neq('status', 'done')
        .or(`due_date.lte.${today},due_date.is.null`)
        .order('due_date', { ascending: true, nullsFirst: false })
        .limit(5);
      if (error) throw error;
      return data as Task[];
    },
    enabled: !!user?.id,
  });

  // Fetch recent activities
  const { data: activities = [] } = useQuery({
    queryKey: ['mobile-dashboard-activities', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_activity_log')
        .select('id, activity_type, description, created_at, companies:company_id(name)')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false })
        .limit(3);
      if (error) throw error;
      return data as Activity[];
    },
    enabled: !!user?.id && (isAdmin || activeRole === 'fund_partner'),
  });

  // Fetch upcoming meetings
  const { data: meetings = [] } = useQuery({
    queryKey: ['mobile-dashboard-meetings'],
    queryFn: async () => {
      const today = format(new Date(), 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('company_meetings')
        .select('id, title, meeting_date, companies:company_id(name)')
        .gte('meeting_date', today)
        .order('meeting_date', { ascending: true })
        .limit(3);
      if (error) throw error;
      return data as Meeting[];
    },
    enabled: isAdmin || activeRole === 'fund_partner',
  });

  const handleQuickAction = (actionId: string) => {
    switch (actionId) {
      case 'activity':
        setActivityOpen(true);
        break;
      case 'task':
        setTaskOpen(true);
        break;
      case 'mileage':
        setMileageOpen(true);
        break;
      case 'mileage-history':
        navigate('/admin/mileage');
        break;
      case 'report':
        navigate('/monthly-report');
        break;
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'meeting': return '💻';
      case 'call': return '📱';
      case 'note': return '📝';
      default: return '📋';
    }
  };

  const isOverdue = (dueDate: string | null) => {
    if (!dueDate) return false;
    return new Date(dueDate) < new Date(format(new Date(), 'yyyy-MM-dd'));
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Welcome Section */}
      <div className="pt-2">
        <h1 className="text-2xl font-bold">{greeting}, {firstName}!</h1>
        <p className="text-muted-foreground">
          {format(new Date(), "EEEE 'd.' d. MMMM", { locale: da })}
        </p>
      </div>

      {/* Quick Actions */}
      <section>
        <h2 className="text-sm font-medium text-muted-foreground mb-3">Hurtige handlinger</h2>
        <MobileQuickActions onAction={handleQuickAction} />
      </section>

      {/* My Tasks Today */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-medium text-muted-foreground">
            Mine opgaver ({tasks.length})
          </h2>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 text-xs"
            onClick={() => navigate('/tasks')}
          >
            Se alle
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
        
        {tasks.length === 0 ? (
          <Card className="p-4 text-center text-muted-foreground">
            <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-green-500" />
            <p className="text-sm">Ingen aktive opgaver</p>
          </Card>
        ) : (
          <div className="space-y-2">
            {tasks.map((task) => (
              <Card 
                key={task.id} 
                className="p-3 flex items-center gap-3 cursor-pointer active:bg-accent/50"
                onClick={() => navigate('/tasks')}
              >
                <div className={cn(
                  "h-2 w-2 rounded-full flex-shrink-0",
                  task.priority === 'high' ? 'bg-red-500' : 
                  task.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{task.title}</p>
                  {task.due_date && (
                    <p className={cn(
                      "text-xs",
                      isOverdue(task.due_date) ? 'text-destructive' : 'text-muted-foreground'
                    )}>
                      {isOverdue(task.due_date) ? (
                        <span className="flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          Forfalden
                        </span>
                      ) : (
                        format(new Date(task.due_date), 'd. MMM', { locale: da })
                      )}
                    </p>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Recent Activities - Only for admins/fund partners */}
      {(isAdmin || activeRole === 'fund_partner') && activities.length > 0 && (
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3">Seneste aktivitet</h2>
          <div className="space-y-2">
            {activities.map((activity) => (
              <Card key={activity.id} className="p-3">
                <div className="flex items-start gap-3">
                  <span className="text-lg">{getActivityIcon(activity.activity_type)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{activity.description}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {activity.companies?.name && (
                        <Badge variant="secondary" className="text-xs">
                          {activity.companies.name}
                        </Badge>
                      )}
                      <span>{format(new Date(activity.created_at), 'd. MMM', { locale: da })}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Upcoming Meetings - Only for admins/fund partners */}
      {(isAdmin || activeRole === 'fund_partner') && meetings.length > 0 && (
        <section>
          <h2 className="text-sm font-medium text-muted-foreground mb-3">Kommende møder</h2>
          <div className="space-y-2">
            {meetings.map((meeting) => (
              <Card key={meeting.id} className="p-3 flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{meeting.title}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    {meeting.companies?.name && (
                      <span>{meeting.companies.name}</span>
                    )}
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {format(new Date(meeting.meeting_date), 'd. MMM HH:mm', { locale: da })}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Dialogs/Sheets */}
      <ActivityShortcutDialog 
        open={activityOpen} 
        onOpenChange={setActivityOpen} 
      />
      
      <Drawer open={taskOpen} onOpenChange={setTaskOpen}>
        <DrawerContent>
          <QuickTaskSheet onSuccess={() => setTaskOpen(false)} />
        </DrawerContent>
      </Drawer>
      
      <MileageQuickSheet 
        open={mileageOpen} 
        onOpenChange={setMileageOpen} 
      />
    </div>
  );
};

function getGreeting() {
  const hour = new Date().getHours();
  if (hour < 10) return 'God morgen';
  if (hour < 12) return 'God formiddag';
  if (hour < 18) return 'God eftermiddag';
  return 'God aften';
}
