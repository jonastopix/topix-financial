import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { formatPercentage, formatNumber } from '@/lib/formatters';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useMonthlyReports, useNPSResponses } from '@/hooks/useCompanyData';
import { calculateYTD, calculateYOY, calculateScorecard, calculateHealthIndex } from '@/lib/metricsCalculations';
import { TrendingUp, TrendingDown, DollarSign, Activity, Users } from 'lucide-react';

interface CompanyComparisonDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentCompanyId: string;
  currentCompanyName: string;
}

export default function CompanyComparisonDialog({
  open,
  onOpenChange,
  currentCompanyId,
  currentCompanyName,
}: CompanyComparisonDialogProps) {
  const [compareCompanyId, setCompareCompanyId] = useState<string>('');
  const currentYear = new Date().getFullYear();

  // Fetch all companies for selection
  const { data: companies } = useQuery({
    queryKey: ['companies-for-comparison'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, industry')
        .eq('is_active', true)
        .neq('id', currentCompanyId)
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Current company data
  const { data: currentReports = [] } = useMonthlyReports(currentCompanyId);
  const { data: currentNPS = [] } = useNPSResponses(currentCompanyId);

  // Compare company data
  const { data: compareReports = [] } = useMonthlyReports(compareCompanyId);
  const { data: compareNPS = [] } = useNPSResponses(compareCompanyId);

  const { data: compareCompany } = useQuery({
    queryKey: ['company', compareCompanyId],
    queryFn: async () => {
      if (!compareCompanyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .eq('id', compareCompanyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!compareCompanyId,
  });

  // Calculate metrics for both companies
  const currentScorecard = calculateScorecard(currentReports, currentNPS, currentYear);
  const currentHealthIndex = calculateHealthIndex(
    currentScorecard.financial,
    currentScorecard.growth,
    currentScorecard.transparency,
    currentScorecard.relationship
  );
  
  const currentMetrics = {
    ytd: calculateYTD(currentReports, currentYear),
    yoy: calculateYOY(currentReports, currentYear),
    scorecard: currentScorecard,
    healthIndex: currentHealthIndex,
  };

  let compareMetrics = null;
  if (compareCompanyId) {
    const compareScorecard = calculateScorecard(compareReports, compareNPS, currentYear);
    const compareHealthIndex = calculateHealthIndex(
      compareScorecard.financial,
      compareScorecard.growth,
      compareScorecard.transparency,
      compareScorecard.relationship
    );
    
    compareMetrics = {
      ytd: calculateYTD(compareReports, currentYear),
      yoy: calculateYOY(compareReports, currentYear),
      scorecard: compareScorecard,
      healthIndex: compareHealthIndex,
    };
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('da-DK', {
      style: 'currency',
      currency: 'DKK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const ComparisonCard = ({ 
    label, 
    currentValue, 
    compareValue, 
    format = 'number',
    icon: Icon 
  }: { 
    label: string; 
    currentValue: number; 
    compareValue: number | null; 
    format?: 'number' | 'currency' | 'percent';
    icon?: any;
  }) => {
    const formatValue = (val: number) => {
      if (format === 'currency') return formatCurrency(val);
      if (format === 'percent') return formatPercentage(val, 1);
      return formatNumber(val, 0);
    };

    const diff = compareValue !== null ? currentValue - compareValue : null;
    const showArrow = diff !== null && diff !== 0;

    return (
      <Card className="p-4">
        <div className="flex items-center gap-2 mb-3">
          {Icon && <Icon className="h-4 w-4 text-muted-foreground" />}
          <span className="text-sm text-muted-foreground">{label}</span>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{currentCompanyName}</span>
            <span className="text-lg font-bold">{formatValue(currentValue)}</span>
          </div>
          {compareValue !== null && (
            <>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">{compareCompany?.name}</span>
                <span className="text-lg font-bold">{formatValue(compareValue)}</span>
              </div>
              {showArrow && (
                <div className="flex items-center justify-end gap-1 text-sm">
                  {diff > 0 ? (
                    <>
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span className="text-green-500 font-semibold">+{formatValue(Math.abs(diff))}</span>
                    </>
                  ) : (
                    <>
                      <TrendingDown className="h-4 w-4 text-red-500" />
                      <span className="text-red-500 font-semibold">-{formatValue(Math.abs(diff))}</span>
                    </>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </Card>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Sammenlign selskaber</DialogTitle>
          <DialogDescription>
            Sammenlign {currentCompanyName} med et andet portfolio-selskab
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <label className="text-sm font-medium mb-2 block">Vælg selskab at sammenligne med</label>
            <Select value={compareCompanyId} onValueChange={setCompareCompanyId}>
              <SelectTrigger>
                <SelectValue placeholder="Vælg et selskab..." />
              </SelectTrigger>
              <SelectContent>
                {companies?.map((company) => (
                  <SelectItem key={company.id} value={company.id}>
                    {company.name} {company.industry && `(${company.industry})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {compareMetrics && (
            <>
              <div>
                <h3 className="text-lg font-semibold mb-4">Health Index</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <ComparisonCard
                    label="Overall Health"
                    currentValue={currentMetrics.healthIndex}
                    compareValue={compareMetrics.healthIndex}
                    format="number"
                  />
                  <ComparisonCard
                    label="Financial Score"
                    currentValue={currentMetrics.scorecard.financial}
                    compareValue={compareMetrics.scorecard.financial}
                    format="number"
                    icon={DollarSign}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">YTD Performance ({currentYear})</h3>
                <div className="grid gap-4 md:grid-cols-3">
                  <ComparisonCard
                    label="YTD Omsætning"
                    currentValue={currentMetrics.ytd.revenue}
                    compareValue={compareMetrics.ytd.revenue}
                    format="currency"
                    icon={DollarSign}
                  />
                  <ComparisonCard
                    label="YTD EBITDA"
                    currentValue={currentMetrics.ytd.ebitda}
                    compareValue={compareMetrics.ytd.ebitda}
                    format="currency"
                    icon={Activity}
                  />
                  <ComparisonCard
                    label="EBITDA Margin"
                    currentValue={currentMetrics.ytd.margin}
                    compareValue={compareMetrics.ytd.margin}
                    format="percent"
                  />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">YOY Growth</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <ComparisonCard
                    label="Omsætningsvækst"
                    currentValue={currentMetrics.yoy.revenueGrowth}
                    compareValue={compareMetrics.yoy.revenueGrowth}
                    format="percent"
                    icon={TrendingUp}
                  />
                  <ComparisonCard
                    label="EBITDA Vækst"
                    currentValue={currentMetrics.yoy.ebitdaGrowth}
                    compareValue={compareMetrics.yoy.ebitdaGrowth}
                    format="percent"
                    icon={TrendingUp}
                  />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">Scorecard Comparison</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <ComparisonCard
                    label="Growth Score"
                    currentValue={currentMetrics.scorecard.growth}
                    compareValue={compareMetrics.scorecard.growth}
                    format="number"
                  />
                  <ComparisonCard
                    label="Transparency Score"
                    currentValue={currentMetrics.scorecard.transparency}
                    compareValue={compareMetrics.scorecard.transparency}
                    format="number"
                  />
                </div>
              </div>
            </>
          )}

          {!compareCompanyId && (
            <div className="text-center py-12 text-muted-foreground">
              Vælg et selskab for at se sammenligning
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
