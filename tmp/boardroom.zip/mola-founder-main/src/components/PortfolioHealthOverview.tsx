import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { calculateScorecard, calculateHealthIndex } from '@/lib/metricsCalculations';

export function PortfolioHealthOverview() {
  const currentYear = new Date().getFullYear();

  // Fetch all active companies with their data
  const { data: portfolioData, isLoading } = useQuery({
    queryKey: ['portfolio-health-overview', currentYear],
    queryFn: async () => {
      // Get all active companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, status')
        .eq('is_active', true);
      
      if (companiesError) throw companiesError;

      // Get monthly reports for all companies
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', companies?.map(c => c.id) || []);
      
      if (reportsError) throw reportsError;

      // Get NPS responses for all companies
      const { data: npsData, error: npsError } = await supabase
        .from('nps_responses')
        .select('*')
        .in('company_id', companies?.map(c => c.id) || []);
      
      if (npsError) throw npsError;

      // Calculate health for each company
      const companiesWithHealth = companies?.map(company => {
        const companyReports = reports?.filter(r => r.company_id === company.id) || [];
        const companyNPS = npsData?.filter(n => n.company_id === company.id) || [];
        
        const scorecard = calculateScorecard(companyReports, companyNPS, currentYear);
        const healthIndex = calculateHealthIndex(
          scorecard.financial,
          scorecard.growth,
          scorecard.transparency,
          scorecard.relationship
        );

        return {
          ...company,
          healthIndex,
          scorecard,
        };
      }) || [];

      // Calculate portfolio averages
      const avgHealth = companiesWithHealth.length > 0
        ? companiesWithHealth.reduce((sum, c) => sum + c.healthIndex, 0) / companiesWithHealth.length
        : 0;

      const avgFinancial = companiesWithHealth.length > 0
        ? companiesWithHealth.reduce((sum, c) => sum + c.scorecard.financial, 0) / companiesWithHealth.length
        : 0;

      const avgGrowth = companiesWithHealth.length > 0
        ? companiesWithHealth.reduce((sum, c) => sum + c.scorecard.growth, 0) / companiesWithHealth.length
        : 0;

      const avgTransparency = companiesWithHealth.length > 0
        ? companiesWithHealth.reduce((sum, c) => sum + c.scorecard.transparency, 0) / companiesWithHealth.length
        : 0;

      const avgRelationship = companiesWithHealth.length > 0
        ? companiesWithHealth.reduce((sum, c) => sum + c.scorecard.relationship, 0) / companiesWithHealth.length
        : 0;

      // Categorize companies by health
      const healthy = companiesWithHealth.filter(c => c.healthIndex >= 80).length;
      const stable = companiesWithHealth.filter(c => c.healthIndex >= 50 && c.healthIndex < 80).length;
      const atRisk = companiesWithHealth.filter(c => c.healthIndex < 50).length;

      return {
        avgHealth,
        avgFinancial,
        avgGrowth,
        avgTransparency,
        avgRelationship,
        healthy,
        stable,
        atRisk,
        totalCompanies: companiesWithHealth.length,
        companiesWithHealth,
      };
    },
  });

  if (isLoading || !portfolioData) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Portfolio Health Overview</h2>
        </div>
        <p className="text-muted-foreground">Indlæser...</p>
      </Card>
    );
  }

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'text-green-500';
    if (score >= 50) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getHealthBg = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-bold">Portfolio Health Overview</h2>
        </div>
        <div className={`text-2xl lg:text-3xl font-bold ${getHealthColor(portfolioData.avgHealth)}`}>
          {Math.round(portfolioData.avgHealth)}
        </div>
      </div>

      {/* Health Distribution */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center p-4 rounded-lg bg-green-500/10 border border-green-500/20">
          <CheckCircle2 className="h-8 w-8 text-green-500 mx-auto mb-2" />
          <p className="text-2xl lg:text-3xl font-bold text-green-500">{portfolioData.healthy}</p>
          <p className="text-sm text-muted-foreground">Sund (80+)</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
          <Clock className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
          <p className="text-2xl lg:text-3xl font-bold text-yellow-500">{portfolioData.stable}</p>
          <p className="text-sm text-muted-foreground">Stabil (50-79)</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-red-500/10 border border-red-500/20">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-2" />
          <p className="text-2xl lg:text-3xl font-bold text-red-500">{portfolioData.atRisk}</p>
          <p className="text-sm text-muted-foreground">Risiko ({'<'}50)</p>
        </div>
      </div>

      {/* Scorecard Averages */}
      <div className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Financial</span>
            <span className="text-sm font-bold">{Math.round(portfolioData.avgFinancial)}%</span>
          </div>
          <Progress value={portfolioData.avgFinancial} className="h-2" />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Growth</span>
            <span className="text-sm font-bold">{Math.round(portfolioData.avgGrowth)}%</span>
          </div>
          <Progress value={portfolioData.avgGrowth} className="h-2" />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Transparency</span>
            <span className="text-sm font-bold">{Math.round(portfolioData.avgTransparency)}%</span>
          </div>
          <Progress value={portfolioData.avgTransparency} className="h-2" />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Relationship</span>
            <span className="text-sm font-bold">{Math.round(portfolioData.avgRelationship)}%</span>
          </div>
          <Progress value={portfolioData.avgRelationship} className="h-2" />
        </div>
      </div>

      {/* Top & Bottom Performers */}
      <div className="mt-6 pt-6 border-t">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-500" />
              Top Performer
            </h4>
            {portfolioData.companiesWithHealth.sort((a, b) => b.healthIndex - a.healthIndex)[0] && (
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium text-sm">
                  {portfolioData.companiesWithHealth.sort((a, b) => b.healthIndex - a.healthIndex)[0].name}
                </p>
                <p className={`text-lg lg:text-xl font-bold ${getHealthColor(portfolioData.companiesWithHealth.sort((a, b) => b.healthIndex - a.healthIndex)[0].healthIndex)}`}>
                  {Math.round(portfolioData.companiesWithHealth.sort((a, b) => b.healthIndex - a.healthIndex)[0].healthIndex)}
                </p>
              </div>
            )}
          </div>
          <div>
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-red-500" />
              Needs Attention
            </h4>
            {portfolioData.companiesWithHealth.sort((a, b) => a.healthIndex - b.healthIndex)[0] && (
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="font-medium text-sm">
                  {portfolioData.companiesWithHealth.sort((a, b) => a.healthIndex - b.healthIndex)[0].name}
                </p>
                <p className={`text-lg lg:text-xl font-bold ${getHealthColor(portfolioData.companiesWithHealth.sort((a, b) => a.healthIndex - b.healthIndex)[0].healthIndex)}`}>
                  {Math.round(portfolioData.companiesWithHealth.sort((a, b) => a.healthIndex - b.healthIndex)[0].healthIndex)}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}
