import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Send, X } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { da } from "date-fns/locale";
import type { Invitation } from "@/hooks/useInvitations";

interface PendingInvitationsCardProps {
  invitations: Invitation[];
  onResend: (invitation: Invitation) => void;
  onCancel: (id: string) => void;
}

export const PendingInvitationsCard = ({ 
  invitations, 
  onResend, 
  onCancel 
}: PendingInvitationsCardProps) => {
  const pendingInvitations = invitations.filter(inv => inv.status === 'pending');

  if (pendingInvitations.length === 0) {
    return null;
  }

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'mola_admin':
      case 'owner':
        return 'destructive';
      case 'fund_partner':
        return 'default';
      case 'founder':
        return 'secondary';
      default:
        return 'outline';
    }
  };

  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      'mola_admin': 'MOLA Admin',
      'fund_partner': 'Fund Partner',
      'founder': 'Founder',
      'investor': 'Investor',
      'dd_partner': 'DD Partner',
      'owner': 'Owner',
    };
    return labels[role] || role;
  };

  return (
    <Alert className="border-yellow-500/50 bg-yellow-500/10">
      <Clock className="h-4 w-4 text-yellow-600" />
      <AlertDescription>
        <div className="space-y-4">
          <div className="font-semibold text-foreground">
            Afventende invitationer ({pendingInvitations.length})
          </div>
          <div className="space-y-2">
            {pendingInvitations.map((invitation) => (
              <div
                key={invitation.id}
                className="flex items-center justify-between gap-4 rounded-lg border border-border bg-card p-3"
              >
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-foreground truncate">
                      {invitation.email}
                    </span>
                    <Badge variant={getRoleBadgeVariant(invitation.invited_role)}>
                      {getRoleLabel(invitation.invited_role)}
                    </Badge>
                    {invitation.company?.name && (
                      <span className="text-sm text-muted-foreground">
                        • {invitation.company.name}
                      </span>
                    )}
                    {invitation.fund?.name && (
                      <span className="text-sm text-muted-foreground">
                        • {invitation.fund.name}
                      </span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Inviteret{' '}
                    {formatDistanceToNow(new Date(invitation.created_at), {
                      addSuffix: true,
                      locale: da,
                    })}
                    {' • '}
                    Udløber{' '}
                    {formatDistanceToNow(new Date(invitation.expires_at), {
                      addSuffix: true,
                      locale: da,
                    })}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onResend(invitation)}
                  >
                    <Send className="h-3 w-3 mr-1" />
                    Gensend
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onCancel(invitation.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </AlertDescription>
    </Alert>
  );
};
