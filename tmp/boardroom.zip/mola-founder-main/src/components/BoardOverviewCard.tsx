import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, Calendar, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useBoardMembers } from '@/hooks/useBoardMembers';
import { useBoardGovernance } from '@/hooks/useBoardGovernance';
import { useCompanyMeetings } from '@/hooks/useCompanyMeetings';
import { format, differenceInMonths } from 'date-fns';
import { da } from 'date-fns/locale';

interface BoardOverviewCardProps {
  companyId: string;
  fiscalYearEndMonth: number;
  fiscalYearEndDay: number;
}

export function BoardOverviewCard({ companyId, fiscalYearEndMonth, fiscalYearEndDay }: BoardOverviewCardProps) {
  const { activeMembers } = useBoardMembers(companyId);
  const { stats } = useBoardGovernance(companyId, new Date().getFullYear());
  const { meetings } = useCompanyMeetings(companyId);

  const boardMeetings = meetings.filter(m => m.is_board_meeting);
  const nextBoardMeeting = boardMeetings.find(
    m => new Date(m.meeting_date) > new Date()
  );

  const upcomingTermExpiries = activeMembers.filter(member => {
    if (!member.term_end_date) return false;
    const monthsUntilEnd = differenceInMonths(new Date(member.term_end_date), new Date());
    return monthsUntilEnd <= 3 && monthsUntilEnd >= 0;
  });

  const overdueItems = stats.total - stats.completed;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Bestyrelseoversigt</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {/* Board Members */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span className="text-sm">Medlemmer</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{activeMembers.length}</span>
              {upcomingTermExpiries.length > 0 && (
                <Badge variant="destructive" className="text-xs">
                  {upcomingTermExpiries.length} udløber snart
                </Badge>
              )}
            </div>
          </div>

          {/* Next Board Meeting */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span className="text-sm">Næste møde</span>
            </div>
            {nextBoardMeeting ? (
              <div className="space-y-1">
                <div className="text-sm font-medium">
                  {format(new Date(nextBoardMeeting.meeting_date), 'PPP', { locale: da })}
                </div>
                <div className="text-xs text-muted-foreground">
                  {nextBoardMeeting.title}
                </div>
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">Ingen planlagt</span>
            )}
          </div>

          {/* Governance Completion */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <CheckCircle2 className="h-4 w-4" />
              <span className="text-sm">Governance</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{Math.round(stats.percentage)}%</span>
              <span className="text-sm text-muted-foreground">
                {stats.completed}/{stats.total}
              </span>
            </div>
          </div>

          {/* Overdue Items */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2 text-muted-foreground">
              <AlertTriangle className="h-4 w-4" />
              <span className="text-sm">Udestående</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-2xl font-bold ${overdueItems > 0 ? 'text-destructive' : ''}`}>
                {overdueItems}
              </span>
              {overdueItems > 0 && (
                <Badge variant="destructive" className="text-xs">
                  Kræver opmærksomhed
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
