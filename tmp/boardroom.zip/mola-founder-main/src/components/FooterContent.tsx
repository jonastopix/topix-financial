import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useFooterSettings, useFooterLinks } from "@/hooks/useFooterSettings";
import * as LucideIcons from "lucide-react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import molaLogo from "@/assets/mola-logo.png";

interface FooterContentProps {
  className?: string;
}

export const FooterContent = ({ className }: FooterContentProps) => {
  const { data: settings } = useFooterSettings();
  const { data: navLinks } = useFooterLinks("navigation");
  const { data: resourceLinks } = useFooterLinks("resources");
  const { data: legalLinks } = useFooterLinks("legal");

  const aboutSetting = settings?.find((s) => s.section_key === "about");
  const contactSetting = settings?.find((s) => s.section_key === "contact");
  const newsletterSetting = settings?.find((s) => s.section_key === "newsletter");
  const ctaSetting = settings?.find((s) => s.section_key === "cta");
  const copyrightSetting = settings?.find((s) => s.section_key === "copyright");

  const renderIcon = (iconName?: string) => {
    if (!iconName) return null;
    const Icon = LucideIcons[iconName as keyof typeof LucideIcons] as any;
    if (Icon && typeof Icon === "function") {
      return <Icon className="h-4 w-4 group-hover:translate-x-1 transition-transform" />;
    }
    return null;
  };

  const renderSocialIcon = (iconName: string) => {
    const Icon = LucideIcons[iconName as keyof typeof LucideIcons] as any;
    if (Icon && typeof Icon === "function") {
      return <Icon className="h-5 w-5" />;
    }
    return null;
  };

  // Fallback to hardcoded footer if no data
  if (!settings || settings.length === 0) {
    return (
      <footer className={`bg-gradient-to-b from-card/30 via-card/50 to-background border-t-2 border-primary/20 mt-auto ${className || ''}`}>
        <div className="container mx-auto px-6 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <img src={molaLogo} alt="MOLA Logo" className="h-10 w-auto" />
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Din komplette løsning til intelligent porteføljestyring.
              </p>
            </div>
          </div>
          <div className="border-t border-border/50 pt-8">
            <p className="text-sm text-muted-foreground text-center">
              © {new Date().getFullYear()} MOLA. Alle rettigheder forbeholdes.
            </p>
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer className={`bg-gradient-to-b from-card/30 via-card/50 to-background border-t-2 border-primary/20 mt-auto ${className || ''}`}>
      <div className="container mx-auto px-6 py-16">
        {/* Main Footer Content - 4 columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Column 1: About MOLA */}
          {aboutSetting?.is_active && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <img src={molaLogo} alt="MOLA Logo" className="h-10 w-auto" />
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {aboutSetting.content?.description}
              </p>
              {aboutSetting.content?.social_links && (
                <div className="flex gap-3 pt-2">
                  {aboutSetting.content.social_links.map((social: any) => (
                    social.url && social.url !== "#" && (
                      <a
                        key={social.platform}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
                      >
                        {renderSocialIcon(social.icon)}
                      </a>
                    )
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Column 2: Navigation */}
          {navLinks && navLinks.length > 0 && (
            <div>
              <h3 className="font-semibold text-lg mb-6 text-foreground">Navigation</h3>
              <ul className="space-y-3">
                {navLinks
                  .filter((link) => link.is_active)
                  .map((link) => (
                    <li key={link.id}>
                      {link.is_external ? (
                        <a
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 flex items-center gap-2 group"
                        >
                          {renderIcon(link.icon_name)}
                          <span>{link.title}</span>
                        </a>
                      ) : (
                        <Link
                          to={link.url}
                          className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 flex items-center gap-2 group"
                        >
                          {renderIcon(link.icon_name)}
                          <span>{link.title}</span>
                        </Link>
                      )}
                    </li>
                  ))}
              </ul>
            </div>
          )}

          {/* Column 3: Resources */}
          {resourceLinks && resourceLinks.length > 0 && (
            <div>
              <h3 className="font-semibold text-lg mb-6 text-foreground">Ressourcer</h3>
              <ul className="space-y-3">
                {resourceLinks
                  .filter((link) => link.is_active)
                  .map((link) => (
                    <li key={link.id}>
                      {link.is_external ? (
                        <a
                          href={link.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 flex items-center gap-2 group"
                        >
                          {renderIcon(link.icon_name)}
                          <span>{link.title}</span>
                        </a>
                      ) : (
                        <Link
                          to={link.url}
                          className="text-sm text-muted-foreground hover:text-primary transition-colors duration-300 flex items-center gap-2 group"
                        >
                          {renderIcon(link.icon_name)}
                          <span>{link.title}</span>
                        </Link>
                      )}
                    </li>
                  ))}
              </ul>
            </div>
          )}

          {/* Column 4: Contact & Newsletter */}
          {(contactSetting?.is_active || newsletterSetting?.is_active) && (
            <div>
              {contactSetting?.is_active && (
                <>
                  <h3 className="font-semibold text-lg mb-6 text-foreground">Kontakt</h3>
                  <ul className="space-y-3 mb-6">
                    {contactSetting.content?.email && (
                      <li className="text-sm text-muted-foreground flex items-center gap-2">
                        <Mail className="h-4 w-4 text-primary flex-shrink-0" />
                        <a
                          href={`mailto:${contactSetting.content.email}`}
                          className="hover:text-primary transition-colors duration-300"
                        >
                          {contactSetting.content.email}
                        </a>
                      </li>
                    )}
                    {contactSetting.content?.phone && (
                      <li className="text-sm text-muted-foreground flex items-center gap-2">
                        <Phone className="h-4 w-4 text-primary flex-shrink-0" />
                        <span>{contactSetting.content.phone}</span>
                      </li>
                    )}
                    {contactSetting.content?.address && (
                      <li className="text-sm text-muted-foreground flex items-start gap-2">
                        <MapPin className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                        <span>{contactSetting.content.address}</span>
                      </li>
                    )}
                  </ul>
                </>
              )}
              {newsletterSetting?.is_active && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-foreground">
                    {newsletterSetting.content?.title || "Nyhedsbrev"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {newsletterSetting.content?.description || "Hold dig opdateret"}
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="email"
                      placeholder={newsletterSetting.content?.placeholder || "Din email"}
                      className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                    />
                    <Button size="sm" className="shrink-0">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Call to Action Section */}
        {ctaSetting?.is_active && ctaSetting.content?.title && (
          <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-primary/10 rounded-lg p-8 mb-12 border border-primary/20">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left">
                <h3 className="text-xl font-semibold mb-2 text-foreground">
                  {ctaSetting.content.title}
                </h3>
                <p className="text-sm text-muted-foreground">{ctaSetting.content.description}</p>
              </div>
              {ctaSetting.content?.buttons && (
                <div className="flex gap-3">
                  {ctaSetting.content.buttons.map((button: any, index: number) => {
                    const ButtonIcon = button.icon
                      ? (LucideIcons[button.icon as keyof typeof LucideIcons] as any)
                      : null;
                    return (
                      <Button
                        key={index}
                        variant={button.variant || "default"}
                        asChild
                        className="hover:scale-105 transition-transform duration-300"
                      >
                        <Link to={button.url}>
                          {ButtonIcon && <ButtonIcon className="h-4 w-4 mr-2" />}
                          {button.text}
                        </Link>
                      </Button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Bottom Bar - Legal & Copyright */}
        <div className="border-t border-border/50 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              {copyrightSetting?.content?.text?.replace("{year}", new Date().getFullYear().toString()) ||
                `© ${new Date().getFullYear()} MOLA. Alle rettigheder forbeholdes.`}
            </p>
            {legalLinks && legalLinks.length > 0 && (
              <div className="flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
                {legalLinks
                  .filter((link) => link.is_active)
                  .map((link) => (
                    <Link
                      key={link.id}
                      to={link.url}
                      className="hover:text-primary transition-colors duration-300"
                    >
                      {link.title}
                    </Link>
                  ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
