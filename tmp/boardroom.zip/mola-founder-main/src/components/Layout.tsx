import { ReactNode, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { FooterContent } from '@/components/FooterContent';
import { useRole } from '@/contexts/RoleContext';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb';
import { TooltipProvider } from '@/components/ui/tooltip';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/AppSidebar';
import { Home, UserCircle, LogOut, Search } from 'lucide-react';
import RoleSwitcher from './RoleSwitcher';
import CompanySelector from './CompanySelector';
import AnnouncementBar from './AnnouncementBar';
import { OnlineUsersIndicator } from './OnlineUsersIndicator';
import MobileBottomNav from './MobileBottomNav';
import { CompanyActivityFAB } from './CompanyActivityFAB';
import { useIsMobile } from '@/hooks/use-mobile';
import { useKeyboardShortcuts } from '@/contexts/KeyboardShortcutContext';
import molaLogo from '@/assets/mola-logo.png';
import { LiveActivityToast } from './LiveActivityToast';
import { GlobalCelebration } from './GlobalCelebration';
import { ActivityTimerFAB } from './ActivityTimerFAB';
import { LevelUpCelebration } from './LevelUpCelebration';
import { useGamification } from '@/hooks/useGamification';

interface LayoutProps {
  children: ReactNode;
}

const Layout = ({ children }: LayoutProps) => {
  const { signOut, user } = useAuth();
  const { isAdmin } = useRole();
  const location = useLocation();
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { setIsSearchOpen } = useKeyboardShortcuts();
  const { levelUpCelebration, clearLevelUpCelebration } = useGamification();

  // Extract company ID from path if present
  const companyIdMatch = location.pathname.match(/\/company\/([a-f0-9-]+)/);
  const companyId = companyIdMatch ? companyIdMatch[1] : null;

  // Fetch company data for breadcrumb
  const { data: company } = useQuery({
    queryKey: ['company-breadcrumb', companyId],
    queryFn: async () => {
      if (!companyId) return null;
      const { data, error } = await supabase
        .from('companies')
        .select('id, name')
        .eq('id', companyId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  // Smooth scroll to top on navigation
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  // Path to label mapping for breadcrumbs
  const pathLabels: Record<string, string> = {
    '/': 'Dashboard',
    '/company': 'Companies',
    '/monthly-report': 'Monthly Report',
    '/financial-dashboard': 'Finansiel Dashboard',
    '/tasks': 'Opgaver',
    '/insights': 'Insights',
    '/procurement': 'Deals & Indkøb',
    '/procurement/benchmarks': 'Benchmarks',
    '/procurement/admin': 'Admin',
    '/portfolio/overview': 'Portfolio Overview',
    '/portfolio/valuations': 'Valuations',
    '/portfolio/companies': 'Companies',
    '/portfolio/due-diligence': 'Due Diligence',
    '/my-due-diligence': 'Due Diligence',
    '/admin-settings': 'Admin Indstillinger',
    '/user-management': 'Brugeradministration',
    '/fund-management': 'Fund Management',
    '/fund-partner-dashboard': 'Portfolio Dashboard',
    '/resources': 'Resources',
    '/support': 'Support',
    '/contact': 'Contact',
    '/shipping': 'Shipping',
    '/profile': 'Min Profil',
    '/exits-history': 'Exits Historik',
  };

  // Generate breadcrumb items from current path
  const getBreadcrumbs = () => {
    const pathSegments = location.pathname.split('/').filter(Boolean);
    
    // Always start with home
    const breadcrumbs = [{ path: '/', label: 'Hjem' }];

    // If we're not on home page
    if (pathSegments.length > 0) {
      let currentPath = '';
      
      pathSegments.forEach((segment) => {
        currentPath += `/${segment}`;
        
        // Special case: /company should link to /portfolio/companies
        let linkPath = currentPath;
        if (currentPath === '/company') {
          linkPath = '/portfolio/companies';
        }
        
        // Check if this segment is a UUID (company ID)
        const isUUID = /^[a-f0-9-]{36}$/i.test(segment);
        let label = pathLabels[currentPath] || segment.charAt(0).toUpperCase() + segment.slice(1);
        
        // Replace UUID with company name if we have it
        if (isUUID && company?.name) {
          label = company.name;
        }
        
        breadcrumbs.push({
          path: linkPath,
          label,
        });
      });
    }

    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  return (
    <TooltipProvider>
      <SidebarProvider>
        <div className="flex min-h-screen w-full bg-background">
          <AppSidebar />
          
          <div className="flex-1 flex flex-col min-w-0 pt-14 md:pt-0">
            <header className="glass-nav fixed md:sticky top-0 left-0 right-0 z-50 border-b border-border/50">
              <div className="container mx-auto">
                <div className="flex items-center justify-between gap-4 py-3 px-4">
                  {/* Left: Sidebar Trigger */}
                  <div className="flex items-center gap-3">
                    <SidebarTrigger />
                  </div>

                  {/* Center: Logo on mobile, Announcement Bar on desktop */}
                  <div className="flex-1 flex justify-center md:justify-start">
                    {/* Mobile: Centered logo */}
                    <Link to="/" className="md:hidden">
                      <img 
                        src={molaLogo} 
                        alt="Mola" 
                        className="h-8 w-auto"
                      />
                    </Link>
                    
                    {/* Desktop: AnnouncementBar for admins */}
                    {isAdmin && <AnnouncementBar className="hidden md:flex flex-1 mx-8" />}
                  </div>

                  {/* Right: Controls */}
                  <div className="flex items-center gap-2">
                    {/* Global Search Button */}
                    {user && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsSearchOpen(true)}
                        className="gap-2"
                      >
                        <Search className="h-4 w-4" />
                        <span className="hidden lg:inline">Søg</span>
                        <kbd className="hidden lg:inline-flex h-5 items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground">
                          ⌘K
                        </kbd>
                      </Button>
                    )}
                    {/* Hide selectors on mobile - accessible via sidebar */}
                    {user && !isMobile && <CompanySelector />}
                    {user && !isMobile && <RoleSwitcher />}
                    {user && !isMobile && <OnlineUsersIndicator />}
                    {user && (
                      <>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => navigate('/profile')} 
                          className="gap-2 hidden md:flex"
                        >
                          <UserCircle className="h-4 w-4" />
                          <span className="hidden lg:inline">Profil</span>
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={signOut} 
                          className="gap-2 hidden md:flex"
                        >
                          <LogOut className="h-4 w-4" />
                          <span className="hidden lg:inline">Log ud</span>
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </header>

            {/* Breadcrumb Navigation */}
            {breadcrumbs.length > 1 && (
              <div className="border-b bg-card/50 backdrop-blur-sm">
                <div className="container mx-auto flex h-12 items-center gap-2 px-4">
                  <Breadcrumb>
                  <BreadcrumbList>
                    {breadcrumbs.map((crumb, index) => {
                      const isLast = index === breadcrumbs.length - 1;
                      
                      return (
                        <div key={crumb.path} className="flex items-center">
                          <BreadcrumbItem>
                            {isLast ? (
                              <BreadcrumbPage>{crumb.label}</BreadcrumbPage>
                            ) : (
                              <BreadcrumbLink asChild>
                                <Link to={crumb.path} className="flex items-center gap-1.5">
                                  {index === 0 && <Home className="h-3.5 w-3.5" />}
                                  {crumb.label}
                                </Link>
                              </BreadcrumbLink>
                            )}
                          </BreadcrumbItem>
                          {!isLast && <BreadcrumbSeparator />}
                        </div>
                      );
                    })}
                  </BreadcrumbList>
                </Breadcrumb>
                </div>
              </div>
            )}

            <main className="flex-1">
              <div className="container mx-auto py-4 sm:py-8 px-4 sm:px-6 pb-20 md:pb-6">
                {children}
              </div>
            </main>

            <FooterContent className="hidden md:block" />
          </div>

          {/* Company Activity FAB - shown on company pages (desktop) */}
          <CompanyActivityFAB />

          {/* Mobile Bottom Navigation - includes UnifiedQuickFAB inline */}
          <MobileBottomNav />

          {/* Live Activity Toast */}
          <LiveActivityToast />
          
          {/* Activity Timer FAB */}
          <ActivityTimerFAB />
          
          {/* Global Celebration */}
          <GlobalCelebration />
          
          {/* Level Up Celebration */}
          <LevelUpCelebration level={levelUpCelebration} onClose={clearLevelUpCelebration} />
        </div>
      </SidebarProvider>
    </TooltipProvider>
  );
};

export default Layout;
