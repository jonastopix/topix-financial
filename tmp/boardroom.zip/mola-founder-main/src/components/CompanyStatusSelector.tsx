import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CompanyStatus } from '@/hooks/useCompanyManagement';
import { useRole } from '@/contexts/RoleContext';

interface CompanyStatusSelectorProps {
  status: CompanyStatus;
  onStatusChange: (status: CompanyStatus) => void;
  companyId: string;
}

export function CompanyStatusSelector({ status, onStatusChange }: CompanyStatusSelectorProps) {
  const { isAdmin } = useRole();

  if (!isAdmin) {
    return null;
  }

  return (
    <Select value={status} onValueChange={(value) => onStatusChange(value as CompanyStatus)}>
      <SelectTrigger className="w-[180px]">
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="bg-background z-50">
        <SelectItem value="new_investment">🟡 Ny investering</SelectItem>
        <SelectItem value="due_diligence">🔵 Due Diligence</SelectItem>
        <SelectItem value="active">🟢 Aktiv</SelectItem>
        <SelectItem value="exited">🎯 Solgt</SelectItem>
        <SelectItem value="bankruptcy">🔴 Konkurs</SelectItem>
        <SelectItem value="rejected">⚫ Afvist</SelectItem>
        <SelectItem value="archived">📦 Arkiveret</SelectItem>
      </SelectContent>
    </Select>
  );
}
