import { useState } from "react";
import { useCompanyPR } from "@/hooks/useCompanyPR";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  Search, 
  Bookmark, 
  BookmarkCheck, 
  ExternalLink, 
  Trash2, 
  TrendingUp, 
  TrendingDown, 
  Minus,
  Calendar,
  Newspaper,
  AlertCircle,
  Info,
  ThumbsDown,
  Ban,
  Sparkles,
  Shield,
  RefreshCw,
  Check,
  X,
  Clock,
  CheckCheck,
  XCircle
} from "lucide-react";
import { format, parseISO } from "date-fns";
import { da } from "date-fns/locale";

interface CompanyPRViewProps {
  companyId: string;
}

export function CompanyPRView({ companyId }: CompanyPRViewProps) {
  const [searchTerms, setSearchTerms] = useState("");
  const [dismissedArticles, setDismissedArticles] = useState<Set<string>>(new Set());
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [articleToBlock, setArticleToBlock] = useState<{ url: string; source: string } | null>(null);
  
  const {
    savedArticles,
    isLoadingSaved,
    pendingArticles,
    isLoadingPending,
    approvePending,
    isApproving,
    dismissPending,
    isDismissingPending,
    bulkApproveTrusted,
    isBulkApprovingTrusted,
    bulkDismissAll,
    isBulkDismissingAll,
    bulkApproveAll,
    isBulkApprovingAll,
    triggerScan,
    isScanning,
    searchArticles,
    isSearching,
    searchResults,
    saveArticle,
    isSaving,
    deleteArticle,
    dismissArticle,
    blockSource,
    learnedSources,
    blockedSources,
    unblockSource,
  } = useCompanyPR(companyId);

  const handleBlockAndDismissPending = (articleId: string, url: string) => {
    const domain = extractDomain(url);
    dismissPending(articleId);
    blockSource({ domain, reason: "Markeret som irrelevant" });
  };

  const extractDomain = (url: string): string => {
    try {
      const hostname = new URL(url).hostname;
      return hostname.replace(/^www\./, '');
    } catch {
      return url;
    }
  };

  const handleDismiss = (article: { url: string; title: string; source: string; snippet: string; published_at: string | null; ai_summary: string | null; sentiment: "positive" | "neutral" | "negative"; relevance_score: number }) => {
    dismissArticle(article);
    setDismissedArticles(prev => new Set([...prev, article.url]));
    setArticleToBlock({ url: article.url, source: article.source });
    setBlockDialogOpen(true);
  };

  const handleBlockSource = () => {
    if (articleToBlock) {
      const domain = extractDomain(articleToBlock.url);
      blockSource({ domain, reason: "Bruger markerede som irrelevant" });
    }
    setBlockDialogOpen(false);
    setArticleToBlock(null);
  };

  const handleSearch = async () => {
    try {
      await searchArticles(searchTerms || undefined);
    } catch (error) {
      console.error("Search failed:", error);
    }
  };

  const getSentimentBadge = (sentiment: "positive" | "neutral" | "negative" | null) => {
    switch (sentiment) {
      case "positive":
        return (
          <Badge variant="default" className="bg-green-500/20 text-green-700 border-green-500/30">
            <TrendingUp className="h-3 w-3 mr-1" />
            Positiv
          </Badge>
        );
      case "negative":
        return (
          <Badge variant="default" className="bg-red-500/20 text-red-700 border-red-500/30">
            <TrendingDown className="h-3 w-3 mr-1" />
            Negativ
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary">
            <Minus className="h-3 w-3 mr-1" />
            Neutral
          </Badge>
        );
    }
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Nylig artikel";
    try {
      return format(parseISO(dateString), "d. MMMM yyyy", { locale: da });
    } catch {
      return "Nylig artikel";
    }
  };

  const hasNoResults = searchResults && searchResults.articles.length === 0;
  const requiresApiKey = searchResults?.requires_api_key;

  return (
    <div className="space-y-6">
      {/* Pending Articles from Automated Scans */}
      {pendingArticles && pendingArticles.length > 0 && (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-amber-600" />
                  Nye foreslåede artikler ({pendingArticles.length})
                </CardTitle>
                <CardDescription>
                  Automatisk fundne artikler der afventer din vurdering.
                </CardDescription>
              </div>
              <div className="flex gap-2 flex-wrap">
                {/* Bulk actions */}
                {learnedSources && learnedSources.some(s => s.trust_score > 10) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => bulkApproveTrusted()}
                    disabled={isBulkApprovingTrusted}
                    className="text-green-600 hover:text-green-700 hover:bg-green-50"
                  >
                    {isBulkApprovingTrusted ? (
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <Sparkles className="h-4 w-4 mr-2" />
                    )}
                    Godkend trusted
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => bulkApproveAll()}
                  disabled={isBulkApprovingAll}
                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                >
                  {isBulkApprovingAll ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <CheckCheck className="h-4 w-4 mr-2" />
                  )}
                  Godkend alle
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => bulkDismissAll()}
                  disabled={isBulkDismissingAll}
                  className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                >
                  {isBulkDismissingAll ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <XCircle className="h-4 w-4 mr-2" />
                  )}
                  Afvis alle
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => triggerScan()}
                  disabled={isScanning}
                >
                  {isScanning ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Scanner...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Scan nu
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingArticles.map((article) => {
              const domain = extractDomain(article.url);
              const sourceStats = learnedSources?.find(s => s.domain === domain);
              const isTrusted = sourceStats && sourceStats.trust_score > 10;
              
              return (
                <Card key={article.id} className={`overflow-hidden ${isTrusted ? 'ring-1 ring-green-500/30' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          {article.source && (
                            <Badge variant="secondary">{article.source}</Badge>
                          )}
                          {isTrusted && (
                            <Badge variant="default" className="bg-green-500/20 text-green-700 border-green-500/30">
                              <Sparkles className="h-3 w-3 mr-1" />
                              Trusted
                            </Badge>
                          )}
                        </div>
                        <h4 className="font-semibold">{article.title}</h4>
                        {article.snippet && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{article.snippet}</p>
                        )}
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {formatDate(article.published_at)}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => approvePending(article.id)}
                          disabled={isApproving}
                          title="Godkend artikel"
                          className="text-green-600 hover:text-green-700 hover:bg-green-50"
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => dismissPending(article.id)}
                          disabled={isDismissingPending}
                          title="Afvis artikel"
                          className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                        >
                          <X className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => handleBlockAndDismissPending(article.id, article.url)}
                          title="Bloker kilde"
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Ban className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="outline"
                          asChild
                          title="Åbn artikel"
                        >
                          <a href={article.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </CardContent>
        </Card>
      )}

      {/* Search Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Søg efter PR & Nyheder
              </CardTitle>
              <CardDescription>
                Søg manuelt efter nyheder og presseomtale om virksomheden.
              </CardDescription>
            </div>
            {!pendingArticles?.length && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => triggerScan()}
                disabled={isScanning}
              >
                {isScanning ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Scanner...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Auto-scan
                  </>
                )}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <Input
              placeholder="Tilføj søgeord (valgfrit)..."
              value={searchTerms}
              onChange={(e) => setSearchTerms(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} disabled={isSearching}>
              {isSearching ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  Søger...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Søg
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Newspaper className="h-5 w-5" />
              Søgeresultater for {searchResults.company_name}
            </CardTitle>
            {!hasNoResults && (
              <CardDescription>
                Fundet {searchResults.articles.length} artikler. Klik på bogmærke-ikonet for at gemme.
              </CardDescription>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {requiresApiKey ? (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {searchResults.message || "PR-søgning er ikke konfigureret. Kontakt administrator."}
                </AlertDescription>
              </Alert>
            ) : hasNoResults ? (
              <div className="text-center py-8 text-muted-foreground">
                <Info className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="font-medium">Ingen artikler fundet</p>
                <p className="text-sm mt-1">
                  Prøv at justere søgeordene eller søg igen senere.
                </p>
              </div>
            ) : (
              searchResults.articles
                .filter(article => !dismissedArticles.has(article.url))
                .map((article, index) => {
                  const domain = extractDomain(article.url);
                  const sourceStats = learnedSources?.find(s => s.domain === domain);
                  const isTrusted = sourceStats && sourceStats.trust_score > 10;
                  const isAlreadySaved = savedArticles?.some(
                    saved => saved.url.toLowerCase() === article.url.toLowerCase()
                  );
                  
                  return (
                    <Card key={index} className={`overflow-hidden ${isTrusted ? 'ring-1 ring-green-500/30' : ''}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              {article.source && (
                                <Badge variant="secondary">{article.source}</Badge>
                              )}
                              {isTrusted && (
                                <Badge variant="default" className="bg-green-500/20 text-green-700 border-green-500/30">
                                  <Sparkles className="h-3 w-3 mr-1" />
                                  Trusted
                                </Badge>
                              )}
                              {isAlreadySaved && (
                                <Badge variant="default" className="bg-blue-500/20 text-blue-700 border-blue-500/30">
                                  <BookmarkCheck className="h-3 w-3 mr-1" />
                                  Allerede gemt
                                </Badge>
                              )}
                            </div>
                            <h4 className="font-semibold text-lg">{article.title}</h4>
                            {article.snippet && (
                              <p className="text-sm text-muted-foreground">{article.snippet}</p>
                            )}
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <span className="flex items-center gap-1">
                                <Calendar className="h-3 w-3" />
                                {formatDate(article.published_at)}
                              </span>
                            </div>
                          </div>
                          <div className="flex flex-col gap-2">
                            {isAlreadySaved ? (
                              <Button
                                size="icon"
                                variant="outline"
                                disabled
                                title="Allerede gemt"
                                className="text-blue-600 cursor-default"
                              >
                                <BookmarkCheck className="h-4 w-4" />
                              </Button>
                            ) : (
                              <Button
                                size="icon"
                                variant="outline"
                                onClick={() => saveArticle(article)}
                                disabled={isSaving}
                                title="Gem artikel"
                                className="text-green-600 hover:text-green-700 hover:bg-green-50"
                              >
                                <Bookmark className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              size="icon"
                              variant="outline"
                              onClick={() => handleDismiss(article)}
                              title="Ikke relevant"
                              className="text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                            >
                              <ThumbsDown className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="outline"
                              asChild
                              title="Åbn artikel"
                            >
                              <a href={article.url} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
            )}
          </CardContent>
        </Card>
      )}

      {/* Saved Articles */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookmarkCheck className="h-5 w-5" />
            Gemte Artikler
          </CardTitle>
          <CardDescription>
            Artikler du har gemt til senere reference.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingSaved ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : savedArticles && savedArticles.length > 0 ? (
            <div className="space-y-4">
              {savedArticles.map((article) => (
                <Card key={article.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          {article.sentiment && getSentimentBadge(article.sentiment)}
                          {article.relevance_score && (
                            <Badge variant="outline">
                              Relevans: {article.relevance_score}%
                            </Badge>
                          )}
                          {article.source && (
                            <Badge variant="secondary">{article.source}</Badge>
                          )}
                        </div>
                        <h4 className="font-semibold">{article.title}</h4>
                        {article.snippet && (
                          <p className="text-sm text-muted-foreground">{article.snippet}</p>
                        )}
                        {article.ai_summary && (
                          <div className="bg-muted/50 p-3 rounded-lg">
                            <p className="text-sm font-medium mb-1">AI Resumé:</p>
                            <p className="text-sm">{article.ai_summary}</p>
                          </div>
                        )}
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {formatDate(article.published_at)}
                          </span>
                          <span>
                            Gemt: {formatDate(article.created_at)}
                          </span>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button
                          size="icon"
                          variant="outline"
                          asChild
                          title="Åbn artikel"
                        >
                          <a href={article.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => deleteArticle(article.id)}
                          title="Slet artikel"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Newspaper className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>Ingen gemte artikler endnu.</p>
              <p className="text-sm">Søg efter nyheder og gem de relevante artikler.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Learned Preferences Section */}
      {(learnedSources?.length || blockedSources?.length) ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              Lærte Præferencer
            </CardTitle>
            <CardDescription>
              Systemet lærer af dine valg og prioriterer kilder du stoler på.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {learnedSources && learnedSources.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  Top Trusted Kilder
                </h4>
                <div className="flex flex-wrap gap-2">
                  {learnedSources
                    .filter(s => s.trust_score > 0)
                    .slice(0, 10)
                    .map(source => (
                      <Badge key={source.domain} variant="secondary" className="text-xs">
                        {source.domain}
                        <span className="ml-1 text-green-600">+{source.save_count}</span>
                      </Badge>
                    ))}
                </div>
              </div>
            )}

            {blockedSources && blockedSources.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2 flex items-center gap-2">
                  <Shield className="h-4 w-4 text-red-600" />
                  Blokerede Kilder
                </h4>
                <div className="flex flex-wrap gap-2">
                  {blockedSources.map(source => (
                    <Badge 
                      key={source.id} 
                      variant="outline" 
                      className="text-xs cursor-pointer hover:bg-muted"
                      onClick={() => unblockSource(source.id)}
                      title="Klik for at genaktivere"
                    >
                      <Ban className="h-3 w-3 mr-1 text-red-500" />
                      {source.domain || source.url}
                      <span className="ml-1 text-muted-foreground">×</span>
                    </Badge>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Klik på en kilde for at genaktivere den.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      ) : null}

      {/* Block Source Dialog */}
      <AlertDialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Bloker denne kilde?</AlertDialogTitle>
            <AlertDialogDescription>
              Vil du permanent blokere artikler fra{" "}
              <strong>{articleToBlock ? extractDomain(articleToBlock.url) : ""}</strong>?
              <br />
              Du kan altid genaktivere kilden senere under "Lærte Præferencer".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Nej, kun skjul denne artikel</AlertDialogCancel>
            <AlertDialogAction onClick={handleBlockSource} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              <Ban className="h-4 w-4 mr-2" />
              Bloker kilden
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
