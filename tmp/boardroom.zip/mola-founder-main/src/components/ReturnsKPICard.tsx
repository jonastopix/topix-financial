import { Card } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface ReturnsKPICardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
}

export function ReturnsKPICard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend = 'neutral',
}: ReturnsKPICardProps) {
  const trendColors = {
    up: 'text-green-600',
    down: 'text-red-600',
    neutral: 'text-muted-foreground',
  };

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl lg:text-3xl font-bold mt-2 truncate">{value}</p>
          {subtitle && (
            <p className={`text-sm mt-1 ${trendColors[trend]}`}>{subtitle}</p>
          )}
        </div>
        <div className="ml-4 flex-shrink-0">
          <div className="p-3 bg-primary/10 rounded-lg">
            <Icon className="h-6 w-6 text-primary" />
          </div>
        </div>
      </div>
    </Card>
  );
}
