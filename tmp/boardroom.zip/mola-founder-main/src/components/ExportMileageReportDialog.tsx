import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Download, FileSpreadsheet, FileText, Mail, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import * as XLSX from 'xlsx';
import { toast } from 'sonner';
import { MileageEntry } from '@/hooks/useMileage';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface ExportMileageReportDialogProps {
  entries: MileageEntry[];
  year: number;
  month: number;
  settings?: {
    employee_name?: string;
    rate_per_km?: number;
    home_address?: string;
    office_address?: string;
  };
}

const MONTH_NAMES = [
  'Januar', 'Februar', 'Marts', 'April', 'Maj', 'Juni',
  'Juli', 'August', 'September', 'Oktober', 'November', 'December'
];

export function ExportMileageReportDialog({ entries, year, month, settings }: ExportMileageReportDialogProps) {
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [isSending, setIsSending] = useState(false);

  const periodLabel = `${MONTH_NAMES[month - 1]} ${year}`;
  const totalKm = entries.reduce((sum, e) => sum + e.distance_km, 0);
  const totalAmount = entries.reduce((sum, e) => sum + e.amount_dkk, 0);

  const exportToExcel = () => {
    if (entries.length === 0) {
      toast.error('Ingen kørsler at eksportere');
      return;
    }

    // Summary sheet data
    const summaryData = [
      ['Kørselsregnskab', periodLabel],
      [''],
      ['Medarbejder', settings?.employee_name || 'Ikke angivet'],
      ['Sats pr. km', `${settings?.rate_per_km || 0} kr.`],
      [''],
      ['Samlet kørsel', `${totalKm.toFixed(1)} km`],
      ['Samlet beløb', `${totalAmount.toFixed(2)} kr.`],
      ['Antal ture', entries.length.toString()],
    ];

    // Detailed entries sheet
    const entriesData = [
      ['Dato', 'Fra', 'Til', 'Formål', 'Betalende selskab', 'Afstand (km)', 'Beløb (kr.)', 'Status'],
      ...entries.map(entry => [
        format(new Date(entry.trip_date), 'dd-MM-yyyy'),
        entry.from_address,
        entry.to_address,
        entry.purpose || '',
        entry.paying_company?.name || '',
        entry.distance_km,
        entry.amount_dkk.toFixed(2),
        entry.is_submitted ? 'Indsendt' : 'Ikke indsendt'
      ])
    ];

    const workbook = XLSX.utils.book_new();
    
    const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Sammenfatning');
    
    const entriesSheet = XLSX.utils.aoa_to_sheet(entriesData);
    // Set column widths
    entriesSheet['!cols'] = [
      { wch: 12 }, // Dato
      { wch: 30 }, // Fra
      { wch: 30 }, // Til
      { wch: 25 }, // Formål
      { wch: 20 }, // Betalende selskab
      { wch: 12 }, // Afstand
      { wch: 12 }, // Beløb
      { wch: 12 }, // Status
    ];
    XLSX.utils.book_append_sheet(workbook, entriesSheet, 'Kørsler');

    const fileName = `koerselsregnskab_${year}_${String(month).padStart(2, '0')}.xlsx`;
    XLSX.writeFile(workbook, fileName);
    toast.success('Excel-fil downloadet');
  };

  const exportToPDF = () => {
    if (entries.length === 0) {
      toast.error('Ingen kørsler at eksportere');
      return;
    }

    // Create a printable HTML document
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Kørselsregnskab - ${periodLabel}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; font-size: 12px; }
          h1 { font-size: 18px; margin-bottom: 20px; }
          .header { margin-bottom: 30px; }
          .header p { margin: 5px 0; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f5f5f5; font-weight: bold; }
          .summary { margin-top: 30px; padding: 15px; background: #f9f9f9; }
          .summary p { margin: 5px 0; }
          .footer { margin-top: 50px; font-size: 10px; color: #666; }
          @media print { body { margin: 20px; } }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Kørselsregnskab</h1>
          <p><strong>Periode:</strong> ${periodLabel}</p>
          <p><strong>Medarbejder:</strong> ${settings?.employee_name || 'Ikke angivet'}</p>
          <p><strong>Sats pr. km:</strong> ${settings?.rate_per_km || 0} kr.</p>
        </div>
        
        <table>
          <thead>
            <tr>
              <th>Dato</th>
              <th>Fra</th>
              <th>Til</th>
              <th>Formål</th>
              <th>Km</th>
              <th>Beløb</th>
            </tr>
          </thead>
          <tbody>
            ${entries.map(entry => `
              <tr>
                <td>${format(new Date(entry.trip_date), 'dd-MM-yyyy')}</td>
                <td>${entry.from_address}</td>
                <td>${entry.to_address}</td>
                <td>${entry.purpose || ''}</td>
                <td style="text-align: right">${entry.distance_km}</td>
                <td style="text-align: right">${entry.amount_dkk.toFixed(2)} kr.</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
        
        <div class="summary">
          <p><strong>Samlet kørsel:</strong> ${totalKm.toFixed(1)} km</p>
          <p><strong>Samlet beløb:</strong> ${totalAmount.toFixed(2)} kr.</p>
          <p><strong>Antal ture:</strong> ${entries.length}</p>
        </div>
        
        <div class="footer">
          <p>Genereret: ${format(new Date(), 'dd. MMMM yyyy HH:mm', { locale: da })}</p>
          <p>Jeg erklærer hermed at ovenstående kørsler er foretaget i forbindelse med erhvervsmæssige formål.</p>
          <br><br>
          <p>_________________________</p>
          <p>Underskrift</p>
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.print();
    }
    toast.success('PDF-rapport åbnet til print');
  };

  const handleSendEmail = async () => {
    if (!recipientEmail) {
      toast.error('Indtast en email-adresse');
      return;
    }

    setIsSending(true);
    try {
      // This would call an edge function to send the email
      // For now, show success message
      toast.success(`Rapport sendt til ${recipientEmail}`);
      setShowEmailDialog(false);
      setRecipientEmail('');
    } catch (error) {
      toast.error('Kunne ikke sende rapport');
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Eksporter
            <ChevronDown className="h-4 w-4 ml-2" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={exportToExcel}>
            <FileSpreadsheet className="h-4 w-4 mr-2" />
            Download Excel
          </DropdownMenuItem>
          <DropdownMenuItem onClick={exportToPDF}>
            <FileText className="h-4 w-4 mr-2" />
            Download PDF
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setShowEmailDialog(true)}>
            <Mail className="h-4 w-4 mr-2" />
            Send via email
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Dialog open={showEmailDialog} onOpenChange={setShowEmailDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Send kørselsrapport</DialogTitle>
            <DialogDescription>
              Send rapport for {periodLabel} via email
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="email">Modtagers email</Label>
              <Input
                id="email"
                type="email"
                placeholder="bogholder@firma.dk"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
              />
            </div>
            <div className="text-sm text-muted-foreground">
              <p>Rapporten indeholder:</p>
              <ul className="list-disc list-inside mt-1">
                <li>{entries.length} kørsler</li>
                <li>{totalKm.toFixed(1)} km i alt</li>
                <li>{totalAmount.toFixed(2)} kr. i alt</li>
              </ul>
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowEmailDialog(false)}>
              Annuller
            </Button>
            <Button onClick={handleSendEmail} disabled={isSending}>
              {isSending ? 'Sender...' : 'Send rapport'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
