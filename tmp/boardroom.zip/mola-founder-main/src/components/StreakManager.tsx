import { motion } from 'framer-motion';
import { Flame, Snowflake, Zap, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useGamification } from '@/hooks/useGamification';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export function StreakManager() {
  const { stats, buyStreakFreeze, isLoading } = useGamification();

  if (isLoading || !stats) {
    return null;
  }

  const canBuyFreeze = stats.xp >= 50 && stats.streakFreezeCount < 2;
  const streakMilestones = [7, 14, 30, 60, 100];
  const nextMilestone = streakMilestones.find(m => m > stats.activityStreak) || 100;
  const daysToNextMilestone = nextMilestone - stats.activityStreak;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <Flame className="h-4 w-4 text-orange-500" />
          Streak Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current streak display */}
        <div className="text-center py-4 bg-gradient-to-br from-orange-500/10 to-red-500/10 rounded-lg">
          <motion.div
            animate={stats.activityStreak > 0 ? {
              scale: [1, 1.1, 1],
            } : {}}
            transition={{ repeat: Infinity, duration: 2 }}
            className="text-5xl mb-2"
          >
            🔥
          </motion.div>
          <div className="text-3xl font-bold">
            {stats.activityStreak}
          </div>
          <p className="text-sm text-muted-foreground">
            {stats.activityStreak === 1 ? 'dag' : 'dage'} i træk
          </p>
        </div>

        {/* Next milestone */}
        {stats.activityStreak > 0 && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Næste milestone</span>
            <Badge variant="outline">
              {daysToNextMilestone} dage til {nextMilestone} 🎯
            </Badge>
          </div>
        )}

        {/* Streak freezes */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Streak Freeze</span>
            <div className="flex gap-1">
              {[0, 1].map((i) => (
                <div
                  key={i}
                  className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    i < stats.streakFreezeCount
                      ? 'bg-blue-500 text-white'
                      : 'bg-muted text-muted-foreground'
                  }`}
                >
                  <Snowflake className="h-3 w-3" />
                </div>
              ))}
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Streak freeze beskytter din streak hvis du glemmer en dag
          </p>
        </div>

        {/* Buy freeze button */}
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button
              variant="outline"
              className="w-full"
              disabled={!canBuyFreeze}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Køb Streak Freeze
              <Badge variant="secondary" className="ml-2">
                <Zap className="h-3 w-3 mr-1" />
                50 XP
              </Badge>
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <Snowflake className="h-5 w-5 text-blue-500" />
                Køb Streak Freeze?
              </AlertDialogTitle>
              <AlertDialogDescription>
                En streak freeze beskytter automatisk din streak hvis du glemmer at logge aktivitet en dag.
                <br /><br />
                <strong>Pris:</strong> 50 XP
                <br />
                <strong>Din XP:</strong> {stats.xp} XP
                <br />
                <strong>Max antal:</strong> 2 freezes
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuller</AlertDialogCancel>
              <AlertDialogAction onClick={() => buyStreakFreeze()}>
                Køb for 50 XP
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Streak tips */}
        <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg">
          <p className="font-medium mb-1">💡 Streak Tips</p>
          <ul className="space-y-1 list-disc list-inside">
            <li>Log mindst én aktivitet hver dag</li>
            <li>Få +5 XP bonus per streak-dag</li>
            <li>Køb freeze før du mister din streak</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
