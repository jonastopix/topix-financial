import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Trash2 } from 'lucide-react';
import { FundOwnership } from '@/hooks/useFundManagement';
import { Badge } from '@/components/ui/badge';

interface FundOwnershipTableProps {
  ownerships: FundOwnership[];
  onDelete: (ownershipId: string) => void;
}

export function FundOwnershipTable({ ownerships, onDelete }: FundOwnershipTableProps) {
  const getOwnerTypeBadge = (type: string) => {
    const variants = {
      person: 'default',
      company: 'secondary',
      fund: 'outline',
    } as const;

    return <Badge variant={variants[type as keyof typeof variants]}>{type}</Badge>;
  };

  return (
    <div className="overflow-x-auto w-full max-w-full">
      <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Ejer</TableHead>
          <TableHead>Type</TableHead>
          <TableHead className="text-right">Ejerandel</TableHead>
          <TableHead className="text-right">Handlinger</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {ownerships.length === 0 ? (
          <TableRow>
            <TableCell colSpan={4} className="text-center text-muted-foreground">
              Ingen ejere tilføjet endnu
            </TableCell>
          </TableRow>
        ) : (
          ownerships.map((ownership) => (
            <TableRow key={ownership.id}>
              <TableCell className="font-medium">{ownership.owner_name}</TableCell>
              <TableCell>{getOwnerTypeBadge(ownership.owner_type)}</TableCell>
              <TableCell className="text-right">{ownership.ownership_pct}%</TableCell>
              <TableCell className="text-right">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDelete(ownership.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
    </div>
  );
}
