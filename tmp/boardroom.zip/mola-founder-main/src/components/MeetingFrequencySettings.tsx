import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Calendar, Clock, Send } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';

interface MeetingFrequencySettingsProps {
  companyId: string;
  currentFrequency?: string;
  currentDuration?: number;
  lastMeetingDate?: string;
  lastInvitationSent?: string;
}

const FREQUENCY_LABELS = {
  weekly: 'Ugentlig',
  biweekly: 'Hver 2. uge',
  monthly: 'Månedlig',
  quarterly: 'Kvartalsvis',
  never: 'Aldrig'
};

const FREQUENCY_DAYS = {
  weekly: 7,
  biweekly: 14,
  monthly: 30,
  quarterly: 90
};

export function MeetingFrequencySettings({
  companyId,
  currentFrequency = 'monthly',
  currentDuration = 60,
  lastMeetingDate,
  lastInvitationSent
}: MeetingFrequencySettingsProps) {
  const [frequency, setFrequency] = useState(currentFrequency);
  const [duration, setDuration] = useState(currentDuration);
  const [isSaving, setIsSaving] = useState(false);
  const [isSendingNow, setIsSendingNow] = useState(false);

  const calculateNextInvitation = () => {
    if (!lastMeetingDate || frequency === 'never') return null;
    
    const lastMeeting = new Date(lastMeetingDate);
    const days = FREQUENCY_DAYS[frequency as keyof typeof FREQUENCY_DAYS];
    const nextDate = new Date(lastMeeting);
    nextDate.setDate(nextDate.getDate() + days);
    
    return nextDate;
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { error } = await supabase
        .from('companies')
        .update({
          meeting_frequency: frequency,
          meeting_duration_minutes: duration
        })
        .eq('id', companyId);

      if (error) throw error;
      toast.success('Mødeindstillinger opdateret');
    } catch (error) {
      console.error('Error updating meeting settings:', error);
      toast.error('Kunne ikke opdatere mødeindstillinger');
    } finally {
      setIsSaving(false);
    }
  };

  const handleSendNow = async () => {
    setIsSendingNow(true);
    try {
      // Call edge function to send invitation manually
      const { error } = await supabase.functions.invoke('send-meeting-invitations', {
        body: { companyId }
      });

      if (error) throw error;
      
      toast.success('Møde invitation sendt');
    } catch (error) {
      console.error('Error sending invitation:', error);
      toast.error('Kunne ikke sende invitation');
    } finally {
      setIsSendingNow(false);
    }
  };

  const nextInvitation = calculateNextInvitation();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Mødefrekvens
        </CardTitle>
        <CardDescription>
          Indstil hvor ofte der automatisk skal sendes Calendly invitationer
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="frequency">Mødefrekvens</Label>
          <Select value={frequency} onValueChange={setFrequency}>
            <SelectTrigger id="frequency">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(FREQUENCY_LABELS).map(([value, label]) => (
                <SelectItem key={value} value={value}>
                  {label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="duration">Mødets varighed (minutter)</Label>
          <Input
            id="duration"
            type="number"
            value={duration}
            onChange={(e) => setDuration(parseInt(e.target.value))}
            min={15}
            max={240}
            step={15}
          />
        </div>

        {lastMeetingDate && (
          <div className="rounded-lg border bg-muted/50 p-4 space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Sidste møde:</span>
              <span className="font-medium">
                {format(new Date(lastMeetingDate), 'PPP', { locale: da })}
              </span>
            </div>
            
            {nextInvitation && frequency !== 'never' && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Næste invitation:</span>
                <span className="font-medium">
                  {format(nextInvitation, 'PPP', { locale: da })}
                </span>
              </div>
            )}

            {lastInvitationSent && (
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Seneste invitation sendt:</span>
                <span className="font-medium">
                  {format(new Date(lastInvitationSent), 'PPP', { locale: da })}
                </span>
              </div>
            )}
          </div>
        )}

        <div className="flex gap-2">
          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1"
          >
            <Clock className="h-4 w-4 mr-2" />
            Gem indstillinger
          </Button>
          
          {frequency !== 'never' && (
            <Button
              onClick={handleSendNow}
              disabled={isSendingNow}
              variant="outline"
            >
              <Send className="h-4 w-4 mr-2" />
              Send invitation nu
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
