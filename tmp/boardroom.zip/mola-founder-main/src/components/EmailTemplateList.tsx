import { EmailTemplate } from '@/hooks/useEmailTemplates';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Mail, Circle, Send } from 'lucide-react';
import { cn } from '@/lib/utils';

interface EmailTemplateListProps {
  templates: EmailTemplate[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onSendTest: (id: string) => void;
}

export function EmailTemplateList({ templates, selectedId, onSelect, onSendTest }: EmailTemplateListProps) {
  return (
    <div className="space-y-2">
      {templates.map((template) => (
        <div key={template.id} className="relative group">
          <Button
            variant={selectedId === template.id ? 'secondary' : 'ghost'}
            className={cn(
              'w-full justify-start text-left h-auto py-4 pr-14',
              selectedId === template.id && 'bg-secondary'
            )}
            onClick={() => onSelect(template.id)}
          >
            <div className="flex items-start gap-3 w-full">
              <Mail className="w-5 h-5 mt-0.5 shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="font-semibold truncate">{template.template_name}</span>
                  <Badge
                    variant={template.is_active ? 'default' : 'secondary'}
                    className="shrink-0"
                  >
                    <Circle className={cn(
                      'w-2 h-2 mr-1',
                      template.is_active ? 'fill-current' : ''
                    )} />
                    {template.is_active ? 'Aktiv' : 'Inaktiv'}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate">
                  {template.subject}
                </p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {template.available_variables.slice(0, 3).map((variable) => (
                    <Badge key={variable} variant="outline" className="text-xs">
                      {`{{${variable}}}`}
                    </Badge>
                  ))}
                  {template.available_variables.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{template.available_variables.length - 3}
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={(e) => {
              e.stopPropagation();
              onSendTest(template.id);
            }}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  );
}
