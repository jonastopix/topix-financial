import { useState } from 'react';
import { format, isAfter, isBefore, addDays } from 'date-fns';
import { da } from 'date-fns/locale';
import { Task, useTaskManagement } from '@/hooks/useTaskManagement';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  AlertCircle,
  Calendar as CalendarIcon,
  Building2,
  User,
  MoreVertical,
  CheckCircle2,
  Clock,
  Circle,
  Trash2,
  Repeat,
  Link as LinkIcon,
  ChevronDown,
  Lock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import TaskDetailsDialog from './TaskDetailsDialog';

interface TaskCardProps {
  task: Task;
  onDragStart?: (taskId: string) => void;
  onDragEnd?: () => void;
  isDragging?: boolean;
}

const TaskCard = ({ task, onDragStart, onDragEnd, isDragging }: TaskCardProps) => {
  const { updateTask, deleteTask } = useTaskManagement();
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-destructive text-destructive-foreground';
      case 'high':
        return 'bg-orange-500 text-white';
      case 'medium':
        return 'bg-yellow-500 text-black';
      case 'low':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'done':
        return <CheckCircle2 className="h-4 w-4 text-green-600" />;
      case 'in_progress':
        return <Clock className="h-4 w-4 text-blue-600" />;
      case 'cancelled':
        return <Circle className="h-4 w-4 text-muted-foreground" />;
      default:
        return <Circle className="h-4 w-4" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'todo':
        return 'Ikke påbegyndt';
      case 'in_progress':
        return 'I gang';
      case 'done':
        return 'Færdig';
      case 'cancelled':
        return 'Annulleret';
      default:
        return status;
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'Akut';
      case 'high':
        return 'Høj';
      case 'medium':
        return 'Mellem';
      case 'low':
        return 'Lav';
      default:
        return priority;
    }
  };

  const isOverdue = task.due_date && task.status !== 'done' && isBefore(new Date(task.due_date), new Date());
  const isDueSoon = task.due_date && task.status !== 'done' && 
    isAfter(new Date(task.due_date), new Date()) && 
    isBefore(new Date(task.due_date), addDays(new Date(), 3));

  const handleStatusChange = (status: Task['status']) => {
    updateTask.mutate({ id: task.id, status });
  };

  const handlePriorityChange = (priority: Task['priority']) => {
    updateTask.mutate({ id: task.id, priority });
  };

  const handleDateChange = (date: Date | undefined) => {
    updateTask.mutate({ id: task.id, due_date: date ? format(date, 'yyyy-MM-dd') : null });
    setIsDatePickerOpen(false);
  };

  const handleDelete = () => {
    if (confirm('Er du sikker på at du vil slette denne opgave?')) {
      deleteTask.mutate(task.id);
    }
  };

  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData('taskId', task.id);
    e.dataTransfer.effectAllowed = 'move';
    onDragStart?.(task.id);
  };

  return (
    <>
      <Card 
        className={cn(
          'group hover:shadow-md transition-all cursor-grab active:cursor-grabbing',
          isOverdue && 'border-destructive',
          isDueSoon && 'border-yellow-500',
          isDragging && 'opacity-50 shadow-lg'
        )}
        draggable
        onDragStart={handleDragStart}
        onDragEnd={onDragEnd}
        onClick={() => setIsDetailsOpen(true)}
      >
        <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex items-start gap-2 flex-1 min-w-0">
            {getStatusIcon(task.status)}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-medium text-base truncate">{task.title}</h3>
                {task.is_private && (
                  <span title="Privat opgave">
                    <Lock className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
                  </span>
                )}
                {task.is_recurring && (
                  <span title="Gentagende opgave">
                    <Repeat className="h-4 w-4 text-primary flex-shrink-0" />
                  </span>
                )}
                {task.parent_task_id && (
                  <span title="Del af gentagende opgave">
                    <LinkIcon className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                  </span>
                )}
              </div>
              {task.assigned_profile && (
                <div className="flex items-center gap-1.5 mt-1">
                  <User className="h-3.5 w-3.5 text-primary" />
                  <span className="text-sm font-medium text-foreground">
                    {task.assigned_profile.full_name || 'Ikke tildelt'}
                    {task.assigned_profile.company_name && (
                      <span className="text-muted-foreground font-normal ml-1">
                        ({task.assigned_profile.company_name})
                      </span>
                    )}
                  </span>
                </div>
              )}
              {task.parent_task && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  Del af: {task.parent_task.title}
                </p>
              )}
              {task.description && (
                <p className="text-sm text-muted-foreground mt-1">
                  {task.description.length > 100 
                    ? `${task.description.substring(0, 100)}...` 
                    : task.description}
                </p>
              )}
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-8 w-8 opacity-0 group-hover:opacity-100"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover">
              <DropdownMenuItem onClick={() => handleStatusChange('todo')}>
                <Circle className="h-4 w-4 mr-2" />
                Ikke påbegyndt
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleStatusChange('in_progress')}>
                <Clock className="h-4 w-4 mr-2" />
                I gang
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleStatusChange('done')}>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Færdig
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDelete} className="text-destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Slet
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex flex-wrap gap-2 items-center">
          {/* Inline Priority Dropdown */}
          <div onClick={(e) => e.stopPropagation()}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Badge 
                  variant="outline" 
                  className={cn(
                    getPriorityColor(task.priority),
                    'cursor-pointer hover:opacity-80 transition-opacity flex items-center gap-1'
                  )}
                >
                  {getPriorityLabel(task.priority)}
                  <ChevronDown className="h-3 w-3" />
                </Badge>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="bg-popover">
                <DropdownMenuItem onClick={() => handlePriorityChange('urgent')}>
                  <Badge className="bg-destructive text-destructive-foreground mr-2">Akut</Badge>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handlePriorityChange('high')}>
                  <Badge className="bg-orange-500 text-white mr-2">Høj</Badge>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handlePriorityChange('medium')}>
                  <Badge className="bg-yellow-500 text-black mr-2">Mellem</Badge>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handlePriorityChange('low')}>
                  <Badge className="bg-muted text-muted-foreground mr-2">Lav</Badge>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <Badge variant="outline">
            {getStatusLabel(task.status)}
          </Badge>

          {/* Inline Date Picker */}
          <div onClick={(e) => e.stopPropagation()}>
            <Popover open={isDatePickerOpen} onOpenChange={setIsDatePickerOpen}>
              <PopoverTrigger asChild>
                <div 
                  className={cn(
                    'flex items-center gap-1 text-xs cursor-pointer hover:underline transition-all px-2 py-1 rounded-md hover:bg-muted',
                    isOverdue && 'text-destructive font-medium',
                    isDueSoon && 'text-yellow-600 font-medium',
                    !task.due_date && 'text-muted-foreground'
                  )}
                >
                  {isOverdue && <AlertCircle className="h-3 w-3" />}
                  <CalendarIcon className="h-3 w-3" />
                  {task.due_date 
                    ? format(new Date(task.due_date), 'dd MMM yyyy', { locale: da })
                    : 'Tilføj dato'
                  }
                </div>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0 bg-popover" align="start">
                <Calendar
                  mode="single"
                  selected={task.due_date ? new Date(task.due_date) : undefined}
                  onSelect={handleDateChange}
                  initialFocus
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        {task.company && (
          <div className="flex items-center gap-1 mt-3 text-xs text-muted-foreground">
            <Building2 className="h-3 w-3" />
            {task.company.name}
          </div>
        )}
      </CardContent>
    </Card>
    
    <TaskDetailsDialog 
      task={task} 
      open={isDetailsOpen} 
      onOpenChange={setIsDetailsOpen} 
    />
  </>
  );
};

export default TaskCard;
