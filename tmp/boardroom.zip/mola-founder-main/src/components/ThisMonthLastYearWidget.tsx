import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { useMonthlyReports } from '@/hooks/useCompanyData';
import { Calendar, TrendingUp, TrendingDown } from 'lucide-react';
import { formatCurrency } from '@/lib/formatters';

interface ThisMonthLastYearWidgetProps {
  companyId?: string;
}

export default function ThisMonthLastYearWidget({ companyId }: ThisMonthLastYearWidgetProps) {
  const { data: reports, isLoading } = useMonthlyReports(companyId);

  if (isLoading) {
    return (
      <Card className="min-h-[300px]">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Year-over-Year
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Skeleton className="h-4 w-24" />
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
            <Skeleton className="h-8 w-32" />
          </div>
          <div className="space-y-3 pt-4">
            <Skeleton className="h-4 w-24" />
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </div>
            <Skeleton className="h-8 w-32" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!reports || reports.length === 0) {
    return null;
  }

  // Get latest report
  const sortedReports = [...reports].sort((a, b) => {
    if (a.period_year !== b.period_year) {
      return b.period_year - a.period_year;
    }
    return b.period_month - a.period_month;
  });

  const latestReport = sortedReports[0];
  
  // Find same month last year
  const lastYearReport = reports.find(
    r => r.period_month === latestReport.period_month && 
         r.period_year === latestReport.period_year - 1
  );

  if (!lastYearReport) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Year-over-Year
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-muted-foreground">
            Ikke nok historisk data til sammenligning endnu.
          </div>
        </CardContent>
      </Card>
    );
  }

  const currentRevenue = latestReport.revenue_dkk;
  const lastYearRevenue = lastYearReport.revenue_dkk;
  const revenueChange = currentRevenue - lastYearRevenue;
  const revenueChangePct = lastYearRevenue > 0 
    ? (revenueChange / lastYearRevenue * 100) 
    : 0;

  const currentEbitda = latestReport.ebitda_dkk;
  const lastYearEbitda = lastYearReport.ebitda_dkk;
  const ebitdaChange = currentEbitda - lastYearEbitda;
  const ebitdaChangePct = lastYearEbitda !== 0 
    ? (ebitdaChange / Math.abs(lastYearEbitda) * 100) 
    : 0;

  const monthName = new Date(2024, latestReport.period_month - 1).toLocaleString('da-DK', { 
    month: 'long' 
  });

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          📅 {monthName} - Year-over-Year
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Revenue Comparison */}
        <div>
          <div className="text-sm text-muted-foreground mb-2">Omsætning</div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-muted-foreground mb-1">I år ({latestReport.period_year})</div>
              <div className="text-2xl font-bold text-foreground">
                {formatCurrency(currentRevenue)}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Sidste år ({lastYearReport.period_year})</div>
              <div className="text-xl font-semibold text-muted-foreground">
                {formatCurrency(lastYearRevenue)}
              </div>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            {revenueChangePct >= 0 ? (
              <Badge variant="default" className="bg-success text-success-foreground">
                <TrendingUp className="h-3 w-3 mr-1" />
                +{revenueChangePct.toFixed(1)}% YoY 🚀
              </Badge>
            ) : (
              <Badge variant="destructive">
                <TrendingDown className="h-3 w-3 mr-1" />
                {revenueChangePct.toFixed(1)}% YoY
              </Badge>
            )}
            <span className="text-sm text-muted-foreground">
              ({revenueChange >= 0 ? '+' : ''}{formatCurrency(revenueChange)})
            </span>
          </div>
        </div>

        {/* EBITDA Comparison */}
        <div className="pt-4 border-t border-border">
          <div className="text-sm text-muted-foreground mb-2">EBITDA</div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-muted-foreground mb-1">I år ({latestReport.period_year})</div>
              <div className="text-2xl font-bold text-foreground">
                {formatCurrency(currentEbitda)}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground mb-1">Sidste år ({lastYearReport.period_year})</div>
              <div className="text-xl font-semibold text-muted-foreground">
                {formatCurrency(lastYearEbitda)}
              </div>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            {ebitdaChange >= 0 ? (
              <Badge variant="default" className="bg-success text-success-foreground">
                <TrendingUp className="h-3 w-3 mr-1" />
                {lastYearEbitda !== 0 ? `+${ebitdaChangePct.toFixed(1)}%` : 'Bedring'} YoY
              </Badge>
            ) : (
              <Badge variant="destructive">
                <TrendingDown className="h-3 w-3 mr-1" />
                {lastYearEbitda !== 0 ? `${ebitdaChangePct.toFixed(1)}%` : 'Fald'} YoY
              </Badge>
            )}
            <span className="text-sm text-muted-foreground">
              ({ebitdaChange >= 0 ? '+' : ''}{formatCurrency(ebitdaChange)})
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
