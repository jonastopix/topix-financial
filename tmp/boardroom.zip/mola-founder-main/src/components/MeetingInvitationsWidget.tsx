import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Calendar, CheckCircle, Clock, XCircle, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';
import { da } from 'date-fns/locale';
import { toast } from 'sonner';
import { useState } from 'react';

export function MeetingInvitationsWidget() {
  const [resendingId, setResendingId] = useState<string | null>(null);

  const { data: invitations, isLoading, refetch } = useQuery({
    queryKey: ['meeting-invitations'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('meeting_invitations')
        .select(`
          *,
          companies(name)
        `)
        .order('sent_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      return data;
    }
  });

  const handleResend = async (invitationId: string, companyId: string) => {
    setResendingId(invitationId);
    try {
      const { error } = await supabase.functions.invoke('send-meeting-invitations', {
        body: { companyId }
      });

      if (error) throw error;
      
      toast.success('Invitation sendt igen');
      refetch();
    } catch (error) {
      console.error('Error resending invitation:', error);
      toast.error('Kunne ikke gensende invitation');
    } finally {
      setResendingId(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'booked':
        return (
          <Badge variant="default" className="bg-green-500">
            <CheckCircle className="h-3 w-3 mr-1" />
            Booket
          </Badge>
        );
      case 'sent':
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            Afventer
          </Badge>
        );
      case 'expired':
        return (
          <Badge variant="destructive">
            <XCircle className="h-3 w-3 mr-1" />
            Udløbet
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Møde Invitationer
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!invitations || invitations.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Møde Invitationer
          </CardTitle>
          <CardDescription>
            Ingen invitationer sendt endnu
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Møde Invitationer
        </CardTitle>
        <CardDescription>
          Status på sendte Calendly invitationer
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {invitations.map((invitation) => (
          <div
            key={invitation.id}
            className="flex items-center justify-between rounded-lg border p-3 hover:bg-muted/50 transition-colors"
          >
            <div className="flex-1 space-y-1">
              <p className="font-medium">
                {(invitation.companies as any)?.name || 'Unknown Company'}
              </p>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>
                  Sendt: {format(new Date(invitation.sent_at), 'PPP', { locale: da })}
                </span>
                {invitation.next_expected_meeting_date && (
                  <>
                    <span>•</span>
                    <span>
                      Forventet: {format(new Date(invitation.next_expected_meeting_date), 'PPP', { locale: da })}
                    </span>
                  </>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2">
              {getStatusBadge(invitation.status)}
              
              {invitation.status === 'sent' && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleResend(invitation.id, invitation.company_id)}
                  disabled={resendingId === invitation.id}
                >
                  <RefreshCw className={`h-4 w-4 ${resendingId === invitation.id ? 'animate-spin' : ''}`} />
                </Button>
              )}
            </div>
          </div>
        ))}

        {invitations.length >= 10 && (
          <p className="text-sm text-muted-foreground text-center pt-2">
            Viser de 10 seneste invitationer
          </p>
        )}
      </CardContent>
    </Card>
  );
}
