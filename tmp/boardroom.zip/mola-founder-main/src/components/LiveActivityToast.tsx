import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLiveActivityNotifications } from '@/hooks/useLiveActivityNotifications';
import { X } from 'lucide-react';

export function LiveActivityToast() {
  const { newEvent, clearEvent } = useLiveActivityNotifications();

  if (!newEvent) return null;

  return (
    <div className="fixed bottom-20 right-4 z-50 md:bottom-4">
      <AnimatePresence>
        {newEvent && (
          <motion.div
            initial={{ opacity: 0, x: 100, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 100, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative bg-card border border-border rounded-lg shadow-lg p-4 pr-10 max-w-sm"
          >
            <button
              onClick={clearEvent}
              className="absolute top-2 right-2 p-1 rounded-md hover:bg-muted transition-colors"
            >
              <X className="h-4 w-4 text-muted-foreground" />
            </button>
            
            <div className="flex items-start gap-3">
              <span className="text-xl flex-shrink-0">
                {newEvent.event_icon || '📢'}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground">
                  Live Aktivitet
                </p>
                <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">
                  {newEvent.event_message}
                </p>
              </div>
            </div>
            
            {/* Progress bar */}
            <motion.div
              initial={{ scaleX: 1 }}
              animate={{ scaleX: 0 }}
              transition={{ duration: 5, ease: 'linear' }}
              className="absolute bottom-0 left-0 right-0 h-1 bg-primary/30 origin-left rounded-b-lg"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
