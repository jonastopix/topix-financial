import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function useDataAccessRequests() {
  const queryClient = useQueryClient();

  const { data: requests, isLoading } = useQuery({
    queryKey: ['data-access-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('data_access_requests')
        .select('*')
        .order('requested_at', { ascending: false });
      
      if (error) throw error;
      return data;
    }
  });

  const createRequest = useMutation({
    mutationFn: async (params: {
      request_type: string;
      reason?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('data_access_requests')
        .insert([{
          ...params,
          user_id: user.id
        }])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-access-requests'] });
      toast.success('Anmodning sendt', {
        description: 'MOLA vil behandle din anmodning inden for 1-3 hverdage'
      });
    },
    onError: (error: Error) => {
      toast.error('Kunne ikke sende anmodning', {
        description: error.message
      });
    }
  });

  return { requests, isLoading, createRequest };
}

export function useDataRequestManagement() {
  const queryClient = useQueryClient();

  const approveRequest = useMutation({
    mutationFn: async (requestId: string) => {
      const { error } = await supabase
        .from('data_access_requests')
        .update({ 
          status: 'approved',
          processed_at: new Date().toISOString()
        })
        .eq('id', requestId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-access-requests'] });
      toast.success('Anmodning godkendt');
    }
  });

  const rejectRequest = useMutation({
    mutationFn: async ({ requestId, reason }: { requestId: string; reason: string }) => {
      const { error } = await supabase
        .from('data_access_requests')
        .update({ 
          status: 'rejected',
          rejection_reason: reason,
          processed_at: new Date().toISOString()
        })
        .eq('id', requestId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-access-requests'] });
      toast.success('Anmodning afvist');
    }
  });

  const generateDataFile = useMutation({
    mutationFn: async (requestId: string) => {
      const { data, error } = await supabase.functions.invoke('generate-user-data-export', {
        body: { requestId }
      });
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['data-access-requests'] });
      toast.success('Data fil genereret', {
        description: 'Brugeren kan nu downloade deres data'
      });
    },
    onError: (error: Error) => {
      toast.error('Kunne ikke generere data fil', {
        description: error.message
      });
    }
  });

  return { approveRequest, rejectRequest, generateDataFile };
}
