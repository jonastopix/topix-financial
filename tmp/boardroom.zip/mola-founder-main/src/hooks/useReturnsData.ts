import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Dividend, Exit, Valuation } from '@/lib/returnsCalculations';

export function useDividends(companyId?: string) {
  return useQuery({
    queryKey: ['dividends', companyId],
    queryFn: async () => {
      let query = supabase
        .from('dividends')
        .select('*')
        .order('paid_date', { ascending: false });

      if (companyId) {
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Dividend[];
    },
    enabled: !!companyId,
  });
}

export function useExits(companyId?: string) {
  return useQuery({
    queryKey: ['exits', companyId],
    queryFn: async () => {
      let query = supabase
        .from('exits')
        .select('*')
        .order('closing_date', { ascending: false });

      if (companyId) {
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Exit[];
    },
    enabled: !!companyId,
  });
}

export function useValuations(companyId?: string) {
  return useQuery({
    queryKey: ['valuations', companyId],
    queryFn: async () => {
      let query = supabase
        .from('valuations')
        .select('*')
        .order('as_of_date', { ascending: false });

      if (companyId) {
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Valuation[];
    },
    enabled: !!companyId,
  });
}

export function useFunds() {
  return useQuery({
    queryKey: ['funds'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('*')
        .order('name');

      if (error) throw error;
      return data;
    },
  });
}

export function useCompanyReturnsData(companyId?: string) {
  const dividends = useDividends(companyId);
  const exits = useExits(companyId);
  const valuations = useValuations(companyId);

  return {
    dividends: dividends.data || [],
    exits: exits.data || [],
    valuations: valuations.data || [],
    isLoading: dividends.isLoading || exits.isLoading || valuations.isLoading,
    error: dividends.error || exits.error || valuations.error,
  };
}
