import { useState, useEffect } from 'react';

export const useGlobalKeyboardShortcuts = () => {
  const [isCreateTaskOpen, setIsCreateTaskOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isActivityOpen, setIsActivityOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd+K / Ctrl+K to open search - works everywhere except in dialogs
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
        return;
      }

      // Ignore other shortcuts if user is typing in an input field
      const target = e.target as HTMLElement;
      const tagName = target.tagName.toLowerCase();
      
      if (
        tagName === 'input' || 
        tagName === 'textarea' || 
        tagName === 'select' ||
        target.isContentEditable ||
        target.closest('[role="dialog"]') // Ignore when a dialog is open
      ) {
        return;
      }
      
      // Press "t" to open task dialog
      if (e.key === 't' && !e.metaKey && !e.ctrlKey && !e.altKey && !e.shiftKey) {
        e.preventDefault();
        setIsCreateTaskOpen(true);
      }
      
      // Press "a" to open activity registration
      if (e.key === 'a' && !e.metaKey && !e.ctrlKey && !e.altKey && !e.shiftKey) {
        e.preventDefault();
        setIsActivityOpen(true);
      }
      
      // Press "s" to open search (same as Cmd+K)
      if (e.key === 's' && !e.metaKey && !e.ctrlKey && !e.altKey && !e.shiftKey) {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  return { 
    isCreateTaskOpen, 
    setIsCreateTaskOpen, 
    isSearchOpen, 
    setIsSearchOpen,
    isActivityOpen,
    setIsActivityOpen,
  };
};
