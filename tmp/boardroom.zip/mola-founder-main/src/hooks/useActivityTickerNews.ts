import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';

interface TickerNews {
  id: string;
  icon: string;
  message: string;
  type: 'stat' | 'ranking' | 'activity' | 'milestone';
  priority: number;
  created_at: string;
}

export function useActivityTickerNews() {
  const { user } = useAuth();
  const { isAdmin } = useRole();

  return useQuery({
    queryKey: ['activity-ticker-news', user?.id, isAdmin],
    queryFn: async () => {
      const news: TickerNews[] = [];
      const now = new Date().toISOString();

      // Fetch active companies count
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, status')
        .eq('is_active', true);

      if (!companiesError && companies) {
        const activeCount = companies.length;
        news.push({
          id: 'active-companies',
          icon: '📊',
          message: `${activeCount} aktive selskaber i MOLA-porteføljen`,
          type: 'stat',
          priority: 1,
          created_at: now,
        });
      }

      // Fetch portfolio rankings for highlights
      const { data: rankings, error: rankingsError } = await supabase
        .from('portfolio_rankings')
        .select('*')
        .order('calculated_at', { ascending: false })
        .limit(100);

      if (!rankingsError && rankings && rankings.length > 0) {
        // Get latest rankings per metric
        const latestByMetric = rankings.reduce((acc: any, ranking: any) => {
          if (!acc[ranking.metric_type] || acc[ranking.metric_type].calculated_at < ranking.calculated_at) {
            acc[ranking.metric_type] = ranking;
          }
          return acc;
        }, {});

        // YTD Revenue highlight
        const ytdRevenueRankings = rankings.filter(r => r.metric_type === 'ytd_revenue');
        if (ytdRevenueRankings.length > 0) {
          const topPerformer = ytdRevenueRankings.sort((a, b) => b.metric_value - a.metric_value)[0];
          if (topPerformer.metric_value > 0) {
            news.push({
              id: 'top-revenue',
              icon: '🚀',
              message: `Top-performeren har ${(topPerformer.metric_value / 1000000).toFixed(1)}M DKK i YTD omsætning`,
              type: 'ranking',
              priority: 2,
              created_at: now,
            });
          }
        }

        // EBITDA Margin highlight
        const ebitdaMarginRankings = rankings.filter(r => r.metric_type === 'ebitda_margin');
        if (ebitdaMarginRankings.length > 0) {
          const bestMargin = ebitdaMarginRankings.sort((a, b) => b.metric_value - a.metric_value)[0];
          if (bestMargin.metric_value > 0) {
            news.push({
              id: 'best-margin',
              icon: '⭐',
              message: `Bedste EBITDA-margin i porteføljen: ${bestMargin.metric_value.toFixed(0)}%`,
              type: 'ranking',
              priority: 3,
              created_at: now,
            });
          }
        }

        // Average EBITDA margin - only show if meaningful (>= 1%)
        const validMargins = ebitdaMarginRankings.filter(r => r.metric_value > 0);
        const avgMargin = validMargins.length > 0
          ? validMargins.reduce((sum, r) => sum + r.metric_value, 0) / validMargins.length
          : 0;
        if (avgMargin >= 1) {
          news.push({
            id: 'avg-margin',
            icon: '🎯',
            message: `Gns. EBITDA-margin på ${avgMargin.toFixed(1)}% i porteføljen`,
            type: 'stat',
            priority: 4,
            created_at: now,
          });
        }

        // Sum total YTD revenue
        const totalYTDRevenue = ytdRevenueRankings.reduce((sum, r) => sum + r.metric_value, 0);
        if (totalYTDRevenue > 0) {
          news.push({
            id: 'total-revenue',
            icon: '💰',
            message: `${(totalYTDRevenue / 1000000).toFixed(0)}M DKK samlet YTD omsætning på tværs af porteføljen`,
            type: 'stat',
            priority: 5,
            created_at: now,
          });
        }

        // Profitable companies count
        const profitableCount = ebitdaMarginRankings.filter(r => r.metric_value > 0).length;
        if (profitableCount > 0) {
          news.push({
            id: 'profitable-companies',
            icon: '📈',
            message: `${profitableCount} selskaber er profitable i år`,
            type: 'stat',
            priority: 6,
            created_at: now,
          });
        }
      }

      // Fetch recent monthly reports for activity stats (previous month)
      const currentYear = new Date().getFullYear();
      const currentMonth = new Date().getMonth() + 1;
      
      // Reports are submitted for the previous month
      const reportMonth = currentMonth === 1 ? 12 : currentMonth - 1;
      const reportYear = currentMonth === 1 ? currentYear - 1 : currentYear;
      
      const monthNames = ['januar', 'februar', 'marts', 'april', 'maj', 'juni', 
                          'juli', 'august', 'september', 'oktober', 'november', 'december'];
      
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('company_id')
        .eq('period_year', reportYear)
        .eq('period_month', reportMonth);

      if (!reportsError && reports && reports.length > 0) {
        const reportCount = reports.length;
        const percentage = companies ? Math.round((reportCount / companies.length) * 100) : 0;
        news.push({
          id: 'report-activity',
          icon: '📝',
          message: `${reportCount} founders har indsendt rapport for ${monthNames[reportMonth - 1]} (${percentage}%)`,
          type: 'activity',
          priority: 7,
          created_at: now,
        });
      }

      // Fetch funding rounds this year
      const { data: fundingRounds, error: fundingError } = await supabase
        .from('funding_rounds')
        .select('id')
        .gte('invested_at', `${currentYear}-01-01`);

      if (!fundingError && fundingRounds && fundingRounds.length > 0) {
        news.push({
          id: 'new-investments',
          icon: '🤝',
          message: `${fundingRounds.length} nye investeringer i ${currentYear}`,
          type: 'milestone',
          priority: 8,
          created_at: now,
        });
      }

      // Shuffle news to provide variation
      const shuffled = news.sort(() => Math.random() - 0.5);
      
      return shuffled;
    },
    enabled: !!user,
    refetchInterval: 60000, // Refresh every minute
  });
}
