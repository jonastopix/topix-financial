import { useCallback } from 'react';
import { useRole } from '@/contexts/RoleContext';
import { useValuationSettings } from './useValuationSettings';
import { useMonthlyReports } from './useCompanyData';
import { supabase } from '@/integrations/supabase/client';
import { calculateLTMMetrics, calculateMarketBasedValuation } from '@/lib/valuationCalculations';
import { toast } from 'sonner';

interface ValuationResult {
  success: boolean;
  valuation?: number;
  breakdown?: any;
  error?: string;
}

/**
 * Hook to calculate market-based valuations (admin-only)
 */
export function useValuationCalculator(companyId: string | undefined) {
  const { isAdmin } = useRole();
  const { data: settings } = useValuationSettings(companyId);
  const { data: monthlyReports } = useMonthlyReports(companyId);

  const canCalculate = !!(
    isAdmin &&
    settings?.revenue_multiple &&
    settings?.ebitda_multiple &&
    monthlyReports &&
    monthlyReports.length > 0
  );

  const calculateValuation = useCallback(async (): Promise<ValuationResult> => {
    if (!isAdmin) {
      return { success: false, error: 'Unauthorized - Admin only' };
    }

    if (!settings || !monthlyReports || !companyId) {
      return { success: false, error: 'Missing required data' };
    }

    try {
      // 1. Calculate LTM metrics
      const ltmMetrics = calculateLTMMetrics(monthlyReports);

      if (ltmMetrics.monthsUsed === 0) {
        toast.error('Ingen finansiel data tilgængelig for beregning');
        return { success: false, error: 'No financial data available' };
      }

      // 2. Calculate market-based valuation
      const breakdown = calculateMarketBasedValuation({
        ltmRevenue: ltmMetrics.ltmRevenue,
        ltmEBITDA: ltmMetrics.ltmEBITDA,
        revenueMultiple: settings.revenue_multiple,
        ebitdaMultiple: settings.ebitda_multiple,
        revenueWeight: settings.valuation_weight_revenue_pct,
      });

      // 3. Insert into valuations table
      const sourceText = ltmMetrics.isAnnualized
        ? `Market-based (${ltmMetrics.monthsUsed}M annualized, ${settings.active_markets} markets)`
        : `Market-based (LTM, ${settings.active_markets} markets)`;

      const { error } = await supabase.from('valuations').insert({
        company_id: companyId,
        post_money_valuation_dkk: breakdown.totalValuation,
        as_of_date: new Date().toISOString().split('T')[0],
        source: sourceText,
      });

      if (error) {
        console.error('Error inserting valuation:', error);
        toast.error('Fejl ved gemning af valuation');
        throw error;
      }

      toast.success('Valuation beregnet og gemt!');
      return { success: true, valuation: breakdown.totalValuation, breakdown };
    } catch (error) {
      console.error('Error calculating valuation:', error);
      return { success: false, error: 'Calculation failed' };
    }
  }, [isAdmin, settings, monthlyReports, companyId]);

  return { canCalculate, calculateValuation };
}
