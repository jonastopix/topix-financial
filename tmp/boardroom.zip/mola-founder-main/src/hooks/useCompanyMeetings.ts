import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface Meeting {
  id: string;
  company_id: string;
  meeting_date: string;
  duration_minutes: number;
  meeting_type: string;
  participants: any[];
  title: string;
  notes?: string;
  action_items?: any[];
  created_by: string;
  created_at: string;
  updated_at: string;
  calendly_event_uuid?: string | null;
  calendly_reschedule_count?: number;
  ical_uid?: string | null;
  is_board_meeting?: boolean;
  agenda_items?: any[];
  decisions?: any[];
  minutes_document_id?: string | null;
  minutes_external_url?: string | null;
  signature_status?: string;
  signed_at?: string | null;
  signed_by?: string[] | null;
}

export interface CreateMeetingInput {
  company_id: string;
  meeting_date: string;
  duration_minutes: number;
  meeting_type: string;
  participants: Array<{ id: string; name: string }>;
  title: string;
  notes?: string;
  action_items?: Array<{ text: string; completed: boolean }>;
}

export function useCompanyMeetings(companyId?: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: meetings = [], isLoading } = useQuery({
    queryKey: ['company-meetings', companyId],
    queryFn: async () => {
      let query = supabase
        .from('company_meetings')
        .select('*')
        .order('meeting_date', { ascending: false });

      if (companyId) {
        query = query.eq('company_id', companyId);
      }

      const { data, error } = await query;
      if (error) throw error;
      
      // Parse JSONB fields from database
      return (data || []).map(meeting => ({
        ...meeting,
        participants: Array.isArray(meeting.participants) ? meeting.participants : [],
        action_items: Array.isArray(meeting.action_items) ? meeting.action_items : [],
        agenda_items: Array.isArray(meeting.agenda_items) ? meeting.agenda_items : [],
        decisions: Array.isArray(meeting.decisions) ? meeting.decisions : [],
        signed_by: Array.isArray(meeting.signed_by) ? meeting.signed_by : null,
      })) as Meeting[];
    },
    enabled: !!companyId,
  });

  const createMeeting = useMutation({
    mutationFn: async (input: CreateMeetingInput) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('company_meetings')
        .insert({
          ...input,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;

      // Log activity
      await supabase.from('company_activity_log').insert({
        company_id: input.company_id,
        user_id: user.id,
        activity_type: 'meeting_logged',
        description: `Registrerede møde: ${input.title} (${input.duration_minutes} min)`,
        metadata: {
          meeting_id: data.id,
          meeting_type: input.meeting_type,
          duration_minutes: input.duration_minutes,
        },
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-meetings'] });
      queryClient.invalidateQueries({ queryKey: ['company-activity-log'] });
      toast({
        title: 'Møde registreret',
        description: 'Mødet er blevet gemt.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Fejl',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const updateMeeting = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Meeting> & { id: string }) => {
      const { data, error } = await supabase
        .from('company_meetings')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-meetings'] });
      toast({
        title: 'Møde opdateret',
        description: 'Ændringerne er blevet gemt.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Fejl',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteMeeting = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('company_meetings')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-meetings'] });
      toast({
        title: 'Møde slettet',
        description: 'Mødet er blevet fjernet.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Fejl',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Calculate statistics
  const stats = {
    totalMeetings: meetings.length,
    totalMinutes: meetings.reduce((sum, m) => sum + Number(m.duration_minutes), 0),
    averageDuration: meetings.length > 0
      ? meetings.reduce((sum, m) => sum + Number(m.duration_minutes), 0) / meetings.length
      : 0,
    meetingsByType: meetings.reduce((acc, m) => {
      acc[m.meeting_type] = (acc[m.meeting_type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>),
  };

  return {
    meetings,
    isLoading,
    createMeeting,
    updateMeeting,
    deleteMeeting,
    stats,
  };
}
