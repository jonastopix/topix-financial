import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Database } from "@/integrations/supabase/types";

type IncomeEntry = Database["public"]["Tables"]["income_entries"]["Row"];
type IncomeEntryInsert = Database["public"]["Tables"]["income_entries"]["Insert"];

export function useIncomeEntries() {
  const queryClient = useQueryClient();

  const { data: incomeEntries, isLoading } = useQuery({
    queryKey: ["income-entries"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("income_entries")
        .select("*")
        .order("income_date", { ascending: false });

      if (error) throw error;
      return data as IncomeEntry[];
    },
  });

  const createIncomeEntry = useMutation({
    mutationFn: async (entryData: Omit<IncomeEntryInsert, "created_by">) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Bruger ikke autentificeret");

      const { data, error } = await supabase
        .from("income_entries")
        .insert([{ ...entryData, created_by: user.id }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["income-entries"] });
      toast.success("Faktura oprettet");
    },
    onError: (error: Error) => {
      toast.error("Fejl ved oprettelse af faktura: " + error.message);
    },
  });

  const updateIncomeEntry = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<IncomeEntry> & { id: string }) => {
      const { data, error } = await supabase
        .from("income_entries")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["income-entries"] });
      toast.success("Faktura opdateret");
    },
    onError: (error: Error) => {
      toast.error("Fejl ved opdatering af faktura: " + error.message);
    },
  });

  const deleteIncomeEntry = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("income_entries").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["income-entries"] });
      toast.success("Faktura slettet");
    },
    onError: (error: Error) => {
      toast.error("Fejl ved sletning af faktura: " + error.message);
    },
  });

  return {
    incomeEntries,
    isLoading,
    createIncomeEntry: createIncomeEntry.mutate,
    updateIncomeEntry: updateIncomeEntry.mutate,
    deleteIncomeEntry: deleteIncomeEntry.mutate,
  };
}

export type { IncomeEntry, IncomeEntryInsert };
