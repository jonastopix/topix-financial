import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface DirectoryFilters {
  search?: string;
  industry?: string;
  skills?: string[];
  sortBy?: 'name' | 'recent';
}

export const useFoundersDirectory = (filters: DirectoryFilters = {}) => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['founders-directory', filters],
    queryFn: async () => {
      let query = supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          title,
          bio,
          skills,
          linkedin_url,
          avatar_url,
          is_active,
          created_at,
          company_id,
          can_help_with,
          company:companies!profiles_company_id_fkey(
            id,
            name,
            logo_url,
            industry,
            description,
            business_model,
            target_market
          )
        `)
        .eq('is_active', true)
        .not('full_name', 'is', null)
        .neq('id', user?.id || ''); // Exclude current user

      // Apply industry filter
      if (filters.industry && filters.industry !== 'all') {
        query = query.eq('company.industry', filters.industry);
      }

      // Apply skills filter
      if (filters.skills && filters.skills.length > 0) {
        query = query.overlaps('skills', filters.skills);
      }

      // Apply search filter - also search in can_help_with
      if (filters.search) {
        query = query.or(
          `full_name.ilike.%${filters.search}%,` +
          `title.ilike.%${filters.search}%,` +
          `can_help_with.ilike.%${filters.search}%,` +
          `company.name.ilike.%${filters.search}%`
        );
      }

      // Apply sorting
      if (filters.sortBy === 'recent') {
        query = query.order('created_at', { ascending: false });
      } else {
        query = query.order('full_name', { ascending: true });
      }

      const { data, error } = await query;

      if (error) throw error;

      // Fetch badges separately for each founder's company
      if (data && data.length > 0) {
        const dataWithBadges = await Promise.all(
          data.map(async (founder) => {
            if (founder.company_id) {
              const { data: badges } = await supabase
                .from('badges')
                .select('code, label')
                .eq('company_id', founder.company_id)
                .order('earned_at', { ascending: false })
                .limit(3);
              
              return {
                ...founder,
                badges: badges || [],
              };
            }
            return {
              ...founder,
              badges: [],
            };
          })
        );
        return dataWithBadges;
      }

      return data;
    },
    enabled: !!user,
  });
};
