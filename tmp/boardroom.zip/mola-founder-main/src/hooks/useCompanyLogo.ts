import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const MAX_LOGO_SIZE = 200; // Max width/height in pixels

export function useCompanyLogo() {
  const [isUploading, setIsUploading] = useState(false);

  const resizeImage = (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      img.onload = () => {
        let width = img.width;
        let height = img.height;

        // Calculate new dimensions while maintaining aspect ratio
        if (width > height) {
          if (width > MAX_LOGO_SIZE) {
            height = Math.round((height * MAX_LOGO_SIZE) / width);
            width = MAX_LOGO_SIZE;
          }
        } else {
          if (height > MAX_LOGO_SIZE) {
            width = Math.round((width * MAX_LOGO_SIZE) / height);
            height = MAX_LOGO_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;

        // Draw image with white background for transparent PNGs
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Failed to create blob'));
            }
          },
          'image/jpeg',
          0.9
        );
      };

      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = URL.createObjectURL(file);
    });
  };

  const uploadLogo = async (file: File, companyId: string): Promise<string | null> => {
    try {
      setIsUploading(true);

      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error('Filen skal være et billede');
        return null;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Billedet er for stort. Maks 5MB.');
        return null;
      }

      // Resize image
      const resizedBlob = await resizeImage(file);

      // Generate unique file name
      const fileExt = 'jpg';
      const fileName = `${companyId}-${Date.now()}.${fileExt}`;
      const filePath = `${companyId}/${fileName}`;

      // Delete old logo if exists
      const { data: existingFiles } = await supabase.storage
        .from('company-logos')
        .list(companyId);

      if (existingFiles && existingFiles.length > 0) {
        const filesToDelete = existingFiles.map((file) => `${companyId}/${file.name}`);
        await supabase.storage.from('company-logos').remove(filesToDelete);
      }

      // Upload new logo
      const { error: uploadError } = await supabase.storage
        .from('company-logos')
        .upload(filePath, resizedBlob, {
          contentType: 'image/jpeg',
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('company-logos')
        .getPublicUrl(filePath);

      toast.success('Logo uploadet');
      return publicUrl;
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast.error('Kunne ikke uploade logo');
      return null;
    } finally {
      setIsUploading(false);
    }
  };

  const deleteLogo = async (companyId: string): Promise<boolean> => {
    try {
      const { data: files } = await supabase.storage
        .from('company-logos')
        .list(companyId);

      if (files && files.length > 0) {
        const filesToDelete = files.map((file) => `${companyId}/${file.name}`);
        await supabase.storage.from('company-logos').remove(filesToDelete);
      }

      return true;
    } catch (error) {
      console.error('Error deleting logo:', error);
      return false;
    }
  };

  return {
    uploadLogo,
    deleteLogo,
    isUploading,
  };
}
