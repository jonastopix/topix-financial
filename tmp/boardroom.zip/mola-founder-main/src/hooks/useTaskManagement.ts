import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useCallback, useEffect } from 'react';

// Helper function to show Monday sync feedback
const showMondaySyncFeedback = (success: boolean, message?: string) => {
  toast({
    title: success ? '✓ Monday synkroniseret' : '⚠ Monday sync fejlet',
    description: success 
      ? 'Opgaven er synkroniseret til Monday.com' 
      : message || 'Kunne ikke synkronisere til Monday.com',
    variant: success ? 'default' : 'destructive',
    className: success 
      ? 'border-green-500 bg-green-50 dark:bg-green-950 [&>div]:text-green-600 dark:[&>div]:text-green-400' 
      : undefined,
    duration: success ? 2000 : 4000,
  });
};

// Helper function to trigger Monday sync with feedback
const triggerMondaySync = async (taskId: string, userId: string): Promise<boolean> => {
  try {
    const { data, error } = await supabase.functions.invoke('monday-user-sync', {
      body: { taskId, userId },
    });
    
    if (error) {
      console.error('[Monday Sync] Error:', error);
      showMondaySyncFeedback(false, error.message);
      return false;
    }
    
    // Check if sync was skipped (no Monday config, or sync not needed)
    if (data?.skipped) {
      console.log('[Monday Sync] Skipped:', data.reason);
      return true; // Don't show error for skipped syncs
    }
    
    if (data?.success) {
      console.log('[Monday Sync] Success:', data);
      showMondaySyncFeedback(true);
      return true;
    }
    
    // If data exists but success is false
    if (data && !data.success) {
      console.warn('[Monday Sync] Failed:', data);
      showMondaySyncFeedback(false, data.error || 'Ukendt fejl');
      return false;
    }
    
    return true;
  } catch (err) {
    console.error('[Monday Sync] Exception:', err);
    showMondaySyncFeedback(false, err instanceof Error ? err.message : 'Netværksfejl');
    return false;
  }
};

export interface Task {
  id: string;
  title: string;
  description?: string;
  status: 'todo' | 'in_progress' | 'done' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  due_date?: string;
  assigned_to?: string;
  created_by: string;
  company_id?: string;
  completed_at?: string;
  created_at: string;
  updated_at: string;
  // Privacy
  is_private: boolean;
  // Recurring task fields
  is_recurring?: boolean;
  recurrence_pattern?: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
  recurrence_interval?: number;
  recurrence_end_date?: string;
  recurrence_count?: number;
  parent_task_id?: string;
  next_occurrence_date?: string;
  recurrence_day_of_week?: number;
  recurrence_day_of_month?: number;
  assigned_profile?: {
    full_name?: string;
    company_name?: string;
  };
  created_profile?: {
    full_name?: string;
  };
  company?: {
    name: string;
  };
  parent_task?: {
    title: string;
  };
  child_tasks?: Array<{
    id: string;
    title: string;
    status: string;
    completed_at: string;
    due_date: string;
  }>;
}

export interface CreateTaskInput {
  title: string;
  description?: string;
  status?: 'todo' | 'in_progress' | 'done' | 'cancelled';
  priority?: 'low' | 'medium' | 'high' | 'urgent';
  due_date?: string;
  assigned_to?: string;
  company_id?: string;
  // Privacy - default true (private)
  is_private?: boolean;
  // Recurring task fields
  is_recurring?: boolean;
  recurrence_pattern?: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom';
  recurrence_interval?: number;
  recurrence_end_date?: string;
  recurrence_count?: number;
  recurrence_day_of_week?: number;
  recurrence_day_of_month?: number;
  next_occurrence_date?: string;
}

export const useTaskManagement = () => {
  const queryClient = useQueryClient();

  // Real-time subscription for cross-device sync
  useEffect(() => {
    const channel = supabase
      .channel('tasks-realtime')
      .on(
        'postgres_changes',
        {
          event: '*', // INSERT, UPDATE, DELETE
          schema: 'public',
          table: 'tasks',
        },
        (payload) => {
          console.log('[Tasks Realtime] Change detected:', payload.eventType);
          // Invalidate queries to refetch latest data
          queryClient.invalidateQueries({ queryKey: ['tasks'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient]);

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['tasks'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('tasks')
        .select(`
          *,
          assigned_profile:assigned_to(full_name, company_name),
          created_profile:created_by(full_name),
          company:company_id(name),
          parent_task:parent_task_id(title),
          child_tasks:tasks!parent_task_id(id, title, status, completed_at, due_date)
        `)
        .order('due_date', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as unknown as Task[];
    },
  });

  const createTask = useMutation({
    mutationFn: async (input: CreateTaskInput) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('tasks')
        .insert({
          ...input,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      
      // Trigger Monday sync with visual feedback
      const syncUserId = data.assigned_to || data.created_by;
      if (syncUserId) {
        // Fire async - don't block the UI
        triggerMondaySync(data.id, syncUserId);
      }
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      toast({
        title: 'Opgave oprettet',
        description: 'Din opgave er blevet oprettet.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke oprette opgave: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  const updateTask = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<Task> & { id: string }) => {
      const updateData: any = { ...updates };
      if (updates.status === 'done' && !updates.completed_at) {
        updateData.completed_at = new Date().toISOString();
      }
      if (updates.status !== 'done' && updateData.completed_at !== undefined) {
        updateData.completed_at = null;
      }

      const { data, error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      
      // Trigger Monday sync with visual feedback
      const syncUserId = data.assigned_to || data.created_by;
      if (syncUserId) {
        // Fire async - don't block the UI
        triggerMondaySync(data.id, syncUserId);
      }
      
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      toast({
        title: 'Opgave opdateret',
        description: 'Dine ændringer er gemt.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke opdatere opgave: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  const deleteTask = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      toast({
        title: 'Opgave slettet',
        description: 'Opgaven er blevet slettet.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke slette opgave: ' + error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    tasks,
    isLoading,
    createTask,
    updateTask,
    deleteTask,
  };
};
