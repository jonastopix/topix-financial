import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface User {
  id: string;
  email: string;
  full_name: string;
  company_name: string;
  company_id: string | null;
  fund_id: string | null;
  roles: string[];
  is_active: boolean;
  last_sign_in_at: string | null;
  created_at: string;
}

interface FetchUsersParams {
  search?: string;
  role?: string;
  status?: string;
  page?: number;
  limit?: number;
}

export function useUserManagement(params: FetchUsersParams = {}) {
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ['users', params],
    queryFn: async () => {
      const queryParams = new URLSearchParams();
      if (params.search) queryParams.append('search', params.search);
      if (params.role) queryParams.append('role', params.role);
      if (params.status) queryParams.append('status', params.status);
      if (params.page) queryParams.append('page', params.page.toString());
      if (params.limit) queryParams.append('limit', params.limit.toString());

      const { data, error } = await supabase.functions.invoke('get-users-list', {
        body: queryParams.toString(),
      });

      if (error) throw error;
      return data as { users: User[]; total: number; page: number; limit: number };
    },
  });

  const addRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const { data, error } = await supabase.functions.invoke('manage-user-roles', {
        body: { action: 'add_role', userId, role },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('Rolle tilføjet');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved tilføjelse af rolle: ' + error.message);
    },
  });

  const removeRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      const { data, error } = await supabase.functions.invoke('manage-user-roles', {
        body: { action: 'remove_role', userId, role },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success('Rolle fjernet');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved fjernelse af rolle: ' + error.message);
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ userId, action }: { userId: string; action: 'activate' | 'deactivate' }) => {
      const { data, error } = await supabase.functions.invoke('manage-user-status', {
        body: { action, userId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      toast.success(variables.action === 'activate' ? 'Bruger aktiveret' : 'Bruger deaktiveret');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved opdatering af status: ' + error.message);
    },
  });

  return {
    users: data?.users || [],
    total: data?.total || 0,
    isLoading,
    error,
    addRole: addRoleMutation.mutate,
    removeRole: removeRoleMutation.mutate,
    updateStatus: updateStatusMutation.mutate,
  };
}
