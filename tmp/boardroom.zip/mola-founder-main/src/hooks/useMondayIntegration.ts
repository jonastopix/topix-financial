import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface MondayBoard {
  id: string;
  name: string;
  columns?: MondayColumn[];
  groups?: MondayGroup[];
}

interface MondayColumn {
  id: string;
  title: string;
  type: string;
}

interface MondayGroup {
  id: string;
  title: string;
}

interface MondayConfig {
  id: string;
  user_id: string;
  board_id: string | null;
  board_name: string | null;
  status_column_id: string | null;
  priority_column_id: string | null;
  date_column_id: string | null;
  group_id: string | null;
  company_column_id: string | null;
  link_column_id: string | null;
  assignee_column_id: string | null;
  monday_user_id: string | null;
  monday_user_name: string | null;
  webhook_id: string | null;
  is_active: boolean;
  last_sync_at: string | null;
  created_at: string;
  updated_at: string;
}

interface ColumnMapping {
  status_column_id?: string | null;
  date_column_id?: string | null;
  company_column_id?: string | null;
  link_column_id?: string | null;
  assignee_column_id?: string | null;
}

export const useMondayIntegration = () => {
  const queryClient = useQueryClient();

  const { data: config, isLoading: isLoadingConfig } = useQuery({
    queryKey: ['monday-config'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('monday_user_config')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;
      return data as MondayConfig | null;
    },
  });

  const validateAndFetchBoards = useMutation({
    mutationFn: async (apiToken: string) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'validate_and_fetch_boards', apiToken },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data.boards as MondayBoard[];
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: 'Forbindelse oprettet',
        description: 'Din Monday.com API token er gyldig.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke validere API token',
        variant: 'destructive',
      });
    },
  });

  const selectBoard = useMutation({
    mutationFn: async (boardId: string) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'select_board', boardId },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data.board as MondayBoard;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: 'Board valgt',
        description: 'Vælg nu kolonne-mapping for at aktivere synkronisering.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke vælge board',
        variant: 'destructive',
      });
    },
  });

  const fetchColumns = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'fetch_columns' },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data.columns as MondayColumn[];
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke hente kolonner',
        variant: 'destructive',
      });
    },
  });

  const fetchBoardsWithSavedToken = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'fetch_boards_with_saved_token' },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.needsReauth) throw new Error('TOKEN_EXPIRED');
      if (response.data.error) throw new Error(response.data.error);

      return response.data.boards as MondayBoard[];
    },
  });

  const saveColumnMapping = useMutation({
    mutationFn: async (columnMapping: ColumnMapping) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'save_column_mapping', columnMapping },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: 'Kolonne-mapping gemt',
        description: 'Monday.com synkronisering er nu aktiv.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke gemme kolonne-mapping',
        variant: 'destructive',
      });
    },
  });

  const toggleSync = useMutation({
    mutationFn: async (activate: boolean) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: activate ? 'activate' : 'deactivate' },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data;
    },
    onSuccess: (_, activate) => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: activate ? 'Sync aktiveret' : 'Sync deaktiveret',
        description: activate 
          ? 'Dine opgaver synkroniseres nu med Monday.com.'
          : 'Monday.com synkronisering er sat på pause.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke ændre sync status',
        variant: 'destructive',
      });
    },
  });

  const disconnect = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'disconnect' },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: 'Forbindelse fjernet',
        description: 'Din Monday.com integration er afbrudt.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke fjerne forbindelse',
        variant: 'destructive',
      });
    },
  });

  const recreateWebhook = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Ikke logget ind');

      const response = await supabase.functions.invoke('monday-connect', {
        body: { action: 'recreate_webhook' },
      });

      if (response.error) throw new Error(response.error.message);
      if (response.data.error) throw new Error(response.data.error);

      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['monday-config'] });
      toast({
        title: 'Webhook oprettet',
        description: `${data.webhookCount} webhooks oprettet - synkronisering fra Monday.com er nu aktiv.`,
      });
    },
    onError: (error) => {
      toast({
        title: 'Fejl',
        description: error.message || 'Kunne ikke oprette webhook',
        variant: 'destructive',
      });
    },
  });

  const syncTask = async (taskId: string, userId: string, action?: 'delete') => {
    try {
      const response = await supabase.functions.invoke('monday-user-sync', {
        body: { taskId, userId, action },
      });

      if (response.error) {
        console.error('Sync error:', response.error);
      }

      return response.data;
    } catch (error) {
      console.error('Failed to sync task to Monday:', error);
    }
  };

  return {
    config,
    isLoadingConfig,
    isConnected: !!config?.board_id,
    isActive: config?.is_active ?? false,
    hasWebhook: !!config?.webhook_id,
    validateAndFetchBoards,
    selectBoard,
    fetchColumns,
    fetchBoardsWithSavedToken,
    saveColumnMapping,
    toggleSync,
    disconnect,
    recreateWebhook,
    syncTask,
  };
};
