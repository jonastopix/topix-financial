import { useMemo } from 'react';
import { useTaskManagement } from './useTaskManagement';
import { startOfDay, startOfWeek, subDays, isAfter, isSameDay } from 'date-fns';

export type ProductivityLevel = 'cold' | 'warming' | 'hot' | 'fire' | 'legendary';

export interface ProductivityStats {
  completedToday: number;
  completedThisWeek: number;
  averagePerDay: number;
  currentStreak: number;
  isAboveAverage: boolean;
  productivityLevel: ProductivityLevel;
  percentageVsAverage: number;
  dailyGoal: number;
}

export const useTaskProductivity = () => {
  const { tasks, isLoading } = useTaskManagement();

  const stats = useMemo<ProductivityStats>(() => {
    if (!tasks || tasks.length === 0) {
      return {
        completedToday: 0,
        completedThisWeek: 0,
        averagePerDay: 0,
        currentStreak: 0,
        isAboveAverage: false,
        productivityLevel: 'cold',
        percentageVsAverage: 0,
        dailyGoal: 3,
      };
    }

    const now = new Date();
    const todayStart = startOfDay(now);
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const thirtyDaysAgo = subDays(now, 30);

    // Get completed tasks
    const completedTasks = tasks.filter(t => t.status === 'done' && t.completed_at);

    // Completed today
    const completedToday = completedTasks.filter(t => 
      isAfter(new Date(t.completed_at!), todayStart)
    ).length;

    // Completed this week
    const completedThisWeek = completedTasks.filter(t => 
      isAfter(new Date(t.completed_at!), weekStart)
    ).length;

    // Average per day (last 30 days)
    const last30DaysTasks = completedTasks.filter(t => 
      isAfter(new Date(t.completed_at!), thirtyDaysAgo)
    ).length;
    const averagePerDay = Math.round((last30DaysTasks / 30) * 10) / 10;

    // Calculate streak
    let currentStreak = 0;
    let checkDate = todayStart;
    
    // Check if today has any completions, if not start from yesterday
    const hasCompletedToday = completedToday > 0;
    if (!hasCompletedToday) {
      checkDate = subDays(checkDate, 1);
    }

    // Count consecutive days with at least 1 completion
    for (let i = 0; i < 365; i++) {
      const dayStart = startOfDay(subDays(todayStart, hasCompletedToday ? i : i + 1));
      const hasCompletion = completedTasks.some(t => 
        isSameDay(new Date(t.completed_at!), dayStart)
      );
      
      if (hasCompletion) {
        currentStreak++;
      } else {
        break;
      }
    }

    // Productivity level based on today's completions
    let productivityLevel: ProductivityLevel = 'cold';
    if (completedToday >= 7) productivityLevel = 'legendary';
    else if (completedToday >= 5) productivityLevel = 'fire';
    else if (completedToday >= 3) productivityLevel = 'hot';
    else if (completedToday >= 1) productivityLevel = 'warming';

    // Percentage vs average
    const percentageVsAverage = averagePerDay > 0 
      ? Math.round(((completedToday - averagePerDay) / averagePerDay) * 100)
      : completedToday > 0 ? 100 : 0;

    return {
      completedToday,
      completedThisWeek,
      averagePerDay,
      currentStreak,
      isAboveAverage: completedToday > averagePerDay,
      productivityLevel,
      percentageVsAverage,
      dailyGoal: 3,
    };
  }, [tasks]);

  return { stats, isLoading };
};
