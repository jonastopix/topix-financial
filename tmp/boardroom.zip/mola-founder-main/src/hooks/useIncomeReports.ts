import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface MonthlyData {
  month: string;
  faktura: number;
  løn: number;
  anden: number;
}

interface QuarterlyData {
  quarter: string;
  total: number;
}

interface YearlyData {
  year: number;
  total: number;
}

export function useIncomeReports(year: number) {
  const { data: monthlyData = [], isLoading: isMonthlyLoading } = useQuery({
    queryKey: ["income-monthly", year],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("income_entries")
        .select("*")
        .gte("income_date", `${year}-01-01`)
        .lte("income_date", `${year}-12-31`);

      if (error) throw error;

      const months = [
        "Jan", "Feb", "Mar", "Apr", "Maj", "Jun",
        "Jul", "Aug", "Sep", "Okt", "Nov", "Dec"
      ];

      const monthlyTotals: MonthlyData[] = months.map((month, idx) => ({
        month,
        faktura: 0,
        løn: 0,
        anden: 0,
      }));

      data?.forEach((entry) => {
        const entryDate = new Date(entry.income_date);
        const monthIdx = entryDate.getMonth();
        const type = entry.income_type as "faktura" | "løn" | "anden";
        monthlyTotals[monthIdx][type] += entry.amount_dkk;
      });

      return monthlyTotals;
    },
  });

  const { data: quarterlyData = [], isLoading: isQuarterlyLoading } = useQuery({
    queryKey: ["income-quarterly", year],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("income_entries")
        .select("*")
        .gte("income_date", `${year}-01-01`)
        .lte("income_date", `${year}-12-31`);

      if (error) throw error;

      const quarters: QuarterlyData[] = [
        { quarter: "Q1", total: 0 },
        { quarter: "Q2", total: 0 },
        { quarter: "Q3", total: 0 },
        { quarter: "Q4", total: 0 },
      ];

      data?.forEach((entry) => {
        const entryDate = new Date(entry.income_date);
        const month = entryDate.getMonth();
        const quarterIdx = Math.floor(month / 3);
        quarters[quarterIdx].total += entry.amount_dkk;
      });

      return quarters;
    },
  });

  const { data: yearlyData = [], isLoading: isYearlyLoading } = useQuery({
    queryKey: ["income-yearly"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("income_entries")
        .select("income_date, amount_dkk");

      if (error) throw error;

      const yearlyTotals = new Map<number, number>();

      data?.forEach((entry) => {
        const entryYear = new Date(entry.income_date).getFullYear();
        const current = yearlyTotals.get(entryYear) || 0;
        yearlyTotals.set(entryYear, current + entry.amount_dkk);
      });

      const result: YearlyData[] = Array.from(yearlyTotals.entries())
        .map(([year, total]) => ({ year, total }))
        .sort((a, b) => a.year - b.year);

      return result;
    },
  });

  return {
    monthlyData,
    quarterlyData,
    yearlyData,
    isLoading: isMonthlyLoading || isQuarterlyLoading || isYearlyLoading,
  };
}
