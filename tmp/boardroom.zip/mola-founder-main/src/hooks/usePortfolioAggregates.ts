import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface PortfolioAggregates {
  avgMarketingPct: number | null;
  avgEbitdaMargin: number | null;
  profitableCompanies: number;
  totalActiveCompanies: number;
  portfolioTrend: 'up' | 'down' | 'neutral';
}

export function usePortfolioAggregates() {
  return useQuery({
    queryKey: ['portfolio-aggregates'],
    queryFn: async (): Promise<PortfolioAggregates> => {
      const currentYear = new Date().getFullYear();
      
      // Get all active companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id')
        .eq('is_active', true)
        .eq('status', 'active');

      if (companiesError) throw companiesError;
      
      const totalActiveCompanies = companies?.length || 0;
      
      if (totalActiveCompanies === 0) {
        return {
          avgMarketingPct: null,
          avgEbitdaMargin: null,
          profitableCompanies: 0,
          totalActiveCompanies: 0,
          portfolioTrend: 'neutral',
        };
      }

      // Get latest reports for all companies
      const { data: reports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('company_id, revenue_dkk, ebitda_dkk, marketing_cost_dkk, period_year, period_month')
        .eq('period_year', currentYear)
        .order('period_month', { ascending: false });

      if (reportsError) throw reportsError;

      // Calculate aggregates
      let totalMarketingPct = 0;
      let totalEbitdaMargin = 0;
      let companiesWithMarketingData = 0;
      let companiesWithEbitdaData = 0;
      let profitableCompanies = 0;

      const latestReportsByCompany = new Map<string, any>();
      
      reports?.forEach(report => {
        if (!latestReportsByCompany.has(report.company_id)) {
          latestReportsByCompany.set(report.company_id, report);
        }
      });

      latestReportsByCompany.forEach(report => {
        if (report.revenue_dkk && report.marketing_cost_dkk) {
          const marketingPct = (report.marketing_cost_dkk / report.revenue_dkk) * 100;
          totalMarketingPct += marketingPct;
          companiesWithMarketingData++;
        }

        if (report.revenue_dkk && report.ebitda_dkk !== null) {
          const ebitdaMargin = (report.ebitda_dkk / report.revenue_dkk) * 100;
          totalEbitdaMargin += ebitdaMargin;
          companiesWithEbitdaData++;
          
          if (report.ebitda_dkk > 0) {
            profitableCompanies++;
          }
        }
      });

      const avgMarketingPct = companiesWithMarketingData > 0 
        ? totalMarketingPct / companiesWithMarketingData 
        : null;
      
      const avgEbitdaMargin = companiesWithEbitdaData > 0 
        ? totalEbitdaMargin / companiesWithEbitdaData 
        : null;

      // Determine portfolio trend (comparing current month avg EBITDA to previous month)
      let portfolioTrend: 'up' | 'down' | 'neutral' = 'neutral';
      
      if (avgEbitdaMargin !== null) {
        const currentMonth = new Date().getMonth() + 1;
        const prevMonth = currentMonth === 1 ? 12 : currentMonth - 1;
        const prevYear = currentMonth === 1 ? currentYear - 1 : currentYear;

        const { data: prevReports } = await supabase
          .from('monthly_reports')
          .select('revenue_dkk, ebitda_dkk')
          .eq('period_year', prevYear)
          .eq('period_month', prevMonth);

        if (prevReports && prevReports.length > 0) {
          let prevTotalMargin = 0;
          let prevCount = 0;
          
          prevReports.forEach(r => {
            if (r.revenue_dkk && r.ebitda_dkk !== null) {
              prevTotalMargin += (r.ebitda_dkk / r.revenue_dkk) * 100;
              prevCount++;
            }
          });

          if (prevCount > 0) {
            const prevAvgMargin = prevTotalMargin / prevCount;
            if (avgEbitdaMargin > prevAvgMargin + 1) portfolioTrend = 'up';
            else if (avgEbitdaMargin < prevAvgMargin - 1) portfolioTrend = 'down';
          }
        }
      }

      return {
        avgMarketingPct,
        avgEbitdaMargin,
        profitableCompanies,
        totalActiveCompanies,
        portfolioTrend,
      };
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });
}
