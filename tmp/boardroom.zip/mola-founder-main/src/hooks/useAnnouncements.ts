import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';

export interface Announcement {
  id: string;
  type: 'manual' | 'auto';
  priority: 'success' | 'warning' | 'error' | 'info';
  message: string;
  link_url?: string;
  company_id?: string;
  metadata?: any;
}

export const useAnnouncements = () => {
  const { isAdmin, selectedCompanyId } = useRole();

  return useQuery({
    queryKey: ['announcements', selectedCompanyId],
    queryFn: async () => {
      if (!isAdmin) return [];

      // Fetch manual announcements from database
      const { data: manualAnnouncements, error } = await supabase
        .from('announcements')
        .select('*')
        .eq('is_active', true)
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .order('priority', { ascending: false });

      if (error) throw error;

      // Generate auto announcements based on company data
      const autoAnnouncements: Announcement[] = [];

      // 1. Check for missing monthly reports (last month)
      const lastMonth = new Date();
      lastMonth.setMonth(lastMonth.getMonth() - 1);
      const lastMonthYear = lastMonth.getFullYear();
      const lastMonthMonth = lastMonth.getMonth() + 1;

      const { data: companies } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true)
        .eq('status', 'active');

      if (companies) {
        const { data: reports } = await supabase
          .from('monthly_reports')
          .select('company_id')
          .eq('period_year', lastMonthYear)
          .eq('period_month', lastMonthMonth);

        const companiesWithReports = new Set(reports?.map(r => r.company_id) || []);
        const companiesMissingReports = companies.filter(c => !companiesWithReports.has(c.id));

        if (companiesMissingReports.length > 0) {
          const companyIds = companiesMissingReports.map(c => c.id).join(',');
          autoAnnouncements.push({
            id: 'missing-reports',
            type: 'auto',
            priority: 'warning',
            message: `⚠️ ${companiesMissingReports.length} selskab${companiesMissingReports.length > 1 ? 'er' : ''} mangler monthly report for ${lastMonth.toLocaleDateString('da-DK', { month: 'long' })}`,
            link_url: `/portfolio/companies?missingReports=${companyIds}`,
          });
        }
      }

      // 2. Check for recent dividends this month
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);

      const { data: dividends } = await supabase
        .from('dividends')
        .select('amount_dkk')
        .gte('paid_date', startOfMonth.toISOString());

      if (dividends && dividends.length > 0) {
        const totalDividends = dividends.reduce((sum, d) => sum + Number(d.amount_dkk), 0);
        if (totalDividends > 0) {
          autoAnnouncements.push({
            id: 'recent-dividends',
            type: 'auto',
            priority: 'success',
            message: `💰 ${totalDividends.toLocaleString('da-DK')} DKK i dividende modtaget denne måned`,
            link_url: '/returns',
          });
        }
      }

      // 3. Check for recent badges (last 7 days)
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const { data: recentBadges } = await supabase
        .from('badges')
        .select('label, companies(name)')
        .gte('earned_at', sevenDaysAgo.toISOString().split('T')[0])
        .limit(1)
        .single();

      if (recentBadges && recentBadges.companies) {
        autoAnnouncements.push({
          id: 'recent-badge',
          type: 'auto',
          priority: 'success',
          message: `🎉 ${(recentBadges.companies as any).name} har optjent '${recentBadges.label}' badge!`,
          link_url: '/portfolio/companies',
        });
      }

      // Merge and prioritize (error > warning > success > info)
      const allAnnouncements = [...(manualAnnouncements || []), ...autoAnnouncements];
      
      const priorityOrder = { error: 0, warning: 1, success: 2, info: 3 };
      allAnnouncements.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);

      // Filter by selected company if applicable
      if (selectedCompanyId) {
        return allAnnouncements.filter(a => !a.company_id || a.company_id === selectedCompanyId);
      }

      return allAnnouncements.slice(0, 5); // Max 5 announcements
    },
    enabled: isAdmin,
    refetchInterval: 60000, // Refresh every minute
  });
};
