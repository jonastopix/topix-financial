import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { calculateYTDPerformance, calculateForecast, calculateFinancialAnalysis } from '@/lib/metricsCalculations';

export function usePortfolioFinancials(year: number) {
  return useQuery({
    queryKey: ['portfolio-financials', year],
    queryFn: async () => {
      // Fetch all active companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, invested_amount_dkk')
        .eq('is_active', true)
        .order('name');

      if (companiesError) throw companiesError;
      if (!companies || companies.length === 0) return null;

      // Fetch all monthly reports for these companies
      const { data: allReports, error: reportsError } = await supabase
        .from('monthly_reports')
        .select('*')
        .in('company_id', companies.map(c => c.id))
        .order('period_year', { ascending: false })
        .order('period_month', { ascending: false });

      if (reportsError) throw reportsError;

      // Calculate aggregated metrics
      const companiesWithData = companies.map(company => {
        const companyReports = allReports?.filter(r => r.company_id === company.id) || [];
        
        if (companyReports.length === 0) {
          return {
            company,
            ytdPerformance: null,
            forecast: null,
            financialAnalysis: null,
          };
        }

        const ytdPerformance = calculateYTDPerformance(companyReports, year);
        const forecast = calculateForecast(companyReports, year);
        const financialAnalysis = calculateFinancialAnalysis(
          companyReports,
          year,
          company.invested_amount_dkk ? Number(company.invested_amount_dkk) : undefined
        );

        return {
          company,
          ytdPerformance,
          forecast,
          financialAnalysis,
        };
      });

      // Calculate portfolio totals
      const portfolioYTD = companiesWithData.reduce((acc, c) => {
        if (!c.ytdPerformance) return acc;
        return {
          ytdRevenue: acc.ytdRevenue + c.ytdPerformance.ytdRevenue,
          ytdEBITDA: acc.ytdEBITDA + c.ytdPerformance.ytdEBITDA,
          ytdMarketingCost: acc.ytdMarketingCost + c.ytdPerformance.ytdMarketingCost,
          budgetYTDRevenue: acc.budgetYTDRevenue + c.ytdPerformance.budgetYTDRevenue,
          budgetYTDEBITDA: acc.budgetYTDEBITDA + c.ytdPerformance.budgetYTDEBITDA,
          reportedMonths: Math.max(acc.reportedMonths, c.ytdPerformance.reportedMonths),
        };
      }, {
        ytdRevenue: 0,
        ytdEBITDA: 0,
        ytdMarketingCost: 0,
        budgetYTDRevenue: 0,
        budgetYTDEBITDA: 0,
        reportedMonths: 0,
      });

      const revenueVsBudgetPct = portfolioYTD.budgetYTDRevenue > 0 
        ? ((portfolioYTD.ytdRevenue / portfolioYTD.budgetYTDRevenue - 1) * 100)
        : 0;
      
      const ebitdaVsBudgetPct = portfolioYTD.budgetYTDEBITDA > 0
        ? ((portfolioYTD.ytdEBITDA / portfolioYTD.budgetYTDEBITDA - 1) * 100)
        : 0;

      const ebitdaMarginYTD = portfolioYTD.ytdRevenue > 0 
        ? (portfolioYTD.ytdEBITDA / portfolioYTD.ytdRevenue) * 100 
        : 0;

      const marketingPctYTD = portfolioYTD.ytdRevenue > 0 
        ? (portfolioYTD.ytdMarketingCost / portfolioYTD.ytdRevenue) * 100 
        : 0;

      const revenueROI = portfolioYTD.ytdMarketingCost > 0 
        ? (portfolioYTD.ytdRevenue / portfolioYTD.ytdMarketingCost) * 100 
        : 0;

      const ebitdaROI = portfolioYTD.ytdMarketingCost > 0 
        ? (portfolioYTD.ytdEBITDA / portfolioYTD.ytdMarketingCost) * 100 
        : 0;

      const isOnTarget = portfolioYTD.ytdRevenue >= portfolioYTD.budgetYTDRevenue && 
                        portfolioYTD.ytdEBITDA >= portfolioYTD.budgetYTDEBITDA;

      // Calculate historical trend data (last 12 months aggregated)
      const monthlyTrend: Array<{
        period: string;
        period_year: number;
        period_month: number;
        revenue: number;
        ebitda: number;
        margin: number;
      }> = [];

      // Get unique months from all reports
      const uniqueMonths = new Map<string, { year: number; month: number }>();
      allReports?.forEach(report => {
        const key = `${report.period_year}-${report.period_month}`;
        if (!uniqueMonths.has(key)) {
          uniqueMonths.set(key, { year: report.period_year, month: report.period_month });
        }
      });

      // Sort months (newest first)
      const sortedMonths = Array.from(uniqueMonths.values()).sort((a, b) => {
        if (b.year !== a.year) return b.year - a.year;
        return b.month - a.month;
      });

      // Take last 12 months
      const last12Months = sortedMonths.slice(0, 12).reverse();

      // Aggregate data for each month
      last12Months.forEach(({ year: periodYear, month: periodMonth }) => {
        const monthReports = allReports?.filter(
          r => r.period_year === periodYear && r.period_month === periodMonth
        ) || [];

        const monthRevenue = monthReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
        const monthEBITDA = monthReports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
        const monthMargin = monthRevenue > 0 ? (monthEBITDA / monthRevenue) * 100 : 0;

        const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec'];
        const period = `${monthNames[periodMonth - 1]} ${periodYear}`;

        monthlyTrend.push({
          period,
          period_year: periodYear,
          period_month: periodMonth,
          revenue: monthRevenue,
          ebitda: monthEBITDA,
          margin: monthMargin,
        });
      });

      return {
        companies: companiesWithData,
        portfolioTotals: {
          ...portfolioYTD,
          revenueVsBudgetPct,
          ebitdaVsBudgetPct,
          ebitdaMarginYTD,
          marketingPctYTD,
          revenueROI,
          ebitdaROI,
          isOnTarget,
        },
        monthlyTrend,
      };
    },
  });
}
