import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DistanceResult {
  distance_km: number;
  duration_minutes: number;
}

interface CacheEntry {
  result: DistanceResult;
  timestamp: number;
}

// Cache duration: 7 days
const CACHE_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

function getCacheKey(from: string, to: string): string {
  return `distance_${from.toLowerCase().trim()}_${to.toLowerCase().trim()}`;
}

function getFromCache(from: string, to: string): DistanceResult | null {
  try {
    const key = getCacheKey(from, to);
    const cached = localStorage.getItem(key);
    if (!cached) return null;
    
    const entry: CacheEntry = JSON.parse(cached);
    if (Date.now() - entry.timestamp > CACHE_DURATION_MS) {
      localStorage.removeItem(key);
      return null;
    }
    
    return entry.result;
  } catch {
    return null;
  }
}

function setInCache(from: string, to: string, result: DistanceResult): void {
  try {
    const key = getCacheKey(from, to);
    const entry: CacheEntry = {
      result,
      timestamp: Date.now(),
    };
    localStorage.setItem(key, JSON.stringify(entry));
  } catch {
    // Ignore cache errors
  }
}

export function useDistanceCalculation() {
  const [isCalculating, setIsCalculating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<DistanceResult | null>(null);

  const calculateDistance = useCallback(async (
    fromAddress: string,
    toAddress: string
  ): Promise<DistanceResult | null> => {
    if (!fromAddress || !toAddress) {
      setError(null);
      setLastResult(null);
      return null;
    }

    // Check cache first
    const cached = getFromCache(fromAddress, toAddress);
    if (cached) {
      setLastResult(cached);
      setError(null);
      return cached;
    }

    setIsCalculating(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('calculate-distance', {
        body: { fromAddress, toAddress },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Kunne ikke beregne afstand');
      }

      if (data.error) {
        throw new Error(data.error);
      }

      const result: DistanceResult = {
        distance_km: data.distance_km,
        duration_minutes: data.duration_minutes,
      };

      // Cache the result
      setInCache(fromAddress, toAddress, result);
      setLastResult(result);
      
      return result;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Ukendt fejl';
      setError(message);
      setLastResult(null);
      return null;
    } finally {
      setIsCalculating(false);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    calculateDistance,
    isCalculating,
    error,
    lastResult,
    clearError,
  };
}
