import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export type DocumentType = 
  | 'shareholder_agreement'
  | 'articles_of_association' 
  | 'annual_report'
  | 'board_minutes'
  | 'investment_memo'
  | 'term_sheet'
  | 'valuation_report'
  | 'other';

export interface CompanyDocument {
  id: string;
  company_id: string;
  document_type: DocumentType;
  file_name: string;
  file_path: string;
  file_size: number;
  mime_type: string;
  notes?: string;
  version: number;
  is_latest: boolean;
  uploaded_by: string;
  uploaded_at: string;
  created_at: string;
}

export function useCompanyDocuments(companyId?: string, documentType?: DocumentType) {
  const queryClient = useQueryClient();

  const { data: documents, isLoading } = useQuery({
    queryKey: ['company-documents', companyId, documentType],
    queryFn: async () => {
      if (!companyId) return [];

      let query = supabase
        .from('company_documents')
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });

      if (documentType) {
        query = query.eq('document_type', documentType);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as CompanyDocument[];
    },
    enabled: !!companyId,
  });

  const uploadDocument = useMutation({
    mutationFn: async ({
      file,
      companyId,
      documentType,
      notes,
    }: {
      file: File;
      companyId: string;
      documentType: DocumentType;
      notes?: string;
    }) => {
      const fileExt = file.name.split('.').pop();
      const fileName = `${companyId}/${documentType}/${Date.now()}.${fileExt}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('company-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Create database record
      const { data, error: dbError } = await supabase
        .from('company_documents')
        .insert({
          company_id: companyId,
          document_type: documentType,
          file_name: file.name,
          file_path: fileName,
          file_size: file.size,
          mime_type: file.type,
          notes,
          uploaded_by: (await supabase.auth.getUser()).data.user?.id,
        })
        .select()
        .single();

      if (dbError) throw dbError;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-documents'] });
      toast.success('Dokument uploadet');
    },
    onError: (error: any) => {
      toast.error('Fejl ved upload: ' + error.message);
    },
  });

  const deleteDocument = useMutation({
    mutationFn: async (documentId: string) => {
      // Get document info first
      const { data: doc } = await supabase
        .from('company_documents')
        .select('file_path')
        .eq('id', documentId)
        .single();

      if (doc) {
        // Delete from storage
        await supabase.storage
          .from('company-documents')
          .remove([doc.file_path]);
      }

      // Delete from database
      const { error } = await supabase
        .from('company_documents')
        .delete()
        .eq('id', documentId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-documents'] });
      toast.success('Dokument slettet');
    },
    onError: (error: any) => {
      toast.error('Fejl ved sletning: ' + error.message);
    },
  });

  const downloadDocument = async (filePath: string, fileName: string) => {
    try {
      const { data, error } = await supabase.storage
        .from('company-documents')
        .download(filePath);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error: any) {
      toast.error('Fejl ved download: ' + error.message);
    }
  };

  return {
    documents,
    isLoading,
    uploadDocument,
    deleteDocument,
    downloadDocument,
  };
}
