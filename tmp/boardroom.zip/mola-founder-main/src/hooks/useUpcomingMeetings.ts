import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { startOfToday, addDays, format } from 'date-fns';

export interface UpcomingMeeting {
  id: string;
  title: string;
  meeting_date: string;
  duration_minutes: number;
  meeting_type: string;
  company_id: string;
  company_name: string;
  company_logo_url?: string | null;
  is_board_meeting?: boolean;
}

export function useUpcomingMeetings(daysAhead: number = 7) {
  const today = startOfToday();
  const endDate = addDays(today, daysAhead);

  return useQuery({
    queryKey: ['upcoming-meetings', daysAhead],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_meetings')
        .select(`
          id,
          title,
          meeting_date,
          duration_minutes,
          meeting_type,
          company_id,
          is_board_meeting,
          companies!inner(name, logo_url)
        `)
        .gte('meeting_date', format(today, 'yyyy-MM-dd'))
        .lte('meeting_date', format(endDate, 'yyyy-MM-dd'))
        .order('meeting_date', { ascending: true });

      if (error) throw error;

      return (data || []).map(meeting => ({
        id: meeting.id,
        title: meeting.title,
        meeting_date: meeting.meeting_date,
        duration_minutes: meeting.duration_minutes,
        meeting_type: meeting.meeting_type,
        company_id: meeting.company_id,
        company_name: (meeting.companies as any)?.name || 'Unknown',
        company_logo_url: (meeting.companies as any)?.logo_url,
        is_board_meeting: meeting.is_board_meeting,
      })) as UpcomingMeeting[];
    },
  });
}
