import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface DDPartnerAssignment {
  id: string;
  user_id: string;
  company_id: string;
  assigned_at: string;
  assigned_by: string;
  notes: string | null;
  specialization: 'economic' | 'legal' | null;
  approval_status: 'pending' | 'approved' | 'rejected';
  approved_at: string | null;
  approval_notes: string | null;
}

export function useDDPartnerAssignments(companyId: string | undefined) {
  const queryClient = useQueryClient();

  const { data: assignments, isLoading } = useQuery({
    queryKey: ['dd-partner-assignments', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('dd_partner_assignments')
        .select(`
          *,
          profiles:user_id (
            id,
            full_name,
            company_name
          )
        `)
        .eq('company_id', companyId);

      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });

  const assignDDPartner = useMutation({
    mutationFn: async ({ userId, notes, specialization }: { 
      userId: string; 
      notes?: string;
      specialization: 'economic' | 'legal';
    }) => {
      if (!companyId) throw new Error('Company ID is required');

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('dd_partner_assignments')
        .insert({
          user_id: userId,
          company_id: companyId,
          assigned_by: user.id,
          notes: notes || null,
          specialization,
          approval_status: 'pending',
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dd-partner-assignments', companyId] });
      toast.success('DD partner tildelt');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved tildeling: ' + error.message);
    },
  });

  const removeDDPartner = useMutation({
    mutationFn: async (assignmentId: string) => {
      const { error } = await supabase
        .from('dd_partner_assignments')
        .delete()
        .eq('id', assignmentId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dd-partner-assignments', companyId] });
      toast.success('DD partner fjernet');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved fjernelse: ' + error.message);
    },
  });

  const approveDDPartner = useMutation({
    mutationFn: async ({ assignmentId, notes }: { assignmentId: string; notes?: string }) => {
      const { error } = await supabase
        .from('dd_partner_assignments')
        .update({
          approval_status: 'approved',
          approved_at: new Date().toISOString(),
          approval_notes: notes || null,
        })
        .eq('id', assignmentId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dd-partner-assignments', companyId] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases-with-progress'] });
      toast.success('DD godkendt');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved godkendelse: ' + error.message);
    },
  });

  const rejectDDPartner = useMutation({
    mutationFn: async ({ assignmentId, notes }: { assignmentId: string; notes?: string }) => {
      const { error } = await supabase
        .from('dd_partner_assignments')
        .update({
          approval_status: 'rejected',
          approved_at: new Date().toISOString(),
          approval_notes: notes || null,
        })
        .eq('id', assignmentId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dd-partner-assignments', companyId] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases-with-progress'] });
      toast.success('DD afvist');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved afvisning: ' + error.message);
    },
  });

  return {
    assignments: assignments || [],
    isLoading,
    assignDDPartner: assignDDPartner.mutate,
    removeDDPartner: removeDDPartner.mutate,
    approveDDPartner: approveDDPartner.mutate,
    rejectDDPartner: rejectDDPartner.mutate,
  };
}

// Hook to get available DD partners (users with dd_partner role)
export function useAvailableDDPartners() {
  return useQuery({
    queryKey: ['available-dd-partners'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_roles')
        .select(`
          user_id,
          profiles:user_id (
            id,
            full_name,
            company_name
          )
        `)
        .eq('role', 'dd_partner');

      if (error) throw error;
      
      return data.map(item => ({
        id: item.user_id,
        full_name: (item.profiles as any)?.full_name || '',
        company_name: (item.profiles as any)?.company_name || '',
      }));
    },
  });
}
