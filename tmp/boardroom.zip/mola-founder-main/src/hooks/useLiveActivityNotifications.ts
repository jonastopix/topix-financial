import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { RealtimeChannel } from '@supabase/supabase-js';

interface ActivityEvent {
  id: string;
  event_type: string;
  event_message: string;
  event_icon: string | null;
  created_at: string;
}

export function useLiveActivityNotifications() {
  const { user } = useAuth();
  const [newEvent, setNewEvent] = useState<ActivityEvent | null>(null);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);
  const shownEventsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!user) return;

    const activityChannel = supabase
      .channel('live-activity-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'portfolio_activity_events',
        },
        (payload) => {
          const event = payload.new as ActivityEvent;
          
          // Don't show events we've already shown
          if (shownEventsRef.current.has(event.id)) return;
          
          shownEventsRef.current.add(event.id);
          setNewEvent(event);
          
          // Clear after showing
          setTimeout(() => {
            setNewEvent(null);
          }, 5000);
        }
      )
      .subscribe();

    setChannel(activityChannel);

    return () => {
      if (activityChannel) {
        activityChannel.unsubscribe();
      }
    };
  }, [user]);

  const clearEvent = () => setNewEvent(null);

  return { newEvent, clearEvent };
}
