import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface MileageSettings {
  id: string;
  user_id: string;
  employee_name: string;
  private_address: string;
  office_address: string | null;
  accountant_name: string | null;
  accountant_email: string | null;
  high_rate_per_km: number;
  low_rate_per_km: number;
  default_paying_fund_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface MileageEntry {
  id: string;
  user_id: string;
  paying_company_id: string | null;
  paying_fund_id: string | null;
  trip_date: string;
  from_address_type: 'private' | 'office' | 'manual';
  from_address: string;
  to_company_id: string | null;
  to_address: string;
  purpose: string;
  distance_km: number;
  rate_per_km: number;
  amount_dkk: number;
  is_submitted: boolean;
  submitted_at: string | null;
  created_at: string;
  updated_at: string;
  paying_company?: { name: string } | null;
  paying_fund?: { name: string } | null;
  to_company?: { name: string } | null;
}

export interface MileageSubmission {
  id: string;
  user_id: string;
  paying_company_id: string;
  period_year: number;
  period_month: number;
  total_km: number;
  total_amount_dkk: number;
  entries_snapshot: any;
  employee_name: string;
  sent_to_emails: string[];
  sent_at: string;
  created_at: string;
  paying_company?: { name: string };
}

export function useMileageSettings() {
  const { user } = useAuth();
  
  return useQuery({
    queryKey: ['mileage-settings', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('mileage_settings')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (error) throw error;
      return data as MileageSettings | null;
    },
    enabled: !!user?.id,
  });
}

export function useMileageEntries(filters?: { 
  payingCompanyId?: string; 
  isSubmitted?: boolean;
  year?: number;
  month?: number;
}) {
  const { user } = useAuth();
  
  return useQuery({
    queryKey: ['mileage-entries', user?.id, filters],
    queryFn: async () => {
      if (!user?.id) return [];
      
      let query = supabase
        .from('mileage_entries')
        .select(`
          *,
          paying_company:companies!mileage_entries_paying_company_id_fkey(name),
          paying_fund:funds!mileage_entries_paying_fund_id_fkey(name),
          to_company:companies!mileage_entries_to_company_id_fkey(name)
        `)
        .eq('user_id', user.id)
        .order('trip_date', { ascending: false });
      
      if (filters?.payingCompanyId) {
        query = query.eq('paying_company_id', filters.payingCompanyId);
      }
      
      if (filters?.isSubmitted !== undefined) {
        query = query.eq('is_submitted', filters.isSubmitted);
      }
      
      if (filters?.year && filters?.month) {
        const startDate = `${filters.year}-${String(filters.month).padStart(2, '0')}-01`;
        const endDate = new Date(filters.year, filters.month, 0).toISOString().split('T')[0];
        query = query.gte('trip_date', startDate).lte('trip_date', endDate);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as MileageEntry[];
    },
    enabled: !!user?.id,
  });
}

export function useMileageSubmissions() {
  const { user } = useAuth();
  
  return useQuery({
    queryKey: ['mileage-submissions', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('mileage_submissions')
        .select(`
          *,
          paying_company:companies!mileage_submissions_paying_company_id_fkey(name)
        `)
        .eq('user_id', user.id)
        .order('sent_at', { ascending: false });
      
      if (error) throw error;
      return data as MileageSubmission[];
    },
    enabled: !!user?.id,
  });
}

export function useMileageMutations() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  
  const upsertSettings = useMutation({
    mutationFn: async (settings: Partial<MileageSettings> & { employee_name: string; private_address: string }) => {
      if (!user?.id) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('mileage_settings')
        .upsert({
          user_id: user.id,
          ...settings,
        }, { onConflict: 'user_id' })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mileage-settings'] });
      toast.success('Indstillinger gemt');
    },
    onError: (error) => {
      toast.error('Kunne ikke gemme indstillinger: ' + error.message);
    },
  });
  
  const createEntry = useMutation({
    mutationFn: async (entry: {
      paying_company_id?: string | null;
      paying_fund_id?: string | null;
      trip_date: string;
      from_address_type: 'private' | 'office' | 'manual';
      from_address: string;
      to_company_id?: string | null;
      to_address: string;
      purpose: string;
      distance_km: number;
      rate_per_km?: number;
    }) => {
      if (!user?.id) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('mileage_entries')
        .insert({
          user_id: user.id,
          ...entry,
          rate_per_km: entry.rate_per_km || 3.94,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mileage-entries'] });
      toast.success('Kørsel registreret');
    },
    onError: (error) => {
      toast.error('Kunne ikke registrere kørsel: ' + error.message);
    },
  });
  
  const deleteEntry = useMutation({
    mutationFn: async (entryId: string) => {
      const { error } = await supabase
        .from('mileage_entries')
        .delete()
        .eq('id', entryId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mileage-entries'] });
      toast.success('Kørsel slettet');
    },
    onError: (error) => {
      toast.error('Kunne ikke slette kørsel: ' + error.message);
    },
  });
  
  return {
    upsertSettings,
    createEntry,
    deleteEntry,
  };
}

export type PayingEntityType = 'company' | 'fund' | 'unknown';

export interface PayingEntityGroup {
  entityId: string;
  entityType: PayingEntityType;
  entityName: string;
  entries: MileageEntry[];
  totalKm: number;
  totalAmount: number;
}

export function useUnsubmittedEntriesByPayingEntity(): PayingEntityGroup[] {
  const { data: entries = [] } = useMileageEntries({ isSubmitted: false });
  
  const groupedByEntity = entries.reduce((acc, entry) => {
    // Use fund if no company, create composite key
    const entityId = entry.paying_company_id || entry.paying_fund_id || 'unknown';
    const entityType: PayingEntityType = entry.paying_company_id ? 'company' : (entry.paying_fund_id ? 'fund' : 'unknown');
    const entityName = entry.paying_company?.name || entry.paying_fund?.name || 'Ukendt';
    const key = `${entityType}-${entityId}`;
    
    if (!acc[key]) {
      acc[key] = {
        entityId,
        entityType,
        entityName,
        entries: [],
        totalKm: 0,
        totalAmount: 0,
      };
    }
    acc[key].entries.push(entry);
    acc[key].totalKm += Number(entry.distance_km);
    acc[key].totalAmount += Number(entry.amount_dkk);
    return acc;
  }, {} as Record<string, PayingEntityGroup>);
  
  return Object.values(groupedByEntity);
}

// Backward compatibility alias
export const useUnsubmittedEntriesByCompany = useUnsubmittedEntriesByPayingEntity;
