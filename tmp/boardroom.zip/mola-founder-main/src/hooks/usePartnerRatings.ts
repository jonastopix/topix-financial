import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface PartnerRating {
  id: string;
  partner_id: string;
  user_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  updated_at: string;
}

export interface PartnerRatingStats {
  partner_id: string;
  average_rating: number;
  rating_count: number;
  user_rating: number | null;
}

export const usePartnerRatings = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['partner-ratings'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('trusted_partner_ratings')
        .select('*');

      if (error) throw error;
      return data as PartnerRating[];
    },
    enabled: !!user,
  });
};

export const usePartnerRatingStats = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['partner-rating-stats', user?.id],
    queryFn: async () => {
      const { data: ratings, error } = await supabase
        .from('trusted_partner_ratings')
        .select('partner_id, rating, user_id');

      if (error) throw error;

      // Calculate stats per partner
      const statsMap = new Map<string, { total: number; count: number; userRating: number | null }>();

      ratings?.forEach((r) => {
        const current = statsMap.get(r.partner_id) || { total: 0, count: 0, userRating: null };
        current.total += r.rating;
        current.count += 1;
        if (r.user_id === user?.id) {
          current.userRating = r.rating;
        }
        statsMap.set(r.partner_id, current);
      });

      const stats: PartnerRatingStats[] = [];
      statsMap.forEach((value, partner_id) => {
        stats.push({
          partner_id,
          average_rating: value.count > 0 ? value.total / value.count : 0,
          rating_count: value.count,
          user_rating: value.userRating,
        });
      });

      return stats;
    },
    enabled: !!user,
  });
};

export const useRatePartner = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ partnerId, rating, comment }: { partnerId: string; rating: number; comment?: string }) => {
      if (!user) throw new Error('User not authenticated');

      // Check if user already has a rating
      const { data: existing } = await supabase
        .from('trusted_partner_ratings')
        .select('id')
        .eq('partner_id', partnerId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (existing) {
        // Update existing rating
        const { error } = await supabase
          .from('trusted_partner_ratings')
          .update({ rating, comment, updated_at: new Date().toISOString() })
          .eq('id', existing.id);

        if (error) throw error;
      } else {
        // Insert new rating
        const { error } = await supabase
          .from('trusted_partner_ratings')
          .insert({
            partner_id: partnerId,
            user_id: user.id,
            rating,
            comment,
          });

        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-ratings'] });
      queryClient.invalidateQueries({ queryKey: ['partner-rating-stats'] });
      toast.success('Din rating er gemt');
    },
    onError: (error) => {
      console.error('Rating error:', error);
      toast.error('Kunne ikke gemme rating');
    },
  });
};

export const useDeletePartnerRating = () => {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (partnerId: string) => {
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('trusted_partner_ratings')
        .delete()
        .eq('partner_id', partnerId)
        .eq('user_id', user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-ratings'] });
      queryClient.invalidateQueries({ queryKey: ['partner-rating-stats'] });
      toast.success('Din rating er fjernet');
    },
    onError: (error) => {
      console.error('Delete rating error:', error);
      toast.error('Kunne ikke fjerne rating');
    },
  });
};
