import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface GovernanceTemplate {
  id: string;
  category: string;
  item_name: string;
  description: string | null;
  frequency: string;
  months_after_fiscal_year_end: number | null;
  required: boolean | null;
  is_active: boolean | null;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export function useGovernanceTemplatesAdmin() {
  const queryClient = useQueryClient();

  // Fetch all templates (including inactive for admin)
  const { data: templates, isLoading } = useQuery({
    queryKey: ['governance-templates-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_governance_templates')
        .select('*')
        .order('category')
        .order('sort_order');
      
      if (error) throw error;
      return data as GovernanceTemplate[];
    },
  });

  // Get unique categories
  const categories = [...new Set(templates?.map(t => t.category) || [])];

  // Create template
  const createTemplate = useMutation({
    mutationFn: async (template: Omit<GovernanceTemplate, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('company_governance_templates')
        .insert(template)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-templates-admin'] });
      queryClient.invalidateQueries({ queryKey: ['governance-templates'] });
      toast.success('Governance punkt oprettet');
    },
    onError: (error) => {
      console.error('Error creating template:', error);
      toast.error('Kunne ikke oprette governance punkt');
    },
  });

  // Update template
  const updateTemplate = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<GovernanceTemplate> & { id: string }) => {
      const { data, error } = await supabase
        .from('company_governance_templates')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-templates-admin'] });
      queryClient.invalidateQueries({ queryKey: ['governance-templates'] });
      toast.success('Governance punkt opdateret');
    },
    onError: (error) => {
      console.error('Error updating template:', error);
      toast.error('Kunne ikke opdatere governance punkt');
    },
  });

  // Delete template (soft delete - set is_active to false)
  const deleteTemplate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('company_governance_templates')
        .update({ is_active: false })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-templates-admin'] });
      queryClient.invalidateQueries({ queryKey: ['governance-templates'] });
      toast.success('Governance punkt deaktiveret');
    },
    onError: (error) => {
      console.error('Error deleting template:', error);
      toast.error('Kunne ikke deaktivere governance punkt');
    },
  });

  // Reactivate template
  const reactivateTemplate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('company_governance_templates')
        .update({ is_active: true })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-templates-admin'] });
      queryClient.invalidateQueries({ queryKey: ['governance-templates'] });
      toast.success('Governance punkt genaktiveret');
    },
    onError: (error) => {
      console.error('Error reactivating template:', error);
      toast.error('Kunne ikke genaktivere governance punkt');
    },
  });

  return {
    templates,
    categories,
    isLoading,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    reactivateTemplate,
  };
}
