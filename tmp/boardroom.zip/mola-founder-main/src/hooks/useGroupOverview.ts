import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

// Status values that count as "active" investments (not exited)
const ACTIVE_STATUSES = ['active', 'new_investment', 'due_diligence'];

export interface GroupCompany {
  id: string;
  name: string;
  cvr: string | null;
  address: string | null;
  city: string | null;
  zipcode: string | null;
  fundId: string | null;
  fundName: string | null;
  investedAmount: number;
  ownershipPct: number;
  latestValuation: number | null;
  valuationDate: string | null;
  status: string;
  industry: string | null;
  investedAt: string | null;
  exitProceeds?: number;
  exitDate?: string | null;
}

export interface GroupFund {
  id: string;
  name: string;
  cvr: string;
  companyCount: number;
  activeCompanyCount: number;
  totalInvested: number;
  activeInvested: number;
  totalValue: number;
  companies: GroupCompany[];
  activeCompanies: GroupCompany[];
  molaOwnershipPct: number; // Mola Invest ApS's ownership in this fund
}

export interface GroupOverviewData {
  funds: GroupFund[];
  // Active portfolio metrics (primary display)
  activeCompanyCount: number;
  activeInvested: number;
  activeValue: number;
  // Historical/exited metrics
  exitedCompanyCount: number;
  exitedInvested: number;
  // Aggregated metrics (includes all time)
  totalInvestedAllTime: number;
  totalDividends: number;
  totalExitProceeds: number;
  dpi: number;
  tvpi: number;
  // Mola Invest ApS perspective metrics
  molaActiveInvested: number;
  molaActiveValue: number;
  molaExitedInvested: number;
  molaTotalDividends: number;
  molaTotalExitProceeds: number;
  molaDpi: number;
  molaTvpi: number;
  // All companies (for backward compatibility)
  companyCount: number;
  totalInvested: number;
  totalValue: number;
  companies: GroupCompany[];
  activeCompanies: GroupCompany[];
  exitedCompanies: GroupCompany[];
}

export function useGroupOverview() {
  return useQuery({
    queryKey: ['group-overview'],
    queryFn: async (): Promise<GroupOverviewData> => {
      // Fetch all companies
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('*')
        .order('name');
      
      if (companiesError) throw companiesError;

      // Fetch all funds
      const { data: funds, error: fundsError } = await supabase
        .from('funds')
        .select('*')
        .order('name');
      
      if (fundsError) throw fundsError;

      // Fetch fund ownership to get Mola Invest ApS's ownership in each fund
      const { data: fundOwnership, error: fundOwnershipError } = await supabase
        .from('fund_ownership')
        .select('fund_id, owner_name, ownership_pct');
      
      if (fundOwnershipError) throw fundOwnershipError;

      // Create lookup for Mola Invest ApS ownership per fund
      const molaOwnershipByFund = new Map<string, number>();
      
      // First, set MOLA INVEST ApS (moderselskabet) to 100% - it IS Mola Invest ApS
      funds?.forEach(fund => {
        const fundNameLower = fund.name.toLowerCase();
        // Match "mola invest aps" but NOT "mola lh invest aps"
        if (fundNameLower.includes('mola invest') && 
            !fundNameLower.includes('lh') && 
            !fundNameLower.includes('viking')) {
          molaOwnershipByFund.set(fund.id, 100);
        }
      });
      
      // Then add ownership from fund_ownership table for other funds
      fundOwnership?.forEach(fo => {
        // Match "Mola Invest" in owner name (case insensitive)
        if (fo.owner_name.toLowerCase().includes('mola invest')) {
          molaOwnershipByFund.set(fo.fund_id, fo.ownership_pct);
        }
      });

      // Fetch all valuations (latest per company)
      const { data: valuations, error: valuationsError } = await supabase
        .from('valuations')
        .select('company_id, post_money_valuation_dkk, as_of_date')
        .order('as_of_date', { ascending: false });
      
      if (valuationsError) throw valuationsError;

      // Fetch all funding rounds
      const { data: fundingRounds, error: fundingError } = await supabase
        .from('funding_rounds')
        .select('company_id, invested_amount_dkk, equity_acquired_pct, fund_id');
      
      if (fundingError) throw fundingError;

      // Fetch all dividends with fund_id for Mola perspective calculation
      const { data: dividends, error: dividendsError } = await supabase
        .from('dividends')
        .select('amount_dkk, fund_id');
      
      if (dividendsError) throw dividendsError;

      // Fetch all exits with company_id for mapping (include ownership % for correct proceeds calculation)
      const { data: exits, error: exitsError } = await supabase
        .from('exits')
        .select('company_id, fund_id, gross_sale_amount_dkk, mola_ownership_pct_at_exit, transaction_costs_dkk, closing_date');
      
      if (exitsError) throw exitsError;

      // Create exit lookup by company_id - calculate MOLA's share of proceeds
      const exitLookup = new Map(
        exits?.map(e => {
          // Calculate MOLA's share: gross_sale × ownership% - transaction_costs
          const molaShare = (e.gross_sale_amount_dkk || 0) * (e.mola_ownership_pct_at_exit || 0) / 100;
          const proceeds = molaShare - (e.transaction_costs_dkk || 0);
          return [e.company_id, {
            proceeds,
            date: e.closing_date,
            fundId: e.fund_id
          }];
        }) || []
      );

      // Create lookup for latest valuation per company
      const latestValuations = new Map<string, { value: number; date: string }>();
      valuations?.forEach(v => {
        if (!latestValuations.has(v.company_id)) {
          latestValuations.set(v.company_id, {
            value: Number(v.post_money_valuation_dkk) || 0,
            date: v.as_of_date
          });
        }
      });

      // Calculate funding totals per company
      const fundingTotals = new Map<string, { invested: number; equity: number }>();
      fundingRounds?.forEach(fr => {
        const existing = fundingTotals.get(fr.company_id) || { invested: 0, equity: 0 };
        fundingTotals.set(fr.company_id, {
          invested: existing.invested + (fr.invested_amount_dkk || 0),
          equity: existing.equity + (fr.equity_acquired_pct || 0)
        });
      });

      // Create fund lookup
      const fundLookup = new Map(funds?.map(f => [f.id, f]) || []);

      // Map companies to GroupCompany
      const groupCompanies: GroupCompany[] = (companies || []).map(c => {
        const fundingData = fundingTotals.get(c.id);
        const valuationData = latestValuations.get(c.id);
        const fund = c.fund_id ? fundLookup.get(c.fund_id) : null;
        const exitData = exitLookup.get(c.id);

        // Calculate ownership - prioritize funding rounds, then company fields
        let ownershipPct = 0;
        if (fundingData && fundingData.equity > 0) {
          ownershipPct = fundingData.equity;
        } else {
          ownershipPct = c.total_equity_share_pct || c.equity_share_pct || 0;
        }

        // Calculate invested - prioritize funding rounds, then company fields
        let investedAmount = 0;
        if (fundingData && fundingData.invested > 0) {
          investedAmount = fundingData.invested;
        } else {
          investedAmount = c.total_invested_amount_dkk || c.invested_amount_dkk || 0;
        }

        return {
          id: c.id,
          name: c.name,
          cvr: c.cvr,
          address: c.address,
          city: c.city,
          zipcode: c.zipcode,
          fundId: c.fund_id,
          fundName: fund?.name || null,
          investedAmount,
          ownershipPct,
          latestValuation: valuationData?.value || null,
          valuationDate: valuationData?.date || null,
          status: c.status,
          industry: c.industry,
          investedAt: c.initial_invested_at || c.invested_at,
          exitProceeds: exitData?.proceeds,
          exitDate: exitData?.date
        };
      });

      // Split companies into active and exited
      const activeCompanies = groupCompanies.filter(c => ACTIVE_STATUSES.includes(c.status));
      const exitedCompanies = groupCompanies.filter(c => c.status === 'exited');

      // Group companies by fund
      const groupFunds: GroupFund[] = (funds || []).map(fund => {
        const fundCompanies = groupCompanies.filter(c => c.fundId === fund.id);
        const fundActiveCompanies = fundCompanies.filter(c => ACTIVE_STATUSES.includes(c.status));
        
        const totalInvested = fundCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
        const activeInvested = fundActiveCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
        
        // Calculate total value: sum of (valuation * ownership %) - only for active companies
        const totalValue = fundActiveCompanies.reduce((sum, c) => {
          if (c.latestValuation && c.ownershipPct > 0) {
            return sum + (c.latestValuation * c.ownershipPct / 100);
          }
          return sum;
        }, 0);

        // Get Mola Invest ApS's ownership in this fund
        const molaOwnershipPct = molaOwnershipByFund.get(fund.id) || 0;

        return {
          id: fund.id,
          name: fund.name,
          cvr: fund.cvr,
          companyCount: fundCompanies.length,
          activeCompanyCount: fundActiveCompanies.length,
          totalInvested,
          activeInvested,
          totalValue,
          companies: fundCompanies,
          activeCompanies: fundActiveCompanies,
          molaOwnershipPct
        };
      });

      // Calculate active portfolio totals
      const activeInvested = activeCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
      const activeValue = activeCompanies.reduce((sum, c) => {
        if (c.latestValuation && c.ownershipPct > 0) {
          return sum + (c.latestValuation * c.ownershipPct / 100);
        }
        return sum;
      }, 0);

      // Calculate exited totals
      const exitedInvested = exitedCompanies.reduce((sum, c) => sum + c.investedAmount, 0);

      // Total invested all time (for DPI/TVPI calculations)
      const totalInvestedAllTime = activeInvested + exitedInvested;

      // Legacy totals (all companies)
      const totalInvested = groupCompanies.reduce((sum, c) => sum + c.investedAmount, 0);
      const totalValue = groupCompanies.reduce((sum, c) => {
        if (c.latestValuation && c.ownershipPct > 0) {
          return sum + (c.latestValuation * c.ownershipPct / 100);
        }
        return sum;
      }, 0);

      const totalDividends = dividends?.reduce((sum, d) => sum + (d.amount_dkk || 0), 0) || 0;
      
      // Calculate total exit proceeds using MOLA's ownership share
      const totalExitProceeds = exits?.reduce((sum, e) => {
        const molaShare = (e.gross_sale_amount_dkk || 0) * (e.mola_ownership_pct_at_exit || 0) / 100;
        return sum + (molaShare - (e.transaction_costs_dkk || 0));
      }, 0) || 0;

      // Calculate DPI and TVPI based on total invested all time
      const distributions = totalDividends + totalExitProceeds;
      const dpi = totalInvestedAllTime > 0 ? distributions / totalInvestedAllTime : 0;
      const tvpi = totalInvestedAllTime > 0 ? (distributions + activeValue) / totalInvestedAllTime : 0;

      // ===== MOLA INVEST ApS PERSPECTIVE =====
      // Calculate metrics weighted by Mola Invest ApS's ownership in each fund
      
      // Create fund ID lookup for quick access
      const fundIdByCompany = new Map(groupCompanies.map(c => [c.id, c.fundId]));

      // Mola's active invested: sum of (company invested × fund's molaOwnershipPct)
      const molaActiveInvested = activeCompanies.reduce((sum, c) => {
        const fundId = c.fundId;
        const molaOwnership = fundId ? (molaOwnershipByFund.get(fundId) || 0) / 100 : 0;
        return sum + (c.investedAmount * molaOwnership);
      }, 0);

      // Mola's active value: sum of (company value × fund's molaOwnershipPct)
      const molaActiveValue = activeCompanies.reduce((sum, c) => {
        if (c.latestValuation && c.ownershipPct > 0) {
          const fundId = c.fundId;
          const molaOwnership = fundId ? (molaOwnershipByFund.get(fundId) || 0) / 100 : 0;
          const companyValue = c.latestValuation * c.ownershipPct / 100;
          return sum + (companyValue * molaOwnership);
        }
        return sum;
      }, 0);

      // Mola's exited invested
      const molaExitedInvested = exitedCompanies.reduce((sum, c) => {
        const fundId = c.fundId;
        const molaOwnership = fundId ? (molaOwnershipByFund.get(fundId) || 0) / 100 : 0;
        return sum + (c.investedAmount * molaOwnership);
      }, 0);

      // Mola's total dividends: sum of (dividend × fund's molaOwnershipPct)
      const molaTotalDividends = dividends?.reduce((sum, d) => {
        const molaOwnership = d.fund_id ? (molaOwnershipByFund.get(d.fund_id) || 0) / 100 : 0;
        return sum + ((d.amount_dkk || 0) * molaOwnership);
      }, 0) || 0;

      // Mola's exit proceeds: sum of (exit proceeds × fund's molaOwnershipPct)
      const molaTotalExitProceeds = exits?.reduce((sum, e) => {
        const molaShare = (e.gross_sale_amount_dkk || 0) * (e.mola_ownership_pct_at_exit || 0) / 100;
        const proceeds = molaShare - (e.transaction_costs_dkk || 0);
        const molaFundOwnership = e.fund_id ? (molaOwnershipByFund.get(e.fund_id) || 0) / 100 : 0;
        return sum + (proceeds * molaFundOwnership);
      }, 0) || 0;

      // Mola's total invested all time
      const molaTotalInvestedAllTime = molaActiveInvested + molaExitedInvested;

      // Mola's DPI and TVPI
      const molaDistributions = molaTotalDividends + molaTotalExitProceeds;
      const molaDpi = molaTotalInvestedAllTime > 0 ? molaDistributions / molaTotalInvestedAllTime : 0;
      const molaTvpi = molaTotalInvestedAllTime > 0 ? (molaDistributions + molaActiveValue) / molaTotalInvestedAllTime : 0;

      return {
        funds: groupFunds,
        // Active portfolio
        activeCompanyCount: activeCompanies.length,
        activeInvested,
        activeValue,
        // Exited
        exitedCompanyCount: exitedCompanies.length,
        exitedInvested,
        // All time
        totalInvestedAllTime,
        totalDividends,
        totalExitProceeds,
        dpi,
        tvpi,
        // Mola Invest ApS perspective
        molaActiveInvested,
        molaActiveValue,
        molaExitedInvested,
        molaTotalDividends,
        molaTotalExitProceeds,
        molaDpi,
        molaTvpi,
        // Legacy/backward compatibility
        companyCount: groupCompanies.length,
        totalInvested,
        totalValue,
        companies: groupCompanies,
        activeCompanies,
        exitedCompanies
      };
    },
  });
}
