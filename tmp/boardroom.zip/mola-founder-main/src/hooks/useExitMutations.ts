import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface ExitInput {
  company_id: string;
  fund_id: string;
  closing_date: string;
  gross_sale_amount_dkk: number;
  mola_ownership_pct_at_exit: number;
  transaction_costs_dkk: number;
  retained_shares_pct: number;
  earnout_possible: boolean;
  earnout_amount_potential_dkk?: number;
  note?: string;
}

interface ExitUpdateInput extends Partial<Omit<ExitInput, 'company_id' | 'fund_id'>> {
  id: string;
}

export function useExitMutations() {
  const queryClient = useQueryClient();

  const createExit = useMutation({
    mutationFn: async (data: ExitInput) => {
      const { data: result, error } = await supabase
        .from('exits')
        .insert(data)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exits'] });
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      toast({
        title: 'Success',
        description: 'Exit recorded successfully. Company status updated to "Exited".',
      });
    },
    onError: (error: any) => {
      console.error('Failed to record exit:', error);
      
      // Check if it's a unique constraint violation
      if (error?.message?.includes('exits_company_id_unique') || error?.code === '23505') {
        toast({
          title: 'Exit allerede registreret',
          description: 'Der er allerede registreret et exit for dette selskab',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Error',
          description: 'Failed to record exit',
          variant: 'destructive',
        });
      }
    },
  });

  const updateExit = useMutation({
    mutationFn: async (data: ExitUpdateInput) => {
      const { id, ...updateData } = data;
      const { data: result, error } = await supabase
        .from('exits')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['exits'] });
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      toast({
        title: 'Success',
        description: 'Exit opdateret succesfuldt.',
      });
    },
    onError: (error: any) => {
      console.error('Failed to update exit:', error);
      toast({
        title: 'Error',
        description: 'Kunne ikke opdatere exit',
        variant: 'destructive',
      });
    },
  });

  return { createExit, updateExit };
}
