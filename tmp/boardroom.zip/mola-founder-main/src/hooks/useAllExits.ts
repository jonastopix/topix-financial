import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ExitWithCompany {
  id: string;
  company_id: string;
  fund_id: string;
  closing_date: string;
  gross_sale_amount_dkk: number;
  mola_ownership_pct_at_exit: number;
  transaction_costs_dkk: number;
  retained_shares_pct: number;
  earnout_possible: boolean;
  earnout_amount_potential_dkk: number | null;
  note: string | null;
  created_at: string;
  company_name: string;
  fund_name: string | null;
  invested_amount_dkk: number | null;
}

export function useAllExits() {
  return useQuery({
    queryKey: ['all-exits'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('exits')
        .select(`
          *,
          companies (
            name,
            invested_amount_dkk
          ),
          funds (
            name
          )
        `)
        .order('closing_date', { ascending: false });

      if (error) throw error;

      // Transform data to flat structure
      return (data || []).map((exit: any) => ({
        id: exit.id,
        company_id: exit.company_id,
        fund_id: exit.fund_id,
        closing_date: exit.closing_date,
        gross_sale_amount_dkk: exit.gross_sale_amount_dkk,
        mola_ownership_pct_at_exit: exit.mola_ownership_pct_at_exit,
        transaction_costs_dkk: exit.transaction_costs_dkk,
        retained_shares_pct: exit.retained_shares_pct,
        earnout_possible: exit.earnout_possible,
        earnout_amount_potential_dkk: exit.earnout_amount_potential_dkk,
        note: exit.note,
        created_at: exit.created_at,
        company_name: exit.companies?.name || 'Unknown',
        fund_name: exit.funds?.name || null,
        invested_amount_dkk: exit.companies?.invested_amount_dkk || null,
      })) as ExitWithCompany[];
    },
  });
}
