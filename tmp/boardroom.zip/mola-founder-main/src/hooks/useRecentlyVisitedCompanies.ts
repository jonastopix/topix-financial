import { useState, useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

const STORAGE_KEY = 'recently_visited_companies';
const MAX_RECENT = 5;

interface RecentVisit {
  companyId: string;
  visitedAt: number;
}

export function useRecentlyVisitedCompanies() {
  const [recentIds, setRecentIds] = useState<string[]>([]);

  // Load from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const visits: RecentVisit[] = JSON.parse(stored);
        setRecentIds(visits.map(v => v.companyId));
      } catch {
        setRecentIds([]);
      }
    }
  }, []);

  // Track a company visit
  const trackVisit = useCallback((companyId: string) => {
    const stored = localStorage.getItem(STORAGE_KEY);
    let visits: RecentVisit[] = [];
    
    if (stored) {
      try {
        visits = JSON.parse(stored);
      } catch {
        visits = [];
      }
    }

    // Remove existing entry for this company
    visits = visits.filter(v => v.companyId !== companyId);
    
    // Add to beginning
    visits.unshift({ companyId, visitedAt: Date.now() });
    
    // Keep only MAX_RECENT
    visits = visits.slice(0, MAX_RECENT);
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(visits));
    setRecentIds(visits.map(v => v.companyId));
  }, []);

  // Fetch company details for recent IDs
  const { data: companies = [], isLoading } = useQuery({
    queryKey: ['recently-visited-companies', recentIds],
    queryFn: async () => {
      if (recentIds.length === 0) return [];
      
      const { data, error } = await supabase
        .from('companies')
        .select('id, name, logo_url, status, industry')
        .in('id', recentIds);
      
      if (error) throw error;
      
      // Sort by visit order
      return recentIds
        .map(id => data.find(c => c.id === id))
        .filter(Boolean) as typeof data;
    },
    enabled: recentIds.length > 0,
  });

  return {
    companies,
    isLoading,
    trackVisit,
  };
}

