import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { DocumentType } from './useCompanyDocuments';

export const getDocumentPriorities = (hasBoard: boolean) => ({
  critical: ['shareholder_agreement', 'articles_of_association', 'annual_report'] as DocumentType[],
  important: hasBoard 
    ? ['board_minutes', 'investment_memo', 'term_sheet', 'valuation_report'] as DocumentType[]
    : ['investment_memo', 'term_sheet', 'valuation_report'] as DocumentType[],
  optional: ['other'] as DocumentType[],
});

// Keep for backward compatibility
export const documentPriorities = getDocumentPriorities(true);

const getAllDocumentTypes = (hasBoard: boolean): DocumentType[] => {
  const priorities = getDocumentPriorities(hasBoard);
  return [
    ...priorities.critical,
    ...priorities.important,
    ...priorities.optional,
  ];
};

export interface CompanyDocumentStatus {
  companyId: string;
  companyName: string;
  totalDocuments: number;
  uploadedDocuments: number;
  completionRate: number;
  missingCritical: DocumentType[];
  missingImportant: DocumentType[];
  uploadedTypes: DocumentType[];
  status: 'critical' | 'warning' | 'good';
}

export function useCompanyDocumentStatus(companyId?: string, hasBoard: boolean = true) {
  return useQuery({
    queryKey: ['company-document-status', companyId, hasBoard],
    queryFn: async () => {
      if (!companyId) return null;

      const { data: documents } = await supabase
        .from('company_documents')
        .select('document_type')
        .eq('company_id', companyId)
        .eq('is_latest', true);

      const uploadedTypes = new Set(documents?.map(d => d.document_type) || []);
      const priorities = getDocumentPriorities(hasBoard);
      const allDocumentTypes = getAllDocumentTypes(hasBoard);
      
      const missingCritical = priorities.critical.filter(t => !uploadedTypes.has(t));
      const missingImportant = priorities.important.filter(t => !uploadedTypes.has(t));
      
      const totalDocuments = allDocumentTypes.length;
      // Only count uploaded types that are relevant for this company
      const relevantUploadedTypes = Array.from(uploadedTypes).filter(t => 
        allDocumentTypes.includes(t as DocumentType)
      );
      const uploadedDocuments = relevantUploadedTypes.length;
      const completionRate = Math.round((uploadedDocuments / totalDocuments) * 100);
      
      let status: 'critical' | 'warning' | 'good' = 'good';
      if (completionRate <= 40 || missingCritical.length > 0) {
        status = 'critical';
      } else if (completionRate <= 70) {
        status = 'warning';
      }

      return {
        companyId,
        totalDocuments,
        uploadedDocuments,
        completionRate,
        missingCritical,
        missingImportant,
        uploadedTypes: Array.from(uploadedTypes),
        status,
      } as CompanyDocumentStatus;
    },
    enabled: !!companyId,
  });
}

export function useAllCompaniesDocumentStatus() {
  return useQuery({
    queryKey: ['all-companies-document-status'],
    queryFn: async () => {
      const { data: companies } = await supabase
        .from('companies')
        .select('id, name, has_board')
        .eq('is_active', true)
        .order('name');

      if (!companies) return [];

      const { data: allDocuments } = await supabase
        .from('company_documents')
        .select('company_id, document_type')
        .eq('is_latest', true);

      const documentsByCompany = new Map<string, Set<DocumentType>>();
      allDocuments?.forEach(doc => {
        if (!documentsByCompany.has(doc.company_id)) {
          documentsByCompany.set(doc.company_id, new Set());
        }
        documentsByCompany.get(doc.company_id)?.add(doc.document_type as DocumentType);
      });

      return companies.map(company => {
        const hasBoard = company.has_board ?? false;
        const priorities = getDocumentPriorities(hasBoard);
        const allDocumentTypes = getAllDocumentTypes(hasBoard);
        
        const uploadedTypes = documentsByCompany.get(company.id) || new Set();
        const missingCritical = priorities.critical.filter(t => !uploadedTypes.has(t));
        const missingImportant = priorities.important.filter(t => !uploadedTypes.has(t));
        
        const totalDocuments = allDocumentTypes.length;
        // Only count uploaded types that are relevant for this company
        const relevantUploadedTypes = Array.from(uploadedTypes).filter(t => 
          allDocumentTypes.includes(t as DocumentType)
        );
        const uploadedDocuments = relevantUploadedTypes.length;
        const completionRate = Math.round((uploadedDocuments / totalDocuments) * 100);
        
        let status: 'critical' | 'warning' | 'good' = 'good';
        if (completionRate <= 40 || missingCritical.length > 0) {
          status = 'critical';
        } else if (completionRate <= 70) {
          status = 'warning';
        }

        return {
          companyId: company.id,
          companyName: company.name,
          totalDocuments,
          uploadedDocuments,
          completionRate,
          missingCritical,
          missingImportant,
          uploadedTypes: Array.from(uploadedTypes),
          status,
        } as CompanyDocumentStatus;
      });
    },
  });
}
