import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { calculateYTD, getLatestMonth } from '@/lib/metricsCalculations';

export function useCompanyFinancials(companyId?: string) {
  return useQuery({
    queryKey: ['company-financials', companyId],
    queryFn: async () => {
      if (!companyId) return null;

      // Fetch monthly reports
      const { data: reports, error } = await supabase
        .from('monthly_reports')
        .select('*')
        .eq('company_id', companyId)
        .order('period_year', { ascending: false })
        .order('period_month', { ascending: false });

      if (error) throw error;
      if (!reports || reports.length === 0) return null;

      const currentYear = new Date().getFullYear();
      const ytd = calculateYTD(reports, currentYear);
      const latestMonth = getLatestMonth(reports);

      return {
        reports,
        ytd,
        latestMonth,
      };
    },
    enabled: !!companyId,
  });
}
