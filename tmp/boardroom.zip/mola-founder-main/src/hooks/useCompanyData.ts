import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';

export const useCompanyData = () => {
  const { user } = useAuth();
  const { isAdmin, selectedCompanyId } = useRole();

  return useQuery({
    queryKey: ['company-data', user?.id, isAdmin, selectedCompanyId],
    queryFn: async () => {
      if (!user) throw new Error('Not authenticated');

      // If admin and a specific company is selected
      if (isAdmin && selectedCompanyId) {
        const { data: company, error } = await supabase
          .from('companies')
          .select('*')
          .eq('id', selectedCompanyId)
          .single();

        if (error) throw error;
        return company;
      }

      // If admin but no specific company selected, return null (show portfolio view)
      if (isAdmin && !selectedCompanyId) {
        return null;
      }

      // For founders, get their company
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('company_id')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;
      if (!profile?.company_id) return null;

      const { data: company, error: companyError } = await supabase
        .from('companies')
        .select('*')
        .eq('id', profile.company_id)
        .single();

      if (companyError) throw companyError;
      return company;
    },
    enabled: !!user,
  });
};

export const useMonthlyReports = (companyId?: string) => {
  return useQuery({
    queryKey: ['monthly-reports', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('monthly_reports')
        .select('*')
        .eq('company_id', companyId)
        .order('period_year', { ascending: false })
        .order('period_month', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });
};

export const useNPSResponses = (companyId?: string) => {
  return useQuery({
    queryKey: ['nps-responses', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('nps_responses')
        .select('*')
        .eq('company_id', companyId)
        .order('period_year', { ascending: false })
        .order('period_quarter', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });
};

export const useShippingPrices = (companyId?: string) => {
  return useQuery({
    queryKey: ['shipping-prices', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('shipping_prices')
        .select('*')
        .eq('company_id', companyId)
        .order('effective_from', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });
};

export const useBadges = (companyId?: string) => {
  return useQuery({
    queryKey: ['badges', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('badges')
        .select('*')
        .eq('company_id', companyId)
        .order('earned_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });
};

export const usePortfolioBenchmarks = () => {
  return useQuery({
    queryKey: ['portfolio-benchmarks'],
    queryFn: async () => {
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id')
        .eq('is_active', true);

      if (companiesError) throw companiesError;

      const companyIds = companies.map(c => c.id);

      const { data: shippingData, error: shippingError } = await supabase
        .from('shipping_prices')
        .select('company_id, home_delivery_dkk, pickup_point_dkk')
        .in('company_id', companyIds)
        .order('effective_from', { ascending: false });

      if (shippingError) throw shippingError;

      const latestPrices = new Map();
      shippingData?.forEach(price => {
        if (!latestPrices.has(price.company_id)) {
          latestPrices.set(price.company_id, price);
        }
      });

      const prices = Array.from(latestPrices.values());

      const avgHomeDelivery = prices.reduce((sum, p) => sum + Number(p.home_delivery_dkk), 0) / prices.length;
      const avgPickupPoint = prices.reduce((sum, p) => sum + Number(p.pickup_point_dkk), 0) / prices.length;

      return {
        shipping: {
          avgHomeDelivery,
          avgPickupPoint,
          count: prices.length,
        },
      };
    },
  });
};