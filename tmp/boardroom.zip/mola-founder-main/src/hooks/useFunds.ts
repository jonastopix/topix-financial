import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface Fund {
  id: string;
  name: string;
  cvr: string;
  inception_date: string | null;
  target_size_dkk: number | null;
  company_type: string | null;
  address: string | null;
  city: string | null;
  zipcode: string | null;
  created_at: string;
}

export function useFunds() {
  return useQuery({
    queryKey: ['funds'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('funds')
        .select('*')
        .order('name');

      if (error) throw error;
      return data as Fund[];
    },
  });
}
