import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface FundOwnership {
  id: string;
  fund_id: string;
  owner_name: string;
  owner_type: 'person' | 'company' | 'fund';
  ownership_pct: number;
  created_at: string;
  updated_at: string;
}

export interface PersonalStake {
  id: string;
  user_id: string;
  entity_name: string;
  entity_type: 'company' | 'fund';
  ownership_pct: number;
  created_at: string;
  updated_at: string;
}

export function useFundOwnership(fundId?: string) {
  return useQuery({
    queryKey: ['fund-ownership', fundId],
    queryFn: async () => {
      let query = supabase
        .from('fund_ownership')
        .select('*')
        .order('owner_name');

      if (fundId) {
        query = query.eq('fund_id', fundId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as FundOwnership[];
    },
    enabled: !!fundId,
  });
}

export function usePersonalStakes(userId?: string) {
  return useQuery({
    queryKey: ['personal-stakes', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('personal_fund_stakes')
        .select('*')
        .eq('user_id', userId!)
        .order('entity_name');

      if (error) throw error;
      return data as PersonalStake[];
    },
    enabled: !!userId,
  });
}

export function useFundManagementMutations() {
  const queryClient = useQueryClient();

  const createFund = useMutation({
    mutationFn: async (fund: { 
      name: string; 
      cvr: string; 
      inception_date?: string; 
      target_size_dkk?: number;
      company_type?: string;
      address?: string;
      city?: string;
      zipcode?: string;
    }) => {
      const { data, error } = await supabase
        .from('funds')
        .insert(fund)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['funds'] });
      toast.success('Fond oprettet');
    },
    onError: (error) => {
      toast.error('Fejl ved oprettelse af fond: ' + error.message);
    },
  });

  const updateFund = useMutation({
    mutationFn: async ({ id, ...fund }: { 
      id: string; 
      name: string; 
      cvr: string; 
      inception_date?: string; 
      target_size_dkk?: number;
      company_type?: string;
      address?: string;
      city?: string;
      zipcode?: string;
    }) => {
      const { data, error } = await supabase
        .from('funds')
        .update(fund)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['funds'] });
      toast.success('Fond opdateret');
    },
    onError: (error) => {
      toast.error('Fejl ved opdatering af fond: ' + error.message);
    },
  });

  const deleteFund = useMutation({
    mutationFn: async (fundId: string) => {
      const { error } = await supabase
        .from('funds')
        .delete()
        .eq('id', fundId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['funds'] });
      toast.success('Fond slettet');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning af fond: ' + error.message);
    },
  });

  const addOwnership = useMutation({
    mutationFn: async (ownership: Omit<FundOwnership, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('fund_ownership')
        .insert(ownership)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fund-ownership'] });
      toast.success('Ejerskab tilføjet');
    },
    onError: (error) => {
      toast.error('Fejl ved tilføjelse af ejerskab: ' + error.message);
    },
  });

  const deleteOwnership = useMutation({
    mutationFn: async (ownershipId: string) => {
      const { error } = await supabase
        .from('fund_ownership')
        .delete()
        .eq('id', ownershipId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['fund-ownership'] });
      toast.success('Ejerskab slettet');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning af ejerskab: ' + error.message);
    },
  });

  const addPersonalStake = useMutation({
    mutationFn: async (stake: Omit<PersonalStake, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('personal_fund_stakes')
        .insert(stake)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['personal-stakes'] });
      toast.success('Personlig ejerandel tilføjet');
    },
    onError: (error) => {
      toast.error('Fejl ved tilføjelse: ' + error.message);
    },
  });

  const deletePersonalStake = useMutation({
    mutationFn: async (stakeId: string) => {
      const { error } = await supabase
        .from('personal_fund_stakes')
        .delete()
        .eq('id', stakeId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['personal-stakes'] });
      toast.success('Personlig ejerandel slettet');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning: ' + error.message);
    },
  });

  return {
    createFund,
    updateFund,
    deleteFund,
    addOwnership,
    deleteOwnership,
    addPersonalStake,
    deletePersonalStake,
  };
}
