import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface FounderDeal {
  id: string;
  company_id: string;
  title: string;
  description: string | null;
  discount_type: 'percentage' | 'fixed_amount' | 'trial_extension' | 'other';
  discount_value: number | null;
  promo_code: string | null;
  categories: string[];
  terms: string | null;
  contact_email: string | null;
  product_url: string | null;
  max_redemptions: number | null;
  current_redemptions: number;
  valid_from: string | null;
  valid_until: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  companies?: {
    name: string;
    logo_url: string | null;
  };
}

export interface FounderDealRedemption {
  id: string;
  deal_id: string;
  redeemed_by_company_id: string;
  redeemed_at: string;
  notes: string | null;
}

export const useFounderDeals = (category?: string) => {
  return useQuery({
    queryKey: ['founder-deals', category],
    queryFn: async () => {
      let query = supabase
        .from('founder_deals')
        .select(`
          *,
          companies:company_id (
            name,
            logo_url
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });
      
      if (category) {
        query = query.contains('categories', [category]);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as FounderDeal[];
    },
  });
};

export const useMyFounderDeals = (companyId?: string) => {
  return useQuery({
    queryKey: ['my-founder-deals', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      
      const { data, error } = await supabase
        .from('founder_deals')
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as FounderDeal[];
    },
    enabled: !!companyId,
  });
};

export const useDealRedemptions = (dealId?: string) => {
  return useQuery({
    queryKey: ['deal-redemptions', dealId],
    queryFn: async () => {
      if (!dealId) return [];
      
      const { data, error } = await supabase
        .from('founder_deal_redemptions')
        .select(`
          *,
          companies:redeemed_by_company_id (
            name,
            logo_url
          )
        `)
        .eq('deal_id', dealId)
        .order('redeemed_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!dealId,
  });
};

export const useCreateFounderDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deal: Omit<FounderDeal, 'id' | 'created_at' | 'updated_at' | 'current_redemptions' | 'companies'>) => {
      const { data, error } = await supabase
        .from('founder_deals')
        .insert(deal)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['founder-deals'] });
      queryClient.invalidateQueries({ queryKey: ['my-founder-deals'] });
      toast({
        title: "Deal oprettet",
        description: "Dit deal er nu synligt for andre founders.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fejl",
        description: "Kunne ikke oprette deal. Prøv igen.",
        variant: "destructive",
      });
      console.error('Error creating deal:', error);
    },
  });
};

export const useUpdateFounderDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<FounderDeal> & { id: string }) => {
      const { data, error } = await supabase
        .from('founder_deals')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['founder-deals'] });
      queryClient.invalidateQueries({ queryKey: ['my-founder-deals'] });
      toast({
        title: "Deal opdateret",
        description: "Dine ændringer er gemt.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fejl",
        description: "Kunne ikke opdatere deal. Prøv igen.",
        variant: "destructive",
      });
      console.error('Error updating deal:', error);
    },
  });
};

export const useRedeemDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ dealId, companyId, notes }: { dealId: string; companyId: string; notes?: string }) => {
      const { data, error } = await supabase
        .from('founder_deal_redemptions')
        .insert({
          deal_id: dealId,
          redeemed_by_company_id: companyId,
          notes: notes || null,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['founder-deals'] });
      queryClient.invalidateQueries({ queryKey: ['deal-redemptions'] });
      toast({
        title: "Deal anvendt",
        description: "Rabatkoden er kopieret til udklipsholderen.",
      });
    },
    onError: (error: any) => {
      if (error.code === '23505') {
        toast({
          title: "Allerede anvendt",
          description: "Du har allerede anvendt dette deal.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Fejl",
          description: "Kunne ikke anvende deal. Prøv igen.",
          variant: "destructive",
        });
      }
      console.error('Error redeeming deal:', error);
    },
  });
};
