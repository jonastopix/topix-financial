import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface ActivityLog {
  id: string;
  company_id: string;
  user_id: string;
  activity_type: string;
  description: string;
  metadata?: any;
  created_at: string;
}

export function useCompanyActivityLog(companyId?: string, activityType?: string, limit: number = 100) {
  return useQuery({
    queryKey: ['company-activity-log', companyId, activityType, limit],
    queryFn: async () => {
      let query = supabase
        .from('company_activity_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (companyId) {
        query = query.eq('company_id', companyId);
      }

      if (activityType) {
        query = query.eq('activity_type', activityType);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as ActivityLog[];
    },
  });
}
