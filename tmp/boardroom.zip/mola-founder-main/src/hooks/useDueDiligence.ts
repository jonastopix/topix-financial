import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type DDStatus = 'not_started' | 'in_progress' | 'pending_review' | 'approved' | 'rejected';
export type DDDocumentType = 'financial' | 'legal' | 'commercial' | 'technical' | 'other';
export type DDCategoryStatus = 'not_started' | 'in_progress' | 'completed' | 'not_applicable';
export type DDDocumentStatus = 'uploaded' | 'under_review' | 'approved' | 'rejected' | 'requires_update';

export interface DDCase {
  id: string;
  company_id: string;
  status: DDStatus;
  assigned_to: string | null;
  started_at: string | null;
  completed_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
  exported_at: string | null;
  exported_by: string | null;
  export_location: string | null;
  files_deleted_from_portal: boolean;
  deadline: string | null;
  companies?: {
    id: string;
    name: string;
    logo_url: string | null;
    status?: string;
    cvr?: string | null;
  };
}

export interface DDChecklistTemplate {
  id: string;
  category: string;
  item_name: string;
  description: string | null;
  required: boolean;
  sort_order: number;
}

export interface DDChecklistProgress {
  id: string;
  case_id: string;
  template_id: string;
  completed: boolean;
  completed_by: string | null;
  completed_at: string | null;
  notes: string | null;
  dd_checklist_templates?: DDChecklistTemplate;
}

export interface DDDocumentCategory {
  id: string;
  category_code: string;
  category_name: string;
  parent_category_code: string | null;
  description: string | null;
  sort_order: number;
  required: boolean;
  created_at: string;
}

export interface DDCategoryProgress {
  id: string;
  case_id: string;
  category_id: string;
  status: DDCategoryStatus;
  document_count: number;
  notes: string | null;
  completed_at: string | null;
  completed_by: string | null;
  created_at: string;
  updated_at: string;
  dd_document_categories?: DDDocumentCategory;
}

export interface DDDocument {
  id: string;
  case_id: string;
  category_id: string | null;
  document_type: DDDocumentType;
  file_name: string;
  file_path: string;
  file_size: number;
  mime_type: string;
  status: DDDocumentStatus;
  uploaded_by: string;
  uploaded_at: string;
  approved_by: string | null;
  approved_at: string | null;
  rejection_reason: string | null;
  notes: string | null;
  comments: string | null;
  archived_at: string | null;
  archived_by: string | null;
  archive_location: string | null;
  original_file_size: number | null;
  dd_document_categories?: DDDocumentCategory;
}

export interface DDCaseWithProgress extends DDCase {
  totalCategories: number;
  completedCategories: number;
  progressPercentage: number;
}

export function useDDCases() {
  return useQuery({
    queryKey: ['dd-cases'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .select(`
          *,
          companies!inner(id, name, logo_url, status)
        `)
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      return data as DDCase[];
    },
  });
}

export function useDDCasesWithProgress() {
  return useQuery({
    queryKey: ['dd-cases-with-progress'],
    queryFn: async () => {
      const { data: cases, error: casesError } = await supabase
        .from('due_diligence_cases')
        .select(`
          *,
          companies(id, name, logo_url, status)
        `)
        .eq('companies.status', 'due_diligence')
        .order('updated_at', { ascending: false });
      
      if (casesError) throw casesError;
      
      // Fetch category progress for all cases
      const { data: progress, error: progressError } = await supabase
        .from('dd_category_progress')
        .select('case_id, status');
      
      if (progressError) throw progressError;
      
      // Calculate progress for each case
      return cases.map(c => {
        const caseProgress = progress.filter(p => p.case_id === c.id);
        const totalCategories = caseProgress.length;
        const completedCategories = caseProgress.filter(
          p => p.status === 'completed'
        ).length;
        
        const progressPercentage = totalCategories > 0 
          ? Math.round((completedCategories / totalCategories) * 100) 
          : 0;
        
        return {
          ...c,
          totalCategories,
          completedCategories,
          progressPercentage
        };
      }) as DDCaseWithProgress[];
    },
  });
}

export function useDDCase(caseId: string | undefined) {
  return useQuery({
    queryKey: ['dd-case', caseId],
    enabled: !!caseId,
    queryFn: async () => {
      if (!caseId) return null;
      
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .select(`
          *,
          companies(id, name, logo_url, cvr, industry)
        `)
        .eq('id', caseId)
        .single();
      
      if (error) throw error;
      return data as DDCase;
    },
  });
}

export function useDDChecklistTemplates() {
  return useQuery({
    queryKey: ['dd-checklist-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dd_checklist_templates')
        .select('*')
        .order('sort_order');
      
      if (error) throw error;
      return data as DDChecklistTemplate[];
    },
  });
}

export function useDDProgress(caseId: string | undefined) {
  return useQuery({
    queryKey: ['dd-progress', caseId],
    enabled: !!caseId,
    queryFn: async () => {
      if (!caseId) return [];
      
      const { data, error } = await supabase
        .from('dd_checklist_progress')
        .select(`
          *,
          dd_checklist_templates(*)
        `)
        .eq('case_id', caseId)
        .order('created_at');
      
      if (error) throw error;
      return data as DDChecklistProgress[];
    },
  });
}

export function useDDCategories() {
  return useQuery({
    queryKey: ['dd-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('dd_document_categories')
        .select('*')
        .order('sort_order');
      
      if (error) throw error;
      return data as DDDocumentCategory[];
    },
  });
}

export function useDDCategoryProgress(caseId: string | undefined) {
  return useQuery({
    queryKey: ['dd-category-progress', caseId],
    enabled: !!caseId,
    queryFn: async () => {
      if (!caseId) return [];
      
      const { data, error } = await supabase
        .from('dd_category_progress')
        .select(`
          *,
          dd_document_categories(*)
        `)
        .eq('case_id', caseId);
      
      if (error) throw error;
      return data as DDCategoryProgress[];
    },
  });
}

export function useDDDocuments(caseId: string | undefined) {
  return useQuery({
    queryKey: ['dd-documents', caseId],
    enabled: !!caseId,
    queryFn: async () => {
      if (!caseId) return [];
      
      const { data, error } = await supabase
        .from('dd_documents')
        .select(`
          *,
          dd_document_categories(*)
        `)
        .eq('case_id', caseId)
        .order('uploaded_at', { ascending: false });
      
      if (error) throw error;
      return data as DDDocument[];
    },
  });
}

export function useCreateDDCase() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (companyId: string) => {
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .insert({
          company_id: companyId,
          status: 'not_started',
          started_at: new Date().toISOString(),
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dd-cases'] });
      toast({
        title: 'DD case oprettet',
        description: 'Due diligence case er blevet oprettet',
      });
    },
    onError: () => {
      toast({
        title: 'Fejl',
        description: 'Kunne ikke oprette DD case',
        variant: 'destructive',
      });
    },
  });
}

export function useUpdateDDCase() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<DDCase> }) => {
      const { data, error } = await supabase
        .from('due_diligence_cases')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['dd-cases'] });
      queryClient.invalidateQueries({ queryKey: ['dd-case', variables.id] });
      toast({
        title: 'Opdateret',
        description: 'DD case er blevet opdateret',
      });
    },
  });
}

export function useToggleDDProgress() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ 
      caseId, 
      templateId, 
      completed, 
      progressId 
    }: { 
      caseId: string; 
      templateId: string; 
      completed: boolean;
      progressId?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      if (progressId) {
        // Update existing progress
        const { data, error } = await supabase
          .from('dd_checklist_progress')
          .update({
            completed,
            completed_by: completed ? user.id : null,
            completed_at: completed ? new Date().toISOString() : null,
          })
          .eq('id', progressId)
          .select()
          .single();
        
        if (error) throw error;
        return data;
      } else {
        // Create new progress entry
        const { data, error } = await supabase
          .from('dd_checklist_progress')
          .insert({
            case_id: caseId,
            template_id: templateId,
            completed,
            completed_by: completed ? user.id : null,
            completed_at: completed ? new Date().toISOString() : null,
          })
          .select()
          .single();
        
        if (error) throw error;
        return data;
      }
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['dd-progress', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-case', variables.caseId] });
    },
  });
}

export function useUpdateCategoryProgress() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({
      caseId,
      categoryId,
      status,
      notes,
    }: {
      caseId: string;
      categoryId: string;
      status: DDCategoryStatus;
      notes?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      const updateData: any = {
        status,
        notes: notes || null,
        updated_at: new Date().toISOString(),
      };

      if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
        updateData.completed_by = user.id;
      } else if (status === 'in_progress') {
        updateData.completed_at = null;
        updateData.completed_by = null;
      }

      const { data, error } = await supabase
        .from('dd_category_progress')
        .update(updateData)
        .eq('case_id', caseId)
        .eq('category_id', categoryId)
        .select()
        .single();

      if (error) throw error;

      // Auto-update DD case status when category is set to in_progress
      if (status === 'in_progress') {
        const { data: ddCase } = await supabase
          .from('due_diligence_cases')
          .select('status')
          .eq('id', caseId)
          .single();

        // Update overall DD case status to in_progress if it's still not_started
        if (ddCase?.status === 'not_started') {
          await supabase
            .from('due_diligence_cases')
            .update({
              status: 'in_progress',
              started_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq('id', caseId);
        }
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['dd-category-progress', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-case', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases'] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases-with-progress'] });
      toast({
        title: 'Status opdateret',
        description: 'Kategoristatus er blevet opdateret',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Opdatering fejlede',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}

export function useUploadDDDocument() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ 
      caseId, 
      categoryId,
      file, 
      documentType,
      notes 
    }: { 
      caseId: string;
      categoryId?: string; 
      file: File; 
      documentType: DDDocumentType;
      notes?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Upload file to storage
      const fileExt = file.name.split('.').pop();
      const timestamp = Date.now();
      const fileName = `dd-documents/${caseId}/${categoryId || 'uncategorized'}/${timestamp}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('company-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Insert document metadata
      const { data, error } = await supabase
        .from('dd_documents')
        .insert({
          case_id: caseId,
          category_id: categoryId || null,
          document_type: documentType,
          file_name: file.name,
          file_path: fileName,
          file_size: file.size,
          mime_type: file.type,
          status: 'uploaded',
          uploaded_by: user.id,
          notes: notes || null,
        })
        .select()
        .single();
      
      if (error) throw error;

      // Check if this is the first document and case status is not_started
      // If so, automatically update the case status to in_progress
      const { data: ddCase } = await supabase
        .from('due_diligence_cases')
        .select('status')
        .eq('id', caseId)
        .single();

      if (ddCase?.status === 'not_started') {
        await supabase
          .from('due_diligence_cases')
          .update({
            status: 'in_progress',
            started_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq('id', caseId);
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['dd-documents', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-category-progress', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-case', variables.caseId] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases'] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases-with-progress'] });
      toast({
        title: 'Dokument uploadet',
        description: 'Dokumentet er blevet uploadet succesfuldt',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Upload fejlede',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
}
