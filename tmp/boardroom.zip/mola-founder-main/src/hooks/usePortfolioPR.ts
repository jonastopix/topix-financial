import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useState } from 'react';

export interface PRArticleWithCompany {
  id: string;
  company_id: string;
  company_name: string;
  title: string;
  source: string | null;
  url: string;
  published_at: string | null;
  snippet: string | null;
  ai_summary: string | null;
  sentiment: 'positive' | 'neutral' | 'negative' | null;
  relevance_score: number | null;
  is_saved: boolean;
  created_at: string;
}

export interface CompanyPRSummary {
  id: string;
  name: string;
  totalArticles: number;
  savedArticles: number;
  positiveCount: number;
  negativeCount: number;
  neutralCount: number;
}

export interface PRStats {
  totalArticles: number;
  savedArticles: number;
  sentimentBreakdown: {
    positive: number;
    neutral: number;
    negative: number;
  };
  articlesByCompany: CompanyPRSummary[];
  recentArticles: PRArticleWithCompany[];
  allCompanies: { id: string; name: string; logo_url: string | null }[];
}

export function usePortfolioPR() {
  const [showOnlySaved, setShowOnlySaved] = useState(true);

  const { data: prData, isLoading, error } = useQuery({
    queryKey: ['portfolio-pr-overview', showOnlySaved],
    queryFn: async () => {
      // Fetch all portfolio companies first
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name, logo_url')
        .eq('is_active', true)
        .order('name');

      if (companiesError) throw companiesError;

      // Fetch PR articles (all or only saved based on toggle)
      let query = supabase
        .from('company_pr_articles')
        .select(`
          id,
          company_id,
          title,
          source,
          url,
          published_at,
          snippet,
          ai_summary,
          sentiment,
          relevance_score,
          is_saved,
          created_at
        `)
        .order('created_at', { ascending: false });

      if (showOnlySaved) {
        query = query.eq('is_saved', true);
      }

      const { data: articles, error: articlesError } = await query;

      if (articlesError) throw articlesError;

      const companyMap = new Map(companies?.map(c => [c.id, c.name]) || []);

      // Merge company names into articles
      const articlesWithCompany: PRArticleWithCompany[] = (articles || []).map(article => ({
        ...article,
        company_name: companyMap.get(article.company_id) || 'Ukendt selskab',
        sentiment: article.sentiment as 'positive' | 'neutral' | 'negative' | null,
      }));

      // Calculate stats
      const sentimentBreakdown = {
        positive: articlesWithCompany.filter(a => a.sentiment === 'positive').length,
        neutral: articlesWithCompany.filter(a => a.sentiment === 'neutral').length,
        negative: articlesWithCompany.filter(a => a.sentiment === 'negative').length,
      };

      // Calculate articles by company (including companies with 0 articles)
      const companyStats = new Map<string, CompanyPRSummary>();

      // Initialize all companies with zero counts
      companies?.forEach(company => {
        companyStats.set(company.id, {
          id: company.id,
          name: company.name,
          totalArticles: 0,
          savedArticles: 0,
          positiveCount: 0,
          negativeCount: 0,
          neutralCount: 0,
        });
      });

      // Count articles per company
      articlesWithCompany.forEach(article => {
        const existing = companyStats.get(article.company_id);
        if (existing) {
          existing.totalArticles++;
          if (article.is_saved) existing.savedArticles++;
          if (article.sentiment === 'positive') existing.positiveCount++;
          if (article.sentiment === 'negative') existing.negativeCount++;
          if (article.sentiment === 'neutral') existing.neutralCount++;
        }
      });

      const articlesByCompany = Array.from(companyStats.values())
        .sort((a, b) => b.totalArticles - a.totalArticles);

      const stats: PRStats = {
        totalArticles: articlesWithCompany.length,
        savedArticles: articlesWithCompany.filter(a => a.is_saved).length,
        sentimentBreakdown,
        articlesByCompany,
        recentArticles: articlesWithCompany.slice(0, 10),
        allCompanies: companies || [],
      };

      return stats;
    },
  });

  return {
    prStats: prData,
    isLoading,
    error,
    showOnlySaved,
    setShowOnlySaved,
  };
}
