import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

export interface SupportContact {
  id: string;
  name: string;
  role: string;
  email: string | null;
  phone: string | null;
  icon_name: string;
  avatar_url: string | null;
  linkedin_url: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export const useSupportContacts = () => {
  return useQuery({
    queryKey: ["support-contacts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("support_contacts")
        .select("*")
        .eq("is_active", true)
        .order("sort_order", { ascending: true });

      if (error) throw error;
      return data as SupportContact[];
    },
  });
};

export const useSupportContactsAdmin = () => {
  return useQuery({
    queryKey: ["support-contacts-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("support_contacts")
        .select("*")
        .order("sort_order", { ascending: true });

      if (error) throw error;
      return data as SupportContact[];
    },
  });
};

export const useCreateSupportContact = () => {
  const queryClient = useQueryClient();

  return useMutation<SupportContact, Error, Omit<SupportContact, "id" | "created_at" | "updated_at">>({
    mutationFn: async (contact: Omit<SupportContact, "id" | "created_at" | "updated_at">) => {
      const { data, error } = await supabase
        .from("support_contacts")
        .insert([contact])
        .select()
        .single();

      if (error) throw error;
      return data as SupportContact;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["support-contacts"] });
      queryClient.invalidateQueries({ queryKey: ["support-contacts-admin"] });
      toast({
        title: "Kontakt oprettet",
        description: "Support kontakt blev oprettet succesfuldt",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fejl",
        description: error.message,
        variant: "destructive",
      });
    },
  });
};

export const useUpdateSupportContact = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<SupportContact> & { id: string }) => {
      const { data, error } = await supabase
        .from("support_contacts")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["support-contacts"] });
      queryClient.invalidateQueries({ queryKey: ["support-contacts-admin"] });
      toast({
        title: "Kontakt opdateret",
        description: "Support kontakt blev opdateret succesfuldt",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fejl",
        description: error.message,
        variant: "destructive",
      });
    },
  });
};

export const useDeleteSupportContact = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("support_contacts")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["support-contacts"] });
      queryClient.invalidateQueries({ queryKey: ["support-contacts-admin"] });
      toast({
        title: "Kontakt slettet",
        description: "Support kontakt blev slettet succesfuldt",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Fejl",
        description: error.message,
        variant: "destructive",
      });
    },
  });
};
