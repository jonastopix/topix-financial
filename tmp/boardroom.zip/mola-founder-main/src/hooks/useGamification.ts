import { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

// XP rewards for different actions
export const XP_REWARDS = {
  activity_logged: 10,
  report_submitted: 50,
  document_uploaded: 15,
  nps_completed: 25,
  daily_challenge_completed: 30,
  streak_bonus_per_day: 5,
  badge_earned: 20,
  task_completed: 10,
  contact_added: 5,
} as const;

// Level thresholds and titles
export const LEVELS = [
  { level: 1, xp: 0, title: 'Begynder', color: 'text-muted-foreground' },
  { level: 2, xp: 100, title: 'Aktiv', color: 'text-blue-500' },
  { level: 3, xp: 300, title: 'Erfaren', color: 'text-green-500' },
  { level: 4, xp: 600, title: 'Veteran', color: 'text-yellow-500' },
  { level: 5, xp: 1000, title: 'Mester', color: 'text-orange-500' },
  { level: 6, xp: 1500, title: 'Ekspert', color: 'text-purple-500' },
  { level: 7, xp: 2500, title: 'Legende', color: 'text-red-500' },
] as const;

export type XpEventType = keyof typeof XP_REWARDS;

export interface GamificationStats {
  xp: number;
  level: number;
  levelTitle: string;
  levelColor: string;
  xpToNextLevel: number;
  xpProgress: number;
  activityStreak: number;
  lastActivityDate: string | null;
  streakFreezeCount: number;
  personalBests: Record<string, number>;
}

export interface XpEvent {
  id: string;
  user_id: string;
  xp_amount: number;
  event_type: string;
  event_description: string | null;
  created_at: string;
}

export interface LeaderboardEntry {
  user_id: string;
  full_name: string;
  avatar_url: string | null;
  xp: number;
  level: number;
  activity_streak: number;
  rank: number;
}

export function useGamification() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [levelUpCelebration, setLevelUpCelebration] = useState<number | null>(null);

  // Fetch current user's gamification stats
  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['gamification-stats', user?.id],
    queryFn: async (): Promise<GamificationStats> => {
      if (!user?.id) throw new Error('No user');

      const { data, error } = await supabase
        .from('profiles')
        .select('xp, level, activity_streak, last_activity_date, streak_freeze_count, personal_bests')
        .eq('id', user.id)
        .single();

      if (error) throw error;

      const xp = data.xp || 0;
      const level = data.level || 1;
      const levelConfig = LEVELS.find(l => l.level === level) || LEVELS[0];
      const nextLevelConfig = LEVELS.find(l => l.level === level + 1);

      const xpToNextLevel = nextLevelConfig ? nextLevelConfig.xp - xp : 0;
      const currentLevelXp = levelConfig.xp;
      const nextLevelXp = nextLevelConfig?.xp || levelConfig.xp;
      const xpProgress = nextLevelConfig 
        ? ((xp - currentLevelXp) / (nextLevelXp - currentLevelXp)) * 100
        : 100;

      return {
        xp,
        level,
        levelTitle: levelConfig.title,
        levelColor: levelConfig.color,
        xpToNextLevel,
        xpProgress: Math.min(100, Math.max(0, xpProgress)),
        activityStreak: data.activity_streak || 0,
        lastActivityDate: data.last_activity_date,
        streakFreezeCount: data.streak_freeze_count || 0,
        personalBests: (data.personal_bests as Record<string, number>) || {},
      };
    },
    enabled: !!user?.id,
  });

  // Fetch XP history
  const { data: xpHistory } = useQuery({
    queryKey: ['xp-history', user?.id],
    queryFn: async (): Promise<XpEvent[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('xp_events')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Fetch leaderboard
  const { data: leaderboard } = useQuery({
    queryKey: ['gamification-leaderboard'],
    queryFn: async (): Promise<LeaderboardEntry[]> => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, avatar_url, xp, level, activity_streak')
        .not('xp', 'is', null)
        .order('xp', { ascending: false })
        .limit(10);

      if (error) throw error;

      return (data || []).map((entry, index) => ({
        user_id: entry.id,
        full_name: entry.full_name || 'Anonym',
        avatar_url: entry.avatar_url,
        xp: entry.xp || 0,
        level: entry.level || 1,
        activity_streak: entry.activity_streak || 0,
        rank: index + 1,
      }));
    },
  });

  // Award XP mutation using the database function
  const awardXpMutation = useMutation({
    mutationFn: async ({ 
      eventType, 
      description, 
      customAmount 
    }: { 
      eventType: XpEventType; 
      description?: string;
      customAmount?: number;
    }) => {
      if (!user?.id) throw new Error('No user');

      const xpAmount = customAmount || XP_REWARDS[eventType];

      const { data, error } = await supabase
        .rpc('award_xp', {
          p_user_id: user.id,
          p_amount: xpAmount,
          p_event_type: eventType,
          p_description: description || null,
        });

      if (error) throw error;
      return data?.[0] || { new_xp: 0, new_level: 1, leveled_up: false };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['gamification-stats'] });
      queryClient.invalidateQueries({ queryKey: ['xp-history'] });
      queryClient.invalidateQueries({ queryKey: ['gamification-leaderboard'] });

      if (result.leveled_up) {
        setLevelUpCelebration(result.new_level);
        const levelConfig = LEVELS.find(l => l.level === result.new_level);
        toast.success(`🎉 Level Up! Du er nu ${levelConfig?.title || 'Level ' + result.new_level}!`);
      }
    },
  });

  // Update streak mutation
  const updateStreakMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error('No user');

      const { data, error } = await supabase
        .rpc('update_activity_streak', {
          p_user_id: user.id,
        });

      if (error) throw error;
      return data?.[0] || { new_streak: 0, streak_bonus: 0 };
    },
    onSuccess: async (result) => {
      queryClient.invalidateQueries({ queryKey: ['gamification-stats'] });

      // Award streak bonus XP if any
      if (result.streak_bonus > 0) {
        await awardXpMutation.mutateAsync({
          eventType: 'streak_bonus_per_day' as XpEventType,
          description: `Streak bonus (${result.new_streak} dage)`,
          customAmount: result.streak_bonus,
        });
        toast.success(`🔥 ${result.new_streak} dages streak! +${result.streak_bonus} XP bonus`);
      }
    },
  });

  // Use streak freeze
  const useStreakFreezeMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error('No user');
      if (!stats || stats.streakFreezeCount <= 0) {
        throw new Error('Ingen streak freeze tilgængelig');
      }

      const { error } = await supabase
        .from('profiles')
        .update({ 
          streak_freeze_count: stats.streakFreezeCount - 1,
          last_activity_date: new Date().toISOString().split('T')[0],
        })
        .eq('id', user.id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gamification-stats'] });
      toast.success('❄️ Streak freeze brugt! Din streak er bevaret');
    },
  });

  // Buy streak freeze (costs 50 XP)
  const buyStreakFreezeMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error('No user');
      if (!stats || stats.xp < 50) {
        throw new Error('Ikke nok XP (kræver 50 XP)');
      }
      if (stats.streakFreezeCount >= 2) {
        throw new Error('Max 2 streak freezes');
      }

      // Deduct XP
      const { error: xpError } = await supabase
        .from('profiles')
        .update({ 
          xp: stats.xp - 50,
          streak_freeze_count: stats.streakFreezeCount + 1,
        })
        .eq('id', user.id);

      if (xpError) throw xpError;

      // Log the XP deduction
      const { error: logError } = await supabase
        .from('xp_events')
        .insert({
          user_id: user.id,
          xp_amount: -50,
          event_type: 'streak_freeze_purchase',
          event_description: 'Købte streak freeze',
        });

      if (logError) throw logError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['gamification-stats'] });
      queryClient.invalidateQueries({ queryKey: ['xp-history'] });
      toast.success('❄️ Streak freeze købt! (-50 XP)');
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  // Get user's rank
  const userRank = useMemo(() => {
    if (!leaderboard || !user?.id) return null;
    const entry = leaderboard.find(e => e.user_id === user.id);
    return entry?.rank || null;
  }, [leaderboard, user?.id]);

  // Calculate XP earned today
  const xpEarnedToday = useMemo(() => {
    if (!xpHistory) return 0;
    const today = new Date().toISOString().split('T')[0];
    return xpHistory
      .filter(e => e.created_at.startsWith(today))
      .reduce((sum, e) => sum + e.xp_amount, 0);
  }, [xpHistory]);

  // Clear level up celebration
  const clearLevelUpCelebration = () => setLevelUpCelebration(null);

  return {
    stats,
    isLoading: statsLoading,
    xpHistory,
    leaderboard,
    userRank,
    xpEarnedToday,
    levelUpCelebration,
    clearLevelUpCelebration,
    awardXp: awardXpMutation.mutateAsync,
    updateStreak: updateStreakMutation.mutateAsync,
    useStreakFreeze: useStreakFreezeMutation.mutateAsync,
    buyStreakFreeze: buyStreakFreezeMutation.mutateAsync,
    isAwarding: awardXpMutation.isPending,
  };
}
