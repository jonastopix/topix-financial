import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface ROASCalculationInput {
  average_order_value: number;
  cost_of_goods: number | null;
  margin_percentage: number | null;
  input_mode: 'cogs' | 'margin';
  shipping_cost: number;
  packaging_cost: number;
  fulfillment_cost: number;
  other_cost: number;
  payment_fee_percentage: number;
  payment_fee_fixed: number;
  contribution_margin: number;
  breakeven_roas: number;
  return_rate_percentage: number | null;
  notes?: string;
}

export interface ROASCalculation extends ROASCalculationInput {
  id: string;
  company_id: string;
  created_at: string;
  return_rate_percentage: number | null;
}

export function useROASCalculations(companyId: string | undefined) {
  const queryClient = useQueryClient();

  const { data: calculations, isLoading } = useQuery({
    queryKey: ['roas-calculations', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      
      const { data, error } = await supabase
        .from('roas_calculations')
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as ROASCalculation[];
    },
    enabled: !!companyId,
  });

  const saveCalculation = useMutation({
    mutationFn: async (calculation: ROASCalculationInput) => {
      if (!companyId) throw new Error('Company ID required');
      
      const { data, error } = await supabase
        .from('roas_calculations')
        .insert({
          company_id: companyId,
          average_order_value: calculation.average_order_value,
          cost_of_goods: calculation.cost_of_goods,
          margin_percentage: calculation.margin_percentage,
          input_mode: calculation.input_mode,
          shipping_cost: calculation.shipping_cost,
          packaging_cost: calculation.packaging_cost,
          fulfillment_cost: calculation.fulfillment_cost,
          other_cost: calculation.other_cost,
          payment_fee_percentage: calculation.payment_fee_percentage,
          payment_fee_fixed: calculation.payment_fee_fixed,
          contribution_margin: calculation.contribution_margin,
          breakeven_roas: calculation.breakeven_roas,
          return_rate_percentage: calculation.return_rate_percentage,
          notes: calculation.notes || null,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roas-calculations', companyId] });
      toast.success('Beregning gemt!');
    },
    onError: (error) => {
      console.error('Error saving calculation:', error);
      toast.error('Kunne ikke gemme beregning');
    },
  });

  const deleteCalculation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('roas_calculations')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roas-calculations', companyId] });
      toast.success('Beregning slettet');
    },
    onError: (error) => {
      console.error('Error deleting calculation:', error);
      toast.error('Kunne ikke slette beregning');
    },
  });

  return {
    calculations: calculations ?? [],
    isLoading,
    saveCalculation,
    deleteCalculation,
  };
}
