import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface FundingRound {
  id: string;
  company_id: string;
  fund_id?: string;
  round_name: string;
  invested_amount_dkk: number;
  equity_acquired_pct: number;
  pre_money_valuation_dkk?: number;
  post_money_valuation_dkk?: number;
  invested_at: string;
  round_type: string;
  note?: string;
  seller_name?: string;
  is_secondary?: boolean;
  created_at: string;
  updated_at: string;
}

export interface FundingRoundInput {
  company_id: string;
  fund_id?: string;
  round_name: string;
  invested_amount_dkk: number;
  equity_acquired_pct: number;
  pre_money_valuation_dkk?: number;
  post_money_valuation_dkk?: number;
  invested_at: string;
  round_type: string;
  note?: string;
  seller_name?: string;
  is_secondary?: boolean;
}

export function useFundingRounds(companyId?: string) {
  return useQuery({
    queryKey: ['funding-rounds', companyId],
    queryFn: async () => {
      let query = supabase
        .from('funding_rounds')
        .select('*')
        .order('invested_at', { ascending: true });
      
      if (companyId) {
        query = query.eq('company_id', companyId);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as FundingRound[];
    },
    enabled: !!companyId,
  });
}

export function useFundingRoundMutations() {
  const queryClient = useQueryClient();

  const createFundingRound = useMutation({
    mutationFn: async (input: FundingRoundInput) => {
      const { data, error } = await supabase
        .from('funding_rounds')
        .insert(input)
        .select()
        .single();

      if (error) throw error;

      // Auto-create valuation if post_money_valuation_dkk exists
      if (data.post_money_valuation_dkk) {
        await supabase.from('valuations').insert({
          company_id: data.company_id,
          post_money_valuation_dkk: data.post_money_valuation_dkk,
          as_of_date: data.invested_at,
          source: `Funding Round: ${data.round_name}`,
        });
      }

      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['funding-rounds', data.company_id] });
      queryClient.invalidateQueries({ queryKey: ['company-data'] });
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['valuations'] });
      queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
      queryClient.invalidateQueries({ queryKey: ['company-returns'] });
      toast.success('Funding round tilføjet');
    },
    onError: (error: any) => {
      toast.error('Kunne ikke tilføje funding round: ' + error.message);
    },
  });

  const updateFundingRound = useMutation({
    mutationFn: async ({ id, ...input }: Partial<FundingRound> & { id: string }) => {
      const { data, error } = await supabase
        .from('funding_rounds')
        .update(input)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // Update or create valuation if post_money_valuation_dkk exists
      if (data.post_money_valuation_dkk && data.invested_at) {
        const source = `Funding Round: ${data.round_name}`;
        
        // Check if valuation already exists for this funding round
        const { data: existingValuation } = await supabase
          .from('valuations')
          .select('id')
          .eq('company_id', data.company_id)
          .eq('source', source)
          .single();

        if (existingValuation) {
          // Update existing valuation
          await supabase
            .from('valuations')
            .update({
              post_money_valuation_dkk: data.post_money_valuation_dkk,
              as_of_date: data.invested_at,
            })
            .eq('id', existingValuation.id);
        } else {
          // Create new valuation
          await supabase.from('valuations').insert({
            company_id: data.company_id,
            post_money_valuation_dkk: data.post_money_valuation_dkk,
            as_of_date: data.invested_at,
            source,
          });
        }
      }

      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['funding-rounds', data.company_id] });
      queryClient.invalidateQueries({ queryKey: ['company-data'] });
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['valuations'] });
      queryClient.invalidateQueries({ queryKey: ['companies-valuations'] });
      queryClient.invalidateQueries({ queryKey: ['company-returns'] });
      toast.success('Funding round opdateret');
    },
    onError: (error: any) => {
      toast.error('Kunne ikke opdatere funding round: ' + error.message);
    },
  });

  const deleteFundingRound = useMutation({
    mutationFn: async ({ id, companyId }: { id: string; companyId: string }) => {
      const { error } = await supabase
        .from('funding_rounds')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { companyId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['funding-rounds', data.companyId] });
      queryClient.invalidateQueries({ queryKey: ['company-data'] });
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      toast.success('Funding round slettet');
    },
    onError: (error: any) => {
      toast.error('Kunne ikke slette funding round: ' + error.message);
    },
  });

  return {
    createFundingRound,
    updateFundingRound,
    deleteFundingRound,
  };
}
