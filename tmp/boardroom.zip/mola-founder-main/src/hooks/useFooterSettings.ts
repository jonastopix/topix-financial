import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface FooterSetting {
  id: string;
  section_key: string;
  content: any;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface FooterLink {
  id: string;
  category: string;
  title: string;
  url: string;
  icon_name?: string;
  sort_order: number;
  is_active: boolean;
  is_external: boolean;
  created_at: string;
  updated_at: string;
}

export const useFooterSettings = () => {
  return useQuery({
    queryKey: ["footer-settings"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("footer_settings")
        .select("*")
        .order("sort_order");

      if (error) throw error;
      return data as FooterSetting[];
    },
  });
};

export const useFooterLinks = (category?: string) => {
  return useQuery({
    queryKey: ["footer-links", category],
    queryFn: async () => {
      let query = supabase
        .from("footer_links")
        .select("*")
        .order("sort_order");

      if (category) {
        query = query.eq("category", category);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as FooterLink[];
    },
  });
};

export const useUpdateFooterSetting = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      updates,
    }: {
      id: string;
      updates: Partial<FooterSetting>;
    }) => {
      const { data, error } = await supabase
        .from("footer_settings")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["footer-settings"] });
      toast.success("Footer indstilling opdateret");
    },
    onError: (error) => {
      console.error("Error updating footer setting:", error);
      toast.error("Kunne ikke opdatere footer indstilling");
    },
  });
};

export const useCreateFooterLink = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (link: Omit<FooterLink, "id" | "created_at" | "updated_at">) => {
      const { data, error } = await supabase
        .from("footer_links")
        .insert(link)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["footer-links"] });
      toast.success("Link tilføjet");
    },
    onError: (error) => {
      console.error("Error creating footer link:", error);
      toast.error("Kunne ikke tilføje link");
    },
  });
};

export const useUpdateFooterLink = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      id,
      updates,
    }: {
      id: string;
      updates: Partial<FooterLink>;
    }) => {
      const { data, error } = await supabase
        .from("footer_links")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["footer-links"] });
      toast.success("Link opdateret");
    },
    onError: (error) => {
      console.error("Error updating footer link:", error);
      toast.error("Kunne ikke opdatere link");
    },
  });
};

export const useDeleteFooterLink = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("footer_links")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["footer-links"] });
      toast.success("Link slettet");
    },
    onError: (error) => {
      console.error("Error deleting footer link:", error);
      toast.error("Kunne ikke slette link");
    },
  });
};
