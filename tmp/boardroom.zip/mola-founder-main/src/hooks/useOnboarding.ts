import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';

interface OnboardingProgress {
  id: string;
  user_id: string;
  role: string;
  version_seen: number;
  completed_steps: string[];
  completed_at: string | null;
  dismissed_at: string | null;
  created_at: string;
  updated_at: string;
}

export function useOnboarding() {
  const { user } = useAuth();
  const { activeRole } = useRole();
  const queryClient = useQueryClient();

  const queryKey = ['onboarding-progress', user?.id, activeRole];

  const { data: progress, isLoading } = useQuery({
    queryKey,
    queryFn: async () => {
      if (!user) return null;

      const { data, error } = await supabase
        .from('onboarding_progress')
        .select('*')
        .eq('user_id', user.id)
        .eq('role', activeRole)
        .maybeSingle();

      if (error) {
        console.error('Error fetching onboarding progress:', error);
        return null;
      }

      return data as OnboardingProgress | null;
    },
    enabled: !!user,
  });

  const createProgress = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error('No user');

      const { data, error } = await supabase
        .from('onboarding_progress')
        .insert({
          user_id: user.id,
          role: activeRole,
          version_seen: 0,
          completed_steps: [],
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const updateProgress = useMutation({
    mutationFn: async (updates: Partial<Pick<OnboardingProgress, 'version_seen' | 'completed_steps' | 'completed_at' | 'dismissed_at'>>) => {
      if (!user || !progress) throw new Error('No user or progress');

      const { data, error } = await supabase
        .from('onboarding_progress')
        .update(updates)
        .eq('id', progress.id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const markStepComplete = async (stepId: string) => {
    if (!progress) {
      // Create progress first, then add step
      const newProgress = await createProgress.mutateAsync();
      await supabase
        .from('onboarding_progress')
        .update({ completed_steps: [stepId] })
        .eq('id', newProgress.id);
      queryClient.invalidateQueries({ queryKey });
      return;
    }

    const newCompletedSteps = [...(progress.completed_steps || [])];
    if (!newCompletedSteps.includes(stepId)) {
      newCompletedSteps.push(stepId);
    }

    await updateProgress.mutateAsync({ completed_steps: newCompletedSteps });
  };

  const completeOnboarding = async (version: number) => {
    if (!progress) {
      const newProgress = await createProgress.mutateAsync();
      await supabase
        .from('onboarding_progress')
        .update({ 
          version_seen: version, 
          completed_at: new Date().toISOString() 
        })
        .eq('id', newProgress.id);
      queryClient.invalidateQueries({ queryKey });
      return;
    }

    await updateProgress.mutateAsync({
      version_seen: version,
      completed_at: new Date().toISOString(),
    });
  };

  const dismissWhatsNew = async () => {
    if (!progress) return;

    await updateProgress.mutateAsync({
      dismissed_at: new Date().toISOString(),
    });
  };

  const resetOnboarding = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error('No user');

      const { error } = await supabase
        .from('onboarding_progress')
        .delete()
        .eq('user_id', user.id)
        .eq('role', activeRole);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const ensureProgressExists = async () => {
    if (!user) return null;
    if (progress) return progress;

    try {
      return await createProgress.mutateAsync();
    } catch (error) {
      // Progress might already exist due to race condition
      queryClient.invalidateQueries({ queryKey });
      return null;
    }
  };

  return {
    progress,
    isLoading,
    markStepComplete,
    completeOnboarding,
    dismissWhatsNew,
    resetOnboarding: resetOnboarding.mutateAsync,
    isResettingOnboarding: resetOnboarding.isPending,
    ensureProgressExists,
  };
}
