import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { 
  calculateDPI, 
  calculateTVPI, 
  calculateDistributions, 
  calculateUnrealizedValue,
  type Dividend,
  type Exit
} from '@/lib/returnsCalculations';

export function usePortfolioMetrics(fundFilter?: string) {
  return useQuery({
    queryKey: ['portfolio-metrics', fundFilter],
    queryFn: async () => {
      // Get ALL companies for historical total invested
      let allCompaniesQuery = supabase
        .from('companies')
        .select('id, invested_amount_dkk, equity_share_pct, total_equity_share_pct, status, fund_id');

      if (fundFilter && fundFilter !== 'all') {
        allCompaniesQuery = allCompaniesQuery.eq('fund_id', fundFilter);
      }

      const { data: allCompanies, error: allCompaniesError } = await allCompaniesQuery;
      if (allCompaniesError) throw allCompaniesError;

      // Get active companies (excluding exited, bankruptcy, rejected) for active count
      const activeCompanies = allCompanies?.filter(c => 
        !['exited', 'bankruptcy', 'rejected'].includes(c.status)
      ) || [];

      const allCompanyIds = allCompanies?.map(c => c.id) || [];

      // Get due diligence cases
      const { data: ddCases, error: ddError } = await supabase
        .from('due_diligence_cases')
        .select('id, status')
        .in('status', ['in_progress', 'pending_review']);
      if (ddError) throw ddError;

      // Get dividends for ALL companies
      const { data: dividends, error: dividendsError } = await supabase
        .from('dividends')
        .select('*')
        .in('company_id', allCompanyIds);
      if (dividendsError) throw dividendsError;

      // Get exits for ALL companies
      const { data: exits, error: exitsError } = await supabase
        .from('exits')
        .select('*')
        .in('company_id', allCompanyIds);
      if (exitsError) throw exitsError;

      // Get valuations (latest for each company)
      const { data: valuations, error: valuationsError } = await supabase
        .from('valuations')
        .select('*')
        .in('company_id', allCompanyIds)
        .order('as_of_date', { ascending: false });
      if (valuationsError) throw valuationsError;

      // Get funding rounds for all companies
      const { data: fundingRounds, error: fundingRoundsError } = await supabase
        .from('funding_rounds')
        .select('*')
        .in('company_id', allCompanyIds);
      if (fundingRoundsError) throw fundingRoundsError;

      // Calculate metrics
      // Historical total: ALL companies regardless of status
      const totalInvested = allCompanies?.reduce((sum, c) => sum + (c.invested_amount_dkk || 0), 0) || 0;
      
      // Active invested: companies NOT exited, bankruptcy, or rejected
      const activeInvested = activeCompanies?.reduce((sum, c) => sum + (c.invested_amount_dkk || 0), 0) || 0;

      // Calculate DPI and TVPI for portfolio using ALL companies (including exited)
      // This gives accurate returns picture including realized exits
      let portfolioDPI = 0;
      let portfolioTVPI = 0;
      
      if (allCompanies && allCompanies.length > 0) {
        const portfolioData = allCompanies.map(company => {
          const companyDividends = dividends?.filter(d => d.company_id === company.id) || [];
          const companyExits = exits?.filter(e => e.company_id === company.id) || [];
          const companyValuations = valuations?.filter(v => v.company_id === company.id) || [];
          const latestValuation = companyValuations[0] || null;
          const companyFundingRounds = fundingRounds?.filter(f => f.company_id === company.id) || [];

          // Calculate equity with priority: sum of funding_rounds > total_equity_share_pct > equity_share_pct
          let equityPct = 0;
          if (companyFundingRounds.length > 0) {
            equityPct = companyFundingRounds.reduce((sum, r) => sum + (r.equity_acquired_pct || 0), 0);
          } else {
            equityPct = company.equity_share_pct || 0;
          }

          const paidIn = company.invested_amount_dkk || 0;
          const distributions = calculateDistributions(companyDividends as Dividend[], companyExits as Exit[]);
          const unrealizedValue = calculateUnrealizedValue(latestValuation, equityPct, companyExits as Exit[]);

          const dpi = calculateDPI(distributions, paidIn);
          const tvpi = calculateTVPI(distributions, unrealizedValue, paidIn);

          return { dpi, tvpi, invested: paidIn };
        });

        // Weighted average DPI and TVPI using total historical invested as denominator
        if (totalInvested > 0) {
          portfolioDPI = portfolioData.reduce((sum, p) => sum + (p.dpi * p.invested), 0) / totalInvested;
          portfolioTVPI = portfolioData.reduce((sum, p) => sum + (p.tvpi * p.invested), 0) / totalInvested;
        }
      }

      // Calculate YTD dividends and exits
      const currentYear = new Date().getFullYear();
      const ytdDividends = dividends
        ?.filter(d => new Date(d.declared_date).getFullYear() === currentYear)
        .reduce((sum, d) => sum + (d.amount_dkk || 0), 0) || 0;

      const ytdExits = exits
        ?.filter(e => new Date(e.closing_date).getFullYear() === currentYear)
        .reduce((sum, e) => {
          const net = (e.gross_sale_amount_dkk || 0) - (e.transaction_costs_dkk || 0);
          return sum + net;
        }, 0) || 0;

      return {
        activeInvestments: activeCompanies?.length || 0,
        dueDiligenceCases: ddCases?.length || 0,
        totalInvested, // Historical total (all companies)
        activeInvested, // Currently active investments only
        dpi: portfolioDPI, // Uses totalInvested as denominator
        tvpi: portfolioTVPI, // Uses totalInvested as denominator
        ytdDividends,
        ytdExits,
      };
    },
  });
}
