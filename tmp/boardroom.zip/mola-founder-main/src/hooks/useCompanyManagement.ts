import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export type CompanyStatus = 'new_investment' | 'due_diligence' | 'active' | 'exited' | 'bankruptcy' | 'rejected';

export interface CompanyFormData {
  name: string;
  cvr?: string;
  founded_date?: string;
  company_type?: string;
  industry?: string;
  description?: string;
  business_model?: string;
  target_market?: string;
  growth_stage?: string;
  address?: string;
  city?: string;
  zipcode?: string;
  phone?: string;
  email?: string;
  logo_url?: string;
  google_drive_url?: string;
  fund_id?: string;
  invested_amount_dkk?: number;
  equity_share_pct?: number;
  invested_at?: string;
  is_active: boolean;
  status?: CompanyStatus;
  has_board?: boolean;
  board_formation_date?: string;
  fiscal_year_end_month?: number;
  fiscal_year_end_day?: number;
  accountant_name?: string;
  accountant_email?: string;
}

export function useCompanyManagement() {
  const queryClient = useQueryClient();

  const createCompany = useMutation({
    mutationFn: async (companyData: CompanyFormData) => {
      // Create company
      const { data: company, error: companyError } = await supabase
        .from('companies')
        .insert(companyData)
        .select()
        .single();

      if (companyError) throw companyError;

      // Auto-create DD case
      const { error: ddError } = await supabase
        .from('due_diligence_cases')
        .insert({
          company_id: company.id,
          status: 'not_started',
        });

      if (ddError) throw ddError;

      // Auto-create initial funding round if investment data exists
      if (company.invested_at && company.invested_amount_dkk && company.equity_share_pct) {
        const postMoneyValuation = company.invested_amount_dkk / (company.equity_share_pct / 100);
        
        const { error: fundingError } = await supabase
          .from('funding_rounds')
          .insert({
            company_id: company.id,
            fund_id: company.fund_id,
            round_name: 'Initial Investment',
            round_type: 'initial',
            invested_amount_dkk: company.invested_amount_dkk,
            equity_acquired_pct: company.equity_share_pct,
            post_money_valuation_dkk: postMoneyValuation,
            invested_at: company.invested_at,
            note: 'Auto-generated from company creation',
          });

        if (fundingError) throw fundingError;
      }

      return company;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies-all'] });
      queryClient.invalidateQueries({ queryKey: ['due-diligence-cases'] });
      toast.success('Selskab oprettet med DD case');
    },
    onError: (error: any) => {
      // Check for duplicate CVR error
      if (error.code === '23505' && error.message.includes('companies_cvr_unique')) {
        toast.error('Et selskab med dette CVR-nummer eksisterer allerede');
      } else {
        toast.error('Fejl ved oprettelse af selskab: ' + error.message);
      }
    },
  });

  const updateCompany = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<CompanyFormData> }) => {
      const { data: company, error } = await supabase
        .from('companies')
        .update(data)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return company;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies-all'] });
      toast.success('Selskab opdateret');
    },
    onError: (error: any) => {
      // Check for duplicate CVR error
      if (error.code === '23505' && error.message.includes('companies_cvr_unique')) {
        toast.error('Et selskab med dette CVR-nummer eksisterer allerede');
      } else {
        toast.error('Fejl ved opdatering: ' + error.message);
      }
    },
  });

  const archiveCompany = useMutation({
    mutationFn: async (companyId: string) => {
      const { error } = await supabase
        .from('companies')
        .update({ 
          status: 'archived',
          is_active: false
        })
        .eq('id', companyId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies-all'] });
      toast.success('Selskab arkiveret');
    },
    onError: (error: any) => {
      toast.error('Fejl ved arkivering: ' + error.message);
    },
  });

  const updateCompanyStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: CompanyStatus }) => {
      // 1. Update company status
      const { data: company, error } = await supabase
        .from('companies')
        .update({ status })
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      // 2. If status is 'due_diligence', handle DD case
      if (status === 'due_diligence') {
        const { data: existingCase, error: caseError } = await supabase
          .from('due_diligence_cases')
          .select('id, status')
          .eq('company_id', id)
          .maybeSingle();

        if (caseError) throw caseError;

        if (!existingCase) {
          // Create new DD case if it doesn't exist
          const { error: createError } = await supabase
            .from('due_diligence_cases')
            .insert({
              company_id: id,
              status: 'not_started',
              started_at: new Date().toISOString(),
            });
          
          if (createError) throw createError;
        } else if (existingCase.status === 'approved' || existingCase.status === 'rejected') {
          // Reopen DD case if it was completed
          const { error: updateError } = await supabase
            .from('due_diligence_cases')
            .update({
              status: 'in_progress',
              started_at: new Date().toISOString(),
            })
            .eq('id', existingCase.id);
          
          if (updateError) throw updateError;
        }
      }

      // 3. If status is 'active', update DD case to 'approved' (if pending review)
      if (status === 'active') {
        const { data: existingCase } = await supabase
          .from('due_diligence_cases')
          .select('id, status')
          .eq('company_id', id)
          .maybeSingle();

        if (existingCase && existingCase.status === 'pending_review') {
          await supabase
            .from('due_diligence_cases')
            .update({
              status: 'approved',
              completed_at: new Date().toISOString(),
            })
            .eq('id', existingCase.id);
        }
      }

      return company;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      queryClient.invalidateQueries({ queryKey: ['companies-all'] });
      queryClient.invalidateQueries({ queryKey: ['dd-cases-with-progress'] });
      queryClient.invalidateQueries({ queryKey: ['due-diligence-cases'] });
      toast.success('Status opdateret');
    },
    onError: (error: any) => {
      toast.error('Fejl ved opdatering af status: ' + error.message);
    },
  });

  return {
    createCompany,
    updateCompany,
    archiveCompany,
    updateCompanyStatus,
  };
}
