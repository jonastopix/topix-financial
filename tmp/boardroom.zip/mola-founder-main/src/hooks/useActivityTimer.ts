import { useState, useEffect, useCallback } from 'react';

const TIMER_STORAGE_KEY = 'activity_timer_state';

interface TimerState {
  isRunning: boolean;
  startTime: number | null;
  companyId: string | null;
  companyName: string | null;
  activityType: string | null;
}

interface SavedTimerState extends TimerState {
  savedAt: number;
}

export function useActivityTimer() {
  const [timerState, setTimerState] = useState<TimerState>({
    isRunning: false,
    startTime: null,
    companyId: null,
    companyName: null,
    activityType: null,
  });
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Load saved state on mount
  useEffect(() => {
    const savedState = localStorage.getItem(TIMER_STORAGE_KEY);
    if (savedState) {
      try {
        const parsed: SavedTimerState = JSON.parse(savedState);
        // Only restore if saved within last 24 hours
        if (Date.now() - parsed.savedAt < 24 * 60 * 60 * 1000) {
          setTimerState({
            isRunning: parsed.isRunning,
            startTime: parsed.startTime,
            companyId: parsed.companyId,
            companyName: parsed.companyName,
            activityType: parsed.activityType,
          });
        } else {
          localStorage.removeItem(TIMER_STORAGE_KEY);
        }
      } catch (e) {
        localStorage.removeItem(TIMER_STORAGE_KEY);
      }
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    if (timerState.isRunning) {
      const saveState: SavedTimerState = {
        ...timerState,
        savedAt: Date.now(),
      };
      localStorage.setItem(TIMER_STORAGE_KEY, JSON.stringify(saveState));
    } else {
      localStorage.removeItem(TIMER_STORAGE_KEY);
    }
  }, [timerState]);

  // Update elapsed time every second
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (timerState.isRunning && timerState.startTime) {
      interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - timerState.startTime!) / 1000);
        setElapsedSeconds(elapsed);
      }, 1000);
    } else {
      setElapsedSeconds(0);
    }

    return () => clearInterval(interval);
  }, [timerState.isRunning, timerState.startTime]);

  const startTimer = useCallback((
    companyId: string,
    companyName: string,
    activityType: string = 'meeting'
  ) => {
    setTimerState({
      isRunning: true,
      startTime: Date.now(),
      companyId,
      companyName,
      activityType,
    });
  }, []);

  const stopTimer = useCallback(() => {
    const result = {
      durationMinutes: Math.ceil(elapsedSeconds / 60),
      elapsedSeconds,
      companyId: timerState.companyId,
      companyName: timerState.companyName,
      activityType: timerState.activityType,
    };

    setTimerState({
      isRunning: false,
      startTime: null,
      companyId: null,
      companyName: null,
      activityType: null,
    });
    setElapsedSeconds(0);

    return result;
  }, [elapsedSeconds, timerState]);

  const cancelTimer = useCallback(() => {
    setTimerState({
      isRunning: false,
      startTime: null,
      companyId: null,
      companyName: null,
      activityType: null,
    });
    setElapsedSeconds(0);
    localStorage.removeItem(TIMER_STORAGE_KEY);
  }, []);

  // Format elapsed time as HH:MM:SS
  const formatElapsedTime = useCallback(() => {
    const hours = Math.floor(elapsedSeconds / 3600);
    const minutes = Math.floor((elapsedSeconds % 3600) / 60);
    const seconds = elapsedSeconds % 60;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }, [elapsedSeconds]);

  // Get elapsed minutes (rounded up)
  const getElapsedMinutes = useCallback(() => {
    return Math.ceil(elapsedSeconds / 60);
  }, [elapsedSeconds]);

  return {
    isRunning: timerState.isRunning,
    companyId: timerState.companyId,
    companyName: timerState.companyName,
    activityType: timerState.activityType,
    elapsedSeconds,
    elapsedTime: formatElapsedTime(),
    elapsedMinutes: getElapsedMinutes(),
    startTimer,
    stopTimer,
    cancelTimer,
  };
}
