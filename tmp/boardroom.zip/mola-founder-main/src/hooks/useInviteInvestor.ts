import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface InviteInvestorParams {
  capTableEntryId: string;
  email: string;
  companyId: string;
}

export function useInviteInvestor() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ capTableEntryId, email, companyId }: InviteInvestorParams) => {
      const { data, error } = await supabase.functions.invoke('invite-investor', {
        body: { capTableEntryId, email, companyId }
      });

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['cap-table', variables.companyId] });
      toast.success('Investor invitation sendt');
    },
    onError: (error) => {
      toast.error('Fejl ved invitation af investor: ' + error.message);
    },
  });
}
