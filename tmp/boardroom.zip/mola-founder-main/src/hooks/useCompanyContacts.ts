import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CompanyContact {
  id: string;
  company_id: string;
  name: string;
  role: string;
  email?: string;
  phone?: string;
  notes?: string;
  is_primary: boolean;
  created_at: string;
  updated_at: string;
}

export interface CreateContactInput {
  company_id: string;
  name: string;
  role: string;
  email?: string;
  phone?: string;
  notes?: string;
  is_primary?: boolean;
}

export function useCompanyContacts(companyId?: string) {
  const queryClient = useQueryClient();

  const { data: contacts, isLoading } = useQuery({
    queryKey: ['company-contacts', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('company_contacts')
        .select('*')
        .eq('company_id', companyId)
        .order('is_primary', { ascending: false })
        .order('name');

      if (error) throw error;
      return data as CompanyContact[];
    },
    enabled: !!companyId,
  });

  const createContact = useMutation({
    mutationFn: async (contactData: CreateContactInput) => {
      const { data, error } = await supabase
        .from('company_contacts')
        .insert(contactData)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-contacts'] });
      toast.success('Kontakt oprettet');
    },
    onError: (error: any) => {
      toast.error('Fejl ved oprettelse: ' + error.message);
    },
  });

  const updateContact = useMutation({
    mutationFn: async ({
      contactId,
      updates,
    }: {
      contactId: string;
      updates: Partial<CompanyContact>;
    }) => {
      const { data, error } = await supabase
        .from('company_contacts')
        .update(updates)
        .eq('id', contactId)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-contacts'] });
      toast.success('Kontakt opdateret');
    },
    onError: (error: any) => {
      toast.error('Fejl ved opdatering: ' + error.message);
    },
  });

  const deleteContact = useMutation({
    mutationFn: async (contactId: string) => {
      const { error } = await supabase
        .from('company_contacts')
        .delete()
        .eq('id', contactId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-contacts'] });
      toast.success('Kontakt slettet');
    },
    onError: (error: any) => {
      toast.error('Fejl ved sletning: ' + error.message);
    },
  });

  return {
    contacts,
    isLoading,
    createContact,
    updateContact,
    deleteContact,
  };
}
