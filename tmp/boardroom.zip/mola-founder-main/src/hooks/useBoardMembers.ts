import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface BoardMember {
  id: string;
  company_id: string;
  name: string;
  role: 'chairman' | 'member' | 'alternate';
  email?: string;
  phone?: string;
  appointed_date: string;
  term_end_date?: string;
  is_active: boolean;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface CreateBoardMemberInput {
  company_id: string;
  name: string;
  role: 'chairman' | 'member' | 'alternate';
  email?: string;
  phone?: string;
  appointed_date: string;
  term_end_date?: string;
  notes?: string;
}

export function useBoardMembers(companyId?: string) {
  const queryClient = useQueryClient();

  const { data: members, isLoading } = useQuery({
    queryKey: ['board-members', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('board_members')
        .select('*')
        .eq('company_id', companyId)
        .order('appointed_date', { ascending: false });

      if (error) throw error;
      return data as BoardMember[];
    },
    enabled: !!companyId,
  });

  const createMember = useMutation({
    mutationFn: async (input: CreateBoardMemberInput) => {
      const { data, error } = await supabase
        .from('board_members')
        .insert(input)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['board-members', companyId] });
      toast.success('Bestyrelsesmedlem tilføjet');
    },
    onError: (error: any) => {
      toast.error('Fejl: ' + error.message);
    },
  });

  const updateMember = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<BoardMember> }) => {
      const { data, error } = await supabase
        .from('board_members')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['board-members', companyId] });
      toast.success('Bestyrelsesmedlem opdateret');
    },
    onError: (error: any) => {
      toast.error('Fejl: ' + error.message);
    },
  });

  const deleteMember = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('board_members')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['board-members', companyId] });
      toast.success('Bestyrelsesmedlem slettet');
    },
    onError: (error: any) => {
      toast.error('Fejl: ' + error.message);
    },
  });

  const activeMembers = members?.filter(m => m.is_active) || [];
  const chairman = activeMembers.find(m => m.role === 'chairman');

  return {
    members: members || [],
    activeMembers,
    chairman,
    isLoading,
    createMember,
    updateMember,
    deleteMember,
  };
}
