import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface DividendInput {
  company_id: string;
  fund_id: string;
  declared_date: string;
  paid_date: string;
  amount_dkk: number;
  note?: string;
}

export function useDividendMutations() {
  const queryClient = useQueryClient();

  const createDividend = useMutation({
    mutationFn: async (data: DividendInput) => {
      const { data: result, error } = await supabase
        .from('dividends')
        .insert(data)
        .select()
        .single();
      
      if (error) throw error;
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dividends'] });
      toast({
        title: 'Success',
        description: 'Dividend registered successfully',
      });
    },
    onError: (error: Error) => {
      console.error('Failed to register dividend:', error);
      toast({
        title: 'Error',
        description: 'Failed to register dividend',
        variant: 'destructive',
      });
    },
  });

  return { createDividend };
}
