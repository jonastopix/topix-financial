import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const usePartnerDealsAdmin = () => {
  return useQuery({
    queryKey: ['partner-deals-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('partner_deals')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });
};

export const useCompanyPricesAdmin = () => {
  return useQuery({
    queryKey: ['company-prices-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_prices')
        .select(`
          *,
          companies:company_id (
            id,
            name
          )
        `)
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });
};

export const useProcurementAdoptionsAdmin = () => {
  return useQuery({
    queryKey: ['procurement-adoptions-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('procurement_adoptions')
        .select(`
          *,
          companies:company_id (
            id,
            name
          ),
          partner_deals:partner_deal_id (
            vendor,
            plan_name
          )
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });
};

export const useAuditLog = () => {
  return useQuery({
    queryKey: ['procurement-audit-log'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('procurement_audit_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      return data;
    },
  });
};

const logAudit = async (entity: string, entityId: string, action: string, diff?: any) => {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;

  await supabase
    .from('procurement_audit_log')
    .insert({
      actor_user_id: user.id,
      entity,
      entity_id: entityId,
      action,
      diff: diff || null,
    });
};

export const useUpsertPartnerDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (deal: any) => {
      const isUpdate = !!deal.id;
      
      let originalData = null;
      if (isUpdate) {
        const { data } = await supabase
          .from('partner_deals')
          .select('*')
          .eq('id', deal.id)
          .single();
        originalData = data;
      }

      const { data, error } = await supabase
        .from('partner_deals')
        .upsert(deal)
        .select()
        .single();
      
      if (error) throw error;

      await logAudit(
        'partner_deals',
        data.id,
        isUpdate ? 'update' : 'create',
        isUpdate ? { before: originalData, after: data } : { after: data }
      );

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-deals-admin'] });
      queryClient.invalidateQueries({ queryKey: ['partner-deals'] });
      toast({
        title: "Partneraftale gemt",
        description: "Ændringerne er blevet gemt.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fejl",
        description: "Kunne ikke gemme partneraftale.",
        variant: "destructive",
      });
      console.error('Error saving partner deal:', error);
    },
  });
};

export const useArchivePartnerDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, archived }: { id: string; archived: boolean }) => {
      const { data, error } = await supabase
        .from('partner_deals')
        .update({ archived })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;

      await logAudit('partner_deals', id, archived ? 'archive' : 'unarchive');

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['partner-deals-admin'] });
      toast({
        title: variables.archived ? "Arkiveret" : "Gendannet",
        description: variables.archived ? "Partneraftalen er arkiveret." : "Partneraftalen er gendannet.",
      });
    },
  });
};

export const useDeletePartnerDeal = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: string) => {
      await logAudit('partner_deals', id, 'delete');

      const { error } = await supabase
        .from('partner_deals')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['partner-deals-admin'] });
      toast({
        title: "Slettet",
        description: "Partneraftalen er permanent slettet.",
      });
    },
  });
};

export const useDeleteCompanyPrice = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (id: string) => {
      await logAudit('company_prices', id, 'delete');

      const { error } = await supabase
        .from('company_prices')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-prices-admin'] });
      toast({
        title: "Slettet",
        description: "Prisen er slettet.",
      });
    },
  });
};

export const useBulkArchiveCompanyPrices = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (ids: string[]) => {
      for (const id of ids) {
        await logAudit('company_prices', id, 'bulk_archive');
      }

      const { error } = await supabase
        .from('company_prices')
        .update({ archived: true })
        .in('id', ids);
      
      if (error) throw error;
    },
    onSuccess: (_, ids) => {
      queryClient.invalidateQueries({ queryKey: ['company-prices-admin'] });
      toast({
        title: "Arkiveret",
        description: `${ids.length} priser arkiveret.`,
      });
    },
  });
};

export const useUpdateAdoptionStatus = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ id, status, notes }: { id: string; status: string; notes?: string }) => {
      const updateData: any = { status };
      
      if (status === 'active' && notes === undefined) {
        updateData.activated_at = new Date().toISOString();
      }
      
      if (notes !== undefined) {
        updateData.notes = notes;
      }

      const { data: before } = await supabase
        .from('procurement_adoptions')
        .select('*')
        .eq('id', id)
        .single();

      const { data, error } = await supabase
        .from('procurement_adoptions')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;

      await logAudit('procurement_adoptions', id, 'status_change', {
        before: before?.status,
        after: status,
      });

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['procurement-adoptions-admin'] });
      toast({
        title: "Status opdateret",
        description: "Adoptionsstatus er opdateret.",
      });
    },
  });
};