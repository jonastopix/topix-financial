import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

export function useProfileManagement() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);

  // Fetch user profile
  const { data: profile, isLoading } = useQuery({
    queryKey: ['user-profile', user?.id],
    queryFn: async () => {
      if (!user) return null;
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Update profile
  const updateProfileMutation = useMutation({
    mutationFn: async (updates: { 
      full_name?: string; 
      company_name?: string;
      title?: string;
      bio?: string;
      skills?: string[];
      linkedin_url?: string;
      can_help_with?: string;
    }) => {
      if (!user) throw new Error('User not authenticated');
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      toast.success('Profil opdateret');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved opdatering af profil: ' + error.message);
    },
  });

  // Upload avatar
  const uploadAvatar = async (file: File): Promise<string | null> => {
    if (!user) {
      toast.error('Bruger ikke autentificeret');
      return null;
    }

    // Validate file
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      toast.error('Kun JPEG, PNG og WEBP billeder er tilladt');
      return null;
    }

    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      toast.error('Filen er for stor. Maksimal størrelse er 5MB');
      return null;
    }

    setIsUploadingAvatar(true);

    try {
      // Resize image
      const resizedBlob = await resizeImage(file);

      // Delete old avatar if exists
      if (profile?.avatar_url) {
        const oldPath = profile.avatar_url.split('/').pop();
        if (oldPath) {
          await supabase.storage
            .from('avatars')
            .remove([`${user.id}/${oldPath}`]);
        }
      }

      // Upload new avatar
      const fileExt = file.name.split('.').pop();
      const fileName = `avatar-${Date.now()}.${fileExt}`;
      const filePath = `${user.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(filePath, resizedBlob, {
          contentType: file.type,
          upsert: true,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('avatars')
        .getPublicUrl(filePath);

      const publicUrl = urlData.publicUrl;

      // Update profile with avatar URL
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      toast.success('Profilbillede uploadet');
      return publicUrl;
    } catch (error: any) {
      toast.error('Fejl ved upload af profilbillede: ' + error.message);
      return null;
    } finally {
      setIsUploadingAvatar(false);
    }
  };

  // Delete avatar
  const deleteAvatar = async (): Promise<boolean> => {
    if (!user || !profile?.avatar_url) return false;

    try {
      const oldPath = profile.avatar_url.split('/').pop();
      if (!oldPath) return false;

      // Delete from storage
      const { error: deleteError } = await supabase.storage
        .from('avatars')
        .remove([`${user.id}/${oldPath}`]);

      if (deleteError) throw deleteError;

      // Update profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: null })
        .eq('id', user.id);

      if (updateError) throw updateError;

      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      toast.success('Profilbillede slettet');
      return true;
    } catch (error: any) {
      toast.error('Fejl ved sletning af profilbillede: ' + error.message);
      return false;
    }
  };

  return {
    profile,
    isLoading,
    isUploadingAvatar,
    updateProfile: updateProfileMutation.mutate,
    uploadAvatar,
    deleteAvatar,
  };
}

// Helper function to resize image
async function resizeImage(file: File): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get canvas context'));
          return;
        }

        // Calculate new dimensions (max 400x400)
        const maxSize = 400;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxSize) {
            height = (height * maxSize) / width;
            width = maxSize;
          }
        } else {
          if (height > maxSize) {
            width = (width * maxSize) / height;
            height = maxSize;
          }
        }

        canvas.width = width;
        canvas.height = height;

        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve(blob);
            } else {
              reject(new Error('Failed to create blob'));
            }
          },
          file.type,
          0.9
        );
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}
