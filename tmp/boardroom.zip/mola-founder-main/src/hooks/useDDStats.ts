import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface DDStats {
  documentUpload: number;
  economicDD: { pending: number; approved: number };
  legalDD: { pending: number; approved: number };
  readyForSigning: number;
}

export function useDDStats() {
  return useQuery({
    queryKey: ['dd-stats'],
    queryFn: async () => {
      // Get all cases with status 'due_diligence'
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, status')
        .eq('status', 'due_diligence');

      if (companiesError) throw companiesError;

      const companyIds = companies?.map(c => c.id) || [];

      if (companyIds.length === 0) {
        return {
          documentUpload: 0,
          economicDD: { pending: 0, approved: 0 },
          legalDD: { pending: 0, approved: 0 },
          readyForSigning: 0,
        };
      }

      // Get all cases
      const { data: cases, error: casesError } = await supabase
        .from('due_diligence_cases')
        .select('id, company_id, status')
        .in('company_id', companyIds);

      if (casesError) throw casesError;

      // Get category progress
      const { data: categoryProgress, error: categoryError } = await supabase
        .from('dd_category_progress')
        .select('case_id, document_count')
        .in('case_id', cases?.map(c => c.id) || []);

      if (categoryError) throw categoryError;

      // Get partner assignments
      const { data: assignments, error: assignmentsError } = await supabase
        .from('dd_partner_assignments')
        .select('company_id, specialization, approval_status')
        .in('company_id', companyIds);

      if (assignmentsError) throw assignmentsError;

      const stats: DDStats = {
        documentUpload: 0,
        economicDD: { pending: 0, approved: 0 },
        legalDD: { pending: 0, approved: 0 },
        readyForSigning: 0,
      };

      // Calculate stats for each company
      companyIds.forEach(companyId => {
        const caseForCompany = cases?.find(c => c.company_id === companyId);
        if (!caseForCompany) return;

        // Check document upload status
        const categoryProgressForCase = categoryProgress?.filter(cp => cp.case_id === caseForCompany.id) || [];
        const totalDocs = categoryProgressForCase.reduce((sum, cp) => sum + (cp.document_count || 0), 0);
        const hasDocuments = totalDocs > 0;

        // Get assignments for this company
        const economicAssignment = assignments?.find(a => a.company_id === companyId && a.specialization === 'economic');
        const legalAssignment = assignments?.find(a => a.company_id === companyId && a.specialization === 'legal');

        // Document upload phase (no documents yet)
        if (!hasDocuments) {
          stats.documentUpload++;
          return;
        }

        // Economic DD phase
        if (economicAssignment) {
          if (economicAssignment.approval_status === 'pending') {
            stats.economicDD.pending++;
          } else if (economicAssignment.approval_status === 'approved') {
            stats.economicDD.approved++;
          }
        }

        // Legal DD phase
        if (legalAssignment) {
          if (legalAssignment.approval_status === 'pending') {
            stats.legalDD.pending++;
          } else if (legalAssignment.approval_status === 'approved') {
            stats.legalDD.approved++;
          }
        }

        // Ready for signing (both approved AND case is pending_review)
        if (
          economicAssignment?.approval_status === 'approved' &&
          legalAssignment?.approval_status === 'approved' &&
          caseForCompany.status === 'pending_review'
        ) {
          stats.readyForSigning++;
        }
      });

      return stats;
    },
  });
}
