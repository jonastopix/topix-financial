import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Invitation {
  id: string;
  email: string;
  invited_role: string;
  invited_by: string;
  status: string;
  company_id: string | null;
  fund_id: string | null;
  invitation_token: string;
  expires_at: string;
  created_at: string;
  accepted_at: string | null;
  notes: string | null;
  company?: { name: string };
  fund?: { name: string };
  invited_by_profile?: { full_name: string };
}

export type { Invitation };

interface InviteUserParams {
  email: string;
  role: string;
  companyId?: string;
  fundId?: string;
  notes?: string;
}

export function useInvitations() {
  const queryClient = useQueryClient();

  const { data: invitations, isLoading, error } = useQuery({
    queryKey: ['invitations'],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('list-invitations');

      if (error) throw error;
      return data.invitations as any[];
    },
  });

  const inviteUserMutation = useMutation({
    mutationFn: async (params: InviteUserParams) => {
      const { data, error } = await supabase.functions.invoke('invite-user', {
        body: {
          email: params.email,
          role: params.role,
          companyId: params.companyId,
          fundId: params.fundId,
          notes: params.notes,
        },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success('Invitation sendt succesfuldt');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Fejl ved afsendelse af invitation');
    },
  });

  const cancelInvitationMutation = useMutation({
    mutationFn: async (invitationId: string) => {
      const { data, error } = await supabase.functions.invoke('manage-invitation', {
        body: {
          action: 'cancel',
          invitationId: invitationId,
        },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success('Invitation annulleret');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved annullering af invitation: ' + error.message);
    },
  });

  const resendInvitationMutation = useMutation({
    mutationFn: async (invitation: Invitation) => {
      const { data, error } = await supabase.functions.invoke('manage-invitation', {
        body: {
          action: 'resend',
          invitationId: invitation.id,
        },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['invitations'] });
      toast.success('Invitation gensendt');
    },
    onError: (error: Error) => {
      toast.error('Fejl ved gensendelse af invitation: ' + error.message);
    },
  });

  return {
    invitations: invitations || [],
    isLoading,
    error,
    inviteUser: inviteUserMutation.mutate,
    cancelInvitation: cancelInvitationMutation.mutate,
    resendInvitation: resendInvitationMutation.mutate,
    isInviting: inviteUserMutation.isPending,
  };
}