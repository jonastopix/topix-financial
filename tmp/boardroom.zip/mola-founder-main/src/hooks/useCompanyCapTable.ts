import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CapTableEntry {
  id: string;
  company_id: string;
  owner_name: string;
  owner_email: string | null;
  owner_cvr: string | null;
  owner_type: 'person' | 'company' | 'fund' | 'other';
  ownership_pct: number;
  shares: number | null;
  share_class: string | null;
  acquired_date: string | null;
  notes: string | null;
  user_id: string | null;
  invited_at: string | null;
  invitation_status: 'pending' | 'accepted' | 'declined' | null;
  created_at: string;
  updated_at: string;
}

export function useCapTable(companyId: string) {
  return useQuery({
    queryKey: ['cap-table', companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_cap_table')
        .select('*')
        .eq('company_id', companyId)
        .order('ownership_pct', { ascending: false });

      if (error) throw error;
      return data as CapTableEntry[];
    },
    enabled: !!companyId,
  });
}

export function useCapTableStats(companyId: string) {
  const { data: entries } = useCapTable(companyId);

  const totalOwnership = entries?.reduce((sum, entry) => sum + Number(entry.ownership_pct), 0) || 0;
  const totalShares = entries?.reduce((sum, entry) => sum + Number(entry.shares || 0), 0) || 0;
  const isValid = Math.abs(totalOwnership - 100) < 0.01; // Allow small rounding errors

  return {
    totalOwnership,
    totalShares,
    isValid,
    entriesCount: entries?.length || 0,
  };
}

export function useCapTableMutations() {
  const queryClient = useQueryClient();

  const addEntry = useMutation({
    mutationFn: async (entry: Omit<CapTableEntry, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('company_cap_table')
        .insert(entry)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['cap-table', variables.company_id] });
      toast.success('Ejer tilføjet til cap table');
    },
    onError: (error) => {
      toast.error('Fejl ved tilføjelse af ejer: ' + error.message);
    },
  });

  const updateEntry = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<CapTableEntry> & { id: string }) => {
      const { data, error } = await supabase
        .from('company_cap_table')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cap-table', data.company_id] });
      toast.success('Ejer opdateret');
    },
    onError: (error) => {
      toast.error('Fejl ved opdatering af ejer: ' + error.message);
    },
  });

  const deleteEntry = useMutation({
    mutationFn: async ({ id, companyId }: { id: string; companyId: string }) => {
      const { error } = await supabase
        .from('company_cap_table')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { id, companyId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['cap-table', data.companyId] });
      toast.success('Ejer slettet fra cap table');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning af ejer: ' + error.message);
    },
  });

  return {
    addEntry,
    updateEntry,
    deleteEntry,
  };
}
