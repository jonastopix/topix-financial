import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type ArticleStatus = 'pending' | 'approved' | 'dismissed' | 'auto_approved';

interface PRArticle {
  id: string;
  company_id: string;
  title: string;
  source: string | null;
  url: string;
  published_at: string | null;
  snippet: string | null;
  ai_summary: string | null;
  sentiment: "positive" | "neutral" | "negative" | null;
  relevance_score: number | null;
  is_saved: boolean;
  searched_by: string | null;
  created_at: string;
  article_status: ArticleStatus | null;
}

interface SearchResult {
  title: string;
  source: string;
  url: string;
  snippet: string;
  published_at: string | null;
  ai_summary: string | null;
  sentiment: "positive" | "neutral" | "negative";
  relevance_score: number;
}

interface SearchResponse {
  company_name: string;
  articles: SearchResult[];
  searched_at: string;
  message?: string;
  requires_api_key?: boolean;
}

interface LearnedSource {
  domain: string;
  trust_score: number;
  save_count: number;
  dismiss_count: number;
}

interface BlockedSource {
  id: string;
  domain: string | null;
  url: string | null;
  reason: string | null;
  created_at: string;
}

interface ScanResult {
  success: boolean;
  companies_scanned: number;
  articles_found: number;
  articles_new: number;
  scanned_at: string;
}

function extractDomain(url: string): string {
  try {
    const hostname = new URL(url).hostname;
    return hostname.replace(/^www\./, '');
  } catch {
    return url;
  }
}

export function useCompanyPR(companyId: string) {
  const queryClient = useQueryClient();

  // Fetch saved PR articles for a company
  const {
    data: savedArticles,
    isLoading: isLoadingSaved,
    error: savedError,
  } = useQuery({
    queryKey: ["company-pr-articles", companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("company_pr_articles")
        .select("*")
        .eq("company_id", companyId)
        .in("article_status", ["approved", "auto_approved"])
        .order("published_at", { ascending: false });

      if (error) throw error;
      return data as PRArticle[];
    },
    enabled: !!companyId,
  });

  // Fetch pending articles (from automated scans)
  const {
    data: pendingArticles,
    isLoading: isLoadingPending,
  } = useQuery({
    queryKey: ["company-pr-pending", companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("company_pr_articles")
        .select("*")
        .eq("company_id", companyId)
        .eq("article_status", "pending")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as PRArticle[];
    },
    enabled: !!companyId,
  });

  // Fetch learned sources for current user
  const { data: learnedSources } = useQuery({
    queryKey: ["pr-learned-sources"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pr_learned_sources")
        .select("domain, trust_score, save_count, dismiss_count")
        .order("trust_score", { ascending: false });

      if (error) throw error;
      return data as LearnedSource[];
    },
  });

  // Fetch blocked sources for current user
  const { data: blockedSources } = useQuery({
    queryKey: ["pr-blocked-sources"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pr_blocked_sources")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as BlockedSource[];
    },
  });

  // Search for new PR articles
  const searchMutation = useMutation({
    mutationFn: async (additionalTerms?: string): Promise<SearchResponse> => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Not authenticated");

      // Get blocked domains to filter on backend
      const blockedDomains = blockedSources
        ?.filter(s => s.domain)
        .map(s => s.domain) || [];

      // Get trusted domains for prioritization
      const trustedDomains = learnedSources
        ?.filter(s => s.trust_score > 5)
        .slice(0, 5)
        .map(s => s.domain) || [];

      const response = await supabase.functions.invoke("search-company-pr", {
        body: {
          company_id: companyId,
          additional_terms: additionalTerms,
          blocked_domains: blockedDomains,
          trusted_domains: trustedDomains,
        },
      });

      if (response.error) throw response.error;
      
      // Get already saved URLs to filter duplicates
      const savedUrls = new Set(
        savedArticles?.map(a => a.url.toLowerCase()) || []
      );
      
      // Filter out blocked URLs client-side as backup AND already saved articles
      const blockedUrls = blockedSources
        ?.filter(s => s.url)
        .map(s => s.url) || [];
      
      const filteredArticles = response.data.articles.filter((article: SearchResult) => {
        const domain = extractDomain(article.url);
        const urlLower = article.url.toLowerCase();
        
        // Skip if already saved
        if (savedUrls.has(urlLower)) {
          return false;
        }
        
        return !blockedDomains.includes(domain) && !blockedUrls.includes(article.url);
      });

      return {
        ...response.data,
        articles: filteredArticles,
      };
    },
  });

  // Track feedback and update trust scores (internal helper)
  const trackFeedback = async (
    article: { url: string; title?: string; source?: string },
    action: 'saved' | 'dismissed' | 'clicked' | 'skipped',
    searchQuery?: string
  ) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const domain = extractDomain(article.url);

    // Insert feedback record (triggers trust score update via database trigger)
    await supabase.from("pr_user_feedback").insert({
      user_id: user.id,
      company_id: companyId,
      article_url: article.url,
      source_domain: domain,
      action,
      search_query: searchQuery,
      article_title: article.title,
    });

    // Also update global trust score for the domain
    const scoreChange = action === 'saved' ? 10 : action === 'dismissed' ? -15 : action === 'clicked' ? 2 : 0;
    
    if (scoreChange !== 0) {
      // Upsert into pr_learned_sources
      const { data: existing } = await supabase
        .from("pr_learned_sources")
        .select("id, trust_score, save_count, dismiss_count, click_count")
        .eq("user_id", user.id)
        .eq("domain", domain)
        .maybeSingle();

      if (existing) {
        await supabase
          .from("pr_learned_sources")
          .update({
            trust_score: existing.trust_score + scoreChange,
            save_count: existing.save_count + (action === 'saved' ? 1 : 0),
            dismiss_count: existing.dismiss_count + (action === 'dismissed' ? 1 : 0),
            click_count: existing.click_count + (action === 'clicked' ? 1 : 0),
            last_updated: new Date().toISOString(),
          })
          .eq("id", existing.id);
      } else {
        await supabase
          .from("pr_learned_sources")
          .insert({
            user_id: user.id,
            domain,
            trust_score: scoreChange,
            save_count: action === 'saved' ? 1 : 0,
            dismiss_count: action === 'dismissed' ? 1 : 0,
            click_count: action === 'clicked' ? 1 : 0,
          });
      }
    }
  };

  // Save an article (from search results)
  const saveMutation = useMutation({
    mutationFn: async (article: SearchResult) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Track the save action
      await trackFeedback(article, 'saved');

      // Use upsert to handle edge case duplicates gracefully
      const { data, error } = await supabase
        .from("company_pr_articles")
        .upsert({
          company_id: companyId,
          title: article.title,
          source: article.source,
          url: article.url,
          published_at: article.published_at,
          snippet: article.snippet,
          ai_summary: article.ai_summary,
          sentiment: article.sentiment,
          relevance_score: article.relevance_score,
          is_saved: true,
          searched_by: user.id,
          article_status: 'approved',
        }, {
          onConflict: 'company_id,url',
          ignoreDuplicates: true
        })
        .select()
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-articles", companyId] });
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success("Artikel gemt");
    },
    onError: (error) => {
      console.error("Failed to save article:", error);
      toast.error("Kunne ikke gemme artikel");
    },
  });

  // Approve a pending article
  const approvePendingMutation = useMutation({
    mutationFn: async (articleId: string) => {
      const { data: article } = await supabase
        .from("company_pr_articles")
        .select("url, title, source")
        .eq("id", articleId)
        .single();
      
      if (article) {
        await trackFeedback(article, 'saved');
      }

      const { error } = await supabase
        .from("company_pr_articles")
        .update({ 
          article_status: 'approved',
          is_saved: true,
        })
        .eq("id", articleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-articles", companyId] });
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success("Artikel godkendt");
    },
    onError: (error) => {
      console.error("Failed to approve article:", error);
      toast.error("Kunne ikke godkende artikel");
    },
  });

  // Dismiss a pending article
  const dismissPendingMutation = useMutation({
    mutationFn: async (articleId: string) => {
      const { data: article } = await supabase
        .from("company_pr_articles")
        .select("url, title, source")
        .eq("id", articleId)
        .single();
      
      if (article) {
        await trackFeedback(article, 'dismissed');
      }

      const { error } = await supabase
        .from("company_pr_articles")
        .update({ 
          article_status: 'dismissed',
          is_saved: false,
        })
        .eq("id", articleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success("Artikel afvist");
    },
  });

  // Bulk approve all pending articles from trusted sources
  const bulkApproveTrustedMutation = useMutation({
    mutationFn: async () => {
      if (!pendingArticles || !learnedSources) return { count: 0 };
      
      const trustedDomains = new Set(
        learnedSources.filter(s => s.trust_score > 10).map(s => s.domain)
      );
      
      const trustedArticles = pendingArticles.filter(article => {
        const domain = extractDomain(article.url);
        return trustedDomains.has(domain);
      });
      
      for (const article of trustedArticles) {
        await trackFeedback({ url: article.url, title: article.title, source: article.source || undefined }, 'saved');
        
        await supabase
          .from("company_pr_articles")
          .update({ article_status: 'approved', is_saved: true })
          .eq("id", article.id);
      }
      
      return { count: trustedArticles.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-articles", companyId] });
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success(`${data.count} artikler godkendt fra trusted kilder`);
    },
  });

  // Bulk dismiss all pending articles
  const bulkDismissAllMutation = useMutation({
    mutationFn: async () => {
      if (!pendingArticles) return { count: 0 };
      
      for (const article of pendingArticles) {
        await trackFeedback({ url: article.url, title: article.title, source: article.source || undefined }, 'dismissed');
      }
      
      const { error } = await supabase
        .from("company_pr_articles")
        .update({ article_status: 'dismissed', is_saved: false })
        .eq("company_id", companyId)
        .eq("article_status", "pending");
      
      if (error) throw error;
      return { count: pendingArticles.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success(`${data.count} artikler afvist`);
    },
  });

  // Bulk approve all pending articles
  const bulkApproveAllMutation = useMutation({
    mutationFn: async () => {
      if (!pendingArticles) return { count: 0 };
      
      for (const article of pendingArticles) {
        await trackFeedback({ url: article.url, title: article.title, source: article.source || undefined }, 'saved');
      }
      
      const { error } = await supabase
        .from("company_pr_articles")
        .update({ article_status: 'approved', is_saved: true })
        .eq("company_id", companyId)
        .eq("article_status", "pending");
      
      if (error) throw error;
      return { count: pendingArticles.length };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-articles", companyId] });
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success(`${data.count} artikler godkendt`);
    },
  });

  // Trigger manual scan for this company
  const scanMutation = useMutation({
    mutationFn: async (): Promise<ScanResult> => {
      const response = await supabase.functions.invoke("scan-all-companies-pr", {
        body: {
          company_ids: [companyId],
          scan_type: 'manual',
        },
      });

      if (response.error) throw response.error;
      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-pending", companyId] });
      toast.success(`Scanning færdig: ${data.articles_new} nye artikler fundet`);
    },
    onError: (error) => {
      console.error("Scan failed:", error);
      toast.error("Scanning fejlede");
    },
  });

  // Dismiss an article (negative feedback)
  const dismissMutation = useMutation({
    mutationFn: async (article: SearchResult) => {
      await trackFeedback(article, 'dismissed');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pr-learned-sources"] });
      toast.success("Feedback registreret");
    },
  });

  // Block a source domain
  const blockSourceMutation = useMutation({
    mutationFn: async ({ domain, url, reason }: { domain?: string; url?: string; reason?: string }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase.from("pr_blocked_sources").insert({
        user_id: user.id,
        domain: domain || null,
        url: url || null,
        reason: reason || null,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pr-blocked-sources"] });
      toast.success("Kilde blokeret");
    },
    onError: (error) => {
      console.error("Failed to block source:", error);
      toast.error("Kunne ikke blokere kilde");
    },
  });

  // Unblock a source
  const unblockSourceMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("pr_blocked_sources")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["pr-blocked-sources"] });
      toast.success("Kilde genaktiveret");
    },
  });

  // Delete a saved article
  const deleteMutation = useMutation({
    mutationFn: async (articleId: string) => {
      const { error } = await supabase
        .from("company_pr_articles")
        .delete()
        .eq("id", articleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["company-pr-articles", companyId] });
      toast.success("Artikel slettet");
    },
    onError: (error) => {
      console.error("Failed to delete article:", error);
      toast.error("Kunne ikke slette artikel");
    },
  });

  return {
    savedArticles,
    isLoadingSaved,
    savedError,
    // Pending articles from automated scans
    pendingArticles,
    isLoadingPending,
    approvePending: approvePendingMutation.mutate,
    isApproving: approvePendingMutation.isPending,
    dismissPending: dismissPendingMutation.mutate,
    isDismissingPending: dismissPendingMutation.isPending,
    // Bulk actions
    bulkApproveTrusted: bulkApproveTrustedMutation.mutate,
    isBulkApprovingTrusted: bulkApproveTrustedMutation.isPending,
    bulkDismissAll: bulkDismissAllMutation.mutate,
    isBulkDismissingAll: bulkDismissAllMutation.isPending,
    bulkApproveAll: bulkApproveAllMutation.mutate,
    isBulkApprovingAll: bulkApproveAllMutation.isPending,
    // Trigger automated scan
    triggerScan: scanMutation.mutateAsync,
    isScanning: scanMutation.isPending,
    // Manual search
    searchArticles: searchMutation.mutateAsync,
    isSearching: searchMutation.isPending,
    searchResults: searchMutation.data,
    saveArticle: saveMutation.mutate,
    isSaving: saveMutation.isPending,
    deleteArticle: deleteMutation.mutate,
    isDeleting: deleteMutation.isPending,
    // Feedback & learning
    dismissArticle: dismissMutation.mutate,
    isDismissing: dismissMutation.isPending,
    blockSource: blockSourceMutation.mutate,
    isBlocking: blockSourceMutation.isPending,
    unblockSource: unblockSourceMutation.mutate,
    learnedSources,
    blockedSources,
  };
}