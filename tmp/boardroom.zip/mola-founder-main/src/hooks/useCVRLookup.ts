import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CVRData {
  name: string;
  startdate: string;
  companytype: string;
  address: string;
  city: string;
  zipcode: string;
  email: string;
  phone: string;
  industrycode: string;
  industrydesc: string;
}

// Convert CVR date format (22/01 - 2009) to ISO format (2009-01-22)
function parseCVRDate(cvrDate: string): string {
  if (!cvrDate) return '';
  
  try {
    // Remove spaces and split by separator
    const cleaned = cvrDate.replace(/\s/g, '');
    
    // Format: "22/01-2009" or "22/01 - 2009"
    const match = cleaned.match(/(\d{2})\/(\d{2})-(\d{4})/);
    
    if (match) {
      const day = match[1];
      const month = match[2];
      const year = match[3];
      return `${year}-${month}-${day}`;
    }
    
    return '';
  } catch (error) {
    console.error('Error parsing CVR date:', error);
    return '';
  }
}

export function useCVRLookup() {
  const [isLoading, setIsLoading] = useState(false);

  const lookupCVR = async (cvr: string): Promise<{ data?: CVRData; error?: string }> => {
    // Validate CVR format (8 digits)
    if (!cvr || !/^\d{8}$/.test(cvr)) {
      toast.error('CVR skal være 8 cifre');
      return { error: 'CVR skal være 8 cifre' };
    }

    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('lookup-cvr', {
        body: { cvr },
      });

      if (error) {
        console.error('Edge function error:', error);
        toast.error('Fejl ved hentning af CVR data');
        return { error: error.message };
      }

      if (!data.success) {
        toast.error(data.error);
        return { error: data.error };
      }

      // Convert date format from CVR (22/01 - 2009) to ISO (2009-01-22)
      const parsedData = {
        ...data.data,
        startdate: parseCVRDate(data.data.startdate)
      };

      toast.success('Virksomhedsdata hentet fra CVR-registret');
      return { data: parsedData };

    } catch (error: any) {
      console.error('CVR lookup error:', error);
      toast.error('Fejl ved hentning af CVR data');
      return { error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  return { lookupCVR, isLoading };
}
