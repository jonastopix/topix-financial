import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface CompanyPrice {
  id: string;
  company_id: string;
  category: string;
  subcategory: string;
  value_numeric: number;
  unit: string;
  sample_volume_monthly: number | null;
  updated_at: string;
  archived: boolean;
}

export interface PartnerDeal {
  id: string;
  category: string;
  vendor: string;
  plan_name: string;
  mola_price: number;
  list_price: number;
  unit: string;
  terms: string;
  contact_email: string;
  activation_url: string | null;
  is_active: boolean;
  created_at: string;
  archived: boolean;
}

export interface ProcurementAdoption {
  id: string;
  company_id: string;
  partner_deal_id: string;
  status: 'pending' | 'active' | 'cancelled' | 'completed';
  notes: string | null;
  activated_at: string | null;
  created_at: string;
  archived: boolean;
}

export const useCompanyPrices = (companyId?: string) => {
  return useQuery({
    queryKey: ['company-prices', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      
      const { data, error } = await supabase
        .from('company_prices')
        .select('*')
        .eq('company_id', companyId)
        .eq('archived', false)
        .order('updated_at', { ascending: false });
      
      if (error) throw error;
      return data as CompanyPrice[];
    },
    enabled: !!companyId,
  });
};

export const usePartnerDeals = (category?: string) => {
  return useQuery({
    queryKey: ['partner-deals', category],
    queryFn: async () => {
      let query = supabase
        .from('partner_deals')
        .select('*')
        .eq('is_active', true)
        .eq('archived', false)
        .order('vendor');
      
      if (category) {
        query = query.eq('category', category);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as PartnerDeal[];
    },
  });
};

export const useProcurementAdoptions = (companyId?: string) => {
  return useQuery({
    queryKey: ['procurement-adoptions', companyId],
    queryFn: async () => {
      if (!companyId) return [];
      
      const { data, error } = await supabase
        .from('procurement_adoptions')
        .select(`
          *,
          partner_deals:partner_deal_id (*)
        `)
        .eq('company_id', companyId)
        .eq('archived', false)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!companyId,
  });
};

export const useSaveCompanyPrices = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (prices: Omit<CompanyPrice, 'id' | 'updated_at' | 'archived'>[]) => {
      const { data, error } = await supabase
        .from('company_prices')
        .upsert(prices, { onConflict: 'company_id,category,subcategory' })
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-prices'] });
      toast({
        title: "Priser gemt",
        description: "Dine priser er blevet opdateret.",
      });
    },
    onError: (error) => {
      toast({
        title: "Fejl",
        description: "Kunne ikke gemme priser. Prøv igen.",
        variant: "destructive",
      });
      console.error('Error saving prices:', error);
    },
  });
};

export const usePortfolioBenchmarks = (category: string, subcategory: string) => {
  return useQuery({
    queryKey: ['portfolio-benchmarks', category, subcategory],
    queryFn: async () => {
      // Get all non-archived company prices for this subcategory from last 90 days
      const ninetyDaysAgo = new Date();
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
      
      const { data, error } = await supabase
        .from('company_prices')
        .select('value_numeric')
        .eq('category', category)
        .eq('subcategory', subcategory)
        .eq('archived', false)
        .gte('updated_at', ninetyDaysAgo.toISOString())
        .order('value_numeric');
      
      if (error) throw error;
      
      if (!data || data.length === 0) {
        return null;
      }
      
      // Calculate median
      const values = data.map(d => d.value_numeric);
      const mid = Math.floor(values.length / 2);
      const median = values.length % 2 === 0
        ? (values[mid - 1] + values[mid]) / 2
        : values[mid];
      
      // Calculate percentiles
      const p40Index = Math.floor(values.length * 0.4);
      const p80Index = Math.floor(values.length * 0.8);
      
      return {
        median,
        p40: values[p40Index],
        p80: values[p80Index],
        sampleCount: values.length,
      };
    },
  });
};

export const calculateSavings = (
  companyValue: number,
  portfolioMedian: number | null,
  monthlyVolume: number | null
) => {
  if (!portfolioMedian || !monthlyVolume) return null;
  
  const monthlySavings = (companyValue - portfolioMedian) * monthlyVolume;
  const annualSavings = monthlySavings * 12;
  
  return {
    monthlySavings,
    annualSavings,
  };
};

export const getSavingsBadge = (
  companyValue: number,
  benchmarks: { p40: number; p80: number } | null
) => {
  if (!benchmarks) return null;
  
  if (companyValue <= benchmarks.p40) {
    return { label: 'Efficient', color: 'success' as const };
  } else if (companyValue <= benchmarks.p80) {
    return { label: 'Potential Saver', color: 'warning' as const };
  } else {
    return { label: 'Review needed', color: 'destructive' as const };
  }
};