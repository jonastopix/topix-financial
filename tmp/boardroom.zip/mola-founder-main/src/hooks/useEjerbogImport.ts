import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useCapTableMutations, useCapTable } from '@/hooks/useCompanyCapTable';
import { toast } from 'sonner';

export interface ParsedEntry {
  owner_name: string;
  owner_type: 'person' | 'company';
  ownership_pct: number;
  shares: number | null;
  owner_cvr: string | null;
}

export interface ParsedEjerbog {
  total_capital: number | null;
  share_denomination: number | null;
  ejerbog_date: string | null;
  entries: ParsedEntry[];
}

// Sanitize filename for Supabase Storage (remove special characters)
const sanitizeFileName = (fileName: string): string => {
  return fileName
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove accents (æ, ø, å → e, o, a)
    .replace(/[^a-zA-Z0-9._-]/g, '_') // Replace invalid chars with underscore
    .replace(/_+/g, '_') // Remove multiple underscores
    .replace(/^_|_$/g, ''); // Remove leading/trailing underscores
};

export function useEjerbogImport(companyId: string) {
  const [isUploading, setIsUploading] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [parsedData, setParsedData] = useState<ParsedEjerbog | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const { addEntry, deleteEntry } = useCapTableMutations();
  const { data: existingEntries } = useCapTable(companyId);

  const uploadAndParse = async (file: File) => {
    setError(null);
    setIsUploading(true);
    
    try {
      // Generate unique file path with sanitized filename
      const timestamp = Date.now();
      const sanitizedName = sanitizeFileName(file.name);
      const filePath = `${companyId}/${timestamp}-${sanitizedName}`;
      
      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('ejerbog-uploads')
        .upload(filePath, file, {
          contentType: 'application/pdf',
          upsert: false,
        });

      if (uploadError) {
        throw new Error(`Upload fejlede: ${uploadError.message}`);
      }

      setIsUploading(false);
      setIsParsing(true);

      // Call edge function to parse
      const { data, error: parseError } = await supabase.functions.invoke('parse-ejerbog', {
        body: { filePath },
      });

      if (parseError) {
        throw new Error(parseError.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      setParsedData(data as ParsedEjerbog);
      toast.success(`Fandt ${data.entries.length} ejere i ejerbogen`);

      // Clean up uploaded file
      await supabase.storage.from('ejerbog-uploads').remove([filePath]);

    } catch (err) {
      const message = err instanceof Error ? err.message : 'Ukendt fejl';
      setError(message);
      toast.error(message);
    } finally {
      setIsUploading(false);
      setIsParsing(false);
    }
  };

  const importEntries = async (entries: ParsedEntry[], clearExisting: boolean, ejerbogDate: string | null) => {
    setIsImporting(true);
    setError(null);

    try {
      // Delete existing entries if requested
      if (clearExisting && existingEntries && existingEntries.length > 0) {
        for (const entry of existingEntries) {
          await deleteEntry.mutateAsync({ id: entry.id, companyId });
        }
      }

      // Import new entries
      for (const entry of entries) {
        await addEntry.mutateAsync({
          company_id: companyId,
          owner_name: entry.owner_name,
          owner_type: entry.owner_type,
          ownership_pct: entry.ownership_pct,
          shares: entry.shares,
          owner_cvr: entry.owner_cvr,
          owner_email: null,
          share_class: null,
          acquired_date: null,
          notes: 'Importeret fra ejerbog',
          user_id: null,
          invited_at: null,
          invitation_status: null,
        });
      }

      // Save ejerbog date to company
      if (ejerbogDate) {
        await supabase
          .from('companies')
          .update({ ejerbog_updated_at: ejerbogDate })
          .eq('id', companyId);
      }

      toast.success(`Importerede ${entries.length} ejere til cap table`);
      setParsedData(null);

    } catch (err) {
      const message = err instanceof Error ? err.message : 'Import fejlede';
      setError(message);
      toast.error(message);
    } finally {
      setIsImporting(false);
    }
  };

  const removeEntry = (index: number) => {
    if (parsedData) {
      const newEntries = [...parsedData.entries];
      newEntries.splice(index, 1);
      setParsedData({ ...parsedData, entries: newEntries });
    }
  };

  const updateEntry = (index: number, updates: Partial<ParsedEntry>) => {
    if (parsedData) {
      const newEntries = [...parsedData.entries];
      newEntries[index] = { ...newEntries[index], ...updates };
      setParsedData({ ...parsedData, entries: newEntries });
    }
  };

  const reset = () => {
    setParsedData(null);
    setError(null);
  };

  return {
    uploadAndParse,
    importEntries,
    removeEntry,
    updateEntry,
    reset,
    isUploading,
    isParsing,
    isImporting,
    isProcessing: isUploading || isParsing || isImporting,
    parsedData,
    error,
    existingEntriesCount: existingEntries?.length || 0,
  };
}
