import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface EmailTemplate {
  id: string;
  template_key: string;
  template_name: string;
  subject: string;
  html_body: string;
  text_body?: string;
  from_name: string;
  from_email: string;
  available_variables: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export function useEmailTemplates() {
  return useQuery({
    queryKey: ['email-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .order('template_name');

      if (error) throw error;
      return data as EmailTemplate[];
    },
  });
}

export function useEmailTemplate(id: string) {
  return useQuery({
    queryKey: ['email-template', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data as EmailTemplate;
    },
    enabled: !!id,
  });
}

export function useEmailTemplateMutations() {
  const queryClient = useQueryClient();

  const updateTemplate = useMutation({
    mutationFn: async (template: Partial<EmailTemplate> & { id: string }) => {
      const { id, ...updates } = template;
      const { data, error } = await supabase
        .from('email_templates')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-templates'] });
      toast.success('Template opdateret');
    },
    onError: (error) => {
      toast.error('Fejl ved opdatering af template: ' + error.message);
    },
  });

  const createTemplate = useMutation({
    mutationFn: async (template: Omit<EmailTemplate, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('email_templates')
        .insert(template)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-templates'] });
      toast.success('Template oprettet');
    },
    onError: (error) => {
      toast.error('Fejl ved oprettelse af template: ' + error.message);
    },
  });

  const deleteTemplate = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('email_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-templates'] });
      toast.success('Template slettet');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning af template: ' + error.message);
    },
  });

  const sendTestEmail = useMutation({
    mutationFn: async ({ templateId, testEmail }: { templateId: string; testEmail: string }) => {
      const { data, error } = await supabase.functions.invoke('send-test-email', {
        body: { templateId, testEmail }
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Test email sendt');
    },
    onError: (error) => {
      toast.error('Fejl ved afsendelse af test email: ' + error.message);
    },
  });

  return {
    updateTemplate,
    createTemplate,
    deleteTemplate,
    sendTestEmail,
  };
}
