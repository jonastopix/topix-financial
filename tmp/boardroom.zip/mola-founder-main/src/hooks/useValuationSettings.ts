import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useRole } from '@/contexts/RoleContext';

export interface ValuationSettings {
  id: string;
  company_id: string;
  revenue_multiple: number;
  ebitda_multiple: number;
  active_markets: number;
  valuation_weight_revenue_pct: number;
  created_at: string;
  updated_at: string;
}

/**
 * Hook to fetch valuation settings for a company (admin-only)
 * Returns null for non-admin users
 */
export function useValuationSettings(companyId: string | undefined) {
  const { isAdmin } = useRole();

  return useQuery({
    queryKey: ['valuation-settings', companyId],
    queryFn: async () => {
      if (!isAdmin || !companyId) return null;

      const { data, error } = await supabase
        .from('company_valuation_settings')
        .select('*')
        .eq('company_id', companyId)
        .maybeSingle();

      if (error) {
        console.error('Error fetching valuation settings:', error);
        throw error;
      }

      return data as ValuationSettings | null;
    },
    enabled: isAdmin && !!companyId,
  });
}
