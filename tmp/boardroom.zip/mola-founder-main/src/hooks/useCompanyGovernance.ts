import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { addMonths, setMonth, setDate, isPast, isBefore } from 'date-fns';

export interface GovernanceTemplate {
  id: string;
  category: string;
  item_name: string;
  description: string | null;
  frequency: string;
  months_after_fiscal_year_end: number | null;
  required: boolean | null;
  is_active: boolean | null;
  sort_order: number;
}

export interface GovernanceProgress {
  id: string;
  company_id: string;
  template_id: string;
  year: number;
  completed: boolean | null;
  completed_at: string | null;
  completed_by: string | null;
  notes: string | null;
  document_url: string | null;
  created_at: string;
}

export interface GovernanceProgressWithTemplate extends GovernanceProgress {
  template: GovernanceTemplate;
  deadline: Date;
  isOverdue: boolean;
  completedByName?: string | null;
}

export function useCompanyGovernance(companyId?: string, year?: number, fiscalYearEndMonth: number = 12, fiscalYearEndDay: number = 31) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const currentYear = year || new Date().getFullYear();

  // Calculate deadline based on fiscal year end and template's months_after_fiscal_year_end
  const calculateDeadline = (template: GovernanceTemplate, forYear: number): Date => {
    // Fiscal year end date for the given year
    const fiscalYearEnd = new Date(forYear, fiscalYearEndMonth - 1, fiscalYearEndDay);
    
    // Add months after fiscal year end
    const monthsAfter = template.months_after_fiscal_year_end || 0;
    return addMonths(fiscalYearEnd, monthsAfter);
  };

  // Fetch all active templates
  const { data: templates, isLoading: templatesLoading } = useQuery({
    queryKey: ['governance-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('company_governance_templates')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');
      
      if (error) throw error;
      return data as GovernanceTemplate[];
    },
  });

  // Fetch progress for this company and year with completed_by user name
  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: ['governance-progress', companyId, currentYear],
    queryFn: async () => {
      if (!companyId) return [];
      
      const { data, error } = await supabase
        .from('company_governance_progress')
        .select(`
          *,
          completed_by_profile:profiles!company_governance_progress_completed_by_fkey(full_name)
        `)
        .eq('company_id', companyId)
        .eq('year', currentYear);
      
      if (error) throw error;
      return data as (GovernanceProgress & { completed_by_profile?: { full_name: string | null } | null })[];
    },
    enabled: !!companyId,
  });

  // Initialize progress for new year
  const initializeProgress = useMutation({
    mutationFn: async () => {
      if (!companyId || !templates) throw new Error('Missing companyId or templates');
      
      const existingTemplateIds = new Set(progress?.map(p => p.template_id) || []);
      const newProgressEntries = templates
        .filter(t => !existingTemplateIds.has(t.id))
        .map(template => ({
          company_id: companyId,
          template_id: template.id,
          year: currentYear,
          completed: false,
        }));
      
      if (newProgressEntries.length === 0) return [];
      
      const { data, error } = await supabase
        .from('company_governance_progress')
        .insert(newProgressEntries)
        .select();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-progress', companyId, currentYear] });
    },
  });

  // Update progress (mark as done/undone, add notes)
  const updateProgress = useMutation({
    mutationFn: async ({ 
      progressId, 
      completed, 
      notes,
      document_url 
    }: { 
      progressId: string; 
      completed?: boolean; 
      notes?: string;
      document_url?: string;
    }) => {
      const updates: Partial<GovernanceProgress> = {};
      
      if (completed !== undefined) {
        updates.completed = completed;
        updates.completed_at = completed ? new Date().toISOString() : null;
        updates.completed_by = completed ? user?.id : null;
      }
      if (notes !== undefined) updates.notes = notes;
      if (document_url !== undefined) updates.document_url = document_url;
      
      const { data, error } = await supabase
        .from('company_governance_progress')
        .update(updates)
        .eq('id', progressId)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-progress', companyId, currentYear] });
    },
  });

  // Combine templates with progress
  const progressWithTemplates: GovernanceProgressWithTemplate[] = (templates || [])
    .map(template => {
      const progressEntry = progress?.find(p => p.template_id === template.id);
      const deadline = calculateDeadline(template, currentYear);
      const isOverdue = isPast(deadline) && !progressEntry?.completed;
      
      return {
        id: progressEntry?.id || '',
        company_id: companyId || '',
        template_id: template.id,
        year: currentYear,
        completed: progressEntry?.completed || false,
        completed_at: progressEntry?.completed_at || null,
        completed_by: progressEntry?.completed_by || null,
        notes: progressEntry?.notes || null,
        document_url: progressEntry?.document_url || null,
        created_at: progressEntry?.created_at || '',
        template,
        deadline,
        isOverdue,
        completedByName: progressEntry?.completed_by_profile?.full_name || null,
      };
    })
    .sort((a, b) => a.template.sort_order - b.template.sort_order);

  // Calculate stats
  const completedCount = progressWithTemplates.filter(p => p.completed).length;
  const totalCount = progressWithTemplates.length;
  const requiredCount = progressWithTemplates.filter(p => p.template.required).length;
  const completedRequiredCount = progressWithTemplates.filter(p => p.template.required && p.completed).length;
  const overdueCount = progressWithTemplates.filter(p => p.isOverdue).length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  return {
    templates,
    progress: progressWithTemplates,
    isLoading: templatesLoading || progressLoading,
    initializeProgress,
    updateProgress,
    calculateDeadline,
    stats: {
      completedCount,
      totalCount,
      requiredCount,
      completedRequiredCount,
      overdueCount,
      completionPercentage,
    },
  };
}
