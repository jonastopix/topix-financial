import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useGamification } from './useGamification';

// Badge definitions
interface BadgeDefinition {
  code: string;
  label: string;
  description: string;
  icon: string;
  target: number;
  type: string;
  isSecret?: boolean;
}

export const BADGE_DEFINITIONS: BadgeDefinition[] = [
  // Achievement badges
  { code: 'first_report', label: 'Første Rapport', description: 'Indsend din første månedsrapport', icon: '📊', target: 1, type: 'achievement' },
  { code: 'report_streak_3', label: 'Rapportør', description: 'Indsend 3 månedsrapporter i træk', icon: '📈', target: 3, type: 'achievement' },
  { code: 'report_master', label: 'Rapportmester', description: 'Indsend 12 månedsrapporter', icon: '🏆', target: 12, type: 'achievement' },
  // Activity badges
  { code: 'first_activity', label: 'Første Aktivitet', description: 'Log din første aktivitet', icon: '📅', target: 1, type: 'achievement' },
  { code: 'activities_10', label: 'Aktiv Partner', description: 'Log 10 aktiviteter', icon: '🤝', target: 10, type: 'achievement' },
  { code: 'activities_50', label: 'Mødemeister', description: 'Log 50 aktiviteter', icon: '👑', target: 50, type: 'achievement' },
  // Streak badges
  { code: 'streak_7', label: 'Ugekriger', description: '7 dages aktivitets-streak', icon: '🔥', target: 7, type: 'streak' },
  { code: 'streak_14', label: 'Touge Tænker', description: '14 dages aktivitets-streak', icon: '💪', target: 14, type: 'streak' },
  { code: 'streak_30', label: 'Månedsmester', description: '30 dages aktivitets-streak', icon: '⭐', target: 30, type: 'streak' },
  { code: 'streak_100', label: 'Streak Legend', description: '100 dages aktivitets-streak', icon: '🌟', target: 100, type: 'streak' },
  // XP badges
  { code: 'xp_100', label: 'XP Starter', description: 'Opnå 100 XP', icon: '💎', target: 100, type: 'xp' },
  { code: 'xp_500', label: 'XP Samler', description: 'Opnå 500 XP', icon: '💰', target: 500, type: 'xp' },
  { code: 'xp_1000', label: 'XP Jæger', description: 'Opnå 1000 XP', icon: '🏅', target: 1000, type: 'xp' },
  { code: 'xp_2500', label: 'XP Champion', description: 'Opnå 2500 XP', icon: '🎖️', target: 2500, type: 'xp' },
  // Document badges
  { code: 'first_document', label: 'Første Dokument', description: 'Upload dit første dokument', icon: '📄', target: 1, type: 'achievement' },
  { code: 'documents_10', label: 'Arkivar', description: 'Upload 10 dokumenter', icon: '📚', target: 10, type: 'achievement' },
  // Special/Growth badges
  { code: 'growth_champion', label: 'Vækstchampion', description: '+25% YoY omsætning', icon: '🚀', target: 25, type: 'growth' },
  { code: 'transparency', label: 'Gennemsigtig', description: 'Alle krævede dokumenter uploadet', icon: '✨', target: 1, type: 'achievement' },
  // Secret badges
  { code: 'night_owl', label: 'Natuglen', description: 'Registrer aktivitet efter kl. 22', icon: '🦉', target: 1, type: 'secret', isSecret: true },
  { code: 'early_bird', label: 'Morgenfrisk', description: 'Registrer aktivitet før kl. 7', icon: '🐦', target: 1, type: 'secret', isSecret: true },
  { code: 'weekend_warrior', label: 'Weekend Kriger', description: 'Log aktivitet i weekenden', icon: '⚔️', target: 1, type: 'secret', isSecret: true },
];

export type BadgeCode = string;

export interface Badge {
  id: string;
  user_id: string;
  code: string;
  label: string;
  description?: string;
  badge_type: string;
  progress: number;
  target: number;
  earned_at: string | null;
  is_secret: boolean;
  created_at: string;
}

export interface BadgeWithDefinition extends Badge {
  icon: string;
  isEarned: boolean;
  progressPercent: number;
}

export function useBadges() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { awardXp } = useGamification();

  // Fetch user's badges
  const { data: userBadges, isLoading } = useQuery({
    queryKey: ['user-badges', user?.id],
    queryFn: async (): Promise<Badge[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('badges')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Get badges with definitions merged
  const badges: BadgeWithDefinition[] = BADGE_DEFINITIONS.map(def => {
    const userBadge = userBadges?.find(b => b.code === def.code);
    const progress = userBadge?.progress || 0;
    const isEarned = userBadge?.earned_at != null;

    return {
      id: userBadge?.id || '',
      user_id: user?.id || '',
      code: def.code,
      label: def.isSecret && !isEarned ? '???' : def.label,
      description: def.isSecret && !isEarned ? 'Hemmeligt badge' : def.description,
      badge_type: def.type,
      progress,
      target: def.target,
      earned_at: userBadge?.earned_at || null,
      is_secret: def.isSecret || false,
      created_at: userBadge?.created_at || '',
      icon: def.isSecret && !isEarned ? '❓' : def.icon,
      isEarned,
      progressPercent: Math.min(100, (progress / def.target) * 100),
    };
  });

  // Get earned badges
  const earnedBadges = badges.filter(b => b.isEarned);
  
  // Get recently earned badges (last 7 days)
  const recentBadges = earnedBadges.filter(b => {
    if (!b.earned_at) return false;
    const earnedDate = new Date(b.earned_at);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return earnedDate > weekAgo;
  });

  // Update badge progress
  const updateProgressMutation = useMutation({
    mutationFn: async ({ code, progress }: { code: BadgeCode; progress: number }) => {
      if (!user?.id) throw new Error('No user');

      const definition = BADGE_DEFINITIONS.find(d => d.code === code);
      if (!definition) throw new Error('Unknown badge');

      const isCompleted = progress >= definition.target;
      const earnedAt = isCompleted ? new Date().toISOString() : null;

      // Check if badge exists
      const { data: existing } = await supabase
        .from('badges')
        .select('id, earned_at')
        .eq('user_id', user.id)
        .eq('code', code)
        .maybeSingle();

      // Don't update if already earned
      if (existing?.earned_at) return { alreadyEarned: true, newlyEarned: false };

      if (existing) {
        // Update existing
        const { error } = await supabase
          .from('badges')
          .update({
            progress,
            earned_at: earnedAt,
          })
          .eq('id', existing.id);

        if (error) throw error;
      } else {
        // Create new - use type assertion since user_id column was added via migration
        const { error } = await supabase
          .from('badges')
          .insert({
            user_id: user.id,
            code,
            label: definition.label,
            description: definition.description,
            badge_type: definition.type,
            progress,
            target: definition.target,
            earned_at: earnedAt,
            is_secret: definition.isSecret || false,
            company_id: null as any, // Legacy field, not used for user badges
          } as any);

        if (error) throw error;
      }

      return { alreadyEarned: false, newlyEarned: isCompleted };
    },
    onSuccess: async (result, { code }) => {
      queryClient.invalidateQueries({ queryKey: ['user-badges'] });

      if (result.newlyEarned) {
        const definition = BADGE_DEFINITIONS.find(d => d.code === code);
        toast.success(
          `🏆 Badge optjent: ${definition?.icon} ${definition?.label}!`,
          { duration: 5000 }
        );

        // Award XP for earning badge
        try {
          await awardXp({
            eventType: 'badge_earned',
            description: `Optjente badge: ${definition?.label}`,
          });
        } catch (e) {
          console.error('Failed to award XP for badge:', e);
        }
      }
    },
  });

  // Increment badge progress by 1
  const incrementProgress = async (code: BadgeCode) => {
    const currentBadge = badges.find(b => b.code === code);
    const currentProgress = currentBadge?.progress || 0;
    
    // Don't increment if already earned
    if (currentBadge?.isEarned) return;

    await updateProgressMutation.mutateAsync({
      code,
      progress: currentProgress + 1,
    });
  };

  // Check and award badges based on current stats
  const checkBadges = async (stats: {
    xp?: number;
    streak?: number;
    activitiesCount?: number;
    reportsCount?: number;
    documentsCount?: number;
  }) => {
    const updates: Promise<any>[] = [];

    // XP badges
    if (stats.xp) {
      if (stats.xp >= 100) updates.push(updateProgressMutation.mutateAsync({ code: 'xp_100', progress: stats.xp }));
      if (stats.xp >= 500) updates.push(updateProgressMutation.mutateAsync({ code: 'xp_500', progress: stats.xp }));
      if (stats.xp >= 1000) updates.push(updateProgressMutation.mutateAsync({ code: 'xp_1000', progress: stats.xp }));
      if (stats.xp >= 2500) updates.push(updateProgressMutation.mutateAsync({ code: 'xp_2500', progress: stats.xp }));
    }

    // Streak badges
    if (stats.streak) {
      if (stats.streak >= 7) updates.push(updateProgressMutation.mutateAsync({ code: 'streak_7', progress: stats.streak }));
      if (stats.streak >= 14) updates.push(updateProgressMutation.mutateAsync({ code: 'streak_14', progress: stats.streak }));
      if (stats.streak >= 30) updates.push(updateProgressMutation.mutateAsync({ code: 'streak_30', progress: stats.streak }));
      if (stats.streak >= 100) updates.push(updateProgressMutation.mutateAsync({ code: 'streak_100', progress: stats.streak }));
    }

    // Activity badges
    if (stats.activitiesCount) {
      if (stats.activitiesCount >= 1) updates.push(updateProgressMutation.mutateAsync({ code: 'first_activity', progress: 1 }));
      if (stats.activitiesCount >= 10) updates.push(updateProgressMutation.mutateAsync({ code: 'activities_10', progress: stats.activitiesCount }));
      if (stats.activitiesCount >= 50) updates.push(updateProgressMutation.mutateAsync({ code: 'activities_50', progress: stats.activitiesCount }));
    }

    // Report badges
    if (stats.reportsCount) {
      if (stats.reportsCount >= 1) updates.push(updateProgressMutation.mutateAsync({ code: 'first_report', progress: 1 }));
      if (stats.reportsCount >= 12) updates.push(updateProgressMutation.mutateAsync({ code: 'report_master', progress: stats.reportsCount }));
    }

    // Document badges
    if (stats.documentsCount) {
      if (stats.documentsCount >= 1) updates.push(updateProgressMutation.mutateAsync({ code: 'first_document', progress: 1 }));
      if (stats.documentsCount >= 10) updates.push(updateProgressMutation.mutateAsync({ code: 'documents_10', progress: stats.documentsCount }));
    }

    await Promise.all(updates);
  };

  // Check secret badges based on time
  const checkSecretBadges = async () => {
    const now = new Date();
    const hour = now.getHours();
    const day = now.getDay();

    const updates: Promise<any>[] = [];

    // Night owl: after 22:00
    if (hour >= 22) {
      updates.push(updateProgressMutation.mutateAsync({ code: 'night_owl', progress: 1 }));
    }

    // Early bird: before 7:00
    if (hour < 7) {
      updates.push(updateProgressMutation.mutateAsync({ code: 'early_bird', progress: 1 }));
    }

    // Weekend warrior: Saturday (6) or Sunday (0)
    if (day === 0 || day === 6) {
      updates.push(updateProgressMutation.mutateAsync({ code: 'weekend_warrior', progress: 1 }));
    }

    await Promise.all(updates);
  };

  return {
    badges,
    earnedBadges,
    recentBadges,
    isLoading,
    updateProgress: updateProgressMutation.mutateAsync,
    incrementProgress,
    checkBadges,
    checkSecretBadges,
    earnedCount: earnedBadges.length,
    totalCount: BADGE_DEFINITIONS.length,
  };
}
