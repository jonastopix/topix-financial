import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface Milestone {
  id: string;
  company_id: string;
  milestone_type: string;
  milestone_value: number;
  achieved_at: string;
  previous_best?: number;
  metadata: Record<string, any>;
}

export function useRecentMilestones(companyId?: string, limit = 5) {
  return useQuery({
    queryKey: ['milestones', companyId, limit],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('founder_milestones')
        .select('*')
        .eq('company_id', companyId)
        .order('achieved_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data as Milestone[];
    },
    enabled: !!companyId,
  });
}

export function useAllMilestones(companyId?: string) {
  return useQuery({
    queryKey: ['milestones-all', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('founder_milestones')
        .select('*')
        .eq('company_id', companyId)
        .order('achieved_at', { ascending: false });

      if (error) throw error;
      return data as Milestone[];
    },
    enabled: !!companyId,
  });
}
