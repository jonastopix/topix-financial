import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function useCompanyStatus(companyId?: string) {
  return useQuery({
    queryKey: ['company-status', companyId],
    queryFn: async () => {
      if (!companyId) return null;

      // Fetch company status directly
      const { data: company, error: companyError } = await supabase
        .from('companies')
        .select('status')
        .eq('id', companyId)
        .single();

      if (companyError) throw companyError;

      // Fetch DD case for this company
      const { data: ddCase, error: ddError } = await supabase
        .from('due_diligence_cases')
        .select('status')
        .eq('company_id', companyId)
        .maybeSingle();

      if (ddError) throw ddError;

      // Determine status - company must be 'due_diligence' status AND have an active DD case
      const isActive = company?.status === 'active';
      const isInDueDiligence = company?.status === 'due_diligence' && 
                                ddCase && 
                                ddCase.status !== 'approved';

      return {
        isInDueDiligence,
        isActive,
        ddStatus: ddCase?.status || null,
        companyStatus: company?.status || null,
      };
    },
    enabled: !!companyId,
  });
}
