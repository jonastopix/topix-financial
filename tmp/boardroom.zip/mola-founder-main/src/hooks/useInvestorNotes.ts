import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface InvestorNote {
  id: string;
  company_id: string;
  investor_id: string;
  note_text: string;
  is_private: boolean;
  created_at: string;
  updated_at: string;
}

export function useInvestorNotes(companyId: string) {
  return useQuery({
    queryKey: ['investor-notes', companyId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('investor_notes')
        .select('*')
        .eq('company_id', companyId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as InvestorNote[];
    },
    enabled: !!companyId,
  });
}

export function useInvestorNotesMutations() {
  const queryClient = useQueryClient();

  const addNote = useMutation({
    mutationFn: async (note: Omit<InvestorNote, 'id' | 'created_at' | 'updated_at'>) => {
      const { data, error } = await supabase
        .from('investor_notes')
        .insert(note)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['investor-notes', variables.company_id] });
      toast.success('Note tilføjet');
    },
    onError: (error) => {
      toast.error('Fejl ved tilføjelse af note: ' + error.message);
    },
  });

  const updateNote = useMutation({
    mutationFn: async ({ id, ...updates }: Partial<InvestorNote> & { id: string }) => {
      const { data, error } = await supabase
        .from('investor_notes')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['investor-notes', data.company_id] });
      toast.success('Note opdateret');
    },
    onError: (error) => {
      toast.error('Fejl ved opdatering af note: ' + error.message);
    },
  });

  const deleteNote = useMutation({
    mutationFn: async ({ id, companyId }: { id: string; companyId: string }) => {
      const { error } = await supabase
        .from('investor_notes')
        .delete()
        .eq('id', id);

      if (error) throw error;
      return { id, companyId };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['investor-notes', data.companyId] });
      toast.success('Note slettet');
    },
    onError: (error) => {
      toast.error('Fejl ved sletning af note: ' + error.message);
    },
  });

  return {
    addNote,
    updateNote,
    deleteNote,
  };
}
