import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface GovernanceTemplate {
  id: string;
  category: string;
  item_name: string;
  description?: string;
  frequency: string;
  required: boolean;
  months_after_fiscal_year_end?: number;
  sort_order: number;
}

export interface GovernanceProgress {
  id: string;
  company_id: string;
  template_id: string;
  year: number;
  completed: boolean;
  completed_at?: string;
  completed_by?: string;
  notes?: string;
  related_meeting_id?: string;
  related_document_id?: string;
  template?: GovernanceTemplate;
}

export function useBoardGovernance(companyId?: string, year?: number) {
  const queryClient = useQueryClient();

  const { data: templates } = useQuery({
    queryKey: ['governance-templates'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('board_governance_checklist_templates')
        .select('*')
        .order('sort_order');

      if (error) throw error;
      return data as GovernanceTemplate[];
    },
  });

  const { data: progress, isLoading } = useQuery({
    queryKey: ['governance-progress', companyId, year],
    queryFn: async () => {
      if (!companyId || !year) return [];

      const { data, error } = await supabase
        .from('board_governance_progress')
        .select(`
          *,
          template:board_governance_checklist_templates(*)
        `)
        .eq('company_id', companyId)
        .eq('year', year);

      if (error) throw error;
      return data as GovernanceProgress[];
    },
    enabled: !!companyId && !!year,
  });

  const initializeProgress = useMutation({
    mutationFn: async ({ companyId, year }: { companyId: string; year: number }) => {
      if (!templates) return;

      const annualTemplates = templates.filter(t => t.frequency === 'annual');
      
      const progressEntries = annualTemplates.map(template => ({
        company_id: companyId,
        template_id: template.id,
        year,
        completed: false,
      }));

      const { error } = await supabase
        .from('board_governance_progress')
        .upsert(progressEntries, { onConflict: 'company_id,template_id,year' });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-progress'] });
    },
  });

  const updateProgress = useMutation({
    mutationFn: async ({ 
      id, 
      completed, 
      notes,
      related_meeting_id,
      related_document_id 
    }: { 
      id: string; 
      completed: boolean; 
      notes?: string;
      related_meeting_id?: string;
      related_document_id?: string;
    }) => {
      const updates: any = {
        completed,
        notes,
        related_meeting_id,
        related_document_id,
      };

      if (completed) {
        updates.completed_at = new Date().toISOString();
        const { data: { user } } = await supabase.auth.getUser();
        updates.completed_by = user?.id;
      } else {
        updates.completed_at = null;
        updates.completed_by = null;
      }

      const { data, error } = await supabase
        .from('board_governance_progress')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['governance-progress', companyId, year] });
      toast.success('Governance status opdateret');
    },
    onError: (error: any) => {
      toast.error('Fejl: ' + error.message);
    },
  });

  const calculateDeadline = (
    template: GovernanceTemplate,
    fiscalYearEndMonth: number,
    fiscalYearEndDay: number,
    year: number
  ): Date | null => {
    if (template.frequency !== 'annual' || template.months_after_fiscal_year_end === null) {
      return null;
    }

    const fiscalYearEnd = new Date(year, fiscalYearEndMonth - 1, fiscalYearEndDay);
    const deadline = new Date(fiscalYearEnd);
    deadline.setMonth(deadline.getMonth() + (template.months_after_fiscal_year_end || 0));
    
    return deadline;
  };

  const completedCount = progress?.filter(p => p.completed).length || 0;
  const totalCount = progress?.length || 0;
  const completionPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;

  return {
    templates: templates || [],
    progress: progress || [],
    isLoading,
    initializeProgress,
    updateProgress,
    calculateDeadline,
    stats: {
      completed: completedCount,
      total: totalCount,
      percentage: completionPercentage,
    },
  };
}
