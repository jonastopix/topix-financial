import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface TrustedPartnerCategory {
  id: string;
  name: string;
  slug: string;
  icon_name: string;
  description: string | null;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface TrustedPartner {
  id: string;
  category_id: string;
  company_name: string;
  contact_name: string | null;
  contact_title: string | null;
  email: string | null;
  phone: string | null;
  mobile_phone: string | null;
  website: string | null;
  linkedin_url: string | null;
  description: string | null;
  logo_url: string | null;
  is_mola_recommended: boolean;
  sort_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  category?: TrustedPartnerCategory;
}

// Categories hooks
export const useTrustedPartnerCategories = () => {
  return useQuery({
    queryKey: ['trusted-partner-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('trusted_partner_categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return data as TrustedPartnerCategory[];
    },
  });
};

export const useTrustedPartnerCategoriesAdmin = () => {
  return useQuery({
    queryKey: ['trusted-partner-categories-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('trusted_partner_categories')
        .select('*')
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return data as TrustedPartnerCategory[];
    },
  });
};

export const useCreateTrustedPartnerCategory = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (category: { name: string; slug: string; icon_name?: string; description?: string }) => {
      const { data, error } = await supabase
        .from('trusted_partner_categories')
        .insert([category])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories-admin'] });
      toast.success('Kategori oprettet');
    },
    onError: (error) => {
      console.error('Error creating category:', error);
      toast.error('Fejl ved oprettelse af kategori');
    },
  });
};

export const useUpdateTrustedPartnerCategory = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<TrustedPartnerCategory> & { id: string }) => {
      const { data, error } = await supabase
        .from('trusted_partner_categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories-admin'] });
      toast.success('Kategori opdateret');
    },
    onError: (error) => {
      console.error('Error updating category:', error);
      toast.error('Fejl ved opdatering af kategori');
    },
  });
};

export const useDeleteTrustedPartnerCategory = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('trusted_partner_categories')
        .update({ is_active: false })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partner-categories-admin'] });
      toast.success('Kategori deaktiveret');
    },
    onError: (error) => {
      console.error('Error deleting category:', error);
      toast.error('Fejl ved sletning af kategori');
    },
  });
};

// Partners hooks
export const useTrustedPartners = (categoryId?: string) => {
  return useQuery({
    queryKey: ['trusted-partners', categoryId],
    queryFn: async () => {
      let query = supabase
        .from('trusted_partners')
        .select(`
          *,
          category:trusted_partner_categories(*)
        `)
        .eq('is_active', true)
        .order('sort_order', { ascending: true });
      
      if (categoryId) {
        query = query.eq('category_id', categoryId);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      return data as TrustedPartner[];
    },
  });
};

export const useTrustedPartnersAdmin = () => {
  return useQuery({
    queryKey: ['trusted-partners-admin'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('trusted_partners')
        .select(`
          *,
          category:trusted_partner_categories(*)
        `)
        .order('sort_order', { ascending: true });
      
      if (error) throw error;
      return data as TrustedPartner[];
    },
  });
};

export const useCreateTrustedPartner = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (partner: { 
      category_id: string; 
      company_name: string; 
      contact_name?: string;
      contact_title?: string;
      email?: string;
      phone?: string;
      mobile_phone?: string;
      website?: string;
      linkedin_url?: string;
      description?: string;
      is_mola_recommended?: boolean;
    }) => {
      const { data, error } = await supabase
        .from('trusted_partners')
        .insert([partner])
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partners'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partners-admin'] });
      toast.success('Partner oprettet');
    },
    onError: (error) => {
      console.error('Error creating partner:', error);
      toast.error('Fejl ved oprettelse af partner');
    },
  });
};

export const useUpdateTrustedPartner = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<TrustedPartner> & { id: string }) => {
      const { data, error } = await supabase
        .from('trusted_partners')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partners'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partners-admin'] });
      toast.success('Partner opdateret');
    },
    onError: (error) => {
      console.error('Error updating partner:', error);
      toast.error('Fejl ved opdatering af partner');
    },
  });
};

export const useDeleteTrustedPartner = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('trusted_partners')
        .update({ is_active: false })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trusted-partners'] });
      queryClient.invalidateQueries({ queryKey: ['trusted-partners-admin'] });
      toast.success('Partner deaktiveret');
    },
    onError: (error) => {
      console.error('Error deleting partner:', error);
      toast.error('Fejl ved sletning af partner');
    },
  });
};
