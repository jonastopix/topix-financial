import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function useActiveAnnouncements(companyId?: string) {
  return useQuery({
    queryKey: ['active-announcements', companyId],
    queryFn: async () => {
      const now = new Date().toISOString();
      
      let query = supabase
        .from('announcements')
        .select('*')
        .eq('is_active', true)
        .or(`expires_at.is.null,expires_at.gt.${now}`)
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });

      // Filter for company-specific or general announcements
      if (companyId) {
        query = query.or(`company_id.eq.${companyId},company_id.is.null`);
      } else {
        query = query.is('company_id', null);
      }

      const { data, error } = await query;
      if (error) throw error;

      return data || [];
    },
    enabled: true,
  });
}
