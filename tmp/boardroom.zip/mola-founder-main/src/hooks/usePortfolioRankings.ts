import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface PortfolioRanking {
  id: string;
  company_id: string;
  metric_type: string;
  rank: number;
  percentile: number;
  metric_value: number;
  total_companies: number;
  calculated_at: string;
  period_year: number;
  period_month: number | null;
}

export function usePortfolioRankings(companyId?: string) {
  return useQuery({
    queryKey: ['portfolio-rankings', companyId],
    queryFn: async () => {
      if (!companyId) return [];

      const { data, error } = await supabase
        .from('portfolio_rankings')
        .select('*')
        .eq('company_id', companyId)
        .order('calculated_at', { ascending: false });

      if (error) throw error;
      return data as PortfolioRanking[];
    },
    enabled: !!companyId,
  });
}