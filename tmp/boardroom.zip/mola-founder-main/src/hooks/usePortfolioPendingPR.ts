import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface PendingArticleWithCompany {
  id: string;
  company_id: string;
  company_name: string;
  title: string;
  source: string | null;
  url: string;
  published_at: string | null;
  snippet: string | null;
  ai_summary: string | null;
  sentiment: 'positive' | 'neutral' | 'negative' | null;
  relevance_score: number | null;
  created_at: string;
}

export function usePortfolioPendingPR() {
  const queryClient = useQueryClient();

  // Fetch all pending articles across all companies
  const { data: pendingArticles, isLoading, error, refetch } = useQuery({
    queryKey: ['portfolio-pending-pr'],
    queryFn: async () => {
      // Fetch all companies first
      const { data: companies, error: companiesError } = await supabase
        .from('companies')
        .select('id, name')
        .eq('is_active', true);

      if (companiesError) throw companiesError;

      // Fetch all pending PR articles
      const { data: articles, error: articlesError } = await supabase
        .from('company_pr_articles')
        .select('*')
        .eq('article_status', 'pending')
        .order('created_at', { ascending: false });

      if (articlesError) throw articlesError;

      const companyMap = new Map(companies?.map(c => [c.id, c.name]) || []);

      // Merge company names into articles
      const articlesWithCompany: PendingArticleWithCompany[] = (articles || []).map(article => ({
        id: article.id,
        company_id: article.company_id,
        company_name: companyMap.get(article.company_id) || 'Ukendt selskab',
        title: article.title,
        source: article.source,
        url: article.url,
        published_at: article.published_at,
        snippet: article.snippet,
        ai_summary: article.ai_summary,
        sentiment: article.sentiment as 'positive' | 'neutral' | 'negative' | null,
        relevance_score: article.relevance_score,
        created_at: article.created_at,
      }));

      return articlesWithCompany;
    },
  });

  // Approve a single article
  const approveMutation = useMutation({
    mutationFn: async (articleId: string) => {
      const { error } = await supabase
        .from('company_pr_articles')
        .update({ 
          article_status: 'approved',
          is_saved: true,
        })
        .eq('id', articleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['portfolio-pending-pr'] });
      queryClient.invalidateQueries({ queryKey: ['portfolio-pr-overview'] });
      queryClient.invalidateQueries({ queryKey: ['company-pr-articles'] });
      queryClient.invalidateQueries({ queryKey: ['company-pr-pending'] });
      toast.success('Artikel godkendt');
    },
    onError: (error) => {
      console.error('Failed to approve article:', error);
      toast.error('Kunne ikke godkende artikel');
    },
  });

  // Dismiss a single article
  const dismissMutation = useMutation({
    mutationFn: async (articleId: string) => {
      const { error } = await supabase
        .from('company_pr_articles')
        .update({ 
          article_status: 'dismissed',
          is_saved: false,
        })
        .eq('id', articleId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['portfolio-pending-pr'] });
      toast.success('Artikel afvist');
    },
    onError: (error) => {
      console.error('Failed to dismiss article:', error);
      toast.error('Kunne ikke afvise artikel');
    },
  });

  // Approve all pending articles
  const approveAllMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('company_pr_articles')
        .update({ 
          article_status: 'approved',
          is_saved: true,
        })
        .eq('article_status', 'pending');

      if (error) throw error;
      return { count: pendingArticles?.length || 0 };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['portfolio-pending-pr'] });
      queryClient.invalidateQueries({ queryKey: ['portfolio-pr-overview'] });
      queryClient.invalidateQueries({ queryKey: ['company-pr-articles'] });
      queryClient.invalidateQueries({ queryKey: ['company-pr-pending'] });
      toast.success(`${data.count} artikler godkendt`);
    },
    onError: (error) => {
      console.error('Failed to approve all articles:', error);
      toast.error('Kunne ikke godkende artikler');
    },
  });

  // Dismiss all pending articles
  const dismissAllMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from('company_pr_articles')
        .update({ 
          article_status: 'dismissed',
          is_saved: false,
        })
        .eq('article_status', 'pending');

      if (error) throw error;
      return { count: pendingArticles?.length || 0 };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['portfolio-pending-pr'] });
      toast.success(`${data.count} artikler afvist`);
    },
    onError: (error) => {
      console.error('Failed to dismiss all articles:', error);
      toast.error('Kunne ikke afvise artikler');
    },
  });

  // Group articles by company
  const articlesByCompany = pendingArticles?.reduce((acc, article) => {
    if (!acc[article.company_id]) {
      acc[article.company_id] = {
        companyName: article.company_name,
        articles: [],
      };
    }
    acc[article.company_id].articles.push(article);
    return acc;
  }, {} as Record<string, { companyName: string; articles: PendingArticleWithCompany[] }>) || {};

  return {
    pendingArticles,
    articlesByCompany,
    totalPending: pendingArticles?.length || 0,
    isLoading,
    error,
    refetch,
    approve: approveMutation.mutate,
    dismiss: dismissMutation.mutate,
    approveAll: approveAllMutation.mutate,
    dismissAll: dismissAllMutation.mutate,
    isApproving: approveMutation.isPending,
    isDismissing: dismissMutation.isPending,
    isApprovingAll: approveAllMutation.isPending,
    isDismissingAll: dismissAllMutation.isPending,
  };
}
