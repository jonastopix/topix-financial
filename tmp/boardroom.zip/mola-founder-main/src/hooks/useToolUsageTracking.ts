import { useCallback } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ToolUsageEvent {
  tool_name: string;
  tool_action: string;
  metadata?: Record<string, any>;
  company_id?: string;
}

interface ToolUsageStats {
  tool_name: string;
  total_views: number;
  unique_users: number;
  last_used: string;
}

interface DailyUsage {
  date: string;
  count: number;
  tool_name: string;
}

export function useToolUsageTracking() {
  const { user } = useAuth();

  const trackUsageMutation = useMutation({
    mutationFn: async (event: ToolUsageEvent) => {
      if (!user?.id) return null;

      const { error } = await supabase
        .from('tool_usage_events')
        .insert({
          user_id: user.id,
          tool_name: event.tool_name,
          tool_action: event.tool_action,
          metadata: event.metadata || {},
          company_id: event.company_id || null,
        });

      if (error) {
        console.error('Failed to track tool usage:', error);
        throw error;
      }
    },
  });

  const trackToolUsage = useCallback(
    (toolName: string, action: string, metadata?: Record<string, any>, companyId?: string) => {
      trackUsageMutation.mutate({
        tool_name: toolName,
        tool_action: action,
        metadata,
        company_id: companyId,
      });
    },
    [trackUsageMutation]
  );

  return { trackToolUsage };
}

export function useToolUsageStats(dateRange?: { from: Date; to: Date }) {
  const fromDate = dateRange?.from || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const toDate = dateRange?.to || new Date();

  const statsQuery = useQuery({
    queryKey: ['tool-usage-stats', fromDate.toISOString(), toDate.toISOString()],
    queryFn: async () => {
      // Get aggregated stats per tool
      const { data: rawEvents, error } = await supabase
        .from('tool_usage_events')
        .select('tool_name, tool_action, user_id, created_at')
        .gte('created_at', fromDate.toISOString())
        .lte('created_at', toDate.toISOString())
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Calculate stats per tool
      const toolMap = new Map<string, { views: number; users: Set<string>; lastUsed: string }>();

      for (const event of rawEvents || []) {
        const existing = toolMap.get(event.tool_name) || {
          views: 0,
          users: new Set<string>(),
          lastUsed: event.created_at,
        };

        existing.views += 1;
        if (event.user_id) existing.users.add(event.user_id);
        if (event.created_at > existing.lastUsed) existing.lastUsed = event.created_at;

        toolMap.set(event.tool_name, existing);
      }

      const stats: ToolUsageStats[] = Array.from(toolMap.entries()).map(([name, data]) => ({
        tool_name: name,
        total_views: data.views,
        unique_users: data.users.size,
        last_used: data.lastUsed,
      }));

      return stats.sort((a, b) => b.total_views - a.total_views);
    },
  });

  const dailyUsageQuery = useQuery({
    queryKey: ['tool-usage-daily', fromDate.toISOString(), toDate.toISOString()],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tool_usage_events')
        .select('tool_name, created_at')
        .gte('created_at', fromDate.toISOString())
        .lte('created_at', toDate.toISOString())
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Group by date and tool
      const dailyMap = new Map<string, Map<string, number>>();

      for (const event of data || []) {
        const date = new Date(event.created_at).toISOString().split('T')[0];
        const toolMap = dailyMap.get(date) || new Map<string, number>();
        toolMap.set(event.tool_name, (toolMap.get(event.tool_name) || 0) + 1);
        dailyMap.set(date, toolMap);
      }

      const result: DailyUsage[] = [];
      dailyMap.forEach((toolMap, date) => {
        toolMap.forEach((count, tool_name) => {
          result.push({ date, count, tool_name });
        });
      });

      return result;
    },
  });

  const topUsersQuery = useQuery({
    queryKey: ['tool-usage-top-users', fromDate.toISOString(), toDate.toISOString()],
    queryFn: async () => {
      // First get all events
      const { data: events, error: eventsError } = await supabase
        .from('tool_usage_events')
        .select('user_id, tool_name')
        .gte('created_at', fromDate.toISOString())
        .lte('created_at', toDate.toISOString());

      if (eventsError) throw eventsError;

      // Get unique user IDs
      const userIds = [...new Set((events || []).map(e => e.user_id).filter(Boolean))] as string[];

      // Fetch profiles for those users
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, company_name')
        .in('id', userIds);

      if (profilesError) throw profilesError;

      const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);

      // Count per user
      const userMap = new Map<string, { count: number; name: string; company: string }>();

      for (const event of events || []) {
        if (!event.user_id) continue;
        const profile = profileMap.get(event.user_id);
        const existing = userMap.get(event.user_id) || {
          count: 0,
          name: profile?.full_name || 'Ukendt',
          company: profile?.company_name || '',
        };
        existing.count += 1;
        userMap.set(event.user_id, existing);
      }

      return Array.from(userMap.entries())
        .map(([userId, data]) => ({
          user_id: userId,
          usage_count: data.count,
          full_name: data.name,
          company_name: data.company,
        }))
        .sort((a, b) => b.usage_count - a.usage_count)
        .slice(0, 10);
    },
  });

  return {
    stats: statsQuery.data || [],
    dailyUsage: dailyUsageQuery.data || [],
    topUsers: topUsersQuery.data || [],
    isLoading: statsQuery.isLoading || dailyUsageQuery.isLoading,
    error: statsQuery.error || dailyUsageQuery.error,
  };
}
