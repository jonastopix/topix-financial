import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useGamification } from './useGamification';

// Challenge types and their generation logic
const CHALLENGE_TEMPLATES = [
  {
    type: 'log_activities',
    descriptions: [
      'Log 2 aktiviteter i dag',
      'Registrer 3 møder eller opkald',
    ],
    targetCounts: [2, 3],
    xpRewards: [20, 30],
  },
  {
    type: 'visit_companies',
    descriptions: [
      'Besøg 3 selskabssider',
      'Gennemgå 5 porteføljeselskaber',
    ],
    targetCounts: [3, 5],
    xpRewards: [15, 25],
  },
  {
    type: 'complete_tasks',
    descriptions: [
      'Fuldfør 2 opgaver',
      'Afslut 3 opgaver i dag',
    ],
    targetCounts: [2, 3],
    xpRewards: [25, 40],
  },
  {
    type: 'add_notes',
    descriptions: [
      'Tilføj noter til 2 aktiviteter',
      'Dokumenter 3 møder med noter',
    ],
    targetCounts: [2, 3],
    xpRewards: [15, 25],
  },
  {
    type: 'review_reports',
    descriptions: [
      'Gennemgå en månedsrapport',
      'Tjek 2 selskabers rapporter',
    ],
    targetCounts: [1, 2],
    xpRewards: [20, 35],
  },
];

export interface DailyChallenge {
  id: string;
  user_id: string;
  challenge_date: string;
  challenge_type: string;
  challenge_description: string;
  xp_reward: number;
  target_count: number;
  current_count: number;
  is_completed: boolean;
  completed_at: string | null;
  created_at: string;
}

export function useDailyChallenges() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { awardXp } = useGamification();

  // Get today's date in YYYY-MM-DD format
  const today = new Date().toISOString().split('T')[0];

  // Fetch today's challenges
  const { data: challenges, isLoading } = useQuery({
    queryKey: ['daily-challenges', user?.id, today],
    queryFn: async (): Promise<DailyChallenge[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('daily_challenges')
        .select('*')
        .eq('user_id', user.id)
        .eq('challenge_date', today)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Generate daily challenges if none exist
  const generateChallengesMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) throw new Error('No user');

      // Check if challenges already exist for today
      const { data: existing } = await supabase
        .from('daily_challenges')
        .select('id')
        .eq('user_id', user.id)
        .eq('challenge_date', today)
        .limit(1);

      if (existing && existing.length > 0) {
        return { generated: false };
      }

      // Select 2-3 random challenges
      const shuffled = [...CHALLENGE_TEMPLATES].sort(() => Math.random() - 0.5);
      const selectedTemplates = shuffled.slice(0, Math.random() > 0.5 ? 3 : 2);

      const challengesToInsert = selectedTemplates.map(template => {
        const variantIndex = Math.floor(Math.random() * template.descriptions.length);
        return {
          user_id: user.id,
          challenge_date: today,
          challenge_type: template.type,
          challenge_description: template.descriptions[variantIndex],
          xp_reward: template.xpRewards[variantIndex],
          target_count: template.targetCounts[variantIndex],
          current_count: 0,
          is_completed: false,
        };
      });

      const { error } = await supabase
        .from('daily_challenges')
        .insert(challengesToInsert);

      if (error) throw error;
      return { generated: true };
    },
    onSuccess: (result) => {
      if (result.generated) {
        queryClient.invalidateQueries({ queryKey: ['daily-challenges'] });
      }
    },
  });

  // Update challenge progress
  const updateProgressMutation = useMutation({
    mutationFn: async ({ 
      challengeType, 
      increment = 1 
    }: { 
      challengeType: string; 
      increment?: number 
    }) => {
      if (!user?.id) throw new Error('No user');

      // Find matching challenge for today
      const { data: challenge, error: fetchError } = await supabase
        .from('daily_challenges')
        .select('*')
        .eq('user_id', user.id)
        .eq('challenge_date', today)
        .eq('challenge_type', challengeType)
        .eq('is_completed', false)
        .maybeSingle();

      if (fetchError) throw fetchError;
      if (!challenge) return { updated: false, completed: false };

      const newCount = Math.min(challenge.current_count + increment, challenge.target_count);
      const isCompleted = newCount >= challenge.target_count;

      const { error: updateError } = await supabase
        .from('daily_challenges')
        .update({
          current_count: newCount,
          is_completed: isCompleted,
          completed_at: isCompleted ? new Date().toISOString() : null,
        })
        .eq('id', challenge.id);

      if (updateError) throw updateError;

      return { 
        updated: true, 
        completed: isCompleted, 
        xpReward: isCompleted ? challenge.xp_reward : 0,
        description: challenge.challenge_description,
      };
    },
    onSuccess: async (result) => {
      queryClient.invalidateQueries({ queryKey: ['daily-challenges'] });

      if (result.completed && result.xpReward) {
        toast.success(`🎯 Daglig udfordring fuldført! +${result.xpReward} XP`);
        
        try {
          await awardXp({
            eventType: 'daily_challenge_completed',
            description: result.description,
            customAmount: result.xpReward,
          });
        } catch (e) {
          console.error('Failed to award XP for challenge:', e);
        }
      }
    },
  });

  // Calculate stats
  const completedCount = challenges?.filter(c => c.is_completed).length || 0;
  const totalCount = challenges?.length || 0;
  const totalXpAvailable = challenges?.reduce((sum, c) => sum + c.xp_reward, 0) || 0;
  const xpEarned = challenges
    ?.filter(c => c.is_completed)
    .reduce((sum, c) => sum + c.xp_reward, 0) || 0;

  return {
    challenges: challenges || [],
    isLoading,
    completedCount,
    totalCount,
    totalXpAvailable,
    xpEarned,
    allCompleted: completedCount === totalCount && totalCount > 0,
    generateChallenges: generateChallengesMutation.mutateAsync,
    updateProgress: updateProgressMutation.mutateAsync,
  };
}
