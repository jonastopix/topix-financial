import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { getCountryFlag } from '@/lib/trustpilotCountries';

export interface RatingBreakdown {
  five: number;
  four: number;
  three: number;
  two: number;
  one: number;
}

export interface TrustpilotScore {
  id: string;
  score: number | null;
  totalReviews: number | null;
  ratingBreakdown: RatingBreakdown | null;
  recentScore: number | null;
  recentReviewsCount: number | null;
  recentPeriodDays: number;
  lastFetchedAt: string | null;
  trendDirection: 'up' | 'down' | 'stable';
  trendDelta: number;
}

export interface TrustpilotProfile {
  id: string;
  companyId: string;
  countryCode: string;
  countryName: string;
  countryFlag: string;
  trustpilotUrl: string;
  isPrimary: boolean;
  createdAt: string;
  score: TrustpilotScore | null;
}

export interface AggregatedScores {
  averageScore: number | null;
  totalReviews: number;
  averageRecentScore: number | null;
  recentReviewsCount: number;
  overallTrend: 'up' | 'down' | 'stable';
  trendDelta: number;
}

function calculateTrend(score: number | null, recentScore: number | null): { direction: 'up' | 'down' | 'stable'; delta: number } {
  if (score === null || recentScore === null) {
    return { direction: 'stable', delta: 0 };
  }
  const delta = Number((recentScore - score).toFixed(1));
  if (delta > 0.1) return { direction: 'up', delta };
  if (delta < -0.1) return { direction: 'down', delta };
  return { direction: 'stable', delta };
}

export function useTrustpilotScores(companyId: string) {
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ['trustpilot-scores', companyId],
    queryFn: async () => {
      // Fetch profiles with their scores
      const { data: profiles, error: profilesError } = await supabase
        .from('company_trustpilot_profiles')
        .select(`
          id,
          company_id,
          country_code,
          country_name,
          trustpilot_url,
          is_primary,
          created_at,
          trustpilot_scores (
            id,
            score,
            total_reviews,
            rating_breakdown,
            recent_score,
            recent_reviews_count,
            recent_period_days,
            last_fetched_at
          )
        `)
        .eq('company_id', companyId)
        .order('is_primary', { ascending: false })
        .order('country_name', { ascending: true });

      if (profilesError) throw profilesError;

      return profiles || [];
    },
    enabled: !!companyId,
  });

  // Transform data to typed format
  const profiles: TrustpilotProfile[] = (data || []).map((profile: any) => {
    // Handle both array (one-to-many) and object (one-to-one) response formats from PostgREST
    const scoreData = Array.isArray(profile.trustpilot_scores) 
      ? profile.trustpilot_scores[0] 
      : profile.trustpilot_scores || null;
    const trend = scoreData 
      ? calculateTrend(scoreData.score, scoreData.recent_score)
      : { direction: 'stable' as const, delta: 0 };

    return {
      id: profile.id,
      companyId: profile.company_id,
      countryCode: profile.country_code,
      countryName: profile.country_name,
      countryFlag: getCountryFlag(profile.country_code),
      trustpilotUrl: profile.trustpilot_url,
      isPrimary: profile.is_primary,
      createdAt: profile.created_at,
      score: scoreData ? {
        id: scoreData.id,
        score: scoreData.score ? Number(scoreData.score) : null,
        totalReviews: scoreData.total_reviews,
        ratingBreakdown: scoreData.rating_breakdown as RatingBreakdown | null,
        recentScore: scoreData.recent_score ? Number(scoreData.recent_score) : null,
        recentReviewsCount: scoreData.recent_reviews_count,
        recentPeriodDays: scoreData.recent_period_days || 30,
        lastFetchedAt: scoreData.last_fetched_at,
        trendDirection: trend.direction,
        trendDelta: trend.delta,
      } : null,
    };
  });

  // Calculate aggregated scores
  const aggregated: AggregatedScores = (() => {
    const profilesWithScores = profiles.filter(p => p.score?.score !== null);
    
    if (profilesWithScores.length === 0) {
      return {
        averageScore: null,
        totalReviews: 0,
        averageRecentScore: null,
        recentReviewsCount: 0,
        overallTrend: 'stable' as const,
        trendDelta: 0,
      };
    }

    // Weighted average based on number of reviews
    const totalReviews = profilesWithScores.reduce((sum, p) => sum + (p.score?.totalReviews || 0), 0);
    const recentReviewsCount = profilesWithScores.reduce((sum, p) => sum + (p.score?.recentReviewsCount || 0), 0);
    
    const weightedScore = profilesWithScores.reduce((sum, p) => {
      const weight = p.score?.totalReviews || 0;
      return sum + (p.score?.score || 0) * weight;
    }, 0);
    
    const weightedRecentScore = profilesWithScores
      .filter(p => p.score?.recentScore !== null)
      .reduce((sum, p) => {
        const weight = p.score?.recentReviewsCount || 0;
        return sum + (p.score?.recentScore || 0) * weight;
      }, 0);

    const averageScore = totalReviews > 0 ? Number((weightedScore / totalReviews).toFixed(1)) : null;
    const averageRecentScore = recentReviewsCount > 0 ? Number((weightedRecentScore / recentReviewsCount).toFixed(1)) : null;
    
    const trend = calculateTrend(averageScore, averageRecentScore);

    return {
      averageScore,
      totalReviews,
      averageRecentScore,
      recentReviewsCount,
      overallTrend: trend.direction,
      trendDelta: trend.delta,
    };
  })();

  // Mutation to refresh a single profile
  const refreshProfileMutation = useMutation({
    mutationFn: async (profileId: string) => {
      const { data, error } = await supabase.functions.invoke('fetch-trustpilot-score', {
        body: { profile_id: profileId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trustpilot-scores', companyId] });
    },
  });

  // Mutation to refresh all profiles
  const refreshAllMutation = useMutation({
    mutationFn: async () => {
      const { data, error } = await supabase.functions.invoke('refresh-company-trustpilot-scores', {
        body: { company_id: companyId },
      });
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trustpilot-scores', companyId] });
    },
  });

  return {
    profiles,
    aggregated,
    isLoading,
    error,
    refreshProfile: refreshProfileMutation.mutate,
    refreshAll: refreshAllMutation.mutate,
    isRefreshing: refreshProfileMutation.isPending || refreshAllMutation.isPending,
  };
}

// Hook for managing profiles (CRUD operations)
export function useTrustpilotProfileManagement(companyId: string) {
  const queryClient = useQueryClient();

  const addProfileMutation = useMutation({
    mutationFn: async (profile: {
      countryCode: string;
      countryName: string;
      trustpilotUrl: string;
      isPrimary?: boolean;
    }) => {
      const { data, error } = await supabase
        .from('company_trustpilot_profiles')
        .insert({
          company_id: companyId,
          country_code: profile.countryCode,
          country_name: profile.countryName,
          trustpilot_url: profile.trustpilotUrl,
          is_primary: profile.isPrimary || false,
        })
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trustpilot-scores', companyId] });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async ({ profileId, updates }: {
      profileId: string;
      updates: Partial<{
        countryCode: string;
        countryName: string;
        trustpilotUrl: string;
        isPrimary: boolean;
      }>;
    }) => {
      const updateData: any = {};
      if (updates.countryCode !== undefined) updateData.country_code = updates.countryCode;
      if (updates.countryName !== undefined) updateData.country_name = updates.countryName;
      if (updates.trustpilotUrl !== undefined) updateData.trustpilot_url = updates.trustpilotUrl;
      if (updates.isPrimary !== undefined) updateData.is_primary = updates.isPrimary;

      const { data, error } = await supabase
        .from('company_trustpilot_profiles')
        .update(updateData)
        .eq('id', profileId)
        .select()
        .single();
      
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trustpilot-scores', companyId] });
    },
  });

  const deleteProfileMutation = useMutation({
    mutationFn: async (profileId: string) => {
      const { error } = await supabase
        .from('company_trustpilot_profiles')
        .delete()
        .eq('id', profileId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trustpilot-scores', companyId] });
    },
  });

  return {
    addProfile: addProfileMutation.mutateAsync,
    updateProfile: updateProfileMutation.mutateAsync,
    deleteProfile: deleteProfileMutation.mutateAsync,
    isAdding: addProfileMutation.isPending,
    isUpdating: updateProfileMutation.isPending,
    isDeleting: deleteProfileMutation.isPending,
  };
}
