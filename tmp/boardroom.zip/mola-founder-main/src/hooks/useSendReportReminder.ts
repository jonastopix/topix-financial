import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface SendReminderParams {
  companyId: string;
  targetMonth?: number;
  targetYear?: number;
}

export const useSendReportReminder = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ companyId, targetMonth, targetYear }: SendReminderParams) => {
      const { data, error } = await supabase.functions.invoke("send-report-reminder", {
        body: { companyId, targetMonth, targetYear },
      });

      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      toast.success("Påmindelse sendt", {
        description: `Email sendt til ${data.company} for ${data.period}`,
      });
      queryClient.invalidateQueries({ queryKey: ["companies-with-missing-reports"] });
    },
    onError: (error: any) => {
      console.error("Error sending reminder:", error);
      toast.error("Kunne ikke sende påmindelse", {
        description: error.message || "Der opstod en fejl",
      });
    },
  });
};
