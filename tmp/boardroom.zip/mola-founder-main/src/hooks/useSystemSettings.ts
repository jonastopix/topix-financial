import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useSystemSettings = () => {
  const queryClient = useQueryClient();

  // Hent reminder indstilling
  const { data: remindersEnabled, isLoading } = useQuery({
    queryKey: ['system-settings', 'monthly_report_reminders'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('system_settings')
        .select('setting_value, is_active')
        .eq('setting_key', 'monthly_report_reminders')
        .single();
      
      if (error) throw error;
      return (data?.setting_value as any)?.enabled && data?.is_active;
    }
  });

  // Toggle reminder indstilling
  const toggleReminders = useMutation({
    mutationFn: async (enabled: boolean) => {
      const { error } = await supabase
        .from('system_settings')
        .update({
          setting_value: { enabled },
          is_active: enabled,
          updated_at: new Date().toISOString()
        })
        .eq('setting_key', 'monthly_report_reminders');
      
      if (error) throw error;
      return enabled;
    },
    onSuccess: (enabled) => {
      queryClient.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success(
        enabled 
          ? 'Månedsrapport reminders aktiveret' 
          : 'Månedsrapport reminders deaktiveret'
      );
    },
    onError: (error) => {
      console.error('Error toggling reminders:', error);
      toast.error('Kunne ikke ændre indstilling');
    }
  });

  return { 
    remindersEnabled: remindersEnabled ?? false, 
    isLoading, 
    toggleReminders: toggleReminders.mutateAsync 
  };
};
