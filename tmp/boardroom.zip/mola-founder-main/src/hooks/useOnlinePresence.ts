import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRole } from '@/contexts/RoleContext';
import { supabase } from '@/integrations/supabase/client';
import { RealtimeChannel } from '@supabase/supabase-js';
import { useLocation } from 'react-router-dom';

interface OnlineUser {
  user_id: string;
  full_name: string;
  email: string;
  role: string;
  online_at: string;
  current_page: string;
  current_page_label: string;
}

// Path to readable label mapping
const getPageLabel = (pathname: string): string => {
  const pathLabels: Record<string, string> = {
    '/': 'Dashboard',
    '/monthly-report': 'Månedsrapport',
    '/financial-dashboard': 'Finansiel Dashboard',
    '/tasks': 'Opgaver',
    '/insights': 'Insights',
    '/procurement': 'Deals & Indkøb',
    '/portfolio/overview': 'Portfolio',
    '/portfolio/valuations': 'Valuations',
    '/portfolio/companies': 'Virksomheder',
    '/portfolio/due-diligence': 'Due Diligence',
    '/my-due-diligence': 'Due Diligence',
    '/admin-settings': 'Indstillinger',
    '/user-management': 'Brugere',
    '/fund-management': 'Fonde',
    '/fund-partner-dashboard': 'Partner Dashboard',
    '/resources': 'Ressourcer',
    '/support': 'Support',
    '/profile': 'Profil',
    '/exits-history': 'Exits',
  };
  
  // Check for exact match first
  if (pathLabels[pathname]) return pathLabels[pathname];
  
  // Check for company page
  if (pathname.startsWith('/company/')) {
    return 'Ser på virksomhed';
  }
  
  // Check for partial matches
  for (const [path, label] of Object.entries(pathLabels)) {
    if (pathname.startsWith(path) && path !== '/') {
      return label;
    }
  }
  
  return 'Navigerer';
};

export function useOnlinePresence() {
  const { user } = useAuth();
  const { activeRole } = useRole();
  const location = useLocation();
  const [onlineUsers, setOnlineUsers] = useState<OnlineUser[]>([]);
  const [channel, setChannel] = useState<RealtimeChannel | null>(null);

  useEffect(() => {
    if (!user) return;

    const fetchProfileAndJoin = async () => {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .single();

      const presenceChannel = supabase.channel('online-users');

      presenceChannel
        .on('presence', { event: 'sync' }, () => {
          const state = presenceChannel.presenceState();
          const users: OnlineUser[] = [];
          
          Object.keys(state).forEach(key => {
            const presences = state[key] as any[];
            presences.forEach(presence => {
              users.push(presence as OnlineUser);
            });
          });
          
          setOnlineUsers(users);
        })
        .on('presence', { event: 'join' }, ({ newPresences }) => {
          console.log('User joined:', newPresences);
        })
        .on('presence', { event: 'leave' }, ({ leftPresences }) => {
          console.log('User left:', leftPresences);
        })
        .subscribe(async (status) => {
          if (status === 'SUBSCRIBED') {
            await presenceChannel.track({
              user_id: user.id,
              full_name: profile?.full_name || user.email || 'Bruger',
              email: user.email || '',
              role: activeRole,
              online_at: new Date().toISOString(),
              current_page: location.pathname,
              current_page_label: getPageLabel(location.pathname),
            });
          }
        });

      setChannel(presenceChannel);
    };

    fetchProfileAndJoin();

    return () => {
      if (channel) {
        channel.unsubscribe();
      }
    };
  }, [user, activeRole]);

  // Update presence when location changes
  useEffect(() => {
    if (channel && user) {
      channel.track({
        user_id: user.id,
        current_page: location.pathname,
        current_page_label: getPageLabel(location.pathname),
      });
    }
  }, [location.pathname, channel, user]);

  const otherUsers = onlineUsers.filter(u => u.user_id !== user?.id);

  return { onlineUsers: otherUsers, totalOnline: otherUsers.length };
}
