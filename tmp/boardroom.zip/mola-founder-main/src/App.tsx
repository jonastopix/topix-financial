import { Toaster } from '@/components/ui/toaster';
import { Toaster as Sonner } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { RoleProvider } from '@/contexts/RoleContext';
import { KeyboardShortcutProvider } from '@/contexts/KeyboardShortcutContext';
import ErrorBoundary from '@/components/ErrorBoundary';

import Auth from './pages/Auth';
import AcceptInvitation from './pages/AcceptInvitation';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

import BoardroomDashboard from './pages/BoardroomDashboard';
import MonthlyReport from './pages/MonthlyReport';
import Milestones from './pages/Milestones';
import AdminReporting from './pages/AdminReporting';

import Support from './pages/Support';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';

const queryClient = new QueryClient();

const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
          <div className="text-foreground text-sm">Indlæser...</div>
        </div>
      </div>
    );
  }

  return user ? <>{children}</> : <Navigate to="/auth" replace />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <RoleProvider>
            <KeyboardShortcutProvider>
              <ErrorBoundary>
                <Routes>
                  <Route path="/auth" element={<Auth />} />
                  <Route path="/accept-invitation" element={<AcceptInvitation />} />
                  <Route path="/forgot-password" element={<ForgotPassword />} />
                  <Route path="/reset-password" element={<ResetPassword />} />

                  <Route
                    path="/"
                    element={
                      <ProtectedRoute>
                        <BoardroomDashboard />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/monthly-report"
                    element={
                      <ProtectedRoute>
                        <MonthlyReport />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/milestones"
                    element={
                      <ProtectedRoute>
                        <Milestones />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/admin/reporting"
                    element={
                      <ProtectedRoute>
                        <AdminReporting />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/support"
                    element={
                      <ProtectedRoute>
                        <Support />
                      </ProtectedRoute>
                    }
                  />

                  <Route
                    path="/profile"
                    element={
                      <ProtectedRoute>
                        <Profile />
                      </ProtectedRoute>
                    }
                  />

                  <Route path="*" element={<NotFound />} />
                </Routes>
              </ErrorBoundary>
            </KeyboardShortcutProvider>
          </RoleProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
