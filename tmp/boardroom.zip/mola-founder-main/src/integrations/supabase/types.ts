export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      announcements: {
        Row: {
          company_id: string | null
          created_at: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          link_url: string | null
          message: string
          metadata: Json | null
          priority: string
          type: string
        }
        Insert: {
          company_id?: string | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          link_url?: string | null
          message: string
          metadata?: Json | null
          priority: string
          type: string
        }
        Update: {
          company_id?: string | null
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          link_url?: string | null
          message?: string
          metadata?: Json | null
          priority?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      badges: {
        Row: {
          badge_type: string | null
          code: string
          company_id: string
          created_at: string | null
          description: string | null
          earned_at: string
          id: string
          is_secret: boolean | null
          label: string
          progress: number | null
          target: number | null
          user_id: string | null
        }
        Insert: {
          badge_type?: string | null
          code: string
          company_id: string
          created_at?: string | null
          description?: string | null
          earned_at?: string
          id?: string
          is_secret?: boolean | null
          label: string
          progress?: number | null
          target?: number | null
          user_id?: string | null
        }
        Update: {
          badge_type?: string | null
          code?: string
          company_id?: string
          created_at?: string | null
          description?: string | null
          earned_at?: string
          id?: string
          is_secret?: boolean | null
          label?: string
          progress?: number | null
          target?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "badges_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      board_governance_checklist_templates: {
        Row: {
          category: string
          created_at: string
          description: string | null
          frequency: string
          id: string
          item_name: string
          months_after_fiscal_year_end: number | null
          required: boolean | null
          sort_order: number
        }
        Insert: {
          category: string
          created_at?: string
          description?: string | null
          frequency: string
          id?: string
          item_name: string
          months_after_fiscal_year_end?: number | null
          required?: boolean | null
          sort_order: number
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          frequency?: string
          id?: string
          item_name?: string
          months_after_fiscal_year_end?: number | null
          required?: boolean | null
          sort_order?: number
        }
        Relationships: []
      }
      board_governance_progress: {
        Row: {
          company_id: string
          completed: boolean | null
          completed_at: string | null
          completed_by: string | null
          created_at: string
          id: string
          notes: string | null
          related_document_id: string | null
          related_meeting_id: string | null
          template_id: string
          year: number
        }
        Insert: {
          company_id: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          related_document_id?: string | null
          related_meeting_id?: string | null
          template_id: string
          year: number
        }
        Update: {
          company_id?: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          related_document_id?: string | null
          related_meeting_id?: string | null
          template_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "board_governance_progress_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_governance_progress_completed_by_fkey"
            columns: ["completed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_governance_progress_related_document_id_fkey"
            columns: ["related_document_id"]
            isOneToOne: false
            referencedRelation: "company_documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_governance_progress_related_meeting_id_fkey"
            columns: ["related_meeting_id"]
            isOneToOne: false
            referencedRelation: "company_meetings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_governance_progress_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "board_governance_checklist_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      board_members: {
        Row: {
          appointed_date: string
          company_id: string
          created_at: string
          email: string | null
          id: string
          is_active: boolean | null
          name: string
          notes: string | null
          phone: string | null
          role: string
          term_end_date: string | null
          updated_at: string
        }
        Insert: {
          appointed_date: string
          company_id: string
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          notes?: string | null
          phone?: string | null
          role: string
          term_end_date?: string | null
          updated_at?: string
        }
        Update: {
          appointed_date?: string
          company_id?: string
          created_at?: string
          email?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          notes?: string | null
          phone?: string | null
          role?: string
          term_end_date?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "board_members_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string | null
          description_da: string | null
          id: string
          name_da: string
          name_en: string
          sort_order: number
        }
        Insert: {
          created_at?: string | null
          description_da?: string | null
          id?: string
          name_da: string
          name_en: string
          sort_order: number
        }
        Update: {
          created_at?: string | null
          description_da?: string | null
          id?: string
          name_da?: string
          name_en?: string
          sort_order?: number
        }
        Relationships: []
      }
      companies: {
        Row: {
          accountant_email: string | null
          accountant_name: string | null
          address: string | null
          auto_invite_coinvestors: boolean | null
          auto_invite_dd_partners: boolean | null
          auto_invite_responsible_partner: boolean | null
          board_formation_date: string | null
          brand_aliases: string[] | null
          business_model: string | null
          city: string | null
          company_type: string | null
          created_at: string | null
          cvr: string | null
          description: string | null
          ejerbog_updated_at: string | null
          email: string | null
          equity_share_pct: number | null
          fiscal_year_end_day: number | null
          fiscal_year_end_month: number | null
          founded_date: string | null
          fund_id: string | null
          google_drive_url: string | null
          growth_stage: string | null
          has_board: boolean | null
          id: string
          industry: string | null
          initial_invested_at: string | null
          invested_amount_dkk: number | null
          invested_at: string | null
          is_active: boolean | null
          last_meeting_invitation_sent_at: string | null
          logo_url: string | null
          meeting_duration_minutes: number | null
          meeting_frequency: string | null
          name: string
          phone: string | null
          responsible_partner_id: string | null
          status: Database["public"]["Enums"]["company_status"]
          target_market: string | null
          total_equity_share_pct: number | null
          total_invested_amount_dkk: number | null
          zipcode: string | null
        }
        Insert: {
          accountant_email?: string | null
          accountant_name?: string | null
          address?: string | null
          auto_invite_coinvestors?: boolean | null
          auto_invite_dd_partners?: boolean | null
          auto_invite_responsible_partner?: boolean | null
          board_formation_date?: string | null
          brand_aliases?: string[] | null
          business_model?: string | null
          city?: string | null
          company_type?: string | null
          created_at?: string | null
          cvr?: string | null
          description?: string | null
          ejerbog_updated_at?: string | null
          email?: string | null
          equity_share_pct?: number | null
          fiscal_year_end_day?: number | null
          fiscal_year_end_month?: number | null
          founded_date?: string | null
          fund_id?: string | null
          google_drive_url?: string | null
          growth_stage?: string | null
          has_board?: boolean | null
          id?: string
          industry?: string | null
          initial_invested_at?: string | null
          invested_amount_dkk?: number | null
          invested_at?: string | null
          is_active?: boolean | null
          last_meeting_invitation_sent_at?: string | null
          logo_url?: string | null
          meeting_duration_minutes?: number | null
          meeting_frequency?: string | null
          name: string
          phone?: string | null
          responsible_partner_id?: string | null
          status?: Database["public"]["Enums"]["company_status"]
          target_market?: string | null
          total_equity_share_pct?: number | null
          total_invested_amount_dkk?: number | null
          zipcode?: string | null
        }
        Update: {
          accountant_email?: string | null
          accountant_name?: string | null
          address?: string | null
          auto_invite_coinvestors?: boolean | null
          auto_invite_dd_partners?: boolean | null
          auto_invite_responsible_partner?: boolean | null
          board_formation_date?: string | null
          brand_aliases?: string[] | null
          business_model?: string | null
          city?: string | null
          company_type?: string | null
          created_at?: string | null
          cvr?: string | null
          description?: string | null
          ejerbog_updated_at?: string | null
          email?: string | null
          equity_share_pct?: number | null
          fiscal_year_end_day?: number | null
          fiscal_year_end_month?: number | null
          founded_date?: string | null
          fund_id?: string | null
          google_drive_url?: string | null
          growth_stage?: string | null
          has_board?: boolean | null
          id?: string
          industry?: string | null
          initial_invested_at?: string | null
          invested_amount_dkk?: number | null
          invested_at?: string | null
          is_active?: boolean | null
          last_meeting_invitation_sent_at?: string | null
          logo_url?: string | null
          meeting_duration_minutes?: number | null
          meeting_frequency?: string | null
          name?: string
          phone?: string | null
          responsible_partner_id?: string | null
          status?: Database["public"]["Enums"]["company_status"]
          target_market?: string | null
          total_equity_share_pct?: number | null
          total_invested_amount_dkk?: number | null
          zipcode?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "companies_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      company_activity_log: {
        Row: {
          activity_type: string
          company_id: string
          created_at: string
          description: string
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          activity_type: string
          company_id: string
          created_at?: string
          description: string
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          activity_type?: string
          company_id?: string
          created_at?: string
          description?: string
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_activity_log_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_activity_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      company_cap_table: {
        Row: {
          acquired_date: string | null
          company_id: string
          created_at: string | null
          id: string
          invitation_status: string | null
          invited_at: string | null
          notes: string | null
          owner_cvr: string | null
          owner_email: string | null
          owner_name: string
          owner_type: string
          ownership_pct: number
          share_class: string | null
          shares: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          acquired_date?: string | null
          company_id: string
          created_at?: string | null
          id?: string
          invitation_status?: string | null
          invited_at?: string | null
          notes?: string | null
          owner_cvr?: string | null
          owner_email?: string | null
          owner_name: string
          owner_type: string
          ownership_pct: number
          share_class?: string | null
          shares?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          acquired_date?: string | null
          company_id?: string
          created_at?: string | null
          id?: string
          invitation_status?: string | null
          invited_at?: string | null
          notes?: string | null
          owner_cvr?: string | null
          owner_email?: string | null
          owner_name?: string
          owner_type?: string
          ownership_pct?: number
          share_class?: string | null
          shares?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_cap_table_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_contacts: {
        Row: {
          company_id: string
          created_at: string
          email: string | null
          id: string
          is_primary: boolean
          name: string
          notes: string | null
          phone: string | null
          role: string
          updated_at: string
        }
        Insert: {
          company_id: string
          created_at?: string
          email?: string | null
          id?: string
          is_primary?: boolean
          name: string
          notes?: string | null
          phone?: string | null
          role: string
          updated_at?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          email?: string | null
          id?: string
          is_primary?: boolean
          name?: string
          notes?: string | null
          phone?: string | null
          role?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_contacts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_documents: {
        Row: {
          company_id: string
          created_at: string
          document_type: Database["public"]["Enums"]["document_type"]
          file_name: string
          file_path: string
          file_size: number
          id: string
          is_latest: boolean
          mime_type: string
          notes: string | null
          uploaded_at: string
          uploaded_by: string
          version: number
        }
        Insert: {
          company_id: string
          created_at?: string
          document_type: Database["public"]["Enums"]["document_type"]
          file_name: string
          file_path: string
          file_size: number
          id?: string
          is_latest?: boolean
          mime_type: string
          notes?: string | null
          uploaded_at?: string
          uploaded_by: string
          version?: number
        }
        Update: {
          company_id?: string
          created_at?: string
          document_type?: Database["public"]["Enums"]["document_type"]
          file_name?: string
          file_path?: string
          file_size?: number
          id?: string
          is_latest?: boolean
          mime_type?: string
          notes?: string | null
          uploaded_at?: string
          uploaded_by?: string
          version?: number
        }
        Relationships: [
          {
            foreignKeyName: "company_documents_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      company_governance_progress: {
        Row: {
          company_id: string
          completed: boolean | null
          completed_at: string | null
          completed_by: string | null
          created_at: string | null
          document_url: string | null
          id: string
          notes: string | null
          template_id: string
          year: number
        }
        Insert: {
          company_id: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          document_url?: string | null
          id?: string
          notes?: string | null
          template_id: string
          year: number
        }
        Update: {
          company_id?: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          document_url?: string | null
          id?: string
          notes?: string | null
          template_id?: string
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "company_governance_progress_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_governance_progress_completed_by_fkey"
            columns: ["completed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_governance_progress_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "company_governance_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      company_governance_templates: {
        Row: {
          category: string
          created_at: string | null
          description: string | null
          frequency: string
          id: string
          is_active: boolean | null
          item_name: string
          months_after_fiscal_year_end: number | null
          required: boolean | null
          sort_order: number
          updated_at: string | null
        }
        Insert: {
          category: string
          created_at?: string | null
          description?: string | null
          frequency?: string
          id?: string
          is_active?: boolean | null
          item_name: string
          months_after_fiscal_year_end?: number | null
          required?: boolean | null
          sort_order: number
          updated_at?: string | null
        }
        Update: {
          category?: string
          created_at?: string | null
          description?: string | null
          frequency?: string
          id?: string
          is_active?: boolean | null
          item_name?: string
          months_after_fiscal_year_end?: number | null
          required?: boolean | null
          sort_order?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      company_meetings: {
        Row: {
          action_items: Json | null
          agenda_items: Json | null
          calendly_event_uuid: string | null
          calendly_reschedule_count: number | null
          company_id: string
          created_at: string
          created_by: string
          decisions: Json | null
          duration_minutes: number
          ical_uid: string | null
          id: string
          is_board_meeting: boolean | null
          meeting_date: string
          meeting_type: string
          minutes_document_id: string | null
          minutes_external_url: string | null
          notes: string | null
          participants: Json
          signature_status: string | null
          signed_at: string | null
          signed_by: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          action_items?: Json | null
          agenda_items?: Json | null
          calendly_event_uuid?: string | null
          calendly_reschedule_count?: number | null
          company_id: string
          created_at?: string
          created_by: string
          decisions?: Json | null
          duration_minutes: number
          ical_uid?: string | null
          id?: string
          is_board_meeting?: boolean | null
          meeting_date: string
          meeting_type: string
          minutes_document_id?: string | null
          minutes_external_url?: string | null
          notes?: string | null
          participants?: Json
          signature_status?: string | null
          signed_at?: string | null
          signed_by?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          action_items?: Json | null
          agenda_items?: Json | null
          calendly_event_uuid?: string | null
          calendly_reschedule_count?: number | null
          company_id?: string
          created_at?: string
          created_by?: string
          decisions?: Json | null
          duration_minutes?: number
          ical_uid?: string | null
          id?: string
          is_board_meeting?: boolean | null
          meeting_date?: string
          meeting_type?: string
          minutes_document_id?: string | null
          minutes_external_url?: string | null
          notes?: string | null
          participants?: Json
          signature_status?: string | null
          signed_at?: string | null
          signed_by?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_meetings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "company_meetings_minutes_document_id_fkey"
            columns: ["minutes_document_id"]
            isOneToOne: false
            referencedRelation: "company_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      company_pr_articles: {
        Row: {
          ai_summary: string | null
          article_status: string | null
          company_id: string
          created_at: string
          id: string
          is_saved: boolean
          published_at: string | null
          relevance_score: number | null
          searched_by: string | null
          sentiment: string | null
          snippet: string | null
          source: string | null
          title: string
          url: string
        }
        Insert: {
          ai_summary?: string | null
          article_status?: string | null
          company_id: string
          created_at?: string
          id?: string
          is_saved?: boolean
          published_at?: string | null
          relevance_score?: number | null
          searched_by?: string | null
          sentiment?: string | null
          snippet?: string | null
          source?: string | null
          title: string
          url: string
        }
        Update: {
          ai_summary?: string | null
          article_status?: string | null
          company_id?: string
          created_at?: string
          id?: string
          is_saved?: boolean
          published_at?: string | null
          relevance_score?: number | null
          searched_by?: string | null
          sentiment?: string | null
          snippet?: string | null
          source?: string | null
          title?: string
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_pr_articles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_prices: {
        Row: {
          archived: boolean | null
          category: string
          company_id: string
          id: string
          sample_volume_monthly: number | null
          subcategory: string
          unit: string
          updated_at: string | null
          value_numeric: number
        }
        Insert: {
          archived?: boolean | null
          category: string
          company_id: string
          id?: string
          sample_volume_monthly?: number | null
          subcategory: string
          unit: string
          updated_at?: string | null
          value_numeric: number
        }
        Update: {
          archived?: boolean | null
          category?: string
          company_id?: string
          id?: string
          sample_volume_monthly?: number | null
          subcategory?: string
          unit?: string
          updated_at?: string | null
          value_numeric?: number
        }
        Relationships: [
          {
            foreignKeyName: "company_prices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_trustpilot_profiles: {
        Row: {
          company_id: string
          country_code: string
          country_name: string
          created_at: string | null
          id: string
          is_primary: boolean | null
          trustpilot_url: string
        }
        Insert: {
          company_id: string
          country_code: string
          country_name: string
          created_at?: string | null
          id?: string
          is_primary?: boolean | null
          trustpilot_url: string
        }
        Update: {
          company_id?: string
          country_code?: string
          country_name?: string
          created_at?: string | null
          id?: string
          is_primary?: boolean | null
          trustpilot_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_trustpilot_profiles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      company_valuation_settings: {
        Row: {
          active_markets: number
          company_id: string
          created_at: string | null
          ebitda_multiple: number
          id: string
          revenue_multiple: number
          updated_at: string | null
          valuation_weight_revenue_pct: number
        }
        Insert: {
          active_markets: number
          company_id: string
          created_at?: string | null
          ebitda_multiple: number
          id?: string
          revenue_multiple: number
          updated_at?: string | null
          valuation_weight_revenue_pct?: number
        }
        Update: {
          active_markets?: number
          company_id?: string
          created_at?: string | null
          ebitda_multiple?: number
          id?: string
          revenue_multiple?: number
          updated_at?: string | null
          valuation_weight_revenue_pct?: number
        }
        Relationships: [
          {
            foreignKeyName: "company_valuation_settings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          address: string | null
          city: string | null
          company_id: string | null
          company_type: string | null
          created_at: string | null
          created_by: string
          cvr: string | null
          economic_customer_id: string | null
          economic_last_sync_at: string | null
          economic_sync_status: string | null
          email: string | null
          id: string
          industry_code: string | null
          industry_desc: string | null
          is_active: boolean | null
          name: string
          notes: string | null
          phone: string | null
          updated_at: string | null
          zipcode: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          company_id?: string | null
          company_type?: string | null
          created_at?: string | null
          created_by: string
          cvr?: string | null
          economic_customer_id?: string | null
          economic_last_sync_at?: string | null
          economic_sync_status?: string | null
          email?: string | null
          id?: string
          industry_code?: string | null
          industry_desc?: string | null
          is_active?: boolean | null
          name: string
          notes?: string | null
          phone?: string | null
          updated_at?: string | null
          zipcode?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          company_id?: string | null
          company_type?: string | null
          created_at?: string | null
          created_by?: string
          cvr?: string | null
          economic_customer_id?: string | null
          economic_last_sync_at?: string | null
          economic_sync_status?: string | null
          email?: string | null
          id?: string
          industry_code?: string | null
          industry_desc?: string | null
          is_active?: boolean | null
          name?: string
          notes?: string | null
          phone?: string | null
          updated_at?: string | null
          zipcode?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customers_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_challenges: {
        Row: {
          challenge_date: string
          challenge_description: string
          challenge_type: string
          completed_at: string | null
          created_at: string | null
          current_count: number | null
          id: string
          is_completed: boolean | null
          target_count: number
          user_id: string
          xp_reward: number
        }
        Insert: {
          challenge_date?: string
          challenge_description: string
          challenge_type: string
          completed_at?: string | null
          created_at?: string | null
          current_count?: number | null
          id?: string
          is_completed?: boolean | null
          target_count?: number
          user_id: string
          xp_reward?: number
        }
        Update: {
          challenge_date?: string
          challenge_description?: string
          challenge_type?: string
          completed_at?: string | null
          created_at?: string | null
          current_count?: number | null
          id?: string
          is_completed?: boolean | null
          target_count?: number
          user_id?: string
          xp_reward?: number
        }
        Relationships: []
      }
      data_access_requests: {
        Row: {
          admin_notes: string | null
          download_expires_at: string | null
          downloaded_at: string | null
          file_generated_at: string | null
          file_path: string | null
          id: string
          processed_at: string | null
          processed_by: string | null
          reason: string | null
          rejection_reason: string | null
          request_type: string
          requested_at: string | null
          status: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          download_expires_at?: string | null
          downloaded_at?: string | null
          file_generated_at?: string | null
          file_path?: string | null
          id?: string
          processed_at?: string | null
          processed_by?: string | null
          reason?: string | null
          rejection_reason?: string | null
          request_type?: string
          requested_at?: string | null
          status?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          download_expires_at?: string | null
          downloaded_at?: string | null
          file_generated_at?: string | null
          file_path?: string | null
          id?: string
          processed_at?: string | null
          processed_by?: string | null
          reason?: string | null
          rejection_reason?: string | null
          request_type?: string
          requested_at?: string | null
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      dd_category_progress: {
        Row: {
          case_id: string
          category_id: string
          completed_at: string | null
          completed_by: string | null
          created_at: string
          document_count: number | null
          id: string
          notes: string | null
          status: string
          updated_at: string
        }
        Insert: {
          case_id: string
          category_id: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          document_count?: number | null
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          case_id?: string
          category_id?: string
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          document_count?: number | null
          id?: string
          notes?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "dd_category_progress_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "due_diligence_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dd_category_progress_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "dd_document_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      dd_checklist_progress: {
        Row: {
          case_id: string
          completed: boolean | null
          completed_at: string | null
          completed_by: string | null
          created_at: string | null
          id: string
          notes: string | null
          template_id: string
        }
        Insert: {
          case_id: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          id?: string
          notes?: string | null
          template_id: string
        }
        Update: {
          case_id?: string
          completed?: boolean | null
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          id?: string
          notes?: string | null
          template_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dd_checklist_progress_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "due_diligence_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dd_checklist_progress_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "dd_checklist_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      dd_checklist_templates: {
        Row: {
          category: string
          created_at: string | null
          description: string | null
          id: string
          item_name: string
          required: boolean | null
          sort_order: number
        }
        Insert: {
          category: string
          created_at?: string | null
          description?: string | null
          id?: string
          item_name: string
          required?: boolean | null
          sort_order: number
        }
        Update: {
          category?: string
          created_at?: string | null
          description?: string | null
          id?: string
          item_name?: string
          required?: boolean | null
          sort_order?: number
        }
        Relationships: []
      }
      dd_document_categories: {
        Row: {
          category_code: string
          category_name: string
          created_at: string
          description: string | null
          id: string
          parent_category_code: string | null
          required: boolean | null
          sort_order: number
        }
        Insert: {
          category_code: string
          category_name: string
          created_at?: string
          description?: string | null
          id?: string
          parent_category_code?: string | null
          required?: boolean | null
          sort_order: number
        }
        Update: {
          category_code?: string
          category_name?: string
          created_at?: string
          description?: string | null
          id?: string
          parent_category_code?: string | null
          required?: boolean | null
          sort_order?: number
        }
        Relationships: []
      }
      dd_documents: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          archive_location: string | null
          archived_at: string | null
          archived_by: string | null
          case_id: string
          category_id: string | null
          comments: string | null
          document_type: Database["public"]["Enums"]["dd_document_type"]
          file_name: string
          file_path: string
          file_size: number
          id: string
          mime_type: string
          notes: string | null
          original_file_size: number | null
          rejection_reason: string | null
          status: string | null
          uploaded_at: string | null
          uploaded_by: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          archive_location?: string | null
          archived_at?: string | null
          archived_by?: string | null
          case_id: string
          category_id?: string | null
          comments?: string | null
          document_type: Database["public"]["Enums"]["dd_document_type"]
          file_name: string
          file_path: string
          file_size: number
          id?: string
          mime_type: string
          notes?: string | null
          original_file_size?: number | null
          rejection_reason?: string | null
          status?: string | null
          uploaded_at?: string | null
          uploaded_by: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          archive_location?: string | null
          archived_at?: string | null
          archived_by?: string | null
          case_id?: string
          category_id?: string | null
          comments?: string | null
          document_type?: Database["public"]["Enums"]["dd_document_type"]
          file_name?: string
          file_path?: string
          file_size?: number
          id?: string
          mime_type?: string
          notes?: string | null
          original_file_size?: number | null
          rejection_reason?: string | null
          status?: string | null
          uploaded_at?: string | null
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "dd_documents_case_id_fkey"
            columns: ["case_id"]
            isOneToOne: false
            referencedRelation: "due_diligence_cases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dd_documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "dd_document_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      dd_partner_assignments: {
        Row: {
          approval_notes: string | null
          approval_status: string | null
          approved_at: string | null
          assigned_at: string | null
          assigned_by: string
          company_id: string
          created_at: string | null
          id: string
          notes: string | null
          specialization: string | null
          user_id: string
        }
        Insert: {
          approval_notes?: string | null
          approval_status?: string | null
          approved_at?: string | null
          assigned_at?: string | null
          assigned_by: string
          company_id: string
          created_at?: string | null
          id?: string
          notes?: string | null
          specialization?: string | null
          user_id: string
        }
        Update: {
          approval_notes?: string | null
          approval_status?: string | null
          approved_at?: string | null
          assigned_at?: string | null
          assigned_by?: string
          company_id?: string
          created_at?: string | null
          id?: string
          notes?: string | null
          specialization?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dd_partner_assignments_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      dividends: {
        Row: {
          amount_dkk: number
          company_id: string
          created_at: string | null
          declared_date: string
          fund_id: string
          id: string
          note: string | null
          paid_date: string
        }
        Insert: {
          amount_dkk: number
          company_id: string
          created_at?: string | null
          declared_date: string
          fund_id: string
          id?: string
          note?: string | null
          paid_date: string
        }
        Update: {
          amount_dkk?: number
          company_id?: string
          created_at?: string | null
          declared_date?: string
          fund_id?: string
          id?: string
          note?: string | null
          paid_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "dividends_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "dividends_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          category_id: string
          created_at: string | null
          description_da: string | null
          id: string
          name_da: string
          name_en: string
          required: boolean | null
          sort_order: number
        }
        Insert: {
          category_id: string
          created_at?: string | null
          description_da?: string | null
          id?: string
          name_da: string
          name_en: string
          required?: boolean | null
          sort_order: number
        }
        Update: {
          category_id?: string
          created_at?: string | null
          description_da?: string | null
          id?: string
          name_da?: string
          name_en?: string
          required?: boolean | null
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "documents_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      due_diligence_cases: {
        Row: {
          assigned_to: string | null
          company_id: string
          completed_at: string | null
          created_at: string | null
          deadline: string | null
          export_location: string | null
          exported_at: string | null
          exported_by: string | null
          files_deleted_from_portal: boolean | null
          id: string
          notes: string | null
          started_at: string | null
          status: Database["public"]["Enums"]["dd_status"]
          updated_at: string | null
        }
        Insert: {
          assigned_to?: string | null
          company_id: string
          completed_at?: string | null
          created_at?: string | null
          deadline?: string | null
          export_location?: string | null
          exported_at?: string | null
          exported_by?: string | null
          files_deleted_from_portal?: boolean | null
          id?: string
          notes?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["dd_status"]
          updated_at?: string | null
        }
        Update: {
          assigned_to?: string | null
          company_id?: string
          completed_at?: string | null
          created_at?: string | null
          deadline?: string | null
          export_location?: string | null
          exported_at?: string | null
          exported_by?: string | null
          files_deleted_from_portal?: boolean | null
          id?: string
          notes?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["dd_status"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "due_diligence_cases_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          available_variables: Json
          created_at: string
          from_email: string
          from_name: string
          html_body: string
          id: string
          is_active: boolean
          subject: string
          template_key: string
          template_name: string
          text_body: string | null
          updated_at: string
        }
        Insert: {
          available_variables?: Json
          created_at?: string
          from_email?: string
          from_name?: string
          html_body: string
          id?: string
          is_active?: boolean
          subject: string
          template_key: string
          template_name: string
          text_body?: string | null
          updated_at?: string
        }
        Update: {
          available_variables?: Json
          created_at?: string
          from_email?: string
          from_name?: string
          html_body?: string
          id?: string
          is_active?: boolean
          subject?: string
          template_key?: string
          template_name?: string
          text_body?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      exits: {
        Row: {
          closing_date: string
          company_id: string
          created_at: string | null
          earnout_amount_potential_dkk: number | null
          earnout_possible: boolean | null
          fund_id: string
          gross_sale_amount_dkk: number
          id: string
          mola_ownership_pct_at_exit: number
          note: string | null
          retained_shares_pct: number | null
          transaction_costs_dkk: number | null
        }
        Insert: {
          closing_date: string
          company_id: string
          created_at?: string | null
          earnout_amount_potential_dkk?: number | null
          earnout_possible?: boolean | null
          fund_id: string
          gross_sale_amount_dkk: number
          id?: string
          mola_ownership_pct_at_exit: number
          note?: string | null
          retained_shares_pct?: number | null
          transaction_costs_dkk?: number | null
        }
        Update: {
          closing_date?: string
          company_id?: string
          created_at?: string | null
          earnout_amount_potential_dkk?: number | null
          earnout_possible?: boolean | null
          fund_id?: string
          gross_sale_amount_dkk?: number
          id?: string
          mola_ownership_pct_at_exit?: number
          note?: string | null
          retained_shares_pct?: number | null
          transaction_costs_dkk?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "exits_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: true
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "exits_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      footer_links: {
        Row: {
          category: string
          created_at: string
          icon_name: string | null
          id: string
          is_active: boolean
          is_external: boolean
          sort_order: number
          title: string
          updated_at: string
          url: string
        }
        Insert: {
          category: string
          created_at?: string
          icon_name?: string | null
          id?: string
          is_active?: boolean
          is_external?: boolean
          sort_order?: number
          title: string
          updated_at?: string
          url: string
        }
        Update: {
          category?: string
          created_at?: string
          icon_name?: string | null
          id?: string
          is_active?: boolean
          is_external?: boolean
          sort_order?: number
          title?: string
          updated_at?: string
          url?: string
        }
        Relationships: []
      }
      footer_settings: {
        Row: {
          content: Json
          created_at: string
          id: string
          is_active: boolean
          section_key: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          content?: Json
          created_at?: string
          id?: string
          is_active?: boolean
          section_key: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          content?: Json
          created_at?: string
          id?: string
          is_active?: boolean
          section_key?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      founder_deal_redemptions: {
        Row: {
          deal_id: string
          id: string
          notes: string | null
          redeemed_at: string
          redeemed_by_company_id: string
        }
        Insert: {
          deal_id: string
          id?: string
          notes?: string | null
          redeemed_at?: string
          redeemed_by_company_id: string
        }
        Update: {
          deal_id?: string
          id?: string
          notes?: string | null
          redeemed_at?: string
          redeemed_by_company_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "founder_deal_redemptions_deal_id_fkey"
            columns: ["deal_id"]
            isOneToOne: false
            referencedRelation: "founder_deals"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "founder_deal_redemptions_redeemed_by_company_id_fkey"
            columns: ["redeemed_by_company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      founder_deals: {
        Row: {
          categories: string[]
          company_id: string
          contact_email: string | null
          created_at: string
          current_redemptions: number
          description: string | null
          discount_type: string
          discount_value: number | null
          id: string
          is_active: boolean
          max_redemptions: number | null
          product_url: string | null
          promo_code: string | null
          terms: string | null
          title: string
          updated_at: string
          valid_from: string | null
          valid_until: string | null
        }
        Insert: {
          categories?: string[]
          company_id: string
          contact_email?: string | null
          created_at?: string
          current_redemptions?: number
          description?: string | null
          discount_type: string
          discount_value?: number | null
          id?: string
          is_active?: boolean
          max_redemptions?: number | null
          product_url?: string | null
          promo_code?: string | null
          terms?: string | null
          title: string
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
        }
        Update: {
          categories?: string[]
          company_id?: string
          contact_email?: string | null
          created_at?: string
          current_redemptions?: number
          description?: string | null
          discount_type?: string
          discount_value?: number | null
          id?: string
          is_active?: boolean
          max_redemptions?: number | null
          product_url?: string | null
          promo_code?: string | null
          terms?: string | null
          title?: string
          updated_at?: string
          valid_from?: string | null
          valid_until?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "founder_deals_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      founder_milestones: {
        Row: {
          achieved_at: string
          company_id: string
          created_at: string | null
          id: string
          metadata: Json | null
          milestone_type: string
          milestone_value: number
          previous_best: number | null
        }
        Insert: {
          achieved_at?: string
          company_id: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          milestone_type: string
          milestone_value: number
          previous_best?: number | null
        }
        Update: {
          achieved_at?: string
          company_id?: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          milestone_type?: string
          milestone_value?: number
          previous_best?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "founder_milestones_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      fund_ownership: {
        Row: {
          created_at: string
          fund_id: string
          id: string
          owner_name: string
          owner_type: string
          ownership_pct: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          fund_id: string
          id?: string
          owner_name: string
          owner_type: string
          ownership_pct: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          fund_id?: string
          id?: string
          owner_name?: string
          owner_type?: string
          ownership_pct?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fund_ownership_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      funding_rounds: {
        Row: {
          company_id: string
          created_at: string | null
          equity_acquired_pct: number
          fund_id: string | null
          id: string
          invested_amount_dkk: number
          invested_at: string
          is_secondary: boolean | null
          note: string | null
          post_money_valuation_dkk: number | null
          pre_money_valuation_dkk: number | null
          round_name: string
          round_type: string
          seller_name: string | null
          updated_at: string | null
        }
        Insert: {
          company_id: string
          created_at?: string | null
          equity_acquired_pct: number
          fund_id?: string | null
          id?: string
          invested_amount_dkk: number
          invested_at: string
          is_secondary?: boolean | null
          note?: string | null
          post_money_valuation_dkk?: number | null
          pre_money_valuation_dkk?: number | null
          round_name: string
          round_type?: string
          seller_name?: string | null
          updated_at?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string | null
          equity_acquired_pct?: number
          fund_id?: string | null
          id?: string
          invested_amount_dkk?: number
          invested_at?: string
          is_secondary?: boolean | null
          note?: string | null
          post_money_valuation_dkk?: number | null
          pre_money_valuation_dkk?: number | null
          round_name?: string
          round_type?: string
          seller_name?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "funding_rounds_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "funding_rounds_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      funds: {
        Row: {
          address: string | null
          city: string | null
          company_type: string | null
          created_at: string | null
          cvr: string
          id: string
          inception_date: string | null
          name: string
          target_size_dkk: number | null
          zipcode: string | null
        }
        Insert: {
          address?: string | null
          city?: string | null
          company_type?: string | null
          created_at?: string | null
          cvr: string
          id?: string
          inception_date?: string | null
          name: string
          target_size_dkk?: number | null
          zipcode?: string | null
        }
        Update: {
          address?: string | null
          city?: string | null
          company_type?: string | null
          created_at?: string | null
          cvr?: string
          id?: string
          inception_date?: string | null
          name?: string
          target_size_dkk?: number | null
          zipcode?: string | null
        }
        Relationships: []
      }
      income_access: {
        Row: {
          granted_at: string | null
          granted_by: string
          granted_to_user_id: string
          id: string
          notes: string | null
          owner_user_id: string
        }
        Insert: {
          granted_at?: string | null
          granted_by: string
          granted_to_user_id: string
          id?: string
          notes?: string | null
          owner_user_id: string
        }
        Update: {
          granted_at?: string | null
          granted_by?: string
          granted_to_user_id?: string
          id?: string
          notes?: string | null
          owner_user_id?: string
        }
        Relationships: []
      }
      income_entries: {
        Row: {
          amount_dkk: number
          created_at: string | null
          created_by: string
          customer_id: string
          description: string
          due_date: string | null
          economic_invoice_number: string | null
          economic_last_sync_at: string | null
          economic_pdf_url: string | null
          economic_product_number: string | null
          economic_sync_status: string | null
          id: string
          income_date: string
          income_type: Database["public"]["Enums"]["income_type"]
          notes: string | null
          paid_date: string | null
          status: Database["public"]["Enums"]["income_status"]
          updated_at: string | null
        }
        Insert: {
          amount_dkk: number
          created_at?: string | null
          created_by: string
          customer_id: string
          description: string
          due_date?: string | null
          economic_invoice_number?: string | null
          economic_last_sync_at?: string | null
          economic_pdf_url?: string | null
          economic_product_number?: string | null
          economic_sync_status?: string | null
          id?: string
          income_date: string
          income_type?: Database["public"]["Enums"]["income_type"]
          notes?: string | null
          paid_date?: string | null
          status?: Database["public"]["Enums"]["income_status"]
          updated_at?: string | null
        }
        Update: {
          amount_dkk?: number
          created_at?: string | null
          created_by?: string
          customer_id?: string
          description?: string
          due_date?: string | null
          economic_invoice_number?: string | null
          economic_last_sync_at?: string | null
          economic_pdf_url?: string | null
          economic_product_number?: string | null
          economic_sync_status?: string | null
          id?: string
          income_date?: string
          income_type?: Database["public"]["Enums"]["income_type"]
          notes?: string | null
          paid_date?: string | null
          status?: Database["public"]["Enums"]["income_status"]
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "income_entries_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      investor_notes: {
        Row: {
          company_id: string
          created_at: string | null
          id: string
          investor_id: string
          is_private: boolean | null
          note_text: string
          updated_at: string | null
        }
        Insert: {
          company_id: string
          created_at?: string | null
          id?: string
          investor_id: string
          is_private?: boolean | null
          note_text: string
          updated_at?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string | null
          id?: string
          investor_id?: string
          is_private?: boolean | null
          note_text?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "investor_notes_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      login_attempts: {
        Row: {
          attempted_at: string
          id: string
          identifier: string
          identifier_type: string
          ip_address: string | null
          success: boolean
          user_agent: string | null
        }
        Insert: {
          attempted_at?: string
          id?: string
          identifier: string
          identifier_type: string
          ip_address?: string | null
          success?: boolean
          user_agent?: string | null
        }
        Update: {
          attempted_at?: string
          id?: string
          identifier?: string
          identifier_type?: string
          ip_address?: string | null
          success?: boolean
          user_agent?: string | null
        }
        Relationships: []
      }
      meeting_invitations: {
        Row: {
          calendly_link: string
          company_id: string
          created_at: string | null
          id: string
          last_meeting_date: string | null
          next_expected_meeting_date: string | null
          sent_at: string | null
          sent_to_emails: string[]
          status: string | null
        }
        Insert: {
          calendly_link: string
          company_id: string
          created_at?: string | null
          id?: string
          last_meeting_date?: string | null
          next_expected_meeting_date?: string | null
          sent_at?: string | null
          sent_to_emails: string[]
          status?: string | null
        }
        Update: {
          calendly_link?: string
          company_id?: string
          created_at?: string | null
          id?: string
          last_meeting_date?: string | null
          next_expected_meeting_date?: string | null
          sent_at?: string | null
          sent_to_emails?: string[]
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "meeting_invitations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      mileage_entries: {
        Row: {
          amount_dkk: number | null
          created_at: string
          distance_km: number
          from_address: string
          from_address_type: string
          id: string
          is_submitted: boolean
          paying_company_id: string | null
          paying_fund_id: string | null
          purpose: string
          rate_per_km: number
          submitted_at: string | null
          to_address: string
          to_company_id: string | null
          trip_date: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount_dkk?: number | null
          created_at?: string
          distance_km: number
          from_address: string
          from_address_type: string
          id?: string
          is_submitted?: boolean
          paying_company_id?: string | null
          paying_fund_id?: string | null
          purpose: string
          rate_per_km?: number
          submitted_at?: string | null
          to_address: string
          to_company_id?: string | null
          trip_date?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount_dkk?: number | null
          created_at?: string
          distance_km?: number
          from_address?: string
          from_address_type?: string
          id?: string
          is_submitted?: boolean
          paying_company_id?: string | null
          paying_fund_id?: string | null
          purpose?: string
          rate_per_km?: number
          submitted_at?: string | null
          to_address?: string
          to_company_id?: string | null
          trip_date?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mileage_entries_paying_company_id_fkey"
            columns: ["paying_company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mileage_entries_paying_fund_id_fkey"
            columns: ["paying_fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mileage_entries_to_company_id_fkey"
            columns: ["to_company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      mileage_settings: {
        Row: {
          accountant_email: string | null
          accountant_name: string | null
          created_at: string
          default_paying_fund_id: string | null
          employee_name: string
          high_rate_per_km: number
          id: string
          low_rate_per_km: number
          office_address: string | null
          private_address: string
          updated_at: string
          user_id: string
        }
        Insert: {
          accountant_email?: string | null
          accountant_name?: string | null
          created_at?: string
          default_paying_fund_id?: string | null
          employee_name: string
          high_rate_per_km?: number
          id?: string
          low_rate_per_km?: number
          office_address?: string | null
          private_address: string
          updated_at?: string
          user_id: string
        }
        Update: {
          accountant_email?: string | null
          accountant_name?: string | null
          created_at?: string
          default_paying_fund_id?: string | null
          employee_name?: string
          high_rate_per_km?: number
          id?: string
          low_rate_per_km?: number
          office_address?: string | null
          private_address?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mileage_settings_default_paying_fund_id_fkey"
            columns: ["default_paying_fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      mileage_submissions: {
        Row: {
          created_at: string
          employee_name: string
          entries_snapshot: Json
          id: string
          paying_company_id: string
          period_month: number
          period_year: number
          sent_at: string
          sent_to_emails: string[]
          total_amount_dkk: number
          total_km: number
          user_id: string
        }
        Insert: {
          created_at?: string
          employee_name: string
          entries_snapshot: Json
          id?: string
          paying_company_id: string
          period_month: number
          period_year: number
          sent_at?: string
          sent_to_emails: string[]
          total_amount_dkk: number
          total_km: number
          user_id: string
        }
        Update: {
          created_at?: string
          employee_name?: string
          entries_snapshot?: Json
          id?: string
          paying_company_id?: string
          period_month?: number
          period_year?: number
          sent_at?: string
          sent_to_emails?: string[]
          total_amount_dkk?: number
          total_km?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "mileage_submissions_paying_company_id_fkey"
            columns: ["paying_company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      monday_user_config: {
        Row: {
          assignee_column_id: string | null
          board_id: string | null
          board_name: string | null
          company_column_id: string | null
          created_at: string | null
          date_column_id: string | null
          group_id: string | null
          id: string
          is_active: boolean | null
          last_sync_at: string | null
          link_column_id: string | null
          monday_api_token_encrypted: string | null
          monday_user_id: string | null
          monday_user_name: string | null
          priority_column_id: string | null
          status_column_id: string | null
          updated_at: string | null
          user_id: string
          webhook_id: string | null
        }
        Insert: {
          assignee_column_id?: string | null
          board_id?: string | null
          board_name?: string | null
          company_column_id?: string | null
          created_at?: string | null
          date_column_id?: string | null
          group_id?: string | null
          id?: string
          is_active?: boolean | null
          last_sync_at?: string | null
          link_column_id?: string | null
          monday_api_token_encrypted?: string | null
          monday_user_id?: string | null
          monday_user_name?: string | null
          priority_column_id?: string | null
          status_column_id?: string | null
          updated_at?: string | null
          user_id: string
          webhook_id?: string | null
        }
        Update: {
          assignee_column_id?: string | null
          board_id?: string | null
          board_name?: string | null
          company_column_id?: string | null
          created_at?: string | null
          date_column_id?: string | null
          group_id?: string | null
          id?: string
          is_active?: boolean | null
          last_sync_at?: string | null
          link_column_id?: string | null
          monday_api_token_encrypted?: string | null
          monday_user_id?: string | null
          monday_user_name?: string | null
          priority_column_id?: string | null
          status_column_id?: string | null
          updated_at?: string | null
          user_id?: string
          webhook_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monday_user_config_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      monday_user_map: {
        Row: {
          created_at: string
          email: string | null
          id: string
          monday_user_id: string
          name: string | null
          platform_user_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          monday_user_id: string
          name?: string | null
          platform_user_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          monday_user_id?: string
          name?: string | null
          platform_user_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      monthly_report_notifications: {
        Row: {
          company_id: string
          created_at: string | null
          email_status: string | null
          id: string
          notification_type: string
          recipient_emails: string[]
          sent_at: string | null
          target_month: number
          target_year: number
        }
        Insert: {
          company_id: string
          created_at?: string | null
          email_status?: string | null
          id?: string
          notification_type: string
          recipient_emails: string[]
          sent_at?: string | null
          target_month: number
          target_year: number
        }
        Update: {
          company_id?: string
          created_at?: string | null
          email_status?: string | null
          id?: string
          notification_type?: string
          recipient_emails?: string[]
          sent_at?: string | null
          target_month?: number
          target_year?: number
        }
        Relationships: [
          {
            foreignKeyName: "monthly_report_notifications_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_report_tokens: {
        Row: {
          company_id: string
          created_at: string
          expires_at: string
          id: string
          period_month: number
          period_year: number
          status: string
          submitted_by_email: string | null
          token: string
          used_at: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          expires_at: string
          id?: string
          period_month: number
          period_year: number
          status?: string
          submitted_by_email?: string | null
          token: string
          used_at?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          expires_at?: string
          id?: string
          period_month?: number
          period_year?: number
          status?: string
          submitted_by_email?: string | null
          token?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "monthly_report_tokens_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_reports: {
        Row: {
          budget_ebitda_dkk: number | null
          budget_marketing_cost_dkk: number | null
          budget_revenue_dkk: number | null
          budget_salary_cost_dkk: number | null
          cash_dkk: number | null
          company_id: string
          created_at: string | null
          ebitda_dkk: number | null
          id: string
          marketing_cost_dkk: number | null
          new_customers: number | null
          note: string | null
          orders: number | null
          period_month: number
          period_year: number
          revenue_dkk: number | null
          salary_cost_dkk: number | null
        }
        Insert: {
          budget_ebitda_dkk?: number | null
          budget_marketing_cost_dkk?: number | null
          budget_revenue_dkk?: number | null
          budget_salary_cost_dkk?: number | null
          cash_dkk?: number | null
          company_id: string
          created_at?: string | null
          ebitda_dkk?: number | null
          id?: string
          marketing_cost_dkk?: number | null
          new_customers?: number | null
          note?: string | null
          orders?: number | null
          period_month: number
          period_year: number
          revenue_dkk?: number | null
          salary_cost_dkk?: number | null
        }
        Update: {
          budget_ebitda_dkk?: number | null
          budget_marketing_cost_dkk?: number | null
          budget_revenue_dkk?: number | null
          budget_salary_cost_dkk?: number | null
          cash_dkk?: number | null
          company_id?: string
          created_at?: string | null
          ebitda_dkk?: number | null
          id?: string
          marketing_cost_dkk?: number | null
          new_customers?: number | null
          note?: string | null
          orders?: number | null
          period_month?: number
          period_year?: number
          revenue_dkk?: number | null
          salary_cost_dkk?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "monthly_reports_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      nps_responses: {
        Row: {
          comment: string | null
          company_id: string
          created_at: string | null
          id: string
          period_quarter: number
          period_year: number
          score: number
        }
        Insert: {
          comment?: string | null
          company_id: string
          created_at?: string | null
          id?: string
          period_quarter: number
          period_year: number
          score: number
        }
        Update: {
          comment?: string | null
          company_id?: string
          created_at?: string | null
          id?: string
          period_quarter?: number
          period_year?: number
          score?: number
        }
        Relationships: [
          {
            foreignKeyName: "nps_responses_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_progress: {
        Row: {
          completed_at: string | null
          completed_steps: string[]
          created_at: string
          dismissed_at: string | null
          id: string
          role: string
          updated_at: string
          user_id: string
          version_seen: number
        }
        Insert: {
          completed_at?: string | null
          completed_steps?: string[]
          created_at?: string
          dismissed_at?: string | null
          id?: string
          role?: string
          updated_at?: string
          user_id: string
          version_seen?: number
        }
        Update: {
          completed_at?: string | null
          completed_steps?: string[]
          created_at?: string
          dismissed_at?: string | null
          id?: string
          role?: string
          updated_at?: string
          user_id?: string
          version_seen?: number
        }
        Relationships: []
      }
      partner_deals: {
        Row: {
          activation_url: string | null
          archived: boolean | null
          category: string
          contact_email: string
          created_at: string | null
          id: string
          is_active: boolean | null
          list_price: number
          mola_price: number
          plan_name: string
          terms: string
          unit: string
          vendor: string
        }
        Insert: {
          activation_url?: string | null
          archived?: boolean | null
          category: string
          contact_email: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          list_price: number
          mola_price: number
          plan_name: string
          terms: string
          unit: string
          vendor: string
        }
        Update: {
          activation_url?: string | null
          archived?: boolean | null
          category?: string
          contact_email?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          list_price?: number
          mola_price?: number
          plan_name?: string
          terms?: string
          unit?: string
          vendor?: string
        }
        Relationships: []
      }
      personal_fund_stakes: {
        Row: {
          created_at: string
          entity_name: string
          entity_type: string
          id: string
          ownership_pct: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          entity_name: string
          entity_type: string
          id?: string
          ownership_pct: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          entity_name?: string
          entity_type?: string
          id?: string
          ownership_pct?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      portfolio_activity_events: {
        Row: {
          created_at: string | null
          event_icon: string | null
          event_message: string
          event_type: string
          id: string
        }
        Insert: {
          created_at?: string | null
          event_icon?: string | null
          event_message: string
          event_type: string
          id?: string
        }
        Update: {
          created_at?: string | null
          event_icon?: string | null
          event_message?: string
          event_type?: string
          id?: string
        }
        Relationships: []
      }
      portfolio_rankings: {
        Row: {
          calculated_at: string
          company_id: string
          id: string
          metric_type: string
          metric_value: number
          percentile: number
          period_month: number | null
          period_year: number
          rank: number
          total_companies: number
        }
        Insert: {
          calculated_at?: string
          company_id: string
          id?: string
          metric_type: string
          metric_value: number
          percentile: number
          period_month?: number | null
          period_year: number
          rank: number
          total_companies: number
        }
        Update: {
          calculated_at?: string
          company_id?: string
          id?: string
          metric_type?: string
          metric_value?: number
          percentile?: number
          period_month?: number | null
          period_year?: number
          rank?: number
          total_companies?: number
        }
        Relationships: [
          {
            foreignKeyName: "portfolio_rankings_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      pr_blocked_sources: {
        Row: {
          created_at: string
          domain: string | null
          id: string
          reason: string | null
          url: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          domain?: string | null
          id?: string
          reason?: string | null
          url?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          domain?: string | null
          id?: string
          reason?: string | null
          url?: string | null
          user_id?: string
        }
        Relationships: []
      }
      pr_learned_sources: {
        Row: {
          click_count: number
          dismiss_count: number
          domain: string
          id: string
          last_updated: string
          save_count: number
          trust_score: number
          user_id: string
        }
        Insert: {
          click_count?: number
          dismiss_count?: number
          domain: string
          id?: string
          last_updated?: string
          save_count?: number
          trust_score?: number
          user_id: string
        }
        Update: {
          click_count?: number
          dismiss_count?: number
          domain?: string
          id?: string
          last_updated?: string
          save_count?: number
          trust_score?: number
          user_id?: string
        }
        Relationships: []
      }
      pr_scan_logs: {
        Row: {
          articles_found: number | null
          articles_new: number | null
          company_id: string | null
          error_message: string | null
          id: string
          scan_type: string | null
          scanned_at: string | null
        }
        Insert: {
          articles_found?: number | null
          articles_new?: number | null
          company_id?: string | null
          error_message?: string | null
          id?: string
          scan_type?: string | null
          scanned_at?: string | null
        }
        Update: {
          articles_found?: number | null
          articles_new?: number | null
          company_id?: string | null
          error_message?: string | null
          id?: string
          scan_type?: string | null
          scanned_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pr_scan_logs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      pr_user_feedback: {
        Row: {
          action: string
          article_title: string | null
          article_url: string
          company_id: string
          created_at: string
          id: string
          search_query: string | null
          source_domain: string
          user_id: string
        }
        Insert: {
          action: string
          article_title?: string | null
          article_url: string
          company_id: string
          created_at?: string
          id?: string
          search_query?: string | null
          source_domain: string
          user_id: string
        }
        Update: {
          action?: string
          article_title?: string | null
          article_url?: string
          company_id?: string
          created_at?: string
          id?: string
          search_query?: string | null
          source_domain?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pr_user_feedback_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      procurement_adoptions: {
        Row: {
          activated_at: string | null
          archived: boolean | null
          company_id: string
          created_at: string | null
          id: string
          notes: string | null
          partner_deal_id: string
          status: string
        }
        Insert: {
          activated_at?: string | null
          archived?: boolean | null
          company_id: string
          created_at?: string | null
          id?: string
          notes?: string | null
          partner_deal_id: string
          status: string
        }
        Update: {
          activated_at?: string | null
          archived?: boolean | null
          company_id?: string
          created_at?: string | null
          id?: string
          notes?: string | null
          partner_deal_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "procurement_adoptions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "procurement_adoptions_partner_deal_id_fkey"
            columns: ["partner_deal_id"]
            isOneToOne: false
            referencedRelation: "partner_deals"
            referencedColumns: ["id"]
          },
        ]
      }
      procurement_audit_log: {
        Row: {
          action: string
          actor_user_id: string
          created_at: string | null
          diff: Json | null
          entity: string
          entity_id: string
          id: string
        }
        Insert: {
          action: string
          actor_user_id: string
          created_at?: string | null
          diff?: Json | null
          entity: string
          entity_id: string
          id?: string
        }
        Update: {
          action?: string
          actor_user_id?: string
          created_at?: string | null
          diff?: Json | null
          entity?: string
          entity_id?: string
          id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          activity_streak: number | null
          avatar_url: string | null
          bio: string | null
          calendly_link: string | null
          calendly_webhook_secret: string | null
          can_help_with: string | null
          company_id: string | null
          company_name: string | null
          created_at: string | null
          full_name: string | null
          fund_id: string | null
          id: string
          is_active: boolean | null
          last_activity_date: string | null
          last_sign_in_at: string | null
          level: number | null
          linkedin_url: string | null
          personal_bests: Json | null
          skills: string[] | null
          streak_freeze_count: number | null
          title: string | null
          xp: number | null
        }
        Insert: {
          activity_streak?: number | null
          avatar_url?: string | null
          bio?: string | null
          calendly_link?: string | null
          calendly_webhook_secret?: string | null
          can_help_with?: string | null
          company_id?: string | null
          company_name?: string | null
          created_at?: string | null
          full_name?: string | null
          fund_id?: string | null
          id: string
          is_active?: boolean | null
          last_activity_date?: string | null
          last_sign_in_at?: string | null
          level?: number | null
          linkedin_url?: string | null
          personal_bests?: Json | null
          skills?: string[] | null
          streak_freeze_count?: number | null
          title?: string | null
          xp?: number | null
        }
        Update: {
          activity_streak?: number | null
          avatar_url?: string | null
          bio?: string | null
          calendly_link?: string | null
          calendly_webhook_secret?: string | null
          can_help_with?: string | null
          company_id?: string | null
          company_name?: string | null
          created_at?: string | null
          full_name?: string | null
          fund_id?: string | null
          id?: string
          is_active?: boolean | null
          last_activity_date?: string | null
          last_sign_in_at?: string | null
          level?: number | null
          linkedin_url?: string | null
          personal_bests?: Json | null
          skills?: string[] | null
          streak_freeze_count?: number | null
          title?: string | null
          xp?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      roas_calculations: {
        Row: {
          average_order_value: number
          breakeven_roas: number
          company_id: string
          contribution_margin: number
          cost_of_goods: number | null
          created_at: string
          fulfillment_cost: number | null
          id: string
          input_mode: string
          margin_percentage: number | null
          notes: string | null
          other_cost: number | null
          packaging_cost: number | null
          payment_fee_fixed: number | null
          payment_fee_percentage: number | null
          return_rate_percentage: number | null
          shipping_cost: number | null
        }
        Insert: {
          average_order_value: number
          breakeven_roas: number
          company_id: string
          contribution_margin: number
          cost_of_goods?: number | null
          created_at?: string
          fulfillment_cost?: number | null
          id?: string
          input_mode?: string
          margin_percentage?: number | null
          notes?: string | null
          other_cost?: number | null
          packaging_cost?: number | null
          payment_fee_fixed?: number | null
          payment_fee_percentage?: number | null
          return_rate_percentage?: number | null
          shipping_cost?: number | null
        }
        Update: {
          average_order_value?: number
          breakeven_roas?: number
          company_id?: string
          contribution_margin?: number
          cost_of_goods?: number | null
          created_at?: string
          fulfillment_cost?: number | null
          id?: string
          input_mode?: string
          margin_percentage?: number | null
          notes?: string | null
          other_cost?: number | null
          packaging_cost?: number | null
          payment_fee_fixed?: number | null
          payment_fee_percentage?: number | null
          return_rate_percentage?: number | null
          shipping_cost?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "roas_calculations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      sensitive_data_access_log: {
        Row: {
          accessed_at: string | null
          action: string
          id: string
          ip_address: string | null
          record_id: string
          table_name: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          accessed_at?: string | null
          action: string
          id?: string
          ip_address?: string | null
          record_id: string
          table_name: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          accessed_at?: string | null
          action?: string
          id?: string
          ip_address?: string | null
          record_id?: string
          table_name?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      shipping_prices: {
        Row: {
          company_id: string
          country_code: string | null
          created_at: string | null
          effective_from: string | null
          home_delivery_dkk: number
          id: string
          pickup_point_dkk: number
        }
        Insert: {
          company_id: string
          country_code?: string | null
          created_at?: string | null
          effective_from?: string | null
          home_delivery_dkk: number
          id?: string
          pickup_point_dkk: number
        }
        Update: {
          company_id?: string
          country_code?: string | null
          created_at?: string | null
          effective_from?: string | null
          home_delivery_dkk?: number
          id?: string
          pickup_point_dkk?: number
        }
        Relationships: [
          {
            foreignKeyName: "shipping_prices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      support_contacts: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          email: string | null
          icon_name: string | null
          id: string
          is_active: boolean | null
          linkedin_url: string | null
          name: string
          phone: string | null
          role: string
          sort_order: number | null
          updated_at: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          icon_name?: string | null
          id?: string
          is_active?: boolean | null
          linkedin_url?: string | null
          name: string
          phone?: string | null
          role: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          email?: string | null
          icon_name?: string | null
          id?: string
          is_active?: boolean | null
          linkedin_url?: string | null
          name?: string
          phone?: string | null
          role?: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      system_settings: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          is_active: boolean
          setting_key: string
          setting_value: Json
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          setting_key: string
          setting_value?: Json
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          is_active?: boolean
          setting_key?: string
          setting_value?: Json
          updated_at?: string | null
        }
        Relationships: []
      }
      tasks: {
        Row: {
          assigned_to: string | null
          company_id: string | null
          completed_at: string | null
          created_at: string | null
          created_by: string
          description: string | null
          due_date: string | null
          id: string
          is_private: boolean
          is_recurring: boolean | null
          monday_board_id: string | null
          monday_item_id: string | null
          monday_last_synced_at: string | null
          next_occurrence_date: string | null
          parent_task_id: string | null
          priority: string
          recurrence_count: number | null
          recurrence_day_of_month: number | null
          recurrence_day_of_week: number | null
          recurrence_end_date: string | null
          recurrence_interval: number | null
          recurrence_pattern: string | null
          status: string
          sync_source: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          assigned_to?: string | null
          company_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          created_by: string
          description?: string | null
          due_date?: string | null
          id?: string
          is_private?: boolean
          is_recurring?: boolean | null
          monday_board_id?: string | null
          monday_item_id?: string | null
          monday_last_synced_at?: string | null
          next_occurrence_date?: string | null
          parent_task_id?: string | null
          priority?: string
          recurrence_count?: number | null
          recurrence_day_of_month?: number | null
          recurrence_day_of_week?: number | null
          recurrence_end_date?: string | null
          recurrence_interval?: number | null
          recurrence_pattern?: string | null
          status?: string
          sync_source?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          assigned_to?: string | null
          company_id?: string | null
          completed_at?: string | null
          created_at?: string | null
          created_by?: string
          description?: string | null
          due_date?: string | null
          id?: string
          is_private?: boolean
          is_recurring?: boolean | null
          monday_board_id?: string | null
          monday_item_id?: string | null
          monday_last_synced_at?: string | null
          next_occurrence_date?: string | null
          parent_task_id?: string | null
          priority?: string
          recurrence_count?: number | null
          recurrence_day_of_month?: number | null
          recurrence_day_of_week?: number | null
          recurrence_end_date?: string | null
          recurrence_interval?: number | null
          recurrence_pattern?: string | null
          status?: string
          sync_source?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tasks_parent_task_id_fkey"
            columns: ["parent_task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      tool_usage_events: {
        Row: {
          company_id: string | null
          created_at: string | null
          id: string
          metadata: Json | null
          tool_action: string
          tool_name: string
          user_id: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          tool_action: string
          tool_name: string
          user_id?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          tool_action?: string
          tool_name?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tool_usage_events_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      trusted_partner_categories: {
        Row: {
          created_at: string | null
          description: string | null
          icon_name: string | null
          id: string
          is_active: boolean | null
          name: string
          slug: string
          sort_order: number | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          icon_name?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          slug: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          icon_name?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          slug?: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      trusted_partner_ratings: {
        Row: {
          comment: string | null
          created_at: string | null
          id: string
          partner_id: string
          rating: number
          updated_at: string | null
          user_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string | null
          id?: string
          partner_id: string
          rating: number
          updated_at?: string | null
          user_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string | null
          id?: string
          partner_id?: string
          rating?: number
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trusted_partner_ratings_partner_id_fkey"
            columns: ["partner_id"]
            isOneToOne: false
            referencedRelation: "trusted_partners"
            referencedColumns: ["id"]
          },
        ]
      }
      trusted_partners: {
        Row: {
          category_id: string
          company_name: string
          contact_name: string | null
          contact_title: string | null
          created_at: string | null
          description: string | null
          email: string | null
          id: string
          is_active: boolean | null
          is_mola_recommended: boolean | null
          linkedin_url: string | null
          logo_url: string | null
          mobile_phone: string | null
          phone: string | null
          sort_order: number | null
          updated_at: string | null
          website: string | null
        }
        Insert: {
          category_id: string
          company_name: string
          contact_name?: string | null
          contact_title?: string | null
          created_at?: string | null
          description?: string | null
          email?: string | null
          id?: string
          is_active?: boolean | null
          is_mola_recommended?: boolean | null
          linkedin_url?: string | null
          logo_url?: string | null
          mobile_phone?: string | null
          phone?: string | null
          sort_order?: number | null
          updated_at?: string | null
          website?: string | null
        }
        Update: {
          category_id?: string
          company_name?: string
          contact_name?: string | null
          contact_title?: string | null
          created_at?: string | null
          description?: string | null
          email?: string | null
          id?: string
          is_active?: boolean | null
          is_mola_recommended?: boolean | null
          linkedin_url?: string | null
          logo_url?: string | null
          mobile_phone?: string | null
          phone?: string | null
          sort_order?: number | null
          updated_at?: string | null
          website?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "trusted_partners_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "trusted_partner_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      trustpilot_score_history: {
        Row: {
          fetched_at: string | null
          id: string
          profile_id: string
          recent_score: number | null
          score: number | null
          total_reviews: number | null
        }
        Insert: {
          fetched_at?: string | null
          id?: string
          profile_id: string
          recent_score?: number | null
          score?: number | null
          total_reviews?: number | null
        }
        Update: {
          fetched_at?: string | null
          id?: string
          profile_id?: string
          recent_score?: number | null
          score?: number | null
          total_reviews?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trustpilot_score_history_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: false
            referencedRelation: "company_trustpilot_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trustpilot_scores: {
        Row: {
          created_at: string | null
          id: string
          last_fetched_at: string | null
          profile_id: string
          rating_breakdown: Json | null
          recent_period_days: number | null
          recent_reviews_count: number | null
          recent_score: number | null
          score: number | null
          total_reviews: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          last_fetched_at?: string | null
          profile_id: string
          rating_breakdown?: Json | null
          recent_period_days?: number | null
          recent_reviews_count?: number | null
          recent_score?: number | null
          score?: number | null
          total_reviews?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          last_fetched_at?: string | null
          profile_id?: string
          rating_breakdown?: Json | null
          recent_period_days?: number | null
          recent_reviews_count?: number | null
          recent_score?: number | null
          score?: number | null
          total_reviews?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "trustpilot_scores_profile_id_fkey"
            columns: ["profile_id"]
            isOneToOne: true
            referencedRelation: "company_trustpilot_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      uploads: {
        Row: {
          document_id: string
          file_name: string
          file_path: string
          file_size: number
          id: string
          mime_type: string
          uploaded_at: string | null
          user_id: string
        }
        Insert: {
          document_id: string
          file_name: string
          file_path: string
          file_size: number
          id?: string
          mime_type: string
          uploaded_at?: string | null
          user_id: string
        }
        Update: {
          document_id?: string
          file_name?: string
          file_path?: string
          file_size?: number
          id?: string
          mime_type?: string
          uploaded_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "uploads_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      user_activity_log: {
        Row: {
          action: string
          admin_user_id: string | null
          created_at: string | null
          details: Json | null
          id: string
          user_id: string
        }
        Insert: {
          action: string
          admin_user_id?: string | null
          created_at?: string | null
          details?: Json | null
          id?: string
          user_id: string
        }
        Update: {
          action?: string
          admin_user_id?: string | null
          created_at?: string | null
          details?: Json | null
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_invitations: {
        Row: {
          accepted_at: string | null
          company_id: string | null
          created_at: string
          email: string
          expires_at: string
          fund_id: string | null
          id: string
          invitation_token: string | null
          invited_by: string
          invited_role: Database["public"]["Enums"]["app_role"]
          notes: string | null
          status: string
        }
        Insert: {
          accepted_at?: string | null
          company_id?: string | null
          created_at?: string
          email: string
          expires_at?: string
          fund_id?: string | null
          id?: string
          invitation_token?: string | null
          invited_by: string
          invited_role: Database["public"]["Enums"]["app_role"]
          notes?: string | null
          status?: string
        }
        Update: {
          accepted_at?: string | null
          company_id?: string | null
          created_at?: string
          email?: string
          expires_at?: string
          fund_id?: string | null
          id?: string
          invitation_token?: string | null
          invited_by?: string
          invited_role?: Database["public"]["Enums"]["app_role"]
          notes?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_invitations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_invitations_fund_id_fkey"
            columns: ["fund_id"]
            isOneToOne: false
            referencedRelation: "funds"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_webhook_secrets: {
        Row: {
          calendly_webhook_secret: string | null
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          calendly_webhook_secret?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          calendly_webhook_secret?: string | null
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      valuations: {
        Row: {
          as_of_date: string
          company_id: string
          created_at: string | null
          id: string
          post_money_valuation_dkk: number
          source: string
        }
        Insert: {
          as_of_date: string
          company_id: string
          created_at?: string | null
          id?: string
          post_money_valuation_dkk: number
          source: string
        }
        Update: {
          as_of_date?: string
          company_id?: string
          created_at?: string | null
          id?: string
          post_money_valuation_dkk?: number
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "valuations_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      xp_events: {
        Row: {
          created_at: string | null
          event_description: string | null
          event_type: string
          id: string
          user_id: string
          xp_amount: number
        }
        Insert: {
          created_at?: string | null
          event_description?: string | null
          event_type: string
          id?: string
          user_id: string
          xp_amount: number
        }
        Update: {
          created_at?: string | null
          event_description?: string | null
          event_type?: string
          id?: string
          user_id?: string
          xp_amount?: number
        }
        Relationships: []
      }
    }
    Views: {
      masked_company_contacts: {
        Row: {
          company_id: string | null
          created_at: string | null
          email: string | null
          id: string | null
          is_primary: boolean | null
          name: string | null
          notes: string | null
          phone: string | null
          role: string | null
          updated_at: string | null
        }
        Insert: {
          company_id?: string | null
          created_at?: string | null
          email?: never
          id?: string | null
          is_primary?: boolean | null
          name?: string | null
          notes?: string | null
          phone?: never
          role?: string | null
          updated_at?: string | null
        }
        Update: {
          company_id?: string | null
          created_at?: string | null
          email?: never
          id?: string | null
          is_primary?: boolean | null
          name?: string | null
          notes?: string | null
          phone?: never
          role?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "company_contacts_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      award_xp: {
        Args: {
          p_amount: number
          p_description?: string
          p_event_type: string
          p_user_id: string
        }
        Returns: {
          leveled_up: boolean
          new_level: number
          new_xp: number
        }[]
      }
      can_access_sensitive_data: {
        Args: { _company_id: string; _table_name: string }
        Returns: boolean
      }
      cleanup_demo_data: { Args: never; Returns: undefined }
      cleanup_old_login_attempts: { Args: never; Returns: undefined }
      count_recent_login_attempts: {
        Args: { p_identifier: string; p_window_minutes?: number }
        Returns: number
      }
      decrypt_sensitive_data: {
        Args: { encrypted_data: string }
        Returns: string
      }
      encrypt_sensitive_data: { Args: { data: string }; Returns: string }
      get_user_fund_id: { Args: { _user_id: string }; Returns: string }
      has_income_access: {
        Args: { _owner_id: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      is_company_in_user_fund: {
        Args: { _company_id: string; _user_id: string }
        Returns: boolean
      }
      is_dd_partner_for_company: {
        Args: { _company_id: string; _user_id: string }
        Returns: boolean
      }
      is_founder_of_company: {
        Args: { _company_id: string; _user_id: string }
        Returns: boolean
      }
      log_activity_event: {
        Args: {
          p_event_icon?: string
          p_event_message: string
          p_event_type: string
        }
        Returns: undefined
      }
      owns_shares_in_company: {
        Args: { _company_id: string; _user_id: string }
        Returns: boolean
      }
      update_activity_streak: {
        Args: { p_user_id: string }
        Returns: {
          new_streak: number
          streak_bonus: number
        }[]
      }
    }
    Enums: {
      app_role:
        | "founder"
        | "mola_admin"
        | "fund_partner"
        | "owner"
        | "dd_partner"
        | "external_viewer"
        | "investor"
      company_status:
        | "new_investment"
        | "due_diligence"
        | "active"
        | "exited"
        | "bankruptcy"
        | "rejected"
        | "archived"
      dd_document_type:
        | "financial"
        | "legal"
        | "commercial"
        | "technical"
        | "other"
      dd_status:
        | "not_started"
        | "in_progress"
        | "pending_review"
        | "approved"
        | "rejected"
      document_type:
        | "shareholder_agreement"
        | "articles_of_association"
        | "annual_report"
        | "board_minutes"
        | "investment_memo"
        | "term_sheet"
        | "valuation_report"
        | "other"
      income_status: "draft" | "sent" | "paid" | "cancelled"
      income_type: "faktura" | "løn"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "founder",
        "mola_admin",
        "fund_partner",
        "owner",
        "dd_partner",
        "external_viewer",
        "investor",
      ],
      company_status: [
        "new_investment",
        "due_diligence",
        "active",
        "exited",
        "bankruptcy",
        "rejected",
        "archived",
      ],
      dd_document_type: [
        "financial",
        "legal",
        "commercial",
        "technical",
        "other",
      ],
      dd_status: [
        "not_started",
        "in_progress",
        "pending_review",
        "approved",
        "rejected",
      ],
      document_type: [
        "shareholder_agreement",
        "articles_of_association",
        "annual_report",
        "board_minutes",
        "investment_memo",
        "term_sheet",
        "valuation_report",
        "other",
      ],
      income_status: ["draft", "sent", "paid", "cancelled"],
      income_type: ["faktura", "løn"],
    },
  },
} as const
