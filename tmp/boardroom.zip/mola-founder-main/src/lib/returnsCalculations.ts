// Returns and ROI calculation helpers for MOLA investments

export interface Dividend {
  id: string;
  company_id: string;
  fund_id: string;
  amount_dkk: number;
  declared_date: string;
  paid_date: string;
  note?: string;
}

export interface Exit {
  id: string;
  company_id: string;
  fund_id: string;
  closing_date: string;
  gross_sale_amount_dkk: number;
  mola_ownership_pct_at_exit: number;
  transaction_costs_dkk: number;
  earnout_possible: boolean;
  earnout_amount_potential_dkk?: number;
  retained_shares_pct: number;
  note?: string;
}

export interface Valuation {
  id: string;
  company_id: string;
  as_of_date: string;
  post_money_valuation_dkk: number;
  source: string;
}

export interface CashFlow {
  date: string;
  type: 'investment' | 'dividend' | 'exit';
  amount: number; // negative for investments, positive for distributions
  description: string;
}

export interface FundingRound {
  invested_amount_dkk: number;
  invested_at: string;
}

/**
 * Calculate realized proceeds from an exit
 * Note: gross_sale_amount_dkk is MOLA's share directly, not total sale amount
 */
export function calculateRealizedProceeds(exit: Exit): number {
  // Calculate MOLA's share based on ownership percentage
  const molaShare = exit.gross_sale_amount_dkk * (exit.mola_ownership_pct_at_exit / 100);
  return molaShare - exit.transaction_costs_dkk;
}

/**
 * Calculate total paid-in capital
 */
export function calculatePaidIn(investedAmount: number): number {
  return investedAmount;
}

/**
 * Calculate total distributions (dividends + realized exits)
 */
export function calculateDistributions(
  dividends: Dividend[],
  exits: Exit[]
): number {
  const dividendSum = dividends.reduce((sum, d) => sum + d.amount_dkk, 0);
  const exitSum = exits.reduce((sum, e) => sum + calculateRealizedProceeds(e), 0);
  return dividendSum + exitSum;
}

/**
 * Calculate unrealized value based on latest valuation and current ownership
 */
export function calculateUnrealizedValue(
  latestValuation: Valuation | null,
  currentOwnershipPct: number,
  exits: Exit[]
): number {
  if (!latestValuation) return 0;

  // Base unrealized value from current ownership
  let unrealized =
    latestValuation.post_money_valuation_dkk * (currentOwnershipPct / 100);

  // Add value of retained shares from exits
  exits.forEach((exit) => {
    if (exit.retained_shares_pct > 0) {
      unrealized +=
        latestValuation.post_money_valuation_dkk * (exit.retained_shares_pct / 100);
    }
  });

  return unrealized;
}

/**
 * Calculate DPI (Distributions to Paid-In)
 */
export function calculateDPI(distributions: number, paidIn: number): number {
  if (paidIn === 0) return 0;
  return distributions / paidIn;
}

/**
 * Calculate TVPI (Total Value to Paid-In)
 */
export function calculateTVPI(
  distributions: number,
  unrealizedValue: number,
  paidIn: number
): number {
  if (paidIn === 0) return 0;
  return (distributions + unrealizedValue) / paidIn;
}

/**
 * Calculate MOIC (Multiple on Invested Capital) - same as TVPI
 */
export function calculateMOIC(
  distributions: number,
  unrealizedValue: number,
  paidIn: number
): number {
  return calculateTVPI(distributions, unrealizedValue, paidIn);
}

/**
 * Calculate simple ROI percentage
 */
export function calculateROI(
  distributions: number,
  unrealizedValue: number,
  paidIn: number
): number {
  if (paidIn === 0) return 0;
  return ((distributions + unrealizedValue - paidIn) / paidIn) * 100;
}

import { formatCurrency, formatPercentage as formatPercent, formatNumber } from '@/lib/formatters';

/**
 * Format currency in DKK
 */
export function formatDKK(amount: number): string {
  return formatCurrency(amount, 0);
}

/**
 * Format percentage
 */
export function formatPercentage(value: number, decimals = 1): string {
  return formatPercent(value, decimals);
}

/**
 * Format multiple (e.g., MOIC, DPI, TVPI)
 */
export function formatMultiple(value: number, decimals = 2): string {
  return formatNumber(value, decimals) + 'x';
}
