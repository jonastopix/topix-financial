import { z } from 'zod';

/**
 * Enhanced password schema with strong requirements
 */
export const passwordSchema = z
  .string()
  .min(8, { message: "Password skal være mindst 8 tegn" })
  .regex(/[A-Z]/, { message: "Password skal indeholde mindst ét stort bogstav" })
  .regex(/[a-z]/, { message: "Password skal indeholde mindst ét lille bogstav" })
  .regex(/[0-9]/, { message: "Password skal indeholde mindst ét tal" })
  .regex(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, { message: "Password skal indeholde mindst ét specialtegn" });

/**
 * Email schema
 */
export const emailSchema = z.string().email({ message: "Ugyldig email adresse" });

/**
 * Login schema (less strict - only check email format)
 */
export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, { message: "Password er påkrævet" }),
});

/**
 * Signup schema with enhanced password requirements
 */
export const signupSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords matcher ikke",
  path: ["confirmPassword"],
});

/**
 * Reset password schema
 */
export const resetPasswordSchema = z.object({
  password: passwordSchema,
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords matcher ikke",
  path: ["confirmPassword"],
});

/**
 * Forgot password schema
 */
export const forgotPasswordSchema = z.object({
  email: emailSchema,
});
