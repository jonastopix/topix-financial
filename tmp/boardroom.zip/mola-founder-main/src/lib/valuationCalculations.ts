interface MonthlyReport {
  period_year: number;
  period_month: number;
  revenue_dkk: number;
  ebitda_dkk: number;
}

interface LTMMetrics {
  ltmRevenue: number;
  ltmEBITDA: number;
  monthsUsed: number;
  isAnnualized: boolean;
}

interface ValuationBreakdown {
  revenueComponent: number;
  ebitdaComponent: number;
  totalValuation: number;
  revenueWeight: number;
  ebitdaWeight: number;
  ltmRevenue: number;
  ltmEBITDA: number;
  revenueMultiple: number;
  ebitdaMultiple: number;
}

/**
 * Calculate Last Twelve Months (LTM) metrics from monthly reports
 * If less than 12 months available, annualizes the available data
 */
export function calculateLTMMetrics(reports: MonthlyReport[]): LTMMetrics {
  if (!reports || reports.length === 0) {
    return {
      ltmRevenue: 0,
      ltmEBITDA: 0,
      monthsUsed: 0,
      isAnnualized: false,
    };
  }

  // Sort reports by date (newest first)
  const sortedReports = [...reports].sort((a, b) => {
    const dateA = new Date(a.period_year, a.period_month - 1);
    const dateB = new Date(b.period_year, b.period_month - 1);
    return dateB.getTime() - dateA.getTime();
  });

  // Take last 12 months (or whatever is available)
  const reportsToUse = sortedReports.slice(0, Math.min(12, sortedReports.length));
  const monthsUsed = reportsToUse.length;

  // Sum up the metrics
  let totalRevenue = 0;
  let totalEBITDA = 0;

  reportsToUse.forEach((report) => {
    totalRevenue += Number(report.revenue_dkk) || 0;
    totalEBITDA += Number(report.ebitda_dkk) || 0;
  });

  // If less than 12 months, annualize
  let ltmRevenue = totalRevenue;
  let ltmEBITDA = totalEBITDA;
  let isAnnualized = false;

  if (monthsUsed < 12) {
    ltmRevenue = (totalRevenue / monthsUsed) * 12;
    ltmEBITDA = (totalEBITDA / monthsUsed) * 12;
    isAnnualized = true;
  }

  return {
    ltmRevenue,
    ltmEBITDA,
    monthsUsed,
    isAnnualized,
  };
}

/**
 * Calculate market-based valuation using weighted revenue and EBITDA multiples
 */
export function calculateMarketBasedValuation(params: {
  ltmRevenue: number;
  ltmEBITDA: number;
  revenueMultiple: number;
  ebitdaMultiple: number;
  revenueWeight: number; // 0-100
}): ValuationBreakdown {
  const { ltmRevenue, ltmEBITDA, revenueMultiple, ebitdaMultiple, revenueWeight } = params;

  // Only include EBITDA if positive - negative EBITDA should not reduce valuation
  const ebitdaComponent = ltmEBITDA > 0 
    ? ltmEBITDA * ebitdaMultiple * ((100 - revenueWeight) / 100)
    : 0;

  // If EBITDA is negative, use 100% revenue weighting
  const adjustedRevenueWeight = ltmEBITDA > 0 ? revenueWeight : 100;
  const revenueComponent = ltmRevenue * revenueMultiple * (adjustedRevenueWeight / 100);
  
  const totalValuation = revenueComponent + ebitdaComponent;
  const ebitdaWeight = ltmEBITDA > 0 ? (100 - revenueWeight) : 0;

  return {
    revenueComponent,
    ebitdaComponent,
    totalValuation,
    revenueWeight: adjustedRevenueWeight,
    ebitdaWeight,
    ltmRevenue,
    ltmEBITDA,
    revenueMultiple,
    ebitdaMultiple,
  };
}

/**
 * Format valuation breakdown for display
 */
import { formatCurrency, formatNumber } from '@/lib/formatters';

/**
 * Formats valuation breakdown into detailed string
 * 
 * @param breakdown - The calculated valuation breakdown
 * @returns Multi-line formatted breakdown string
 */
export function formatValuationBreakdown(breakdown: ValuationBreakdown): string {
  const lines = [
    `Revenue: ${formatDKK(breakdown.ltmRevenue)} × ${formatNumber(breakdown.revenueMultiple, 2)}x × ${formatNumber(breakdown.revenueWeight, 0)}% = ${formatDKK(breakdown.revenueComponent)}`,
    `EBITDA: ${formatDKK(breakdown.ltmEBITDA)} × ${formatNumber(breakdown.ebitdaMultiple, 2)}x × ${formatNumber(breakdown.ebitdaWeight, 0)}% = ${formatDKK(breakdown.ebitdaComponent)}`,
    `Total: ${formatDKK(breakdown.totalValuation)}`,
  ];
  return lines.join('\n');
}

function formatDKK(amount: number): string {
  return formatCurrency(amount, 0);
}
