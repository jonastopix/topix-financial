/**
 * Centralized formatting utilities for Danish locale
 * All numbers, currencies, and percentages should use these functions
 * to ensure consistent Danish formatting (1.234.567,89 kr.)
 */

/**
 * Format number with Danish locale
 * @param value - The number to format
 * @param decimals - Number of decimal places (default: 0)
 * @returns Formatted string with Danish locale (e.g., "1.234.567,89")
 */
export function formatNumber(
  value: number, 
  decimals: number = 0
): string {
  return new Intl.NumberFormat('da-DK', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
}

/**
 * Format currency in DKK with Danish locale
 * @param amount - The amount to format
 * @param decimals - Number of decimal places (default: 0)
 * @returns Formatted string with currency (e.g., "1.234.567 kr.")
 */
export function formatCurrency(
  amount: number,
  decimals: number = 0
): string {
  return new Intl.NumberFormat('da-DK', {
    style: 'currency',
    currency: 'DKK',
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(amount);
}

/**
 * Format percentage with Danish locale
 * @param value - The percentage value (e.g., 15.5 for 15.5%)
 * @param decimals - Number of decimal places (default: 1)
 * @returns Formatted string with percentage sign (e.g., "15,5%")
 */
export function formatPercentage(
  value: number,
  decimals: number = 1
): string {
  return new Intl.NumberFormat('da-DK', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value) + '%';
}

/**
 * Format compact numbers (K, M, Mia) with Danish locale
 * @param value - The number to format
 * @param decimals - Number of decimal places (default: 1)
 * @returns Formatted compact string (e.g., "1,2M", "2,5 mia.")
 */
export function formatCompact(
  value: number,
  decimals: number = 1
): string {
  const absValue = Math.abs(value);
  const sign = value < 0 ? '-' : '';
  
  if (absValue >= 1000000000) {
    return sign + formatNumber(absValue / 1000000000, decimals) + ' mia.';
  } else if (absValue >= 1000000) {
    return sign + formatNumber(absValue / 1000000, decimals) + 'M';
  } else if (absValue >= 1000) {
    return sign + formatNumber(absValue / 1000, decimals) + 'k';
  }
  return sign + formatNumber(absValue, decimals);
}
