import { z } from 'zod';

// Password strength levels
export type PasswordStrength = 'very-weak' | 'weak' | 'medium' | 'strong' | 'very-strong';

export interface PasswordValidationResult {
  strength: PasswordStrength;
  score: number; // 0-4
  feedback: {
    hasMinLength: boolean;
    hasUppercase: boolean;
    hasLowercase: boolean;
    hasNumber: boolean;
    hasSpecial: boolean;
    isNotLeaked: boolean | null; // null = not checked yet
  };
  estimatedCrackTime: string;
}

// Enhanced password requirements
const MIN_LENGTH = 8;
const UPPERCASE_REGEX = /[A-Z]/;
const LOWERCASE_REGEX = /[a-z]/;
const NUMBER_REGEX = /[0-9]/;
const SPECIAL_REGEX = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;

// Common weak passwords to block
const COMMON_PASSWORDS = [
  'password', 'password123', '12345678', 'qwerty', 'abc123',
  'monkey', '1234567', 'letmein', 'trustno1', 'dragon',
  'baseball', 'iloveyou', 'master', 'sunshine', 'ashley',
  'bailey', 'passw0rd', 'shadow', '123123', '654321'
];

/**
 * Calculate password strength score (0-4)
 */
export function calculatePasswordStrength(password: string): number {
  let score = 0;

  // Length scoring
  if (password.length >= MIN_LENGTH) score++;
  if (password.length >= 12) score++;

  // Character variety scoring
  if (UPPERCASE_REGEX.test(password)) score++;
  if (LOWERCASE_REGEX.test(password)) score++;
  if (NUMBER_REGEX.test(password)) score++;
  if (SPECIAL_REGEX.test(password)) score++;

  // Cap at 4 (very strong)
  return Math.min(score, 4);
}

/**
 * Get password strength label
 */
export function getStrengthLabel(score: number): PasswordStrength {
  switch (score) {
    case 0:
    case 1:
      return 'very-weak';
    case 2:
      return 'weak';
    case 3:
      return 'medium';
    case 4:
      return 'very-strong';
    default:
      return 'strong';
  }
}

/**
 * Estimate time to crack password (simplified)
 */
export function estimateCrackTime(password: string): string {
  const length = password.length;
  const hasUpper = UPPERCASE_REGEX.test(password);
  const hasLower = LOWERCASE_REGEX.test(password);
  const hasNumber = NUMBER_REGEX.test(password);
  const hasSpecial = SPECIAL_REGEX.test(password);

  let charsetSize = 0;
  if (hasLower) charsetSize += 26;
  if (hasUpper) charsetSize += 26;
  if (hasNumber) charsetSize += 10;
  if (hasSpecial) charsetSize += 10;

  const combinations = Math.pow(charsetSize, length);
  
  // Assume 1 billion guesses per second
  const secondsToCrack = combinations / 1_000_000_000;

  if (secondsToCrack < 1) return 'Øjeblikkeligt';
  if (secondsToCrack < 60) return 'Få sekunder';
  if (secondsToCrack < 3600) return 'Få minutter';
  if (secondsToCrack < 86400) return 'Få timer';
  if (secondsToCrack < 2592000) return 'Få dage';
  if (secondsToCrack < 31536000) return 'Få måneder';
  if (secondsToCrack < 315360000) return 'Få år';
  return '100+ år';
}

/**
 * Validate password against requirements
 */
export function validatePassword(password: string): PasswordValidationResult {
  const feedback = {
    hasMinLength: password.length >= MIN_LENGTH,
    hasUppercase: UPPERCASE_REGEX.test(password),
    hasLowercase: LOWERCASE_REGEX.test(password),
    hasNumber: NUMBER_REGEX.test(password),
    hasSpecial: SPECIAL_REGEX.test(password),
    isNotLeaked: null, // Will be checked separately via API
  };

  const score = calculatePasswordStrength(password);
  const strength = getStrengthLabel(score);
  const estimatedCrackTime = estimateCrackTime(password);

  return {
    strength,
    score,
    feedback,
    estimatedCrackTime,
  };
}

/**
 * Check if password is in common passwords list
 */
export function isCommonPassword(password: string): boolean {
  return COMMON_PASSWORDS.includes(password.toLowerCase());
}

/**
 * Check password against Have I Been Pwned API using k-anonymity
 * https://haveibeenpwned.com/API/v3#PwnedPasswords
 */
export async function checkPasswordLeaked(password: string): Promise<boolean> {
  try {
    // Hash password using SHA-1
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();

    // Use k-anonymity: only send first 5 characters
    const prefix = hashHex.substring(0, 5);
    const suffix = hashHex.substring(5);

    // Query HIBP API
    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      method: 'GET',
      headers: {
        'Add-Padding': 'true', // Prevents HIBP from knowing the hash prefix length
      },
    });

    if (!response.ok) {
      console.warn('HIBP API request failed, skipping leak check');
      return false; // Default to not leaked if API fails
    }

    const text = await response.text();
    const hashes = text.split('\n');

    // Check if our suffix appears in the response
    for (const line of hashes) {
      const [hashSuffix, count] = line.split(':');
      if (hashSuffix === suffix) {
        console.warn(`Password found in ${count} data breaches`);
        return true; // Password is leaked
      }
    }

    return false; // Password not found in breaches
  } catch (error) {
    console.error('Error checking password against HIBP:', error);
    return false; // Default to not leaked if check fails
  }
}

/**
 * Debounce function for performance optimization
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timeoutId: NodeJS.Timeout;
  return (...args: Parameters<T>) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func(...args), delay);
  };
}
