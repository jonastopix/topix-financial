type MonthlyReport = {
  period_month: number;
  period_year: number;
  revenue_dkk: number;
  ebitda_dkk: number;
  cash_dkk: number;
  new_customers: number;
  created_at: string;
  marketing_cost_dkk?: number;
  budget_revenue_dkk?: number;
  budget_ebitda_dkk?: number;
  orders?: number;
};

type NPSResponse = {
  score: number;
  period_quarter: number;
  period_year: number;
};

export const calculateYTD = (reports: MonthlyReport[], year: number) => {
  // Only include reports with actual data (revenue_dkk IS NOT NULL AND > 0)
  // This excludes budget-only records where revenue_dkk = 0
  const ytdReports = reports.filter(r => 
    r.period_year === year && r.revenue_dkk !== null && r.revenue_dkk !== undefined && Number(r.revenue_dkk) > 0
  );
  
  const totalRevenue = ytdReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
  const totalEBITDA = ytdReports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
  const latestCash = ytdReports.length > 0 ? Number(ytdReports[0].cash_dkk) : 0;
  
  return {
    revenue: totalRevenue,
    ebitda: totalEBITDA,
    cash: latestCash,
    margin: totalRevenue > 0 ? (totalEBITDA / totalRevenue) * 100 : 0,
  };
};

export const calculateYOY = (reports: MonthlyReport[], currentYear: number) => {
  const currentYearData = calculateYTD(reports, currentYear);
  const previousYearData = calculateYTD(reports, currentYear - 1);

  const revenueGrowth = previousYearData.revenue > 0 
    ? ((currentYearData.revenue - previousYearData.revenue) / previousYearData.revenue) * 100 
    : 0;

  const ebitdaGrowth = previousYearData.ebitda > 0
    ? ((currentYearData.ebitda - previousYearData.ebitda) / previousYearData.ebitda) * 100
    : 0;

  const marginChange = currentYearData.margin - previousYearData.margin;

  return {
    revenueGrowth,
    ebitdaGrowth,
    marginChange,
  };
};

export const getLatestMonth = (reports: MonthlyReport[]) => {
  if (reports.length === 0) return null;
  
  // Find the latest report that is not in the future and has actual data (revenue_dkk IS NOT NULL)
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1; // JavaScript months are 0-indexed
  
  // Filter out future months and budget-only months, find the most recent one
  const validReports = reports.filter(r => {
    // Check if month is in the past
    const isPast = r.period_year < currentYear || 
                   (r.period_year === currentYear && r.period_month < currentMonth);
    
    // Check if report has actual data (revenue_dkk IS NOT NULL)
    const hasData = r.revenue_dkk !== null && r.revenue_dkk !== undefined && Number(r.revenue_dkk) > 0;
    
    return isPast && hasData;
  });
  
  if (validReports.length === 0) return null;
  
  const latest = validReports[0];
  const previous = validReports[1];

  const revenueChange = previous 
    ? ((Number(latest.revenue_dkk) - Number(previous.revenue_dkk)) / Number(previous.revenue_dkk)) * 100 
    : 0;

  const ebitdaChange = previous
    ? ((Number(latest.ebitda_dkk) - Number(previous.ebitda_dkk)) / Number(previous.ebitda_dkk)) * 100
    : 0;

  return {
    revenue: Number(latest.revenue_dkk),
    ebitda: Number(latest.ebitda_dkk),
    cash: Number(latest.cash_dkk),
    newCustomers: latest.new_customers,
    revenueChange,
    ebitdaChange,
    month: latest.period_month,
    year: latest.period_year,
  };
};

// Advanced scorecard calculations
export const calculateFinancialScore = (reports: MonthlyReport[], currentYear: number): number => {
  const ytdData = calculateYTD(reports, currentYear);
  const yoyData = calculateYOY(reports, currentYear);

  if (ytdData.revenue === 0) return 0;

  // Normalize EBITDA margin (0-30% margin = 0-50 points)
  const marginScore = Math.min(50, (ytdData.margin / 30) * 50);

  // Normalize YTD growth (0-50% growth = 0-50 points)
  const growthScore = Math.min(50, Math.max(0, (yoyData.revenueGrowth / 50) * 50));

  return Math.min(100, marginScore + growthScore);
};

export const calculateGrowthScore = (reports: MonthlyReport[], currentYear: number): number => {
  const yoyData = calculateYOY(reports, currentYear);

  // YOY revenue growth: 0% = 0 points, 50%+ = 100 points
  // Negative growth = 0 points
  const score = Math.max(0, Math.min(100, (yoyData.revenueGrowth / 50) * 100));

  return score;
};

export const calculateTransparencyScore = (reports: MonthlyReport[]): number => {
  // Check last 3 months for on-time submissions (before 20th of the following month)
  const last3Reports = reports.slice(0, 3);

  if (last3Reports.length === 0) return 0;

  const onTimeCount = last3Reports.filter(report => {
    const createdDate = new Date(report.created_at);
    const reportMonth = report.period_month;
    const reportYear = report.period_year;
    
    // Calculate deadline: 20th of the month AFTER the reporting period
    let deadlineMonth = reportMonth + 1;
    let deadlineYear = reportYear;
    
    if (deadlineMonth > 12) {
      deadlineMonth = 1;
      deadlineYear++;
    }
    
    const deadline = new Date(deadlineYear, deadlineMonth - 1, 20, 23, 59, 59);
    
    // Check if submitted before or on deadline
    return createdDate <= deadline;
  }).length;

  // Convert to score: 0/3 = 0, 1/3 = 33, 2/3 = 67, 3/3 = 100
  return (onTimeCount / last3Reports.length) * 100;
};

export const calculateRelationshipScore = (npsResponses: NPSResponse[]): number => {
  if (!npsResponses || npsResponses.length === 0) return 0;

  // Latest NPS score * 10 (0-10 scale becomes 0-100)
  const latestScore = npsResponses[0].score;
  return latestScore * 10;
};

export const calculateScorecard = (reports: MonthlyReport[], npsResponses: NPSResponse[], currentYear: number) => {
  return {
    financial: calculateFinancialScore(reports, currentYear),
    growth: calculateGrowthScore(reports, currentYear),
    transparency: calculateTransparencyScore(reports),
    relationship: calculateRelationshipScore(npsResponses),
  };
};

export const calculateHealthIndex = (
  financial: number,
  growth: number,
  transparency: number,
  relationship: number
): number => {
  return (
    financial * 0.4 +
    growth * 0.3 +
    transparency * 0.2 +
    relationship * 0.1
  );
};

export const getHealthStatus = (score: number) => {
  if (score >= 80) {
    return {
      label: 'Sund',
      color: 'text-green-500',
      bgColor: 'bg-green-500/10',
      borderColor: 'border-green-500/50',
    };
  } else if (score >= 50) {
    return {
      label: 'Stabil',
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/50',
    };
  } else {
    return {
      label: 'Risiko',
      color: 'text-red-500',
      bgColor: 'bg-red-500/10',
      borderColor: 'border-red-500/50',
    };
  }
};

export const calculateNPSMetrics = (responses: NPSResponse[]) => {
  if (responses.length === 0) return { nps: 0, promoters: 0, passives: 0, detractors: 0 };

  const promoters = responses.filter(r => r.score >= 9).length;
  const passives = responses.filter(r => r.score >= 7 && r.score <= 8).length;
  const detractors = responses.filter(r => r.score <= 6).length;
  const total = responses.length;

  const nps = ((promoters - detractors) / total) * 100;

  return {
    nps: Math.round(nps),
    promoters: Math.round((promoters / total) * 100),
    passives: Math.round((passives / total) * 100),
    detractors: Math.round((detractors / total) * 100),
  };
};

// Generate mini trend data for scorecard visualization
export const generateScoreTrend = (reports: MonthlyReport[], scoreType: 'financial' | 'growth' | 'transparency'): number[] => {
  const last6Months = reports.slice(0, 6).reverse();

  if (last6Months.length < 2) return [];

  return last6Months.map((_, index) => {
    const subset = reports.slice(0, index + 1);
    const currentYear = new Date().getFullYear();

    switch (scoreType) {
      case 'financial':
        return calculateFinancialScore(subset, currentYear);
      case 'growth':
        return calculateGrowthScore(subset, currentYear);
      case 'transparency':
        return calculateTransparencyScore(subset);
      default:
        return 0;
    }
  });
};

// YTD Performance calculations with budget comparison
export const calculateYTDPerformance = (reports: MonthlyReport[], year: number) => {
  // Filter to only include reports with actual data (revenue > 0), not budget-only records
  const ytdReports = reports.filter(r => r.period_year === year && Number(r.revenue_dkk) > 0);
  // For budget calculations, we still need all records for the year that have budget data
  const allYearReports = reports.filter(r => r.period_year === year);
  
  const ytdRevenue = ytdReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
  const ytdEBITDA = ytdReports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
  const ytdMarketingCost = ytdReports.reduce((sum, r) => sum + Number(r.marketing_cost_dkk || 0), 0);
  const budgetYTDRevenue = allYearReports.reduce((sum, r) => sum + Number(r.budget_revenue_dkk || 0), 0);
  const budgetYTDEBITDA = allYearReports.reduce((sum, r) => sum + Number(r.budget_ebitda_dkk || 0), 0);
  
  const revenueVsBudgetPct = budgetYTDRevenue > 0 
    ? ((ytdRevenue / budgetYTDRevenue - 1) * 100)
    : 0;
  
  const ebitdaVsBudgetPct = budgetYTDEBITDA > 0
    ? ((ytdEBITDA / budgetYTDEBITDA - 1) * 100)
    : 0;
  
  const ebitdaMarginYTD = ytdRevenue > 0 ? (ytdEBITDA / ytdRevenue) * 100 : 0;
  const marketingPctYTD = ytdRevenue > 0 ? (ytdMarketingCost / ytdRevenue) * 100 : 0;
  const revenueROI = ytdMarketingCost > 0 ? (ytdRevenue / ytdMarketingCost) * 100 : 0;
  const ebitdaROI = ytdMarketingCost > 0 ? (ytdEBITDA / ytdMarketingCost) * 100 : 0;
  
  const isOnTarget = ytdRevenue >= budgetYTDRevenue && ytdEBITDA >= budgetYTDEBITDA;
  
  return {
    ytdRevenue,
    ytdEBITDA,
    ytdMarketingCost,
    budgetYTDRevenue,
    budgetYTDEBITDA,
    revenueVsBudgetPct,
    ebitdaVsBudgetPct,
    ebitdaMarginYTD,
    marketingPctYTD,
    revenueROI,
    ebitdaROI,
    isOnTarget,
    reportedMonths: ytdReports.length,
  };
};

// Helper: Calculate linear trend using simple linear regression
const calculateLinearTrend = (dataPoints: { month: number; value: number }[]) => {
  if (dataPoints.length < 2) return { slope: 0, intercept: 0 };
  
  const n = dataPoints.length;
  const sumX = dataPoints.reduce((sum, p) => sum + p.month, 0);
  const sumY = dataPoints.reduce((sum, p) => sum + p.value, 0);
  const sumXY = dataPoints.reduce((sum, p) => sum + p.month * p.value, 0);
  const sumX2 = dataPoints.reduce((sum, p) => sum + p.month * p.month, 0);
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return { slope, intercept };
};

// Helper: Calculate seasonal factors from prior year data
const calculateSeasonalFactors = (reports: MonthlyReport[], currentYear: number): number[] => {
  const priorYearReports = reports.filter(r => r.period_year === currentYear - 1 && Number(r.revenue_dkk) > 0);
  
  if (priorYearReports.length < 12) {
    // Not enough prior year data, return neutral factors
    return Array(12).fill(1);
  }
  
  const monthlyRevenue = Array(12).fill(0);
  priorYearReports.forEach(r => {
    monthlyRevenue[r.period_month - 1] = Number(r.revenue_dkk);
  });
  
  const avgMonthly = monthlyRevenue.reduce((sum, v) => sum + v, 0) / 12;
  
  // Calculate seasonal factor for each month (1.0 = average, >1 = above avg, <1 = below avg)
  return monthlyRevenue.map(revenue => 
    avgMonthly > 0 ? revenue / avgMonthly : 1
  );
};

// Intelligent Forecast calculations with trend and seasonal analysis
export const calculateForecast = (reports: MonthlyReport[], year: number) => {
  // Filter to only include months with actual revenue data
  const ytdReports = reports
    .filter(r => r.period_year === year && Number(r.revenue_dkk) > 0)
    .sort((a, b) => a.period_month - b.period_month);
  
  const reportedMonths = ytdReports.length;
  
  if (reportedMonths === 0) {
    return {
      reportedMonths: 0,
      avgMonthRevenue: 0,
      avgMonthEBITDA: 0,
      projectedRevenue: 0,
      projectedEBITDA: 0,
      projectedVsBudgetRevenuePct: 0,
      projectedVsBudgetEBITDAPct: 0,
      fullYearBudgetRevenue: 0,
      fullYearBudgetEBITDA: 0,
      confidenceLevel: 'low' as const,
      method: 'insufficient-data' as const,
      bestCaseRevenue: 0,
      worstCaseRevenue: 0,
      bestCaseEBITDA: 0,
      worstCaseEBITDA: 0,
    };
  }
  
  const ytdRevenue = ytdReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
  const ytdEBITDA = ytdReports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
  
  const avgMonthRevenue = ytdRevenue / reportedMonths;
  const avgMonthEBITDA = ytdEBITDA / reportedMonths;
  
  let projectedRevenue = 0;
  let projectedEBITDA = 0;
  let confidenceLevel: 'low' | 'medium' | 'high' = 'low';
  let method: 'simple-runrate' | 'trend-adjusted' | 'advanced-seasonal' = 'simple-runrate';
  
  // Check if we have prior year data
  const priorYearReports = reports.filter(r => r.period_year === year - 1 && Number(r.revenue_dkk) > 0);
  const hasPriorYearData = priorYearReports.length >= 12;
  
  // LEVEL 1: 1-3 months - Simple run-rate
  if (reportedMonths <= 3) {
    projectedRevenue = avgMonthRevenue * 12;
    projectedEBITDA = avgMonthEBITDA * 12;
    confidenceLevel = 'low';
    method = 'simple-runrate';
  }
  // LEVEL 2: 4-6 months - Trend-adjusted
  else if (reportedMonths <= 6) {
    // Calculate trend
    const revenueDataPoints = ytdReports.map((r, idx) => ({
      month: idx + 1,
      value: Number(r.revenue_dkk)
    }));
    const ebitdaDataPoints = ytdReports.map((r, idx) => ({
      month: idx + 1,
      value: Number(r.ebitda_dkk)
    }));
    
    const revenueTrend = calculateLinearTrend(revenueDataPoints);
    const ebitdaTrend = calculateLinearTrend(ebitdaDataPoints);
    
    // Project using trend for remaining months
    let projectedRevenueSum = ytdRevenue;
    let projectedEBITDASum = ytdEBITDA;
    
    for (let month = reportedMonths + 1; month <= 12; month++) {
      projectedRevenueSum += revenueTrend.slope * month + revenueTrend.intercept;
      projectedEBITDASum += ebitdaTrend.slope * month + ebitdaTrend.intercept;
    }
    
    projectedRevenue = projectedRevenueSum;
    projectedEBITDA = projectedEBITDASum;
    confidenceLevel = 'medium';
    method = 'trend-adjusted';
  }
  // LEVEL 3 & 4: 7+ months - Advanced with trend and optional seasonal
  else {
    // Calculate trend
    const revenueDataPoints = ytdReports.map((r, idx) => ({
      month: idx + 1,
      value: Number(r.revenue_dkk)
    }));
    const ebitdaDataPoints = ytdReports.map((r, idx) => ({
      month: idx + 1,
      value: Number(r.ebitda_dkk)
    }));
    
    const revenueTrend = calculateLinearTrend(revenueDataPoints);
    const ebitdaTrend = calculateLinearTrend(ebitdaDataPoints);
    
    let projectedRevenueSum = ytdRevenue;
    let projectedEBITDASum = ytdEBITDA;
    
    if (hasPriorYearData) {
      // Advanced: Use seasonal factors from prior year
      const seasonalFactors = calculateSeasonalFactors(reports, year);
      const priorYearTotal = priorYearReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
      const currentYearTotal = ytdRevenue;
      const yoyGrowthRate = priorYearTotal > 0 ? currentYearTotal / (priorYearTotal * reportedMonths / 12) : 1;
      
      // For remaining months, use prior year pattern adjusted by current growth trend
      for (let month = reportedMonths + 1; month <= 12; month++) {
        const baseRevenue = revenueTrend.slope * month + revenueTrend.intercept;
        const seasonalAdjustment = seasonalFactors[month - 1];
        projectedRevenueSum += baseRevenue * seasonalAdjustment * yoyGrowthRate;
        
        const baseEBITDA = ebitdaTrend.slope * month + ebitdaTrend.intercept;
        projectedEBITDASum += baseEBITDA * seasonalAdjustment * yoyGrowthRate;
      }
      
      projectedRevenue = projectedRevenueSum;
      projectedEBITDA = projectedEBITDASum;
      confidenceLevel = 'high';
      method = 'advanced-seasonal';
    } else {
      // Just use trend without seasonal adjustment
      for (let month = reportedMonths + 1; month <= 12; month++) {
        projectedRevenueSum += revenueTrend.slope * month + revenueTrend.intercept;
        projectedEBITDASum += ebitdaTrend.slope * month + ebitdaTrend.intercept;
      }
      
      projectedRevenue = projectedRevenueSum;
      projectedEBITDA = projectedEBITDASum;
      confidenceLevel = reportedMonths >= 9 ? 'high' : 'medium';
      method = 'trend-adjusted';
    }
  }
  
  // Calculate best/worst case scenarios (±15% for low confidence, ±10% for medium, ±5% for high)
  const variancePercent = confidenceLevel === 'low' ? 0.15 : confidenceLevel === 'medium' ? 0.10 : 0.05;
  const bestCaseRevenue = projectedRevenue * (1 + variancePercent);
  const worstCaseRevenue = projectedRevenue * (1 - variancePercent);
  const bestCaseEBITDA = projectedEBITDA * (1 + variancePercent);
  const worstCaseEBITDA = projectedEBITDA * (1 - variancePercent);
  
  // Get full year budget
  const yearReportsWithBudget = reports.filter(
    r => r.period_year === year && (r.budget_revenue_dkk || 0) > 0
  );
  
  let fullYearBudgetRevenue = 0;
  let fullYearBudgetEBITDA = 0;
  
  if (yearReportsWithBudget.length >= 12) {
    fullYearBudgetRevenue = yearReportsWithBudget.reduce((sum, r) => sum + Number(r.budget_revenue_dkk || 0), 0);
    fullYearBudgetEBITDA = yearReportsWithBudget.reduce((sum, r) => sum + Number(r.budget_ebitda_dkk || 0), 0);
  } else if (yearReportsWithBudget.length > 0) {
    const avgBudgetRevenue = yearReportsWithBudget.reduce((sum, r) => sum + Number(r.budget_revenue_dkk || 0), 0) / yearReportsWithBudget.length;
    const avgBudgetEBITDA = yearReportsWithBudget.reduce((sum, r) => sum + Number(r.budget_ebitda_dkk || 0), 0) / yearReportsWithBudget.length;
    fullYearBudgetRevenue = avgBudgetRevenue * 12;
    fullYearBudgetEBITDA = avgBudgetEBITDA * 12;
  }
  
  const projectedVsBudgetRevenuePct = fullYearBudgetRevenue > 0
    ? ((projectedRevenue / fullYearBudgetRevenue - 1) * 100)
    : 0;
  
  const projectedVsBudgetEBITDAPct = fullYearBudgetEBITDA > 0
    ? ((projectedEBITDA / fullYearBudgetEBITDA - 1) * 100)
    : 0;
  
  return {
    reportedMonths,
    avgMonthRevenue,
    avgMonthEBITDA,
    projectedRevenue,
    projectedEBITDA,
    projectedVsBudgetRevenuePct,
    projectedVsBudgetEBITDAPct,
    fullYearBudgetRevenue,
    fullYearBudgetEBITDA,
    confidenceLevel,
    method,
    bestCaseRevenue,
    worstCaseRevenue,
    bestCaseEBITDA,
    worstCaseEBITDA,
  };
};

// Financial Analysis calculations
export const calculateFinancialAnalysis = (
  reports: MonthlyReport[], 
  year: number, 
  investedAmount?: number
) => {
  const forecast = calculateForecast(reports, year);
  const ytdPerf = calculateYTDPerformance(reports, year);
  
  const investmentMultipleRevenue = investedAmount && investedAmount > 0
    ? forecast.projectedRevenue / investedAmount
    : 0;
  
  const marketingEfficiency = ytdPerf.ytdMarketingCost > 0
    ? ytdPerf.ytdRevenue / ytdPerf.ytdMarketingCost
    : 0;
  
  return {
    investmentMultipleRevenue,
    avgMonthRevenue: forecast.avgMonthRevenue,
    marketingEfficiency,
    profitabilityPct: ytdPerf.ebitdaMarginYTD,
  };
};

// Last 12 months calculations
export const calculateLast12Months = (reports: MonthlyReport[]) => {
  // Filter to only include reports with actual data (revenue > 0), not budget-only records
  const actualReports = reports.filter(r => Number(r.revenue_dkk) > 0);
  
  // Sort by date descending and take last 12
  const sortedReports = [...actualReports].sort((a, b) => {
    if (b.period_year !== a.period_year) return b.period_year - a.period_year;
    return b.period_month - a.period_month;
  });
  
  const last12Reports = sortedReports.slice(0, 12);
  
  if (last12Reports.length === 0) {
    return {
      totalRevenue: 0,
      totalEBITDA: 0,
      totalMarketingCost: 0,
      budgetRevenue: 0,
      budgetEBITDA: 0,
      revenueVsBudgetPct: 0,
      ebitdaVsBudgetPct: 0,
      ebitdaMargin: 0,
      marketingPct: 0,
      revenueROI: 0,
      ebitdaROI: 0,
      avgMonthRevenue: 0,
      avgMonthEBITDA: 0,
      reportedMonths: 0,
    };
  }
  
  const totalRevenue = last12Reports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
  const totalEBITDA = last12Reports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
  const totalMarketingCost = last12Reports.reduce((sum, r) => sum + Number(r.marketing_cost_dkk || 0), 0);
  const budgetRevenue = last12Reports.reduce((sum, r) => sum + Number(r.budget_revenue_dkk || 0), 0);
  const budgetEBITDA = last12Reports.reduce((sum, r) => sum + Number(r.budget_ebitda_dkk || 0), 0);
  
  const revenueVsBudgetPct = budgetRevenue > 0 ? ((totalRevenue / budgetRevenue - 1) * 100) : 0;
  const ebitdaVsBudgetPct = budgetEBITDA > 0 ? ((totalEBITDA / budgetEBITDA - 1) * 100) : 0;
  const ebitdaMargin = totalRevenue > 0 ? (totalEBITDA / totalRevenue) * 100 : 0;
  const marketingPct = totalRevenue > 0 ? (totalMarketingCost / totalRevenue) * 100 : 0;
  const revenueROI = totalMarketingCost > 0 ? (totalRevenue / totalMarketingCost) * 100 : 0;
  const ebitdaROI = totalMarketingCost > 0 ? (totalEBITDA / totalMarketingCost) * 100 : 0;
  
  return {
    totalRevenue,
    totalEBITDA,
    totalMarketingCost,
    budgetRevenue,
    budgetEBITDA,
    revenueVsBudgetPct,
    ebitdaVsBudgetPct,
    ebitdaMargin,
    marketingPct,
    revenueROI,
    ebitdaROI,
    avgMonthRevenue: totalRevenue / last12Reports.length,
    avgMonthEBITDA: totalEBITDA / last12Reports.length,
    reportedMonths: last12Reports.length,
  };
};

// Monthly Forecast calculations for chart visualization
export const calculateMonthlyForecast = (reports: MonthlyReport[], year: number) => {
  // Filter to only include months with actual revenue data
  const ytdReports = reports
    .filter(r => r.period_year === year && Number(r.revenue_dkk) > 0)
    .sort((a, b) => a.period_month - b.period_month);
  
  const reportedMonths = ytdReports.length;
  
  if (reportedMonths === 0 || reportedMonths >= 12) {
    return []; // No forecast needed
  }
  
  // Calculate trends
  const revenueDataPoints = ytdReports.map((r, idx) => ({
    month: idx + 1,
    value: Number(r.revenue_dkk)
  }));
  const ebitdaDataPoints = ytdReports.map((r, idx) => ({
    month: idx + 1,
    value: Number(r.ebitda_dkk)
  }));
  
  const revenueTrend = calculateLinearTrend(revenueDataPoints);
  const ebitdaTrend = calculateLinearTrend(ebitdaDataPoints);
  
  // Check for seasonal factors
  const priorYearReports = reports.filter(r => r.period_year === year - 1 && Number(r.revenue_dkk) > 0);
  const hasPriorYearData = priorYearReports.length >= 12;
  
  let seasonalFactors = Array(12).fill(1);
  let yoyGrowthRate = 1;
  
  if (hasPriorYearData && reportedMonths >= 7) {
    seasonalFactors = calculateSeasonalFactors(reports, year);
    const priorYearTotal = priorYearReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
    const currentYearTotal = ytdReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
    yoyGrowthRate = priorYearTotal > 0 ? currentYearTotal / (priorYearTotal * reportedMonths / 12) : 1;
  }
  
  // Generate forecast for each remaining month
  const forecastMonths = [];
  for (let month = reportedMonths + 1; month <= 12; month++) {
    let forecastRevenue = revenueTrend.slope * month + revenueTrend.intercept;
    let forecastEBITDA = ebitdaTrend.slope * month + ebitdaTrend.intercept;
    
    // Apply seasonal adjustment if available
    if (hasPriorYearData && reportedMonths >= 7) {
      forecastRevenue *= seasonalFactors[month - 1] * yoyGrowthRate;
      forecastEBITDA *= seasonalFactors[month - 1] * yoyGrowthRate;
    }
    
    // Ensure forecast is not negative
    forecastRevenue = Math.max(0, forecastRevenue);
    // EBITDA can be negative, so don't enforce minimum
    
    forecastMonths.push({
      period_month: month,
      period_year: year,
      revenue_dkk: forecastRevenue,
      ebitda_dkk: forecastEBITDA,
      isForecast: true,
    });
  }
  
  return forecastMonths;
};

// Custom period calculations
export const calculateCustomPeriod = (reports: MonthlyReport[], startDate: Date, endDate: Date) => {
  // Filter to only include reports with actual data (revenue > 0), not budget-only records
  const filteredReports = reports.filter(r => {
    const reportDate = new Date(r.period_year, r.period_month - 1);
    return reportDate >= startDate && reportDate <= endDate && Number(r.revenue_dkk) > 0;
  });
  
  if (filteredReports.length === 0) {
    return {
      totalRevenue: 0,
      totalEBITDA: 0,
      totalMarketingCost: 0,
      budgetRevenue: 0,
      budgetEBITDA: 0,
      revenueVsBudgetPct: 0,
      ebitdaVsBudgetPct: 0,
      ebitdaMargin: 0,
      marketingPct: 0,
      revenueROI: 0,
      ebitdaROI: 0,
      avgMonthRevenue: 0,
      avgMonthEBITDA: 0,
      reportedMonths: 0,
    };
  }
  
  const totalRevenue = filteredReports.reduce((sum, r) => sum + Number(r.revenue_dkk), 0);
  const totalEBITDA = filteredReports.reduce((sum, r) => sum + Number(r.ebitda_dkk), 0);
  const totalMarketingCost = filteredReports.reduce((sum, r) => sum + Number(r.marketing_cost_dkk || 0), 0);
  const budgetRevenue = filteredReports.reduce((sum, r) => sum + Number(r.budget_revenue_dkk || 0), 0);
  const budgetEBITDA = filteredReports.reduce((sum, r) => sum + Number(r.budget_ebitda_dkk || 0), 0);
  
  const revenueVsBudgetPct = budgetRevenue > 0 ? ((totalRevenue / budgetRevenue - 1) * 100) : 0;
  const ebitdaVsBudgetPct = budgetEBITDA > 0 ? ((totalEBITDA / budgetEBITDA - 1) * 100) : 0;
  const ebitdaMargin = totalRevenue > 0 ? (totalEBITDA / totalRevenue) * 100 : 0;
  const marketingPct = totalRevenue > 0 ? (totalMarketingCost / totalRevenue) * 100 : 0;
  const revenueROI = totalMarketingCost > 0 ? (totalRevenue / totalMarketingCost) * 100 : 0;
  const ebitdaROI = totalMarketingCost > 0 ? (totalEBITDA / totalMarketingCost) * 100 : 0;
  
  return {
    totalRevenue,
    totalEBITDA,
    totalMarketingCost,
    budgetRevenue,
    budgetEBITDA,
    revenueVsBudgetPct,
    ebitdaVsBudgetPct,
    ebitdaMargin,
    marketingPct,
    revenueROI,
    ebitdaROI,
    avgMonthRevenue: totalRevenue / filteredReports.length,
    avgMonthEBITDA: totalEBITDA / filteredReports.length,
    reportedMonths: filteredReports.length,
  };
};