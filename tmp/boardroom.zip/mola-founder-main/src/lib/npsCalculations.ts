export const getNextQuarterStart = () => {
  const now = new Date();
  const currentQuarter = Math.floor(now.getMonth() / 3) + 1;
  const currentYear = now.getFullYear();

  let nextQuarter = currentQuarter + 1;
  let nextYear = currentYear;

  if (nextQuarter > 4) {
    nextQuarter = 1;
    nextYear += 1;
  }

  const quarterStartMonth = (nextQuarter - 1) * 3;
  return new Date(nextYear, quarterStartMonth, 1);
};

export const getCurrentQuarter = () => {
  const now = new Date();
  return {
    quarter: Math.floor(now.getMonth() / 3) + 1,
    year: now.getFullYear(),
  };
};

export const formatQuarter = (quarter: number, year: number) => {
  return `Q${quarter} ${year}`;
};