export interface TrustpilotCountry {
  code: string;
  name: string;
  domain: string;
  flag: string;
}

export const TRUSTPILOT_COUNTRIES: TrustpilotCountry[] = [
  { code: 'DK', name: 'Danmark', domain: 'dk.trustpilot.com', flag: '🇩🇰' },
  { code: 'DE', name: 'Tyskland', domain: 'de.trustpilot.com', flag: '🇩🇪' },
  { code: 'UK', name: 'Storbritannien', domain: 'uk.trustpilot.com', flag: '🇬🇧' },
  { code: 'US', name: 'USA', domain: 'www.trustpilot.com', flag: '🇺🇸' },
  { code: 'SE', name: 'Sverige', domain: 'se.trustpilot.com', flag: '🇸🇪' },
  { code: 'NO', name: 'Norge', domain: 'no.trustpilot.com', flag: '🇳🇴' },
  { code: 'FI', name: 'Finland', domain: 'fi.trustpilot.com', flag: '🇫🇮' },
  { code: 'NL', name: 'Holland', domain: 'nl.trustpilot.com', flag: '🇳🇱' },
  { code: 'FR', name: 'Frankrig', domain: 'fr.trustpilot.com', flag: '🇫🇷' },
  { code: 'ES', name: 'Spanien', domain: 'es.trustpilot.com', flag: '🇪🇸' },
  { code: 'IT', name: 'Italien', domain: 'it.trustpilot.com', flag: '🇮🇹' },
  { code: 'AT', name: 'Østrig', domain: 'at.trustpilot.com', flag: '🇦🇹' },
  { code: 'CH', name: 'Schweiz', domain: 'ch.trustpilot.com', flag: '🇨🇭' },
  { code: 'BE', name: 'Belgien', domain: 'be.trustpilot.com', flag: '🇧🇪' },
  { code: 'PL', name: 'Polen', domain: 'pl.trustpilot.com', flag: '🇵🇱' },
];

export function getCountryByCode(code: string): TrustpilotCountry | undefined {
  return TRUSTPILOT_COUNTRIES.find(c => c.code === code);
}

export function getCountryFlag(code: string): string {
  return getCountryByCode(code)?.flag || '🌍';
}
