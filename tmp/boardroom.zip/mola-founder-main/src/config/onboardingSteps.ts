export interface OnboardingStep {
  id: string;
  version: number;
  title: string;
  content: string | string[];
  footer?: string;
  cta: string;
  ctaVariant?: 'default' | 'primary';
}

export interface OnboardingRoleConfig {
  currentVersion: number;
  steps: OnboardingStep[];
}

export type UserRole = 'founder' | 'mola_admin' | 'fund_partner' | 'owner' | 'dd_partner' | 'external_viewer' | 'investor';

export const ONBOARDING_CONFIG: Partial<Record<UserRole, OnboardingRoleConfig>> = {
  founder: {
    currentVersion: 1,
    steps: [
      {
        id: 'welcome',
        version: 1,
        title: 'Velkommen til Mola Founder Platform',
        content: 'Dit samarbejdsrum med Mola Invest – hvor rapportering, sparring og værdifulde værktøjer mødes ét sted.',
        cta: 'Næste',
      },
      {
        id: 'features',
        version: 1,
        title: 'Alt hvad du har brug for',
        content: [
          'Månedlig rapportering og benchmark mod andre selskaber',
          'E-commerce værktøjer (ROAS, CLV m.m.)',
          'CRM til sparringsmøder med Mola',
          'Opgavestyring der følger op på beslutninger',
          'Trusted partners med eksklusive rabataftaler',
        ],
        cta: 'Næste',
      },
      {
        id: 'network',
        version: 1,
        title: 'Mød andre founders',
        content: 'Du er ikke alene. I platformen kan du møde andre founders til sparring, erfaringsudveksling og netværk.',
        cta: 'Næste',
      },
      {
        id: 'get_started',
        version: 1,
        title: 'Hvor du starter',
        content: [
          'Indsend din første månedlige rapport',
          'Udforsk e-commerce værktøjerne',
          'Se trusted partners og deres tilbud',
        ],
        footer: 'Mola-teamet står klar til at hjælpe dig i gang.',
        cta: 'Kom i gang',
        ctaVariant: 'primary',
      },
    ],
  },
};

// Helper to get steps for a specific role
export function getOnboardingStepsForRole(role: UserRole): OnboardingRoleConfig | null {
  return ONBOARDING_CONFIG[role] || null;
}

// Helper to get only new steps (for "What's New" flow)
export function getNewStepsForRole(role: UserRole, lastSeenVersion: number): OnboardingStep[] {
  const config = ONBOARDING_CONFIG[role];
  if (!config) return [];
  
  return config.steps.filter(step => step.version > lastSeenVersion);
}

// Helper to check if user needs onboarding
export function needsOnboarding(role: UserRole, versionSeen: number): boolean {
  const config = ONBOARDING_CONFIG[role];
  if (!config) return false;
  
  return versionSeen < config.currentVersion;
}

// Helper to check if it's first time (full onboarding) or just "What's New"
export function isFirstTimeOnboarding(versionSeen: number): boolean {
  return versionSeen === 0;
}
